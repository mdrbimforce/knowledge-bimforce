# Revit Agent-addin 0.1.0

Een kleine addin voor Autodesk Revit. Hij laat een AI-assistent (Claude) met je open Revit werken, via de skill
`revit-agent`. De addin luistert alleen op je eigen computer (127.0.0.1) en vraagt bij elk verzoek een geheim token
dat hij bij elke start van Revit opnieuw maakt.

## Installeren

Normaal doet Claude dit voor je met de skill. Zelf doen:

1. Pak deze zip uit, bijvoorbeeld naar `%USERPROFILE%\RevitAgent`.
2. Sluit Revit (bewaar eerst je werk).
3. Open PowerShell in die map en draai:
   `powershell -ExecutionPolicy Bypass -File .\install.ps1 -RevitYear 2026` (of 2025).
4. Start Revit. De addin is getekend door bimforce. Revit kent die uitgever op jouw computer nog niet en vraagt
   daarom één keer of de addin geladen mag worden. Kies **Always Load**.

Verwijderen: `install.ps1 -RevitYear 2026 -Uninstall`.

## Getekend door bimforce

De DLL's in deze zip zijn getekend met het certificaat `CN=BIMforce Revit Agent, O=BIMforce`
(vingerafdruk `4E0BED71F8741299A18803760E080C6B1867E02B`). Dat is een eigen certificaat van bimforce, niet een van een
certificaatinstantie. Windows en Revit kennen het daarom niet uit zichzelf. Je hebt twee keuzes:

- **Niets doen.** Revit vraagt bij de eerste start één keer of de addin geladen mag worden; kies Always Load.
- **De uitgever vooraf vertrouwen:** `install.ps1 -RevitYear 2026 -TrustPublisher`. Het script controleert dat de DLL
  met het meegeleverde certificaat (`cert/revit-agent-uitgever.cer`) getekend is en voegt dat certificaat toe aan je
  eigen vertrouwde basiscertificaten en vertrouwde uitgevers, alleen voor jouw Windows-account. Windows vraagt zelf om
  bevestiging. Daarna geldt alles wat met dit certificaat getekend is op jouw account als vertrouwd; doe dit dus
  alleen als je bimforce vertrouwt. Terugdraaien: `install.ps1 -RevitYear 2026 -Uninstall -TrustPublisher`.

De handtekening laat ook zien of de DLL na het tekenen veranderd is: rechtsklik op de DLL, Eigenschappen,
Digitale handtekeningen.


## Wat er in deze zip staat

| Map of bestand | Wat |
|---|---|
| `2025/, 2026/` | De addin per Revit-jaar: `RevitAgent.addin` en de map `RevitAgent` met de DLL. |
| `install.ps1` | Installeren en verwijderen voor de huidige gebruiker. |
| `bron/` | De broncode, om zelf te bouwen of een eigen opdracht toe te voegen (`bron/build.ps1 -RevitYear 2026`, .NET 8 SDK). |

Revit 2027 draait op .NET 10; bouw die zelf met `bron/build.ps1 -RevitYear 2027` en de .NET 10 SDK.

## Zelf bouwen en tekenen

Een eigen build uit `bron/` is niet getekend; Revit vraagt dan bij de eerste start of hij geladen mag worden.
Wie dat wil voorkomen, tekent de DLL met een eigen code-signing-certificaat in `Cert:\CurrentUser\My`:
`bron/build.ps1 -RevitYear 2026 -Sign -CertSubject "CN=..." -ExportCertificate`.

## Wat de addin wel en niet zelf wegklikt

- Binnen een opdracht die families laadt of bewerkt, links laadt of een model opent: meldingen met tekst met OK,
  en "Unresolved References" met "Ignore and continue opening". Alles staat in het antwoord aan Claude.
- Altijd: een paar bekende service-meldingen van Autodesk.
- Nooit: bewaar-vragen. De addin bewaart ook nooit uit zichzelf.

Gemaakt door bimforce (bimforce.com)
