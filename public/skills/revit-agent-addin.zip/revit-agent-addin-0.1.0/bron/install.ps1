<#
.SYNOPSIS
  Installeert (of verwijdert) de Revit Agent-addin voor één Revit-jaar, voor de huidige gebruiker.

.DESCRIPTION
  Kopieert RevitAgent.addin en de map RevitAgent\ naar %APPDATA%\Autodesk\Revit\Addins\<jaar>.
  De bestanden komen uit dist\<jaar>\ naast dit script (na build.ps1), of uit <jaar>\ naast dit script
  (in het downloadpakket).
  Draait Revit, dan stopt het script: sluit Revit eerst zelf (bewaar je werk), en start het daarna opnieuw.
  Bij de eerste start vraagt Revit of de addin geladen mag worden: kies "Always Load".
  Is de addin getekend en zit het certificaat van de uitgever erbij (cert\revit-agent-uitgever.cer), dan
  kun je met -TrustPublisher die uitgever vooraf vertrouwen; Revit laadt de addin dan zonder vraag.

.PARAMETER RevitYear
  2025, 2026 of 2027.
.PARAMETER Uninstall
  Haalt de addin weer weg. Met -TrustPublisher erbij ook het certificaat van de uitgever.
.PARAMETER TrustPublisher
  Voegt het certificaat van de uitgever toe aan je eigen vertrouwde basiscertificaten en vertrouwde
  uitgevers (alleen voor jouw Windows-account). Windows vraagt zelf om bevestiging. Doe dit alleen als
  je de uitgever vertrouwt: software die met dit certificaat getekend is, geldt daarna op jouw account
  als vertrouwd.

.EXAMPLE
  .\install.ps1 -RevitYear 2026
  .\install.ps1 -RevitYear 2026 -TrustPublisher
  .\install.ps1 -RevitYear 2026 -Uninstall
#>
param(
    [Parameter(Mandatory = $true)][ValidateSet("2025", "2026", "2027")][string]$RevitYear,
    [switch]$Uninstall,
    [switch]$TrustPublisher
)
$ErrorActionPreference = "Stop"
$Hier = $PSScriptRoot
$Doel = Join-Path $env:APPDATA "Autodesk\Revit\Addins\$RevitYear"

$revit = Get-Process -Name "Revit" -ErrorAction SilentlyContinue
if ($revit) {
    Write-Host "Revit draait nog. Sluit Revit eerst zelf (bewaar je werk) en draai dit script daarna opnieuw." -ForegroundColor Red
    exit 2
}

$CertPad = $null
foreach ($kandidaat in @((Join-Path $Hier "dist\cert\revit-agent-uitgever.cer"), (Join-Path $Hier "cert\revit-agent-uitgever.cer"))) {
    if (Test-Path $kandidaat) { $CertPad = $kandidaat; break }
}
if ($TrustPublisher -and -not $CertPad) {
    Write-Host "Geen certificaat van de uitgever gevonden naast dit script (cert\revit-agent-uitgever.cer); -TrustPublisher kan niet." -ForegroundColor Red
    exit 1
}

if ($Uninstall) {
    $weg = @((Join-Path $Doel "RevitAgent.addin"), (Join-Path $Doel "RevitAgent"))
    foreach ($w in $weg) { if (Test-Path $w) { Remove-Item $w -Recurse -Force; Write-Host "Verwijderd: $w" } }
    if ($TrustPublisher) {
        $duim = (New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $CertPad).Thumbprint
        foreach ($opslag in @("Root", "TrustedPublisher")) {
            $c = Join-Path "Cert:\CurrentUser\$opslag" $duim
            if (Test-Path $c) { Remove-Item $c -Force; Write-Host "Certificaat van de uitgever verwijderd uit $opslag." }
        }
    }
    Write-Host "Revit Agent is verwijderd voor Revit $RevitYear." -ForegroundColor Green
    exit 0
}

$Bron = $null
foreach ($kandidaat in @((Join-Path $Hier "dist\$RevitYear"), (Join-Path $Hier $RevitYear))) {
    if (Test-Path (Join-Path $kandidaat "RevitAgent.addin")) { $Bron = $kandidaat; break }
}
if (-not $Bron) {
    Write-Host "Geen build voor Revit $RevitYear gevonden naast dit script (dist\$RevitYear of $RevitYear). Bouw eerst met build.ps1." -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory -Path (Join-Path $Doel "RevitAgent") -Force | Out-Null
Copy-Item (Join-Path $Bron "RevitAgent.addin") (Join-Path $Doel "RevitAgent.addin") -Force
Copy-Item (Join-Path $Bron "RevitAgent\*") (Join-Path $Doel "RevitAgent\") -Recurse -Force
# Bestanden uit een download kunnen "geblokkeerd" zijn; Revit laadt die niet.
Get-ChildItem (Join-Path $Doel "RevitAgent") -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
Unblock-File (Join-Path $Doel "RevitAgent.addin") -ErrorAction SilentlyContinue

Write-Host "Revit Agent staat klaar voor Revit $RevitYear in $Doel" -ForegroundColor Green

$handtekening = Get-AuthenticodeSignature (Join-Path $Doel "RevitAgent\RevitAgent.Addin.dll")
if ($TrustPublisher) {
    $uitgever = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $CertPad
    if (-not $handtekening.SignerCertificate -or $handtekening.SignerCertificate.Thumbprint -ne $uitgever.Thumbprint) {
        Write-Host "De DLL is niet getekend met het meegeleverde certificaat; de uitgever wordt niet toegevoegd." -ForegroundColor Red
        exit 1
    }
    Write-Host "Uitgever vertrouwen: $($uitgever.Subject) (vingerafdruk $($uitgever.Thumbprint))." -ForegroundColor Yellow
    Write-Host "Windows vraagt nu om bevestiging voor het toevoegen aan je vertrouwde basiscertificaten." -ForegroundColor Yellow
    & certutil.exe -user -addstore Root $CertPad | Out-Null
    if ($LASTEXITCODE -ne 0) { Write-Host "Niet toegevoegd (geweigerd of mislukt). De addin is wel geinstalleerd; Revit vraagt bij de start of hij geladen mag worden." -ForegroundColor Yellow; exit 0 }
    & certutil.exe -user -addstore TrustedPublisher $CertPad | Out-Null
    $handtekening = Get-AuthenticodeSignature (Join-Path $Doel "RevitAgent\RevitAgent.Addin.dll")
}

if ($handtekening.Status -eq "Valid") {
    Write-Host "De addin is getekend door een uitgever die je vertrouwt ($($handtekening.SignerCertificate.Subject)). Start Revit; de addin laadt zonder vraag." -ForegroundColor Green
}
elseif ($handtekening.SignerCertificate) {
    Write-Host "De addin is getekend door $($handtekening.SignerCertificate.Subject), een uitgever die deze computer nog niet kent." -ForegroundColor Yellow
    Write-Host "Start Revit. Revit vraagt of de addin geladen mag worden: kies 'Always Load'. (Of draai dit script opnieuw met -TrustPublisher.)" -ForegroundColor Yellow
}
else {
    Write-Host "Start Revit. Revit vraagt of de addin geladen mag worden (hij is niet getekend): kies 'Always Load'." -ForegroundColor Yellow
}
