using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// swap_family_parameter — replace a FAMILY parameter by a canonical NLRS shared parameter inside
/// loadable families, value/formula/label-preserving.
///
/// Core primitive: FamilyManager.ReplaceParameter(currentParam, externalDefinition, group, isInstance).
/// Per the API it "updates the formulas and labels which reference this parameter" — so formula
/// references AND dimension labels (geometry coupling) move to the new parameter automatically.
/// Invalid for built-in params. The dry-run reports, per family: param found, instance/type, formula,
/// whether other formulas reference it, and whether a dimension label uses it (geometry coupling).
///
/// Workflow per family: projectDoc.EditFamily -> famDoc; ReplaceParameter in a famDoc transaction;
/// LoadFamily back (overwrite); close. SharedParametersFilename is repointed to the NLRS .txt for the
/// ExternalDefinition and restored afterwards.
///
/// params:
///   source_guid | source_name : the family parameter to replace (GUID for shared, else by name)
///   target_guid               : canonical NLRS shared parameter (GUID)
///   shared_param_file         : NLRS .txt (required — source of the target ExternalDefinition)
///   families                  : [string] family names to process (else needs scan_all)
///   scan_all                  : bool — process ALL editable loadable families (expensive: opens each)
///   target_document           : scope by doc Title
///   dry_run                   : bool (default TRUE)
/// </summary>
public static class SwapFamilyHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }

    public static CommandResponse SwapFamilyParameter(CommandRequest request)
    {
        var p = request.Params;
        string? sourceGuid = GetString(p, "source_guid");
        string? sourceName = GetString(p, "source_name");
        string? targetGuid = GetString(p, "target_guid");
        string? sharedParamFile = GetString(p, "shared_param_file");
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool scanAll = GetBool(p, "scan_all", false);
        var famWhitelist = GetStringList(p, "families");

        if (string.IsNullOrWhiteSpace(targetGuid))
            return Err("target_guid is required");
        if (string.IsNullOrWhiteSpace(sourceGuid) && string.IsNullOrWhiteSpace(sourceName))
            return Err("provide source_guid (shared) or source_name");
        if (string.IsNullOrWhiteSpace(sharedParamFile))
            return Err("shared_param_file is required (the NLRS .txt holding the target ExternalDefinition)");
        if ((famWhitelist == null || famWhitelist.Count == 0) && !scanAll)
            return Err("provide 'families' (names) or set scan_all=true (opens every editable family — slow)");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");
                if (!System.IO.File.Exists(sharedParamFile)) return (object)Fail($"shared_param_file not found: {sharedParamFile}");

                string? prevSpf = app.Application.SharedParametersFilename;
                try
                {
                    app.Application.SharedParametersFilename = sharedParamFile;
                    var extDef = FindExternalDefinition(app.Application, targetGuid!);
                    if (extDef == null) return (object)Fail($"target GUID {targetGuid} not in shared_param_file");

                    // save-first backup gate (mirrors the other mutating handlers): one numbered backup
                    // of the pre-swap project before any LoadFamily overwrite, so it's recoverable.
                    bool savedBackup = false;
                    if (!dryRun && GetBool(p, "save_first", false))
                    {
                        try { doc.Save(); savedBackup = true; }
                        catch (Exception ex) { return (object)Fail($"save-first backup failed, family swap aborted: {ex.Message}"); }
                    }

                    // candidate families
                    var fams = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                        .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable);
                    if (famWhitelist != null && famWhitelist.Count > 0)
                    {
                        var want = famWhitelist.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                        fams = fams.Where(f => want.Contains(f.Name.ToLowerInvariant()));
                    }

                    var perFamily = new List<Dictionary<string, object?>>();
                    int processed = 0, replaced = 0, notfound = 0, failed = 0;

                    foreach (var fam in fams.ToList())
                    {
                        processed++;
                        Document? fdoc = null;
                        try
                        {
                            fdoc = doc.EditFamily(fam);
                            var fm = fdoc.FamilyManager;
                            FamilyParameter? src = FindFamilyParam(fm, sourceGuid, sourceName);
                            if (src == null) { notfound++; fdoc.Close(false); continue; }

                            var info = InspectParam(fdoc, fm, src);
                            info["family"] = fam.Name;

                            if (dryRun)
                            {
                                info["action"] = "would_replace";
                                perFamily.Add(info);
                                fdoc.Close(false);
                                continue;
                            }

                            // EXECUTE: ReplaceParameter in a family-doc transaction, then load back.
                            bool ok;
                            using (var t = new Transaction(fdoc, "NLRS family swap"))
                            {
                                t.Start();
                                bool isInstance = src.IsInstance;
                                var grp = src.Definition.GetGroupTypeId();
                                try
                                {
                                    fm.ReplaceParameter(src, extDef, grp, isInstance);
                                    ok = true;
                                }
                                catch (Exception ex) { info["error"] = ex.Message; ok = false; }
                                if (ok) t.Commit(); else t.RollBack();
                            }
                            if (ok)
                            {
                                fdoc.LoadFamily(doc, new FamLoadOpts());  // overwrite the edited family back into the project
                                replaced++;
                                info["action"] = "replaced";
                            }
                            else { failed++; info["action"] = "failed"; }
                            perFamily.Add(info);
                            fdoc.Close(false);
                        }
                        catch (Exception ex)
                        {
                            failed++;
                            perFamily.Add(new Dictionary<string, object?> { ["family"] = fam.Name, ["action"] = "error", ["error"] = ex.Message });
                            try { fdoc?.Close(false); } catch { }
                        }
                    }

                    return (object)new Dictionary<string, object?>
                    {
                        ["document"] = doc.Title,
                        ["dry_run"] = dryRun,
                        ["saved_backup"] = savedBackup,
                        ["target"] = new Dictionary<string, object?> { ["guid"] = targetGuid, ["name"] = extDef.Name },
                        ["families_scanned"] = processed,
                        ["families_with_param"] = perFamily.Count(f => (string?)f.GetValueOrDefault("action") != "error"),
                        ["replaced"] = replaced, ["not_found"] = notfound, ["failed"] = failed,
                        ["results"] = perFamily,
                    };
                }
                finally { try { app.Application.SharedParametersFilename = prevSpf; } catch { } }
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── helpers ──────────────────────────────────────────────────────

    private static FamilyParameter? FindFamilyParam(FamilyManager fm, string? guid, string? name)
    {
        var g = guid?.Trim().ToLowerInvariant();
        foreach (FamilyParameter fp in fm.Parameters)
        {
            if (fp?.Definition == null) continue;
            if (g != null)
            {
                try { if (fp.IsShared && fp.GUID.ToString().ToLowerInvariant() == g) return fp; } catch { }
            }
            else if (name != null && fp.Definition.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return fp;
        }
        return null;
    }

    /// <summary>Dry-run inspection: instance/type, formula, formula-references, dimension-label
    /// (geometry coupling) — all carried over by ReplaceParameter, but reported for transparency.</summary>
    private static Dictionary<string, object?> InspectParam(Document fdoc, FamilyManager fm, FamilyParameter src)
    {
        string srcName = src.Definition.Name;
        bool hasFormula = false;
        try { hasFormula = !string.IsNullOrEmpty(src.Formula); } catch { }

        var refFormulas = new List<string>();
        foreach (FamilyParameter fp in fm.Parameters)
        {
            if (fp == src || fp?.Definition == null) continue;
            string? f = null;
            try { f = fp.Formula; } catch { }
            if (!string.IsNullOrEmpty(f) && f!.Contains(srcName))
                refFormulas.Add(fp.Definition.Name);
        }

        bool geomLabel = false;
        try
        {
            foreach (Dimension dim in new FilteredElementCollector(fdoc).OfClass(typeof(Dimension)).Cast<Dimension>())
            {
                FamilyParameter? lbl = null;
                try { lbl = dim.FamilyLabel; } catch { }
                if (lbl?.Definition != null && lbl.Definition.Name == srcName) { geomLabel = true; break; }
            }
        }
        catch { }

        bool isShared = false; string? sg = null;
        try { isShared = src.IsShared; if (isShared) sg = src.GUID.ToString(); } catch { }

        return new Dictionary<string, object?>
        {
            ["param"] = srcName,
            ["is_shared"] = isShared,
            ["source_guid"] = sg,
            ["is_instance"] = src.IsInstance,
            ["has_formula"] = hasFormula,
            ["referenced_by_formulas"] = refFormulas,
            ["geometry_label"] = geomLabel,
        };
    }

    private static ExternalDefinition? FindExternalDefinition(Autodesk.Revit.ApplicationServices.Application app, string guid)
    {
        var g = guid.Trim().ToLowerInvariant();
        DefinitionFile? df;
        try { df = app.OpenSharedParameterFile(); } catch { return null; }
        if (df == null) return null;
        foreach (DefinitionGroup grp in df.Groups)
            foreach (Definition d in grp.Definitions)
                if (d is ExternalDefinition ed)
                {
                    try { if (ed.GUID.ToString().ToLowerInvariant() == g) return ed; } catch { }
                }
        return null;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                     .Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        return null;
    }
}
