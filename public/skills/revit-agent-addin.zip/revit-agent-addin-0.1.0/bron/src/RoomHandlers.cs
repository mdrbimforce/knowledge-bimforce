using System.Globalization;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace RevitAgent.Addin;

/// <summary>
/// create_room — een room plaatsen in een omsloten gebied op een level, in een opgegeven fase (bv. een
/// ontbrekende room in een ruimtemodel).
///
/// params: target_document, level (naam), point_mm [x, y] (intern stelsel, mm), number, name, phase? (naam; standaard
/// de laatste fase), upper_limit? (levelnaam), limit_offset_mm?, base_offset_mm?, parameters? {naam: waarde}
/// (instance-parameters; tekst via Set, getallen en ja/nee via SetValueString in de projecteenheden), dry_run
/// (default TRUE).
///
/// Werkwijze: een ongeplaatste room in de fase (NewRoom(Phase)), dan per vrij gebied (PlanTopology van level en fase)
/// in een SubTransaction plaatsen tot IsPointInRoom het punt bevat. Zo komt de room in de gevraagde fase, wat
/// NewRoom(Level, UV) niet garandeert. Geen omsloten gebied op het punt = fout, met de vrije gebieden in het
/// antwoord. Bestaat er in die fase al een room met dat nummer, dan verandert er niets (idempotent).
/// dry_run: alles in een transactie die aan het eind wordt teruggedraaid; het antwoord is wat er zou ontstaan.
/// Resultaat op read-back: id, nummer, naam, fase, level, oppervlak, omsloten, punt_in_room, parameters.
/// Warnings worden weggedrukt en gemeld; een error rolt terug. Geen modale dialogen.
/// </summary>
public static class RoomHandlers
{
    private const double MM = 304.8;

    public static CommandResponse CreateRoom(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        string? levelName = HandlerUtil.Str(p, "level");
        string? number = HandlerUtil.Str(p, "number");
        string? name = HandlerUtil.Str(p, "name");
        string? phaseName = HandlerUtil.Str(p, "phase");
        string? upperName = HandlerUtil.Str(p, "upper_limit");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null || levelName == null || number == null || name == null)
            return Err("target_document, level, number en name zijn verplicht");
        var pt = HandlerUtil.Arr(p, "point_mm").Select(NumEl).ToList();
        if (pt.Count < 2 || pt[0] == null || pt[1] == null) return Err("point_mm [x, y] is verplicht");
        double? limitOffset = TopNum(p, "limit_offset_mm"), baseOffset = TopNum(p, "base_offset_mm");
        var extra = new List<(string Naam, JsonElement Waarde)>();
        if (p != null && p.TryGetValue("parameters", out var pe) && pe.ValueKind == JsonValueKind.Object)
            foreach (var kv in pe.EnumerateObject()) extra.Add((kv.Name, kv.Value));

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                if (!dryRun && doc.IsReadOnly) return (object)Fail("target_document is alleen-lezen");
                if (doc.IsModifiable) return (object)Fail("er staat al een transactie open in target_document");

                var levels = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().ToList();
                var level = FindLevel(levels, levelName, out var lerr);
                if (level == null) return (object)Fail(lerr!);
                Level? upper = null;
                if (upperName != null)
                {
                    upper = FindLevel(levels, upperName, out var uerr);
                    if (upper == null) return (object)Fail(uerr!);
                }
                var phases = doc.Phases.Cast<Phase>().ToList();
                var phase = phaseName == null ? phases.LastOrDefault()
                    : phases.FirstOrDefault(f => f.Name.Equals(phaseName, StringComparison.OrdinalIgnoreCase));
                if (phase == null)
                    return (object)Fail($"fase '{phaseName}' niet gevonden (wel: {string.Join(", ", phases.Select(f => f.Name))})");

                var bestaand = new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms)
                    .WhereElementIsNotElementType().OfType<Room>()
                    .Where(r => r.Number == number && r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId() == phase.Id)
                    .ToList();
                if (bestaand.Count > 0)
                    return (object)new Dictionary<string, object?>
                    {
                        ["document"] = doc.Title, ["dry_run"] = dryRun, ["status"] = "bestaat_al",
                        ["room"] = Lees(doc, bestaand[0], null, extra),
                        ["notes"] = new List<string> { $"in fase {phase.Name} bestaat al een room met nummer {number}; niets gewijzigd" },
                    };

                var punt = new XYZ(pt[0]!.Value / MM, pt[1]!.Value / MM, level.Elevation + 1.0);
                var meldingen = new List<string>();
                var notes = new List<string>();
                var pp = new StilleFailures(meldingen);
                Dictionary<string, object?>? gelezen = null;
                var vrij = new List<Dictionary<string, object?>>();
                string status;
                using (var t = new Transaction(doc, $"create_room {number}"))
                {
                    var fho = t.GetFailureHandlingOptions();
                    fho.SetFailuresPreprocessor(pp);
                    fho.SetClearAfterRollback(true);
                    fho.SetForcedModalHandling(false);
                    t.SetFailureHandlingOptions(fho);
                    if (t.Start() != TransactionStatus.Started) return (object)Fail("transactie kon niet starten");
                    try
                    {
                        var room = doc.Create.NewRoom(phase);
                        doc.Regenerate();
                        var topo = doc.get_PlanTopology(level, phase);
                        bool geplaatst = false;
                        foreach (PlanCircuit c in topo.Circuits)
                        {
                            if (c.IsRoomLocated) continue;
                            XYZ? binnen = null;
                            try { var q = c.GetPointInside(); binnen = new XYZ(q.U, q.V, 0); } catch { }
                            vrij.Add(new Dictionary<string, object?>
                            {
                                ["oppervlak_m2"] = Math.Round(c.Area * 0.09290304, 2),
                                ["punt_binnen_mm"] = binnen == null ? null : new[] { Math.Round(binnen.X * MM), Math.Round(binnen.Y * MM) },
                            });
                            using var st = new SubTransaction(doc);
                            st.Start();
                            Room? r2 = null;
                            try { r2 = doc.Create.NewRoom(room, c); doc.Regenerate(); } catch { }
                            if (r2 != null && r2.IsPointInRoom(punt)) { st.Commit(); room = r2; geplaatst = true; break; }
                            st.RollBack();
                        }
                        if (!geplaatst)
                        {
                            t.RollBack();
                            return (object)new Dictionary<string, object?>
                            {
                                ["ok"] = false, ["document"] = doc.Title, ["dry_run"] = dryRun,
                                ["error"] = $"geen vrij omsloten gebied op level {level.Name} (fase {phase.Name}) dat punt [{pt[0]}, {pt[1]}] bevat",
                                ["vrije_gebieden"] = vrij,
                                ["notes"] = new List<string> { "een gebied met al een room telt niet als vrij; controleer de room bounding van wanden en links" },
                            };
                        }
                        room.Number = number;
                        room.Name = name;
                        if (upper != null) room.get_Parameter(BuiltInParameter.ROOM_UPPER_LEVEL)?.Set(upper.Id);
                        if (limitOffset != null) room.get_Parameter(BuiltInParameter.ROOM_UPPER_OFFSET)?.Set(limitOffset.Value / MM);
                        if (baseOffset != null) room.get_Parameter(BuiltInParameter.ROOM_LOWER_OFFSET)?.Set(baseOffset.Value / MM);
                        foreach (var (pn, w) in extra)
                        {
                            var par = room.LookupParameter(pn);
                            if (par == null) { notes.Add($"parameter '{pn}' bestaat niet op de room"); continue; }
                            if (par.IsReadOnly) { notes.Add($"parameter '{pn}' is alleen-lezen"); continue; }
                            bool gezet = par.StorageType switch
                            {
                                StorageType.String => par.Set(Raw(w)),
                                _ => par.SetValueString(Raw(w)),
                            };
                            if (!gezet) notes.Add($"parameter '{pn}': Set gaf false voor '{Raw(w)}'");
                        }
                        doc.Regenerate();
                        gelezen = Lees(doc, room, punt, extra);
                        if (dryRun) { t.RollBack(); status = "zou_plaatsen"; }
                        else
                        {
                            var cs = t.Commit();
                            status = cs == TransactionStatus.Committed ? "geplaatst" : $"niet_gecommit ({cs})";
                            if (cs == TransactionStatus.Committed)
                            {
                                var terug = doc.GetElement(new ElementId((long)gelezen["id"]!)) as Room;
                                gelezen = terug == null ? null : Lees(doc, terug, punt, extra);
                                if (terug == null) status = "na commit niet gevonden";
                            }
                        }
                    }
                    finally
                    {
                        try { if (t.HasStarted() && !t.HasEnded()) t.RollBack(); } catch { }
                    }
                }
                if (dryRun) notes.Add("dry_run: teruggedraaid; room is wat er zou ontstaan (id is dan niet blijvend)");
                return (object)new Dictionary<string, object?>
                {
                    ["ok"] = status is "geplaatst" or "zou_plaatsen", ["document"] = doc.Title, ["dry_run"] = dryRun,
                    ["status"] = status, ["room"] = gelezen, ["meldingen"] = meldingen, ["notes"] = notes,
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> Lees(Document doc, Room r, XYZ? punt, List<(string Naam, JsonElement Waarde)> extra)
    {
        var pars = new Dictionary<string, object?>();
        foreach (var (pn, _) in extra)
        {
            var par = r.LookupParameter(pn);
            pars[pn] = par == null ? null : par.StorageType == StorageType.String ? par.AsString() : par.AsValueString();
        }
        double area = 0;
        try { area = r.Area; } catch { }
        return new Dictionary<string, object?>
        {
            ["id"] = r.Id.Value, ["unique_id"] = r.UniqueId, ["number"] = r.Number,
            ["name"] = r.get_Parameter(BuiltInParameter.ROOM_NAME)?.AsString(),
            ["level"] = r.Level?.Name,
            ["phase"] = doc.GetElement(r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId() ?? ElementId.InvalidElementId)?.Name,
            ["upper_limit"] = doc.GetElement(r.get_Parameter(BuiltInParameter.ROOM_UPPER_LEVEL)?.AsElementId() ?? ElementId.InvalidElementId)?.Name,
            ["limit_offset_mm"] = Math.Round((r.get_Parameter(BuiltInParameter.ROOM_UPPER_OFFSET)?.AsDouble() ?? 0) * MM, 1),
            ["base_offset_mm"] = Math.Round((r.get_Parameter(BuiltInParameter.ROOM_LOWER_OFFSET)?.AsDouble() ?? 0) * MM, 1),
            ["area_m2"] = Math.Round(area * 0.09290304, 2),
            ["omsloten"] = r.Location is LocationPoint && area > 1e-9,
            ["punt_in_room"] = punt == null ? null : r.IsPointInRoom(punt),
            ["location_point_mm"] = r.Location is LocationPoint lp
                ? new[] { Math.Round(lp.Point.X * MM, 1), Math.Round(lp.Point.Y * MM, 1), Math.Round(lp.Point.Z * MM, 1) } : null,
            ["parameters"] = pars,
        };
    }

    private sealed class StilleFailures : IFailuresPreprocessor
    {
        private readonly List<string> _m;
        public StilleFailures(List<string> m) { _m = m; }
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            bool error = false;
            foreach (var f in fa.GetFailureMessages())
            {
                string desc; try { desc = f.GetDescriptionText(); } catch { desc = "?"; }
                FailureSeverity sev; try { sev = f.GetSeverity(); } catch { sev = FailureSeverity.Error; }
                if (sev == FailureSeverity.Warning) { _m.Add("warning: " + desc); try { fa.DeleteWarning(f); } catch { } }
                else { _m.Add("error: " + desc); error = true; }
            }
            return error ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
        }
    }

    private static Level? FindLevel(List<Level> levels, string name, out string? err)
    {
        err = null;
        var exact = levels.FirstOrDefault(l => l.Name == name);
        if (exact != null) return exact;
        var ci = levels.Where(l => l.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
        if (ci.Count == 1) return ci[0];
        err = $"level '{name}' niet gevonden (wel: {string.Join(", ", levels.OrderBy(l => l.Elevation).Select(l => l.Name).Take(20))})";
        return null;
    }

    private static double? NumEl(JsonElement el)
    {
        if (el.ValueKind == JsonValueKind.Number) return el.GetDouble();
        if (el.ValueKind == JsonValueKind.String && double.TryParse(el.GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) return d;
        return null;
    }

    private static double? TopNum(Dictionary<string, JsonElement>? p, string key)
        => p != null && p.TryGetValue(key, out var el) ? NumEl(el) : null;

    private static string Raw(JsonElement v) => v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : v.GetRawText();

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
}
