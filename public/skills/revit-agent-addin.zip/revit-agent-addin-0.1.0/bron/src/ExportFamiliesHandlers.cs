using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// export_families_to_folder — sla loadable families uit een open project als .rfa op in een mapstructuur
/// (bv. een vertaalde bibliotheek in een eigen mappenstructuur). Per family:
/// EditFamily -> Document.SaveAs(pad, overwrite) -> Close(false). Het project zelf wordt niet gewijzigd.
///
/// params:
///   target_document : scope op Title
///   folder          : doelmap (root); wordt aangemaakt
///   families        : [namen] (optioneel; anders alle editable, niet-in-place families) — of
///   prefix          : alleen families waarvan de naam hiermee begint (optioneel, combineerbaar)
///   subfolders      : {family_name: "relatieve/submap"} (optioneel; default: root)
///   file_names      : {family_name: "nieuwe bestandsnaam zonder .rfa"} (optioneel; default: family-naam)
///   overwrite       : bool (default false; een bestaand .rfa blijft staan als exists_skipped)
///   dry_run         : bool (default TRUE) — rapporteert de doelpaden zonder te schrijven
/// </summary>
public static class ExportFamiliesHandlers
{
    public static CommandResponse ExportFamiliesToFolder(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? folder = GetString(p, "folder");
        string? prefix = GetString(p, "prefix");
        bool dryRun = GetBool(p, "dry_run", true);
        bool dialogOk = GetBool(p, "dialog_ok", false);
        int dialogResult = GetInt(p, "dialog_result", 1);
        bool overwrite = GetBool(p, "overwrite", false);
        var names = GetStringList(p, "families");
        var subfolders = GetStringMap(p, "subfolders");
        var fileNames = GetStringMap(p, "file_names");
        if (string.IsNullOrWhiteSpace(folder)) return Err("'folder' is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var want = names?.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                var fams = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable)
                    .Where(f => want == null || want.Count == 0 || want.Contains(f.Name.ToLowerInvariant()))
                    .Where(f => prefix == null || f.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(f => f.Name).ToList();

                var results = new List<Dictionary<string, object?>>();
                int exported = 0, failed = 0;
                if (!dryRun) Directory.CreateDirectory(folder!);

                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.BlindResult = dialogResult;
                foreach (var fam in fams)
                {
                    swallow.Context = fam.Name;
                    string sub = subfolders.TryGetValue(fam.Name, out var s) ? s : "";
                    string fname = fileNames.TryGetValue(fam.Name, out var fn) ? fn : fam.Name;
                    foreach (var c in Path.GetInvalidFileNameChars()) fname = fname.Replace(c, '_');
                    string dir = string.IsNullOrWhiteSpace(sub) ? folder! : Path.Combine(folder!, sub);
                    string path = Path.Combine(dir, fname + ".rfa");
                    var info = new Dictionary<string, object?> { ["family"] = fam.Name, ["category"] = fam.FamilyCategory?.Name, ["path"] = path };
                    if (File.Exists(path) && !overwrite) { info["status"] = "exists_skipped"; results.Add(info); continue; }
                    if (dryRun) { info["status"] = "would_export"; results.Add(info); continue; }
                    Document? fdoc = null;
                    try
                    {
                        Directory.CreateDirectory(dir);
                        MainThreadDispatcher.Log($"export_families_to_folder: '{fam.Name}' -> {path}");
                        fdoc = doc.EditFamily(fam);
                        fdoc.SaveAs(path, new SaveAsOptions { OverwriteExistingFile = true, Compact = true });
                        fdoc.Close(false);
                        info["status"] = "exported"; info["bytes"] = new FileInfo(path).Length; exported++;
                    }
                    catch (Exception ex)
                    {
                        info["status"] = "error"; info["error"] = ex.Message; failed++;
                        try { fdoc?.Close(false); } catch { }
                    }
                    results.Add(info);
                }
                if (want != null)
                    foreach (var n in want)
                        if (!fams.Any(f => f.Name.ToLowerInvariant() == n))
                            results.Add(new Dictionary<string, object?> { ["family"] = n, ["status"] = "family_not_found" });

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["folder"] = folder,
                    ["count"] = fams.Count, ["exported"] = exported, ["failed"] = failed,
                    ["notable_dialogs"] = swallow.NotableReport(), ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) return el.GetString();
        return null;
    }
    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).ToList();
        return null;
    }
    private static Dictionary<string, string> GetStringMap(Dictionary<string, JsonElement>? p, string key)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Object)
            foreach (var kv in el.EnumerateObject())
                if (kv.Value.ValueKind == JsonValueKind.String) d[kv.Name] = kv.Value.GetString() ?? "";
        return d;
    }
    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        return dflt;
    }
}
