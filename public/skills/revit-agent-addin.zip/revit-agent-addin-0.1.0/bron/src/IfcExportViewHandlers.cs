using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// create_ifc_export_views — 3D-views per verdieping voor een IFC-export in delen.
/// Een model van 1,5 GB in één keer exporteren loopt op een laptop met 32 GB het wisselbestand in
/// (Revit 33 GB private, uren zonder output). Per view: section box van peil tot het volgende peil over de
/// XY-omvang van de gekozen categorieën, alle andere categorieën verborgen (dus ook links en isolatie),
/// detailniveau Fine (bij Coarse worden leidingen lijnen). Exporteren met export_ifc + view_name.
///
/// Elementen die een peil kruisen (stijgleidingen) komen in beide delen terecht, met dezelfde GlobalId;
/// de afnemer ontdubbelt op GlobalId.
///
/// Idempotent: een bestaande view met dezelfde naam wordt bijgewerkt, niet opnieuw gemaakt.
///
/// params:
///   target_document : scope op Title
///   prefix          : naamvoorvoegsel (default "IFC_export")
///   categories      : BuiltInCategory-namen (default leidingwerk + mechanical equipment, zonder isolatie)
///   mode            : "only" (default: alleen de categorieën tonen) | "except" (alles behalve de categorieën:
///                     het complement, voor bouwkundige context en overige installaties in een eigen bestand)
///   exclude_families: delen van familienamen die uit de views verdwijnen (zware geometrie)
///   include_families: alleen deze families tonen (de tegenhanger: de zware families in een eigen export)
///   skip_levels     : peilnamen die geen eigen deel krijgen (bv. "02a verhoogde vloer")
///   margin_mm       : marge rond de omvang (default 500)
///   dry_run         : bool (default true)
/// </summary>
public static class IfcExportViewHandlers
{
    private static readonly string[] DefaultCategories =
    {
        "OST_PipeCurves", "OST_PipeFitting", "OST_PipeAccessory", "OST_FlexPipeCurves",
        "OST_MechanicalEquipment", "OST_PlumbingFixtures",
    };

    public static CommandResponse CreateIfcExportViews(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string prefix = GetString(p, "prefix") ?? "IFC_export";
        var catNames = GetStringList(p, "categories");
        if (catNames.Count == 0) catNames = DefaultCategories.ToList();
        var skipLevels = new HashSet<string>(GetStringList(p, "skip_levels"), StringComparer.OrdinalIgnoreCase);
        double marginFt = GetNumber(p, "margin_mm", 500) / 304.8;
        bool dryRun = GetBool(p, "dry_run", true);
        bool except = string.Equals(GetString(p, "mode"), "except", StringComparison.OrdinalIgnoreCase);
        var excludeFamilies = GetStringList(p, "exclude_families");   // deel van de familienaam, hoofdletterongevoelig
        var includeFamilies = GetStringList(p, "include_families");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)new Dictionary<string, object?> { ["error"] = "no matching open document" };

                var notes = new List<string>();
                var cats = new List<BuiltInCategory>();
                foreach (var n in catNames)
                {
                    if (Enum.TryParse<BuiltInCategory>(n, out var bic)) cats.Add(bic);
                    else notes.Add($"onbekende categorie overgeslagen: {n}");
                }
                if (cats.Count == 0) return (object)new Dictionary<string, object?> { ["error"] = "geen geldige categorieën" };
                var allowed = new HashSet<long>(cats.Select(c => (long)c));

                // Omvang en z-middens van de in-scope elementen
                var boxes = new List<(double zMid, BoundingBoxXYZ bb)>();
                var filter = new ElementMulticategoryFilter(cats, except);
                foreach (var e in new FilteredElementCollector(doc).WherePasses(filter).WhereElementIsNotElementType())
                {
                    // complement: alleen modelelementen met een categorie (geen views, annotaties, links)
                    if (except && (e.Category == null || e.Category.CategoryType != CategoryType.Model || e is RevitLinkInstance || e.ViewSpecific)) continue;
                    var bb = e.get_BoundingBox(null);
                    if (bb == null) continue;
                    boxes.Add(((bb.Min.Z + bb.Max.Z) / 2, bb));
                }
                if (boxes.Count == 0) return (object)new Dictionary<string, object?> { ["error"] = "geen elementen in de gekozen categorieën" };
                double minX = boxes.Min(b => b.bb.Min.X), minY = boxes.Min(b => b.bb.Min.Y), minZ = boxes.Min(b => b.bb.Min.Z);
                double maxX = boxes.Max(b => b.bb.Max.X), maxY = boxes.Max(b => b.bb.Max.Y), maxZ = boxes.Max(b => b.bb.Max.Z);

                // Peilen: gesorteerd, overgeslagen namen eruit, gelijke hoogtes ontdubbeld
                var levels = new List<Level>();
                foreach (var l in new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().OrderBy(l => l.Elevation))
                {
                    if (skipLevels.Contains(l.Name)) continue;
                    if (levels.Count > 0 && Math.Abs(levels[^1].Elevation - l.Elevation) < 1.0 / 304.8)
                    { notes.Add($"peil '{l.Name}' heeft dezelfde hoogte als '{levels[^1].Name}' en krijgt geen eigen deel"); continue; }
                    levels.Add(l);
                }
                if (levels.Count == 0) return (object)new Dictionary<string, object?> { ["error"] = "geen peilen gevonden" };

                var zones = new List<(string name, double z0, double z1, int count)>();
                for (int i = 0; i < levels.Count; i++)
                {
                    double z0 = i == 0 ? Math.Min(minZ, levels[i].Elevation) - marginFt : levels[i].Elevation;
                    double z1 = i == levels.Count - 1 ? Math.Max(maxZ, levels[i].Elevation) + marginFt : levels[i + 1].Elevation;
                    int count = boxes.Count(b => b.zMid >= z0 && b.zMid < z1);
                    zones.Add((levels[i].Name, z0, z1, count));
                }

                var vft = new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>()
                    .FirstOrDefault(t => t.ViewFamily == ViewFamily.ThreeDimensional);
                if (vft == null) return (object)new Dictionary<string, object?> { ["error"] = "geen 3D view family type in het document" };
                var existing = new FilteredElementCollector(doc).OfClass(typeof(View3D)).Cast<View3D>()
                    .Where(v => !v.IsTemplate).ToDictionary(v => v.Name, v => v, StringComparer.OrdinalIgnoreCase);

                // Familiefilter: exclude_families haalt zware families uit de export (een paar families kunnen
                // het grootste deel van een bestand uitmaken); include_families toont juist alleen die families.
                var familyHide = new List<ElementId>();
                var familyHits = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                if (excludeFamilies.Count > 0 || includeFamilies.Count > 0)
                {
                    foreach (var fi in new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>())
                    {
                        string fam = fi.Symbol?.FamilyName ?? "";
                        bool ex = excludeFamilies.Any(p => fam.Contains(p, StringComparison.OrdinalIgnoreCase));
                        bool inc = includeFamilies.Count == 0 || includeFamilies.Any(p => fam.Contains(p, StringComparison.OrdinalIgnoreCase));
                        if (ex || !inc) familyHide.Add(fi.Id);
                        if (ex || (includeFamilies.Count > 0 && inc)) familyHits[fam] = familyHits.GetValueOrDefault(fam) + 1;
                    }
                }

                var rows = new List<Dictionary<string, object?>>();
                string status = dryRun ? "dry_run" : "created";
                Transaction? t = null;
                try
                {
                    if (!dryRun) { t = new Transaction(doc, "IFC-exportviews per verdieping"); t.Start(); }
                    foreach (var z in zones)
                    {
                        string name = $"{prefix}_{z.name}";
                        var row = new Dictionary<string, object?>
                        {
                            ["view"] = name, ["z_van_mm"] = Math.Round(z.z0 * 304.8), ["z_tot_mm"] = Math.Round(z.z1 * 304.8),
                            ["elementen_zmidden"] = z.count,
                        };
                        rows.Add(row);
                        if (z.count == 0) { row["status"] = "leeg_overgeslagen"; continue; }
                        bool had = existing.TryGetValue(name, out var view);
                        if (dryRun) { row["status"] = had ? "would_update" : "would_create"; continue; }

                        view ??= View3D.CreateIsometric(doc, vft.Id);
                        if (!had) view.Name = name;
                        if (view.ViewTemplateId != ElementId.InvalidElementId) view.ViewTemplateId = ElementId.InvalidElementId;
                        view.DetailLevel = ViewDetailLevel.Fine;
                        try { view.Discipline = ViewDiscipline.Coordination; } catch (Exception ex) { notes.Add($"{name}: discipline niet gezet ({ex.Message})"); }
                        view.SetSectionBox(new BoundingBoxXYZ
                        {
                            Min = new XYZ(minX - marginFt, minY - marginFt, z.z0),
                            Max = new XYZ(maxX + marginFt, maxY + marginFt, z.z1),
                        });
                        int hidden = 0, shown = 0;
                        foreach (Category c in doc.Settings.Categories)
                        {
                            if (!view.CanCategoryBeHidden(c.Id)) continue;
                            bool show = allowed.Contains(c.Id.Value) != except;
                            if (except && c.Id.Value == (long)BuiltInCategory.OST_RvtLinks) show = false;
                            try { view.SetCategoryHidden(c.Id, !show); if (show) shown++; else hidden++; }
                            catch (Exception ex) { notes.Add($"{name}: categorie {c.Name} niet gezet ({ex.Message})"); }
                        }
                        // familiefilter: per element verbergen (een view filter kan niet op familienaam "bevat"
                        // over alle categorieën heen zonder per categorie een regel)
                        if (familyHide.Count > 0)
                        {
                            var hideNow = familyHide.Where(id => { var e = doc.GetElement(id); return e != null && e.CanBeHidden(view); }).ToList();
                            if (hideNow.Count > 0) view.HideElements(hideNow);
                            row["verborgen_op_familie"] = hideNow.Count;
                        }
                        row["status"] = had ? "updated" : "created";
                        row["view_id"] = view.Id.Value;
                        row["categorieen_zichtbaar"] = shown;
                        row["categorieen_verborgen"] = hidden;
                    }
                    if (t != null)
                    {
                        var ts = t.Commit();
                        if (ts != TransactionStatus.Committed) status = $"niet_gecommit:{ts}";
                    }
                }
                finally
                {
                    if (t != null && t.GetStatus() == TransactionStatus.Started) t.RollBack();
                    t?.Dispose();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["status"] = status, ["families_geraakt"] = familyHits, ["mode"] = except ? "except" : "only", ["categories"] = cats.Select(c => c.ToString()).ToList(),
                    ["elementen_totaal"] = boxes.Count,
                    ["omvang_mm"] = new[] { Math.Round(minX * 304.8), Math.Round(minY * 304.8), Math.Round(minZ * 304.8), Math.Round(maxX * 304.8), Math.Round(maxY * 304.8), Math.Round(maxZ * 304.8) },
                    ["views"] = rows, ["notes"] = notes,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
        => p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String ? el.GetString() : null;
    private static double GetNumber(Dictionary<string, JsonElement>? p, string key, double dflt)
        => p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number ? el.GetDouble() : dflt;
    private static List<string> GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        var list = new List<string>();
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            foreach (var x in el.EnumerateArray())
                if (x.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(x.GetString())) list.Add(x.GetString()!);
        return list;
    }
}
