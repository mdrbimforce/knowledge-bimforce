// Generated from a type catalog (v0.3.0).
// Keep the catalog and this list in step when adding a type.

using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public record TypeCatalogEntry(
    string TypeId,
    string Pattern,
    string RevitClass,
    string ApiAccess,
    string? NlrsChapter,
    string NlrsRelevance,
    bool IsReference,
    string Notes,
    string Discipline
);

public static class TypeCatalog
{
    public static readonly IReadOnlyDictionary<string, TypeCatalogEntry> All = new Dictionary<string, TypeCatalogEntry>
    {
        ["object_styles"] = new("object_styles", "A", "Category", "Document.Settings.Categories (with .SubCategories)", "6", "high", true, "Reference implementation for Pattern A. Includes Subcategories (parent_id != null).", ""),
        ["line_styles"] = new("line_styles", "A", "Category(sub of OST_Lines)", "Document.Settings.Categories[\"OST_Lines\"].SubCategories", "3.2.6", "high", false, "Moved from Pattern B (v0.2.0). Shares implementation with Object Styles — reuse template with parent_category_filter='OST_Lines'.", ""),
        ["phases"] = new("phases", "A", "Phase", "Document.Phases", "3.3", "high", false, "", ""),
        ["phase_filters"] = new("phase_filters", "B", "PhaseFilter", "FEC.OfClass(PhaseFilter)", "3.3.1", "high", false, "Reclassified from mixed A/B (v0.2.0) — pure B access pattern", ""),
        ["worksets"] = new("worksets", "A", "Workset", "FilteredWorksetCollector(doc)", "3.4", "high", false, "", ""),
        ["project_base_point"] = new("project_base_point", "A", "BasePoint", "FEC.OfCategory(OST_ProjectBasePoint)", "7", "medium", false, "", ""),
        ["survey_point"] = new("survey_point", "A", "BasePoint", "FEC.OfCategory(OST_SharedBasePoint)", "7", "medium", false, "", ""),
        ["materials"] = new("materials", "B", "Material", "FEC.OfClass(Material)", "4.1", "high", false, "Has nested asset references", ""),
        ["material_assets"] = new("material_assets", "B", "AppearanceAssetElement|PropertySetElement", "via Material.AppearanceAssetId / StructuralAssetId / ThermalAssetId", "4.2", "high", false, "Nested in Material. Resolved inline in Material detail — no separate query tool needed.", ""),
        ["line_patterns"] = new("line_patterns", "B", "LinePatternElement", "FEC.OfClass(LinePatternElement)", "3.2.6", "high", false, "", ""),
        ["fill_patterns"] = new("fill_patterns", "B", "FillPatternElement", "FEC.OfClass(FillPatternElement)", "3.2.5", "high", false, "", ""),
        ["text_note_types"] = new("text_note_types", "B", "TextNoteType", "FEC.OfClass(TextNoteType)", "3.2.7", "high", false, "", ""),
        ["dimension_types"] = new("dimension_types", "B", "DimensionType", "FEC.OfClass(DimensionType)", "3.2.8", "high", false, "Abstract class. FEC returns all concrete subtypes. Cast to LinearDimensionType/AngularDimensionType/RadialDimensionType/SpotDimensionType/SpotSlopeDimensionType for subtype-specific properties.", ""),
        ["spot_dimension_types"] = new("spot_dimension_types", "B", "SpotDimensionType", "FEC.OfClass(SpotDimensionType)", "3.2.8", "high", false, "Separate entry because SpotDimensionType has unique properties (SpotElevation) not on base DimensionType.", ""),
        ["radial_dimension_types"] = new("radial_dimension_types", "B", "RadialDimensionType", "FEC.OfClass(RadialDimensionType)", "3.2.8", "high", false, "", ""),
        ["spot_slope_dimension_types"] = new("spot_slope_dimension_types", "B", "SpotSlopeDimensionType", "FEC.OfClass(SpotSlopeDimensionType)", "3.2.8", "high", false, "", ""),
        ["view_family_types"] = new("view_family_types", "B", "ViewFamilyType", "FEC.OfClass(ViewFamilyType)", "3.5", "high", false, "", ""),
        ["view_templates"] = new("view_templates", "B", "View(IsTemplate=true)", "FEC.OfClass(View).Where(v => v.IsTemplate)", "3.6", "high", false, "", ""),
        ["view_filters"] = new("view_filters", "B", "ParameterFilterElement", "FEC.OfClass(ParameterFilterElement)", "3.7", "high", false, "", ""),
        ["rebar_types"] = new("rebar_types", "B", "RebarType", "FEC.OfClass(RebarType)", null, "medium", false, "", ""),
        ["rebar_hook_types"] = new("rebar_hook_types", "B", "RebarHookType", "FEC.OfClass(RebarHookType)", null, "medium", false, "", ""),
        ["rebar_coupler_types"] = new("rebar_coupler_types", "B", "RebarCouplerType", "FEC.OfClass(RebarCouplerType)", null, "low", false, "", ""),
        ["keynote_table"] = new("keynote_table", "B", "KeynoteTable", "FEC.OfClass(KeynoteTable)", null, "medium", false, "", ""),
        ["schedule_type"] = new("schedule_type", "B", "ViewScheduleType", "FEC.OfClass(ViewScheduleType)", null, "low", false, "", ""),
        ["stairs_landing_type"] = new("stairs_landing_type", "G", "StairsLandingType", "FEC.OfClass(StairsLandingType)", "3.1", "low", false, "", ""),
        ["stairs_run_type"] = new("stairs_run_type", "G", "StairsRunType", "FEC.OfClass(StairsRunType)", "3.1", "low", false, "", ""),
        ["stairs_support_type"] = new("stairs_support_type", "G", "(category OST_StairsSupports)", "FEC.OfCategory(OST_StairsSupports).WhereElementIsElementType()", "3.1", "low", false, "", ""),
        ["loadable_family"] = new("loadable_family", "C", "Family", "FEC.OfClass(Family).Where(f => !f.IsInPlace)", "3.1", "high", true, "Reference implementation for Pattern C. Three-layer access: Family / FamilySymbol / FamilyInstance.", ""),
        ["family_symbol"] = new("family_symbol", "C", "FamilySymbol", "FEC.OfClass(FamilySymbol) or Family.GetFamilySymbolIds()", "3.2.1", "high", false, "", ""),
        ["family_instance"] = new("family_instance", "C", "FamilyInstance", "FEC.OfClass(FamilyInstance)", null, "medium", false, "", ""),
        ["profile_families"] = new("profile_families", "C", "Family", "FEC + FamilyCategory.Id == OST_ProfileFamilies [verify exact enum]", "3.2.2", "high", false, "", ""),
        ["generic_annotations"] = new("generic_annotations", "C", "Family", "FEC + FamilyCategory.Id == OST_GenericAnnotation", "3.2.3", "high", false, "", ""),
        ["labels"] = new("labels", "C", "Family", "FEC + naming pos3 in {SYM,LAB}", "3.2.3", "high", false, "", ""),
        ["tags"] = new("tags", "C", "Family", "FEC + FamilyCategory matches *Tags BuiltInCategory", "3.2.4", "high", false, "", ""),
        ["filled_region_component"] = new("filled_region_component", "C", "Family", "FEC + FamilyCategory.Id == OST_DetailComponents", "3.2.5", "high", false, "", ""),
        ["wall_type"] = new("wall_type", "D", "WallType", "FEC.OfClass(WallType)", "3.1", "high", false, "", "architectural"),
        ["floor_type"] = new("floor_type", "D", "FloorType", "FEC.OfClass(FloorType)", "3.1", "high", false, "", "architectural"),
        ["ceiling_type"] = new("ceiling_type", "D", "CeilingType", "FEC.OfClass(CeilingType)", "3.1", "high", false, "", "architectural"),
        ["roof_type"] = new("roof_type", "D", "RoofType", "FEC.OfClass(RoofType)", "3.1", "high", false, "Includes Footprint/Extrusion subclasses", "architectural"),
        ["stairs_type"] = new("stairs_type", "D", "StairsType", "FEC.OfClass(StairsType)", "3.1", "high", false, "", "architectural"),
        ["railing_type"] = new("railing_type", "D", "RailingType", "FEC.OfClass(RailingType)", "3.1", "high", false, "", "architectural"),
        ["curtain_system_type"] = new("curtain_system_type", "D", "CurtainSystemType", "FEC.OfClass(CurtainSystemType)", "3.1", "high", false, "", "architectural"),
        ["mullion_type"] = new("mullion_type", "D", "MullionType", "FEC.OfClass(MullionType)", "3.1", "high", false, "", "architectural"),
        ["slab_edge_type"] = new("slab_edge_type", "D", "SlabEdgeType", "FEC.OfClass(SlabEdgeType)", "3.1", "medium", false, "", "architectural"),
        ["fascia_type"] = new("fascia_type", "D", "FasciaType", "FEC.OfClass(FasciaType)", "3.1", "medium", false, "", "architectural"),
        ["gutter_type"] = new("gutter_type", "D", "GutterType", "FEC.OfClass(GutterType)", "3.1", "medium", false, "", "architectural"),
        ["structural_connection_type"] = new("structural_connection_type", "D", "StructuralConnectionType", "FEC.OfClass(StructuralConnectionType)", "3.1", "medium", false, "", "structural"),
        ["duct_type"] = new("duct_type", "D", "DuctType", "FEC.OfClass(DuctType)", "3.1", "high", false, "", "mep"),
        ["pipe_type"] = new("pipe_type", "D", "PipeType", "FEC.OfClass(PipeType)", "3.1", "high", false, "", "mep"),
        ["conduit_type"] = new("conduit_type", "D", "ConduitType", "FEC.OfClass(ConduitType)", "3.1", "high", false, "", "mep"),
        ["cable_tray_type"] = new("cable_tray_type", "D", "CableTrayType", "FEC.OfClass(CableTrayType)", "3.1", "high", false, "", "mep"),
        ["duct_insulation_type"] = new("duct_insulation_type", "D", "DuctInsulationType", "FEC.OfClass(DuctInsulationType)", "3.1", "medium", false, "", "mep"),
        ["pipe_insulation_type"] = new("pipe_insulation_type", "D", "PipeInsulationType", "FEC.OfClass(PipeInsulationType)", "3.1", "medium", false, "", "mep"),
        ["duct_lining_type"] = new("duct_lining_type", "D", "DuctLiningType", "FEC.OfClass(DuctLiningType)", "3.1", "medium", false, "", "mep"),
        ["flex_duct_type"] = new("flex_duct_type", "D", "FlexDuctType", "FEC.OfClass(FlexDuctType)", "3.1", "medium", false, "", "mep"),
        ["flex_pipe_type"] = new("flex_pipe_type", "D", "FlexPipeType", "FEC.OfClass(FlexPipeType)", "3.1", "medium", false, "", "mep"),
        ["wire_type"] = new("wire_type", "D", "WireType", "FEC.OfClass(WireType)", "3.1", "medium", false, "", "mep"),
        ["group_type"] = new("group_type", "E", "GroupType", "FEC.OfClass(GroupType)", null, "low", false, "", ""),
        ["model_group"] = new("model_group", "E", "Group", "FEC.OfClass(Group).WhereElementIsNotElementType() filtered on context", null, "low", false, "", ""),
        ["detail_group"] = new("detail_group", "E", "Group", "filter on OST_IOSDetailGroups", null, "low", false, "", ""),
        ["assembly_instance"] = new("assembly_instance", "E", "AssemblyInstance", "FEC.OfClass(AssemblyInstance)", null, "low", false, "", ""),
        ["part"] = new("part", "E", "Part", "FEC.OfClass(Part)", null, "low", false, "", ""),
        ["mep_mechanical_system"] = new("mep_mechanical_system", "E", "MechanicalSystem", "FEC.OfClass(MechanicalSystem)", null, "medium", false, "", ""),
        ["mep_piping_system"] = new("mep_piping_system", "E", "PipingSystem", "FEC.OfClass(PipingSystem)", null, "medium", false, "", ""),
        ["mep_electrical_system"] = new("mep_electrical_system", "E", "ElectricalSystem", "FEC.OfClass(ElectricalSystem)", null, "medium", false, "", ""),
        ["shared_parameter"] = new("shared_parameter", "F", "SharedParameterElement|ExternalDefinition", "Application.OpenSharedParameterFile() + FEC.OfClass(SharedParameterElement)", "8.1", "high", false, "", ""),
        ["project_parameter"] = new("project_parameter", "F", "ParameterBinding", "Document.ParameterBindings (BindingMap)", null, "high", false, "", ""),
        ["project_information"] = new("project_information", "F", "ProjectInfo", "Document.ProjectInformation", null, "medium", false, "", ""),
        ["classification_system"] = new("classification_system", "F", "(virtual — Shared Parameter or AssemblyCode)", "AssemblyCodeTable (NL-SfB) + Shared Parameters", "5", "high", false, "Not a native Revit type; cross-cutting on assembly_code and shared parameters", ""),
        ["stairs_cut_mark_type"] = new("stairs_cut_mark_type", "G", "CutMarkType", "FEC.OfClass(CutMarkType)", "3.1", "low", false, "", ""),
        ["handrail_type"] = new("handrail_type", "G", "HandRailType", "FEC.OfClass(HandRailType)", "3.1", "medium", false, "", ""),
        ["toprail_type"] = new("toprail_type", "G", "TopRailType", "FEC.OfClass(TopRailType)", "3.1", "medium", false, "", ""),
        ["roof_soffit_type"] = new("roof_soffit_type", "G", "(category OST_RoofSoffit)", "FEC.OfCategory(OST_RoofSoffit).WhereElementIsElementType()", "3.1", "medium", false, "", ""),
        ["beam_system_type"] = new("beam_system_type", "G", "BeamSystemType", "FEC.OfClass(BeamSystemType)", "3.1", "medium", false, "", "structural"),
        ["structural_foundation_type"] = new("structural_foundation_type", "G", "(category OST_StructuralFoundation)", "FEC.OfCategory(OST_StructuralFoundation).WhereElementIsElementType()", "3.1", "medium", false, "", "structural"),
        ["ramp_type"] = new("ramp_type", "G", "(category OST_Ramps)", "FEC.OfCategory(OST_Ramps).WhereElementIsElementType()", "3.1", "medium", false, "", ""),
        ["toposolid_type"] = new("toposolid_type", "G", "ToposolidType", "FEC.OfClass(ToposolidType)", "3.1", "medium", false, "", ""),
        ["building_pad_type"] = new("building_pad_type", "G", "BuildingPadType", "FEC.OfClass(BuildingPadType)", "3.1", "medium", false, "", ""),
        ["duct_system_type"] = new("duct_system_type", "G", "MechanicalSystemType", "FEC.OfClass(MechanicalSystemType)", "3.1", "medium", false, "", "mep"),
        ["piping_system_type"] = new("piping_system_type", "G", "PipingSystemType", "FEC.OfClass(PipingSystemType)", "3.1", "medium", false, "", "mep")
    };

    /// <summary>List all type IDs for a given access pattern.</summary>
    public static IEnumerable<TypeCatalogEntry> ByPattern(string pattern) =>
        All.Values.Where(e => e.Pattern == pattern);

    /// <summary>Try to get an entry; returns null if not found.</summary>
    public static TypeCatalogEntry? Get(string typeId) =>
        All.TryGetValue(typeId, out var entry) ? entry : null;

    /// <summary></summary>
    public static IEnumerable<string> ListTypes(string? pattern = null) =>
        pattern != null
            ? All.Values.Where(e => e.Pattern == pattern).Select(e => e.TypeId)
            : All.Keys;
}
