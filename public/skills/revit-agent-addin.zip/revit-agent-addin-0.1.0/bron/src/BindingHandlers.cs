using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// Parameter-binding mirroring (a precursor to repoint_filter_parameter). repoint_filter_parameter fails
/// when the NLRS target param does not apply to a filter's categories: SetElementFilter rejects a rule
/// whose parameter is not bound there. The old param (FireRating/IsExternal/LoadBearing) IS bound to
/// those categories — so before repointing we make the NLRS param apply wherever the old one does, by
/// unioning the old param's binding categories into the NLRS param's binding.
///
/// mirror_parameter_binding params:
///   target_document : string (required)
///   mappings        : [{source, target}]  — source=old param (binding to mirror FROM), target=NLRS param
///   dry_run         : bool (default true)
///   save_first      : bool (default false)
/// </summary>
public static class BindingHandlers
{
    public static CommandResponse MirrorParameterBinding(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        // category_source: "param" (mirror source param's own binding categories) or "filters" (union
        // the categories of every ParameterFilterElement that references the source param — needed when
        // a copied filter spans more categories than the source param is bound to).
        string categorySource = GetString(p, "category_source") ?? "param";
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };

        var mappings = new List<(string src, string tgt)>();
        if (p != null && p.TryGetValue("mappings", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
                if (it.ValueKind == JsonValueKind.Object
                    && it.TryGetProperty("source", out var s) && it.TryGetProperty("target", out var t)
                    && s.GetString() is string ss && t.GetString() is string tt)
                    mappings.Add((ss, tt));
        if (mappings.Count == 0)
            return new CommandResponse { Success = false, Error = "Parameter 'mappings':[{source,target}] is required" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                    if (d.Title == target) { doc = d; break; }
                if (doc == null) throw new Exception($"target_document '{target}' is not open");

                var create = app.Application.Create;
                var bindings = doc.ParameterBindings;
                var spByName = new Dictionary<string, SharedParameterElement>(StringComparer.OrdinalIgnoreCase);
                foreach (var sp in new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>())
                    spByName[sp.Name] = sp;

                // Plan (read-only) first.
                var plan = new List<(Definition tgtDef, Binding newBinding, bool existed, ForgeTypeId group, Dictionary<string, object?> row)>();
                var results = new List<Dictionary<string, object?>>();
                foreach (var (src, tgt) in mappings)
                {
                    var row = new Dictionary<string, object?> { ["source"] = src, ["target"] = tgt };
                    if (!spByName.TryGetValue(src, out var srcSp)) { row["status"] = "error"; row["error"] = "source param not found"; results.Add(row); continue; }
                    if (!spByName.TryGetValue(tgt, out var tgtSp)) { row["status"] = "error"; row["error"] = "target param not found"; results.Add(row); continue; }
                    var srcDef = srcSp.GetDefinition();
                    var tgtDef = tgtSp.GetDefinition();
                    var srcBinding = bindings.get_Item(srcDef) as ElementBinding;
                    var tgtBinding = bindings.get_Item(tgtDef) as ElementBinding;

                    var union = create.NewCategorySet();
                    int srcN = 0, tgtN = 0;
                    if (categorySource == "filters")
                    {
                        // Categories of every filter whose rules reference the source param.
                        foreach (var pfe in new FilteredElementCollector(doc).OfClass(typeof(ParameterFilterElement)).Cast<ParameterFilterElement>())
                        {
                            if (!FilterHandlers.FilterReferencesParam(pfe.GetElementFilter(), srcSp.Id)) continue;
                            foreach (var cid in pfe.GetCategories())
                            {
                                var c = Category.GetCategory(doc, cid);
                                if (c != null && union.Insert(c)) srcN++;
                            }
                        }
                        if (srcN == 0) { row["status"] = "error"; row["error"] = "no filters reference the source param"; results.Add(row); continue; }
                    }
                    else
                    {
                        if (srcBinding == null) { row["status"] = "error"; row["error"] = "source param has no project binding to mirror"; results.Add(row); continue; }
                        foreach (Category c in srcBinding.Categories) { union.Insert(c); srcN++; }
                    }
                    if (tgtBinding != null) foreach (Category c in tgtBinding.Categories) { union.Insert(c); tgtN++; }

                    bool useType = tgtBinding is TypeBinding || (tgtBinding == null && srcBinding is TypeBinding);
                    Binding nb = useType ? create.NewTypeBinding(union) : create.NewInstanceBinding(union);

                    row["status"] = dryRun ? "would_mirror" : "mirrored";
                    row["binding_kind"] = useType ? "type" : "instance";
                    row["source_categories"] = srcN;
                    row["target_categories_before"] = tgtN;
                    row["union_categories"] = union.Size;
                    plan.Add((tgtDef, nb, tgtBinding != null, tgtDef.GetGroupTypeId(), row));
                    results.Add(row);
                }

                string? saved = null;
                if (!dryRun && plan.Count > 0)
                {
                    if (saveFirst)
                    {
                        try { doc.Save(); saved = doc.Title; }
                        catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                    }
                    using var t = new Transaction(doc, "mirror parameter bindings");
                    t.Start();
                    foreach (var (tgtDef, nb, existed, group, row) in plan)
                    {
                        try
                        {
                            bool ok = existed ? bindings.ReInsert(tgtDef, nb) : bindings.Insert(tgtDef, nb, group);
                            if (!ok) { row["status"] = "error"; row["error"] = "ReInsert/Insert returned false"; }
                        }
                        catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["target_document"] = doc.Title,
                    ["saved_document"] = saved,
                    ["mirrored"] = results.Count(r => (string?)r["status"] is "mirrored" or "would_mirror"),
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>
    /// set_parameter_binding — (re)bind a project shared parameter to an EXPLICIT category list with a
    /// chosen instance/type binding (review SP-binding-edit). Replace-semantics: the given
    /// categories are the desired end-state. Category names are resolved fail-on-mismatch — one unknown
    /// name fails that row with no mutation. Reuses the ReInsert/Insert + NewInstance/TypeBinding motor
    /// from MirrorParameterBinding, but fed from an explicit list instead of a source param/filters.
    ///
    /// params:
    ///   target_document : scope by Title
    ///   bindings : [{guid? | param_name?, kind: "instance"|"type", categories:[UI category names], expected?}]
    ///   dry_run    : bool (default TRUE)
    ///   save_first : bool (default false)
    /// </summary>
    public static CommandResponse SetParameterBinding(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        // Optioneel SP-bestand zodat een parameter die nog NIET in het document
        // bestaat (bv. een leeg project) rechtstreeks vanuit de ExternalDefinition gebonden wordt; Insert maakt dan
        // zelf de SharedParameterElement aan. Per binding kan een 'group' (UI-groep) meegegeven worden.
        string? spf = GetString(p, "shared_param_file");

        var specs = new List<(string? guid, string? name, string kind, List<string> cats, string? grp)>();
        if (p != null && p.TryGetValue("bindings", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? guid = PropStr(it, "guid"); string? name = PropStr(it, "param_name");
                string kind = (PropStr(it, "kind") ?? "instance").ToLowerInvariant();
                var cats = new List<string>();
                if (it.TryGetProperty("categories", out var ce) && ce.ValueKind == JsonValueKind.Array)
                    foreach (var c in ce.EnumerateArray())
                        if (c.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(c.GetString())) cats.Add(c.GetString()!.Trim());
                // Empty categories is allowed for a KIND-ONLY rebind (instance<->type): the existing
                // binding's own category set is reused, so we don't re-resolve names — which lets a param
                // bound to sub-element categories (Fascias/Gutters/… absent from Settings.Categories) still
                // flip its kind. Only a param with neither guid nor name is unusable.
                if (guid == null && name == null) continue;
                specs.Add((guid, name, kind, cats, PropStr(it, "group")));
            }
        if (specs.Count == 0) return new CommandResponse { Success = false, Error = "bindings:[{guid|param_name, kind, categories:[...]}] is required" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)FailObj("no matching open document");

                var catByName = new Dictionary<string, Category>(StringComparer.OrdinalIgnoreCase);
                foreach (Category c in doc.Settings.Categories) catByName[c.Name] = c;

                var spByName = new Dictionary<string, SharedParameterElement>(StringComparer.OrdinalIgnoreCase);
                var spByGuid = new Dictionary<string, SharedParameterElement>(StringComparer.OrdinalIgnoreCase);
                foreach (var sp in new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>())
                { spByName[sp.Name] = sp; try { spByGuid[sp.GuidValue.ToString()] = sp; } catch { } }

                var create = app.Application.Create;
                var bindings = doc.ParameterBindings;
                DefinitionFile? extDefs = null; string? prevSpf = null;
                if (spf != null)
                {
                    try
                    {
                        prevSpf = app.Application.SharedParametersFilename;
                        app.Application.SharedParametersFilename = spf;
                        extDefs = app.Application.OpenSharedParameterFile();
                        if (extDefs == null) return (object)FailObj($"shared_param_file kon niet geopend worden: {spf}");
                    }
                    catch (Exception ex) { return (object)FailObj($"shared_param_file: {ex.Message}"); }
                }

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                { try { doc.Save(); savedBackup = true; } catch (Exception ex) { return (object)FailObj($"save-first failed, aborted: {ex.Message}"); } }

                var results = new List<Dictionary<string, object?>>();
                var plan = new List<(Definition def, Binding nb, bool existed, ForgeTypeId grp, Dictionary<string, object?> row)>();
                foreach (var s in specs)
                {
                    var row = new Dictionary<string, object?> { ["param"] = (object?)s.name ?? s.guid, ["kind"] = s.kind };
                    SharedParameterElement? sp = (s.guid != null && spByGuid.TryGetValue(s.guid, out var g)) ? g
                                              : (s.name != null && spByName.TryGetValue(s.name, out var n)) ? n : null;
                    Definition? def = sp?.GetDefinition();
                    ForgeTypeId? fileGroup = null;
                    if (def == null && extDefs != null)
                    {
                        var ed = FindExternal(extDefs, s.guid, s.name);
                        if (ed != null) { def = ed; fileGroup = MapGroup(s.grp); row["from_file"] = true; row["param"] = ed.Name; }
                    }
                    if (def == null) { row["status"] = "param_not_found"; results.Add(row); continue; }
                    var existing = bindings.get_Item(def) as ElementBinding;
                    CategorySet set;
                    if (s.cats.Count == 0)
                    {
                        // Kind-only rebind: reuse the EXISTING binding's category objects verbatim (no name
                        // re-resolution), so sub-element categories absent from Settings.Categories survive.
                        if (existing == null)
                        { row["status"] = "no_existing_binding"; row["error"] = "kind-only rebind needs an existing binding to reuse its categories"; results.Add(row); continue; }
                        set = existing.Categories;
                    }
                    else
                    {
                        set = create.NewCategorySet(); var missing = new List<string>();
                        foreach (var cn in s.cats)
                        {
                            // Taalonafhankelijk: "OST_GenericModel" (BuiltInCategory) werkt in elke UI-taal; de UI-naam
                            // ("Generic Models" / "Modeles generiques") blijft als fallback.
                            Category? cat = null;
                            if (cn.StartsWith("OST_", StringComparison.OrdinalIgnoreCase) && Enum.TryParse<BuiltInCategory>(cn, true, out var bic))
                            { try { cat = Category.GetCategory(doc, bic); } catch { cat = null; } }
                            if (cat == null) catByName.TryGetValue(cn, out cat);
                            if (cat != null && cat.AllowsBoundParameters) set.Insert(cat);
                            else missing.Add(cn);
                        }
                        if (missing.Count > 0) { row["status"] = "category_not_found"; row["missing"] = missing; results.Add(row); continue; }
                    }
                    bool useType = s.kind == "type";
                    Binding nb = useType ? create.NewTypeBinding(set) : create.NewInstanceBinding(set);
                    row["categories"] = set.Size; row["existed"] = existing != null;
                    row["status"] = dryRun ? (existing != null ? "would_rebind" : "would_bind") : "pending";
                    ForgeTypeId grpId = fileGroup ?? (s.grp != null ? MapGroup(s.grp) : def.GetGroupTypeId());
                    plan.Add((def, nb, existing != null, grpId, row));
                    results.Add(row);
                }

                if (prevSpf != null) { try { app.Application.SharedParametersFilename = prevSpf; } catch { } }
                if (!dryRun && plan.Count > 0)
                {
                    using var t = new Transaction(doc, "NLRS set parameter binding");
                    t.Start();
                    foreach (var (def, nb, existed, grp, row) in plan)
                    {
                        try
                        {
                            bool ok = existed ? bindings.ReInsert(def, nb, grp) : bindings.Insert(def, nb, grp);
                            row["status"] = ok ? (existed ? "rebound" : "bound") : "failed";
                            if (!ok) row["error"] = "ReInsert/Insert returned false";
                        }
                        catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                { ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup, ["results"] = results };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> FailObj(string msg) => new() { ["error"] = msg, ["ok"] = false };

    /// <summary>ExternalDefinition uit een geopend SP-bestand op GUID (voorkeur) of naam.</summary>
    private static ExternalDefinition? FindExternal(DefinitionFile df, string? guid, string? name)
    {
        foreach (DefinitionGroup g in df.Groups)
            foreach (Definition d in g.Definitions)
            {
                if (d is not ExternalDefinition ed) continue;
                if (guid != null && ed.GUID.ToString().Equals(guid, StringComparison.OrdinalIgnoreCase)) return ed;
                if (guid == null && name != null && ed.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return ed;
            }
        return null;
    }

    /// <summary>UI-groepnaam (NL/EN, vrij) -> GroupTypeId; onbekend of leeg -> Data.</summary>
    private static ForgeTypeId MapGroup(string? grp)
    {
        var g = (grp ?? "").Trim().ToLowerInvariant();
        if (g.StartsWith("dimension") || g.StartsWith("afmeting") || g == "geometry") return GroupTypeId.Geometry;
        if (g.StartsWith("identity") || g.StartsWith("identiteit")) return GroupTypeId.IdentityData;
        if (g.StartsWith("fire") || g.StartsWith("brand")) return GroupTypeId.FireProtection;
        if (g.StartsWith("material")) return GroupTypeId.Materials;
        if (g.StartsWith("text") || g.StartsWith("tekst")) return GroupTypeId.Text;
        if (g.StartsWith("general") || g.StartsWith("algemeen")) return GroupTypeId.General;
        if (g.StartsWith("ifc")) return GroupTypeId.Ifc;
        if (g.StartsWith("construction") || g.StartsWith("constructie")) return GroupTypeId.Construction;
        return GroupTypeId.Data;
    }

    private static string? PropStr(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
