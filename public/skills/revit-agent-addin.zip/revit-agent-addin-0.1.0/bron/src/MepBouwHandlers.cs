using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;

namespace RevitAgent.Addin;

/// <summary>
/// Bouwkundige aanvullingen voor de NLRS Onderwijsmodellen: vier commando's.
///
///   create_walls         — wanden uit een lijn (start/eind in mm), wandtype, level, basis- en topbeperking.
///   create_shaft_opening — schachtsparing (shaft opening) tussen twee levels uit een gesloten polygoon.
///   place_hosted_family  — wandgehoste families (deur, luik, handmelder, brandmeldcentrale) in een bestaande wand.
///   reload_link          — RevitLinkType herladen (Reload, of Load als de link uit staat).
///
/// Gemeenschappelijk: target_document (verplicht), dry_run (default TRUE). Coördinaten in mm, interne coördinaten van
/// het model; z is boven het opgegeven level. Per item een TransactionGroup (één ongedaan-maakstap) met transacties die
/// de stille failure-preprocessor hebben (warnings weg, errors → terugrollen; geen modale dialoog), read-back na commit.
/// Idempotent: met Comments (params.Comments of comments) wordt een element met precies die Comments hergebruikt
/// (status bestond); zonder Comments herkent elk commando een geometrisch gelijk element (zie per commando).
/// Resultaat: results [{index, status, element_id, fouten, ...}], tellers, element_ids, failure_meldingen, notes,
/// dialogs_dismissed/dialogs_notable.
/// </summary>
public static partial class MepModelHandlers
{
    // ═══════════════════════════════════════════════════════════════════════
    // gedeelde hulp voor de nieuwe commando's
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>params{} van een item plus het veld comments (als Comments).</summary>
    private static List<(string Name, JsonElement Value)> ItemParams(JsonElement it, List<string> fouten)
    {
        var prms = new List<(string Name, JsonElement Value)>();
        if (it.TryGetProperty("params", out var pe))
        {
            if (pe.ValueKind == JsonValueKind.Object) foreach (var pr in pe.EnumerateObject()) prms.Add((pr.Name, pr.Value.Clone()));
            else if (pe.ValueKind != JsonValueKind.Null) fouten.Add("params is geen object {naam: waarde}");
        }
        var c = HandlerUtil.Str(it, "comments");
        if (c != null)
        {
            if (prms.Any(x => x.Name == "Comments")) fouten.Add("comments en params.Comments zijn allebei opgegeven");
            else prms.Add(("Comments", JsonSerializer.SerializeToElement(c)));
        }
        return prms;
    }

    private static string? CommentsWanted(List<(string Name, JsonElement Value)> prms)
        => prms.Where(x => x.Name is "Comments" or "Opmerkingen" && x.Value.ValueKind == JsonValueKind.String)
               .Select(x => x.Value.GetString()).FirstOrDefault(s => !string.IsNullOrWhiteSpace(s));

    private static Parameter? LookupParam(Element el, string name)
    {
        var par = el.LookupParameter(name);
        if (par != null) return par;
        if (name is "Comments" or "Opmerkingen") return el.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
        if (name is "Mark" or "Merk") return el.get_Parameter(BuiltInParameter.ALL_MODEL_MARK);
        return null;
    }

    private static string? CommentsOf(Element el)
    {
        try { return el.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString(); } catch { return null; }
    }

    /// <summary>Elementen (geen types) met Comments precies 'sleutel' (exact = true), of ook eindigend op ' ' + sleutel
    /// (de scripts zetten '&lt;MARKER&gt; &lt;sleutel&gt;').</summary>
    private static List<Element> ByComments(Document doc, string sleutel, bool exact, ElementFilter? filter = null)
    {
        var col = new FilteredElementCollector(doc).WhereElementIsNotElementType();
        if (filter != null) col = col.WherePasses(filter);
        var res = new List<Element>();
        foreach (var e in col)
        {
            var c = CommentsOf(e);
            if (string.IsNullOrEmpty(c)) continue;
            if (c == sleutel || (!exact && c.EndsWith(" " + sleutel, StringComparison.Ordinal))) res.Add(e);
        }
        return res;
    }

    /// <summary>Instance-parameters zetten in een eigen transactie, met read-back. Rijen per parameter in paramRows.</summary>
    private static void ZetParams(Document doc, ElementId id, List<(string Name, JsonElement Value)> prms, Dictionary<string, object?> paramRows,
                                  List<string> fouten, List<string> meldingen, string txNaam)
    {
        if (prms.Count == 0) return;
        var desired = new Dictionary<string, (StorageType St, object Val)>();
        var (ok, n) = RunTx(doc, txNaam, () =>
        {
            var el = doc.GetElement(id) ?? throw new InvalidOperationException($"element {id.Value} niet gevonden");
            foreach (var (pn, pv) in prms)
            {
                var pr = new Dictionary<string, object?> { ["gevraagd"] = Raw(pv), ["status"] = "fout" };
                paramRows[pn] = pr;
                var par = LookupParam(el, pn);
                if (par == null)
                {
                    bool typePar = doc.GetElement(el.GetTypeId())?.LookupParameter(pn) != null;
                    pr["reden"] = typePar ? "type-parameter; niet gezet (gebruik set_parameter_values_bulk met target \"type\")" : "parameter ontbreekt op de instantie";
                    fouten.Add($"param '{pn}': {pr["reden"]}");
                    continue;
                }
                if (par.IsReadOnly) { pr["reden"] = "read-only"; fouten.Add($"param '{pn}': read-only"); continue; }
                var (val, setStr, err) = ConvertValue(doc, par, pv);
                if (err != null) { pr["reden"] = err; fouten.Add($"param '{pn}': {err}"); continue; }
                bool okSet;
                try { okSet = WriteValue(par, val!, setStr); }
                catch (Exception ex) { pr["reden"] = $"exception bij Set: {ex.Message}"; fouten.Add($"param '{pn}': {ex.Message}"); continue; }
                if (!okSet) { pr["reden"] = "Set gaf false"; fouten.Add($"param '{pn}': Set gaf false"); continue; }
                desired[pn] = (par.StorageType, val!);
                pr["status"] = "gezet_voor_commit";
            }
        }, meldingen);
        if (!ok)
        {
            fouten.Add($"parameters teruggerold: {n}");
            foreach (var kv in paramRows)
                if (kv.Value is Dictionary<string, object?> pr && (string?)pr["status"] == "gezet_voor_commit") { pr["status"] = "fout"; pr["reden"] = "transactie teruggerold"; }
            return;
        }
        var back = doc.GetElement(id);
        foreach (var (pn, d) in desired)
        {
            var pr = (Dictionary<string, object?>)paramRows[pn]!;
            var par = back == null ? null : LookupParam(back, pn);
            pr["gelezen"] = par == null ? null : DisplayValue(par);
            if (par != null && Equal(par, d.St, d.Val)) pr["status"] = "gezet";
            else { pr["status"] = "fout"; pr["reden"] = "read-back wijkt af"; fouten.Add($"param '{pn}': read-back wijkt af"); }
        }
    }

    private static double DistXy(XYZ a, XYZ b) => Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y));

    private static double[]? Xy(JsonElement it, string key, List<string> fouten, bool zOptional = true)
    {
        if (!it.TryGetProperty(key, out var el) || el.ValueKind != JsonValueKind.Array) { fouten.Add($"{key} ontbreekt ([x,y] in mm)"); return null; }
        var v = el.EnumerateArray().Select(NumEl).ToList();
        if (v.Count < 2 || v.Count > 3 || v.Any(x => x == null) || (!zOptional && v.Count != 3)) { fouten.Add($"{key} is geen [x,y]{(zOptional ? " of [x,y,z]" : "")}"); return null; }
        return v.Select(x => x!.Value).ToArray();
    }

    private static Dictionary<string, object?> Envelope(Document doc, bool dryRun, int gevraagd, List<Dictionary<string, object?>> results,
                                                        List<string> meldingen, List<string> notes)
        => new()
        {
            ["document"] = doc.Title,
            ["dry_run"] = dryRun,
            ["gevraagd"] = gevraagd,
            ["tellers"] = results.GroupBy(r => (string?)r["status"] ?? "?").ToDictionary(g => g.Key, g => g.Count()),
            ["element_ids"] = results.Where(r => r.TryGetValue("element_id", out var v) && v != null).Select(r => r["element_id"]).ToList(),
            ["results"] = results,
            ["failure_meldingen"] = meldingen.Take(100).ToList(),
            ["notes"] = notes,
        };

    private static string? DocCheck(Document? doc, string target, bool dryRun)
    {
        if (doc == null) return $"target_document '{target}' is niet open";
        if (doc.IsFamilyDocument) return "target_document is een familiedocument";
        if (!dryRun && doc.IsReadOnly) return "target_document is alleen-lezen";
        if (!dryRun && doc.IsModifiable) return "er staat al een transactie open in target_document";
        return null;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // create_walls
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// create_walls — wanden maken.
    /// params: target_document, dry_run (default TRUE),
    ///   walls:[{wall_type, level, start_mm:[x,y], end_mm:[x,y], base_offset_mm? (0), top_level? + top_offset_mm? (0) |
    ///           height_mm (zonder top_level: onverbonden hoogte), location_line? (WallCenterline | CoreCenterline |
    ///           FinishFaceExterior | FinishFaceInterior | CoreExterior | CoreInterior; default WallCenterline),
    ///           room_bounding? (bool), structural? (bool, default false), flip? (bool), params?{}, comments?}].
    /// Wall.Create met de lijn als wandas; bij een andere location_line wordt de parameter gezet en de lijn opnieuw
    /// toegewezen, zodat die referentielijn op start→eind ligt. Idempotent: Comments gelijk → bestond; zonder Comments
    /// een wand van hetzelfde type op hetzelfde level met dezelfde eindpunten (≤ 1 mm, beide richtingen) → bestond.
    /// Per wand: transactie 1 maakt de wand met alle beperkingen (alles of niets), transactie 2 zet params.
    /// Resultaat per wand: {index, status: zou_maken|gemaakt|gemaakt_met_fouten|bestond|fout, element_id, wand (read-back:
    /// type, levels, offsets, location_line, room_bounding, start/eind, lengte, dikte), params, fouten}.
    /// </summary>
    public static CommandResponse CreateWalls(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var items = HandlerUtil.Arr(p, "walls").Select(x => x.Clone()).ToList();
        if (items.Count == 0) return Err("walls:[{wall_type, level, start_mm, end_mm, base_offset_mm?, top_level?|height_mm, top_offset_mm?, location_line?, room_bounding?, structural?, flip?, params?, comments?}] is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "create_walls" };
                double shortTol = app.Application.ShortCurveTolerance;
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var wallTypes = Collect<WallType>(doc!).ToList();
                var levels = Collect<Level>(doc!).ToList();

                for (int i = 0; i < items.Count; i++)
                {
                    var it = items[i];
                    var fouten = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = i, ["status"] = "fout", ["element_id"] = null, ["fouten"] = fouten };
                    results.Add(row);
                    swallow.Context = $"create_walls #{i}";
                    try
                    {
                        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("wand is geen object"); continue; }
                        string? typeName = HandlerUtil.Str(it, "wall_type");
                        string? levelName = HandlerUtil.Str(it, "level");
                        string? topName = HandlerUtil.Str(it, "top_level");
                        double baseOff = Num(it, "base_offset_mm") ?? 0, topOff = Num(it, "top_offset_mm") ?? 0;
                        double? hMm = Num(it, "height_mm");
                        bool flip = HandlerUtil.Bool(it, "flip") ?? false;
                        bool structural = HandlerUtil.Bool(it, "structural") ?? false;
                        bool? roomBounding = HandlerUtil.Bool(it, "room_bounding");
                        string locName = HandlerUtil.Str(it, "location_line") ?? "WallCenterline";
                        row["wall_type"] = typeName; row["level"] = levelName; row["top_level"] = topName;
                        if (typeName == null) fouten.Add("wall_type ontbreekt");
                        if (levelName == null) fouten.Add("level ontbreekt");
                        var a = Xy(it, "start_mm", fouten); var b = Xy(it, "end_mm", fouten);
                        if (topName == null && (hMm == null || hMm <= 0)) fouten.Add("zonder top_level is height_mm (> 0) verplicht");
                        if (topName != null && hMm != null) fouten.Add("top_level en height_mm allebei opgegeven; kies één");
                        if (!Enum.TryParse<WallLocationLine>(locName, true, out var loc))
                            fouten.Add($"location_line '{locName}' onbekend ({string.Join(", ", Enum.GetNames(typeof(WallLocationLine)))})");
                        var prms = ItemParams(it, fouten);
                        if (fouten.Count > 0) continue;
                        if (a!.Length == 3 || b!.Length == 3) row["noot_z"] = "z in start_mm/end_mm genegeerd; de hoogte volgt uit level en base_offset_mm";

                        var wt = ByName(wallTypes, typeName!, "WallType", fouten);
                        var lvl = FindLevel(levels, levelName!, out var lerr);
                        if (lvl == null) fouten.Add(lerr!);
                        Level? top = null;
                        if (topName != null) { top = FindLevel(levels, topName, out var terr); if (top == null) fouten.Add(terr!); }
                        if (wt == null || lvl == null || (topName != null && top == null)) continue;
                        row["wall_type"] = wt.Name; row["level"] = lvl.Name; row["top_level"] = top?.Name;
                        if (wt.Kind == WallKind.Curtain) row["waarschuwing_type"] = "vliesgevel-type: Wall.Create maakt een vliesgevel zonder indeling";
                        double z0 = lvl.Elevation + baseOff / MM;
                        if (top != null && top.Elevation + topOff / MM <= z0 + Tol)
                        { fouten.Add($"bovenkant ({top.Name} {topOff}) ligt niet boven de onderkant ({lvl.Name} {baseOff})"); continue; }
                        var pa = new XYZ(a![0] / MM, a[1] / MM, lvl.Elevation);
                        var pb = new XYZ(b![0] / MM, b[1] / MM, lvl.Elevation);
                        if (pa.DistanceTo(pb) <= shortTol) { fouten.Add("start en eind vallen samen (korter dan de korte-lijntolerantie)"); continue; }
                        row["gepland"] = new Dictionary<string, object?>
                        {
                            ["start_mm"] = new[] { R(a[0]), R(a[1]) }, ["end_mm"] = new[] { R(b[0]), R(b[1]) }, ["lengte_mm"] = R(pa.DistanceTo(pb) * MM),
                            ["base_offset_mm"] = R(baseOff), ["top_offset_mm"] = top != null ? R(topOff) : null, ["height_mm"] = hMm,
                            ["location_line"] = loc.ToString(), ["flip"] = flip, ["structural"] = structural, ["room_bounding"] = roomBounding,
                        };

                        // ── idempotent ──
                        string? comments = CommentsWanted(prms);
                        List<Wall> bestaand;
                        if (comments != null)
                        {
                            bestaand = ByComments(doc!, comments, exact: true, new ElementClassFilter(typeof(Wall))).Cast<Wall>().ToList();
                            row["herkend_op"] = "comments";
                        }
                        else
                        {
                            bestaand = Collect<Wall>(doc!).Where(w => w.GetTypeId() == wt.Id && w.LevelId == lvl.Id && w.Location is LocationCurve lc && lc.Curve is Line l
                                && ((DistXy(l.GetEndPoint(0), pa) <= Tol && DistXy(l.GetEndPoint(1), pb) <= Tol)
                                 || (DistXy(l.GetEndPoint(0), pb) <= Tol && DistXy(l.GetEndPoint(1), pa) <= Tol))).ToList();
                            row["herkend_op"] = "geometrie";
                        }
                        if (bestaand.Count > 1) { fouten.Add($"{bestaand.Count} bestaande wanden passen ({string.Join(", ", bestaand.Select(w => w.Id.Value).Take(10))}); niet uniek"); continue; }
                        if (bestaand.Count == 1)
                        {
                            row["status"] = "bestond";
                            row["element_id"] = bestaand[0].Id.Value;
                            row["wand"] = ReadWall(doc!, bestaand[0]);
                            continue;
                        }
                        row.Remove("herkend_op");
                        if (dryRun) { row["status"] = "zou_maken"; continue; }

                        // ── maken ──
                        ElementId newId = ElementId.InvalidElementId;
                        var paramRows = new Dictionary<string, object?>();
                        if (prms.Count > 0) row["params"] = paramRows;
                        var groupNotes = new List<string>();
                        bool kept = RunGroup(doc!, $"Wand {wt.Name}", groupNotes, () =>
                        {
                            var line = Line.CreateBound(pa, pb);
                            var (ok1, n1) = RunTx(doc!, $"Wand {wt.Name}", () =>
                            {
                                double h = hMm != null ? hMm.Value / MM : Math.Max(top!.Elevation + topOff / MM - z0, 10 / MM);
                                var w = Wall.Create(doc!, line, wt.Id, lvl.Id, h, baseOff / MM, flip, structural)
                                        ?? throw new InvalidOperationException("Wall.Create gaf null");
                                newId = w.Id;
                                void SetP(BuiltInParameter bip, Action<Parameter> set, string label)
                                {
                                    var par = w.get_Parameter(bip) ?? throw new InvalidOperationException($"{label}-parameter ontbreekt");
                                    if (par.IsReadOnly) throw new InvalidOperationException($"{label}-parameter is read-only");
                                    set(par);
                                }
                                SetP(BuiltInParameter.WALL_BASE_OFFSET, par => { if (!par.Set(baseOff / MM)) throw new InvalidOperationException("base offset zetten gaf false"); }, "base offset");
                                if (top != null)
                                {
                                    SetP(BuiltInParameter.WALL_HEIGHT_TYPE, par => { if (!par.Set(top.Id)) throw new InvalidOperationException("top constraint zetten gaf false"); }, "top constraint");
                                    SetP(BuiltInParameter.WALL_TOP_OFFSET, par => { if (!par.Set(topOff / MM)) throw new InvalidOperationException("top offset zetten gaf false"); }, "top offset");
                                }
                                if (roomBounding != null)
                                    SetP(BuiltInParameter.WALL_ATTR_ROOM_BOUNDING, par => { if (!par.Set(roomBounding.Value ? 1 : 0)) throw new InvalidOperationException("room bounding zetten gaf false"); }, "room bounding");
                                if (loc != WallLocationLine.WallCenterline)
                                {
                                    SetP(BuiltInParameter.WALL_KEY_REF_PARAM, par => { if (!par.Set((int)loc)) throw new InvalidOperationException("location line zetten gaf false"); }, "location line");
                                    doc!.Regenerate();
                                    ((LocationCurve)w.Location).Curve = line;   // referentielijn terug op start→eind
                                }
                            }, meldingen);
                            if (!ok1) { fouten.Add($"wand teruggerold: {n1}"); return false; }
                            if (doc!.GetElement(newId) is not Wall) { fouten.Add("read-back: wand niet gevonden na commit"); return false; }
                            if (n1 != null) groupNotes.Add(n1);
                            ZetParams(doc!, newId, prms, paramRows, fouten, meldingen, "Wand: parameters");
                            return true;
                        });
                        foreach (var gn in groupNotes) fouten.Add(gn);
                        if (!kept || doc!.GetElement(newId) is not Wall wall) { row["status"] = "fout"; continue; }
                        row["element_id"] = newId.Value;
                        var wr = ReadWall(doc!, wall);
                        row["wand"] = wr;
                        // read-back toetsen
                        if (wall.Location is LocationCurve rlc && rlc.Curve is Line rl)
                        {
                            var r0 = new XYZ(rl.GetEndPoint(0).X, rl.GetEndPoint(0).Y, pa.Z); var r1 = new XYZ(rl.GetEndPoint(1).X, rl.GetEndPoint(1).Y, pa.Z);
                            if (!((r0.DistanceTo(pa) <= Tol && r1.DistanceTo(pb) <= Tol) || (r0.DistanceTo(pb) <= Tol && r1.DistanceTo(pa) <= Tol)))
                                fouten.Add($"read-back: wandlijn wijkt af ({string.Join(",", Mm3(r0).Take(2))} → {string.Join(",", Mm3(r1).Take(2))})");
                        }
                        double? Rd(BuiltInParameter bip) { try { var x = wall.get_Parameter(bip); return x != null && x.HasValue ? x.AsDouble() * MM : null; } catch { return null; } }
                        if (Math.Abs((Rd(BuiltInParameter.WALL_BASE_OFFSET) ?? 1e9) - baseOff) > 0.5) fouten.Add("read-back: base offset wijkt af");
                        if (top != null)
                        {
                            long? topId = null; try { topId = wall.get_Parameter(BuiltInParameter.WALL_HEIGHT_TYPE)?.AsElementId().Value; } catch { }
                            if (topId != top.Id.Value) fouten.Add("read-back: top constraint wijkt af");
                            if (Math.Abs((Rd(BuiltInParameter.WALL_TOP_OFFSET) ?? 1e9) - topOff) > 0.5) fouten.Add("read-back: top offset wijkt af");
                        }
                        row["status"] = fouten.Count == 0 ? "gemaakt" : "gemaakt_met_fouten";
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); }
                }
                if (dryRun) notes.Add("dry_run: niets gewijzigd; zou_maken is het plan, bestond = al aanwezig (herkend_op)");
                notes.Add("start_mm/end_mm in mm, interne coördinaten; de lijn is de gekozen location_line");
                notes.Add("overlap met een bestaande wand geeft een Revit-warning (in failure_meldingen), geen fout");
                var res = Envelope(doc!, dryRun, items.Count, results, meldingen, notes);
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> ReadWall(Document doc, Wall w)
    {
        var d = new Dictionary<string, object?> { ["id"] = w.Id.Value };
        try { d["type"] = w.WallType?.Name; } catch { }
        try { d["level"] = (doc.GetElement(w.LevelId) as Level)?.Name; } catch { }
        double? Rd(BuiltInParameter bip) { try { var x = w.get_Parameter(bip); return x != null && x.HasValue ? R(x.AsDouble() * MM) : null; } catch { return null; } }
        d["base_offset_mm"] = Rd(BuiltInParameter.WALL_BASE_OFFSET);
        try { var tid = w.get_Parameter(BuiltInParameter.WALL_HEIGHT_TYPE)?.AsElementId(); d["top_level"] = tid == null || tid == ElementId.InvalidElementId ? null : (doc.GetElement(tid) as Level)?.Name; } catch { }
        d["top_offset_mm"] = Rd(BuiltInParameter.WALL_TOP_OFFSET);
        d["hoogte_mm"] = Rd(BuiltInParameter.WALL_USER_HEIGHT_PARAM);
        try { d["location_line"] = ((WallLocationLine)w.get_Parameter(BuiltInParameter.WALL_KEY_REF_PARAM).AsInteger()).ToString(); } catch { }
        try { d["room_bounding"] = w.get_Parameter(BuiltInParameter.WALL_ATTR_ROOM_BOUNDING)?.AsInteger() == 1; } catch { }
        try { d["structural"] = w.StructuralUsage.ToString(); } catch { }
        try { d["flipped"] = w.Flipped; } catch { }
        try { d["dikte_mm"] = R(w.Width * MM); } catch { }
        if (w.Location is LocationCurve lc && lc.Curve is Line l)
        {
            d["start_mm"] = Mm3(l.GetEndPoint(0)); d["end_mm"] = Mm3(l.GetEndPoint(1)); d["lengte_mm"] = R(l.Length * MM);
        }
        d["comments"] = CommentsOf(w);
        return d;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // create_shaft_opening
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// create_shaft_opening — schachtsparing (shaft opening) die vloeren, daken en plafonds van het eigen model snijdt.
    /// params: target_document, dry_run (default TRUE),
    ///   openings:[{base_level, base_offset_mm? (0), top_level, top_offset_mm? (0), boundary_mm:[[x,y], ...] (≥ 3 punten,
    ///              gesloten polygoon; een herhaald eerste punt aan het eind mag), params?{}, comments?}].
    /// doc.Create.NewOpening(baseLevel, topLevel, CurveArray) met de lijnen op de hoogte van het basislevel, daarna
    /// WALL_BASE_OFFSET en WALL_TOP_OFFSET (de offsets van een shaft opening; terugval op "Base Offset"/"Top Offset").
    /// Idempotent: Comments gelijk → bestond; zonder Comments een shaft opening met hetzelfde basislevel en dezelfde
    /// hoekpunten (≤ 1 mm, volgorde vrij) → bestond.
    /// Resultaat per sparing: {index, status, element_id, sparing (read-back: levels, offsets, hoekpunten, oppervlak_m2), fouten}.
    /// </summary>
    public static CommandResponse CreateShaftOpening(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var items = HandlerUtil.Arr(p, "openings").Select(x => x.Clone()).ToList();
        if (items.Count == 0) return Err("openings:[{base_level, base_offset_mm?, top_level, top_offset_mm?, boundary_mm:[[x,y],...], params?, comments?}] is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "create_shaft_opening" };
                double shortTol = app.Application.ShortCurveTolerance;
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var levels = Collect<Level>(doc!).ToList();

                for (int i = 0; i < items.Count; i++)
                {
                    var it = items[i];
                    var fouten = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = i, ["status"] = "fout", ["element_id"] = null, ["fouten"] = fouten };
                    results.Add(row);
                    swallow.Context = $"create_shaft_opening #{i}";
                    try
                    {
                        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("sparing is geen object"); continue; }
                        string? bn = HandlerUtil.Str(it, "base_level"), tn = HandlerUtil.Str(it, "top_level");
                        double bo = Num(it, "base_offset_mm") ?? 0, to = Num(it, "top_offset_mm") ?? 0;
                        if (bn == null) fouten.Add("base_level ontbreekt");
                        if (tn == null) fouten.Add("top_level ontbreekt");
                        var pts = new List<XYZ>();
                        if (it.TryGetProperty("boundary_mm", out var be) && be.ValueKind == JsonValueKind.Array)
                        {
                            int k = 0;
                            foreach (var q in be.EnumerateArray())
                            {
                                var v = q.ValueKind == JsonValueKind.Array ? q.EnumerateArray().Select(NumEl).ToList() : new List<double?>();
                                if (v.Count < 2 || v.Count > 3 || v.Any(x => x == null)) fouten.Add($"boundary_mm[{k}] is geen [x,y]");
                                else pts.Add(new XYZ(v[0]!.Value / MM, v[1]!.Value / MM, 0));
                                k++;
                            }
                        }
                        else fouten.Add("boundary_mm ontbreekt ([[x,y], ...])");
                        var prms = ItemParams(it, fouten);
                        if (fouten.Count > 0) continue;
                        if (pts.Count >= 2 && pts[0].DistanceTo(pts[^1]) <= Tol) pts.RemoveAt(pts.Count - 1);
                        var dedup = new List<XYZ>();
                        foreach (var q in pts) if (dedup.Count == 0 || dedup[^1].DistanceTo(q) > Tol) dedup.Add(q);
                        pts = dedup;
                        if (pts.Count < 3) { fouten.Add("boundary_mm heeft minstens drie verschillende punten nodig"); continue; }
                        for (int k = 0; k < pts.Count; k++)
                            if (pts[k].DistanceTo(pts[(k + 1) % pts.Count]) <= shortTol) fouten.Add($"zijde {k} is korter dan de korte-lijntolerantie");
                        double area = 0;
                        for (int k = 0; k < pts.Count; k++) { var u = pts[k]; var w = pts[(k + 1) % pts.Count]; area += u.X * w.Y - w.X * u.Y; }
                        area = Math.Abs(area) / 2;
                        if (area * MM * MM / 1e6 < 0.0001) fouten.Add("polygoon heeft geen oppervlak");
                        var bl = FindLevel(levels, bn!, out var be1); var tl = FindLevel(levels, tn!, out var te1);
                        if (bl == null) fouten.Add(be1!);
                        if (tl == null) fouten.Add(te1!);
                        if (fouten.Count > 0) continue;
                        if (tl!.Elevation + to / MM <= bl!.Elevation + bo / MM + Tol) { fouten.Add("bovenkant ligt niet boven de onderkant"); continue; }
                        row["base_level"] = bl.Name; row["top_level"] = tl.Name;
                        row["gepland"] = new Dictionary<string, object?>
                        {
                            ["hoekpunten_mm"] = pts.Select(q => new[] { R(q.X * MM), R(q.Y * MM) }).ToList(), ["oppervlak_m2"] = Math.Round(area * MM * MM / 1e6, 4),
                            ["base_offset_mm"] = R(bo), ["top_offset_mm"] = R(to),
                            ["onderkant_abs_mm"] = R((bl.Elevation * MM) + bo), ["bovenkant_abs_mm"] = R((tl.Elevation * MM) + to),
                        };

                        // ── idempotent ──
                        string? comments = CommentsWanted(prms);
                        var shafts = new FilteredElementCollector(doc!).OfCategory(BuiltInCategory.OST_ShaftOpening).WhereElementIsNotElementType().OfType<Opening>().ToList();
                        List<Opening> bestaand;
                        if (comments != null) { bestaand = shafts.Where(o => CommentsOf(o) == comments).ToList(); row["herkend_op"] = "comments"; }
                        else
                        {
                            bestaand = shafts.Where(o => ParamId(o, BuiltInParameter.WALL_BASE_CONSTRAINT) == bl.Id && SameCorners(OpeningCorners(o), pts)).ToList();
                            row["herkend_op"] = "geometrie";
                        }
                        if (bestaand.Count > 1) { fouten.Add($"{bestaand.Count} bestaande sparingen passen ({string.Join(", ", bestaand.Select(o => o.Id.Value))}); niet uniek"); continue; }
                        if (bestaand.Count == 1)
                        {
                            row["status"] = "bestond"; row["element_id"] = bestaand[0].Id.Value; row["sparing"] = ReadShaft(doc!, bestaand[0]);
                            continue;
                        }
                        row.Remove("herkend_op");
                        if (dryRun) { row["status"] = "zou_maken"; continue; }

                        ElementId newId = ElementId.InvalidElementId;
                        var paramRows = new Dictionary<string, object?>();
                        if (prms.Count > 0) row["params"] = paramRows;
                        var groupNotes = new List<string>();
                        bool kept = RunGroup(doc!, "Schachtsparing", groupNotes, () =>
                        {
                            var (ok1, n1) = RunTx(doc!, "Schachtsparing", () =>
                            {
                                var ca = new CurveArray();
                                for (int k = 0; k < pts.Count; k++)
                                {
                                    var u = new XYZ(pts[k].X, pts[k].Y, bl.Elevation);
                                    var w = new XYZ(pts[(k + 1) % pts.Count].X, pts[(k + 1) % pts.Count].Y, bl.Elevation);
                                    ca.Append(Line.CreateBound(u, w));
                                }
                                var op = doc!.Create.NewOpening(bl, tl, ca) ?? throw new InvalidOperationException("NewOpening gaf null");
                                newId = op.Id;
                                doc.Regenerate();
                                SetLen(op, BuiltInParameter.WALL_BASE_OFFSET, "Base Offset", bo / MM);
                                SetLen(op, BuiltInParameter.WALL_TOP_OFFSET, "Top Offset", to / MM);
                            }, meldingen);
                            if (!ok1) { fouten.Add($"sparing teruggerold: {n1}"); return false; }
                            if (doc!.GetElement(newId) is not Opening) { fouten.Add("read-back: sparing niet gevonden na commit"); return false; }
                            if (n1 != null) groupNotes.Add(n1);
                            ZetParams(doc!, newId, prms, paramRows, fouten, meldingen, "Schachtsparing: parameters");
                            return true;
                        });
                        foreach (var gn in groupNotes) fouten.Add(gn);
                        if (!kept || doc!.GetElement(newId) is not Opening opening) { row["status"] = "fout"; continue; }
                        row["element_id"] = newId.Value;
                        var sr = ReadShaft(doc!, opening);
                        row["sparing"] = sr;
                        if (sr["base_offset_mm"] is double rb && Math.Abs(rb - bo) > 0.5) fouten.Add("read-back: base offset wijkt af");
                        if (sr["top_offset_mm"] is double rt && Math.Abs(rt - to) > 0.5) fouten.Add("read-back: top offset wijkt af");
                        if (!SameCorners(OpeningCorners(opening), pts)) fouten.Add("read-back: hoekpunten wijken af");
                        row["status"] = fouten.Count == 0 ? "gemaakt" : "gemaakt_met_fouten";
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); }
                }
                if (dryRun) notes.Add("dry_run: niets gewijzigd; zou_maken is het plan, bestond = al aanwezig (herkend_op)");
                notes.Add("een shaft opening snijdt alleen vloeren, daken en plafonds van het eigen model, niet die van links");
                var res = Envelope(doc!, dryRun, items.Count, results, meldingen, notes);
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static void SetLen(Element el, BuiltInParameter bip, string naam, double v)
    {
        var par = el.get_Parameter(bip);
        if (par == null || par.StorageType != StorageType.Double) par = el.LookupParameter(naam);
        if (par == null) throw new InvalidOperationException($"{naam} ontbreekt op de sparing");
        if (par.IsReadOnly) { if (Math.Abs(par.AsDouble() - v) > 1e-9) throw new InvalidOperationException($"{naam} is read-only"); return; }
        if (!par.Set(v)) throw new InvalidOperationException($"{naam} zetten gaf false");
    }

    private static List<XYZ> OpeningCorners(Opening o)
    {
        var res = new List<XYZ>();
        try
        {
            foreach (Curve c in o.BoundaryCurves) { var q = c.GetEndPoint(0); res.Add(new XYZ(q.X, q.Y, 0)); }
        }
        catch { }
        return res;
    }

    private static bool SameCorners(List<XYZ> a, List<XYZ> b)
        => a.Count == b.Count && a.All(q => b.Any(r => new XYZ(r.X, r.Y, 0).DistanceTo(q) <= Tol));

    private static Dictionary<string, object?> ReadShaft(Document doc, Opening o)
    {
        var d = new Dictionary<string, object?> { ["id"] = o.Id.Value };
        double? Rd(BuiltInParameter bip, string naam)
        {
            try
            {
                var x = o.get_Parameter(bip);
                if (x == null || x.StorageType != StorageType.Double) x = o.LookupParameter(naam);
                return x != null && x.HasValue ? R(x.AsDouble() * MM) : null;
            }
            catch { return null; }
        }
        d["base_level"] = NameOf(doc, ParamId(o, BuiltInParameter.WALL_BASE_CONSTRAINT));
        d["top_level"] = NameOf(doc, ParamId(o, BuiltInParameter.WALL_HEIGHT_TYPE));
        d["base_offset_mm"] = Rd(BuiltInParameter.WALL_BASE_OFFSET, "Base Offset");
        d["top_offset_mm"] = Rd(BuiltInParameter.WALL_TOP_OFFSET, "Top Offset");
        d["hoekpunten_mm"] = OpeningCorners(o).Select(q => new[] { R(q.X * MM), R(q.Y * MM) }).ToList();
        d["comments"] = CommentsOf(o);
        return d;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // place_hosted_family
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// place_hosted_family — wandgehoste family plaatsen in een bestaande wand (of ander host-element).
    /// params: target_document, dry_run (default TRUE),
    ///   items:[{host_id (getal) | host (getal = id, tekst = Comments van de host, exact of eindigend op " " + tekst, zoals
    ///           de scripts '&lt;MARKER&gt; &lt;sleutel&gt;' zetten), family?, type, level, point_mm:[x,y] of [x,y,z] (z boven het level,
    ///           default 0), flip_facing?, flip_hand?, face? ("auto"|"exterior"|"interior", alleen vlakgebonden families),
    ///           params?{}, comments?}].
    /// OneLevelBasedHosted (deur, raam, wandgehoste armatuur): punt geprojecteerd op de wandas, dan
    /// NewFamilyInstance(punt, symbol, host, level, NonStructural). WorkPlaneBased (vlakgebonden, bv. handmelder uit een
    /// "Hosted"-sjabloon): zijvlak van de wand (HostObjectUtils.GetSideFaces), punt geprojecteerd op dat vlak,
    /// NewFamilyInstance(vlakreferentie, punt, wandrichting, symbol). Niet-gehoste families: geweigerd (place_family_instances).
    /// Idempotent: Comments gelijk → bestond; zonder Comments een instantie van hetzelfde type in dezelfde host binnen
    /// 10 mm → bestond. In een dry-run bestaan wanden uit dezelfde batch nog niet: dan host_niet_gevonden.
    /// Resultaat per item: {index, status, element_id, host_id, placement_type, projectie_afstand_mm, locatie (read-back),
    /// params, fouten}.
    /// </summary>
    public static CommandResponse PlaceHostedFamily(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var items = HandlerUtil.Arr(p, "items").Select(x => x.Clone()).ToList();
        if (items.Count == 0) return Err("items:[{host_id|host, family?, type, level, point_mm, flip_facing?, flip_hand?, face?, params?, comments?}] is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "place_hosted_family" };
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var allSyms = Collect<FamilySymbol>(doc!).ToList();
                var levels = Collect<Level>(doc!).ToList();

                for (int i = 0; i < items.Count; i++)
                {
                    var it = items[i];
                    var fouten = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = i, ["status"] = "fout", ["element_id"] = null, ["fouten"] = fouten };
                    results.Add(row);
                    swallow.Context = $"place_hosted_family #{i}";
                    try
                    {
                        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("item is geen object"); continue; }
                        string? famName = HandlerUtil.Str(it, "family"), typeName = HandlerUtil.Str(it, "type"), levelName = HandlerUtil.Str(it, "level");
                        string face = (HandlerUtil.Str(it, "face") ?? "auto").ToLowerInvariant();
                        bool flipF = HandlerUtil.Bool(it, "flip_facing") ?? false, flipH = HandlerUtil.Bool(it, "flip_hand") ?? false;
                        row["family"] = famName; row["type"] = typeName; row["level"] = levelName;
                        if (typeName == null) fouten.Add("type ontbreekt");
                        if (levelName == null) fouten.Add("level ontbreekt");
                        if (face is not ("auto" or "exterior" or "interior")) fouten.Add($"face '{face}' onbekend (auto|exterior|interior)");
                        var pt = Xy(it, "point_mm", fouten);
                        var prms = ItemParams(it, fouten);
                        // host
                        Element? host = null;
                        long? hid = LongProp(it, "host_id");
                        string? hostKey = null;
                        if (hid == null && it.TryGetProperty("host", out var he))
                        {
                            if (he.ValueKind == JsonValueKind.Number && he.TryGetInt64(out var hv)) hid = hv;
                            else if (he.ValueKind == JsonValueKind.String) { if (long.TryParse(he.GetString(), out var hs)) hid = hs; else hostKey = he.GetString(); }
                        }
                        if (hid == null && string.IsNullOrWhiteSpace(hostKey)) fouten.Add("host_id (of host: id of Comments-sleutel) ontbreekt");
                        if (fouten.Count > 0) continue;
                        if (hid != null)
                        {
                            host = doc!.GetElement(new ElementId(hid.Value));
                            if (host == null) { fouten.Add($"host {hid} niet gevonden"); row["status"] = "host_niet_gevonden"; continue; }
                        }
                        else
                        {
                            var hits = ByComments(doc!, hostKey!, exact: false).Where(e => e is HostObject).ToList();
                            if (hits.Count == 0)
                            {
                                fouten.Add($"geen host met Comments '{hostKey}'" + (dryRun ? " (in een dry-run bestaan wanden uit dezelfde batch nog niet)" : ""));
                                row["status"] = "host_niet_gevonden"; continue;
                            }
                            if (hits.Count > 1) { fouten.Add($"{hits.Count} hosts met Comments '{hostKey}' ({string.Join(", ", hits.Select(h => h.Id.Value).Take(10))})"); continue; }
                            host = hits[0];
                            row["host_sleutel"] = hostKey;
                        }
                        row["host_id"] = host.Id.Value;
                        row["host_categorie"] = host.Category?.Name;

                        // type
                        var cands = allSyms.Where(s => s.Name == typeName && (famName == null || s.Family.Name == famName)).ToList();
                        if (cands.Count != 1)
                        {
                            fouten.Add(cands.Count == 0 ? $"type '{typeName}'{(famName != null ? $" van family '{famName}'" : "")} niet gevonden (niet geladen?)"
                                                        : $"type '{typeName}' bestaat in meerdere families ({string.Join(", ", cands.Select(c => c.Family.Name).Distinct().Take(10))}); geef family op");
                            continue;
                        }
                        var sym = cands[0];
                        row["family"] = sym.Family.Name; row["type_id"] = sym.Id.Value; row["category"] = sym.Category?.Name;
                        var ptype = PlacementType(sym.Family);
                        row["placement_type"] = ptype?.ToString();
                        if (ptype is not (FamilyPlacementType.OneLevelBasedHosted or FamilyPlacementType.WorkPlaneBased))
                        {
                            fouten.Add(ptype == FamilyPlacementType.OneLevelBased
                                ? "geweigerd: family is niet gehost (OneLevelBased); gebruik place_family_instances"
                                : $"geweigerd: placement_type {ptype?.ToString() ?? "onbekend"}; alleen OneLevelBasedHosted en WorkPlaneBased (vlakgebonden)");
                            continue;
                        }
                        var level = FindLevel(levels, levelName!, out var lerr);
                        if (level == null) { fouten.Add(lerr!); continue; }
                        row["level"] = level.Name;
                        double zRel = pt!.Length == 3 ? pt[2] : 0;
                        var raw = new XYZ(pt[0] / MM, pt[1] / MM, level.Elevation + zRel / MM);

                        // punt op de host
                        XYZ place = raw;
                        Reference? faceRef = null;
                        XYZ refDir = XYZ.BasisX;
                        if (host is Wall wall && wall.Location is LocationCurve wlc && wlc.Curve is Line wl)
                        {
                            var d0 = new XYZ(wl.Direction.X, wl.Direction.Y, 0).Normalize();
                            var w0 = new XYZ(wl.GetEndPoint(0).X, wl.GetEndPoint(0).Y, raw.Z);
                            double t = (raw - w0).DotProduct(d0);
                            double len = wl.Length;
                            if (t < -Tol || t > len + Tol) { fouten.Add($"punt ligt buiten de wand ({R(t * MM)} mm langs de as, lengte {R(len * MM)} mm)"); continue; }
                            var opAs = w0 + d0 * t;
                            double afst = opAs.DistanceTo(raw);
                            row["projectie_afstand_mm"] = R(afst * MM);
                            double halfW = 0; try { halfW = wall.Width / 2; } catch { }
                            if (afst > halfW + Tol) row["waarschuwing_punt"] = $"punt ligt {R(afst * MM)} mm van de wandas (halve dikte {R(halfW * MM)} mm); op de wand geprojecteerd";
                            refDir = d0;
                            if (ptype == FamilyPlacementType.OneLevelBasedHosted) place = opAs;
                            else
                            {
                                var (fr, fpt, fnaam, ferr) = WallFace(wall, raw, face);
                                if (ferr != null) { fouten.Add(ferr); continue; }
                                faceRef = fr; place = fpt!; row["vlak"] = fnaam;
                            }
                        }
                        else if (ptype == FamilyPlacementType.WorkPlaneBased)
                        { fouten.Add("vlakgebonden plaatsing alleen in een wand met een rechte aslijn"); continue; }
                        else row["waarschuwing_punt"] = "host is geen rechte wand; punt niet geprojecteerd";
                        row["punt_gebruikt_mm"] = Mm3(place);

                        // idempotent
                        string? comments = CommentsWanted(prms);
                        List<FamilyInstance> bestaand;
                        if (comments != null) { bestaand = ByComments(doc!, comments, exact: true, new ElementClassFilter(typeof(FamilyInstance))).Cast<FamilyInstance>().ToList(); row["herkend_op"] = "comments"; }
                        else
                        {
                            bestaand = new FilteredElementCollector(doc!).OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>()
                                .Where(f => f.Symbol?.Id == sym.Id && f.Host?.Id == host.Id && f.Location is LocationPoint lp && lp.Point.DistanceTo(place) <= 10 / MM).ToList();
                            row["herkend_op"] = "geometrie";
                        }
                        if (bestaand.Count > 1) { fouten.Add($"{bestaand.Count} bestaande instanties passen ({string.Join(", ", bestaand.Select(f => f.Id.Value).Take(10))}); niet uniek"); continue; }
                        if (bestaand.Count == 1)
                        {
                            row["status"] = "bestond"; row["element_id"] = bestaand[0].Id.Value; row["locatie"] = ReadLocation(doc!, bestaand[0], level);
                            continue;
                        }
                        row.Remove("herkend_op");
                        if (dryRun) { row["status"] = "zou_plaatsen"; continue; }

                        ElementId newId = ElementId.InvalidElementId;
                        var paramRows = new Dictionary<string, object?>();
                        if (prms.Count > 0) row["params"] = paramRows;
                        var groupNotes = new List<string>();
                        var hostId = host.Id;
                        bool kept = RunGroup(doc!, $"Plaats {sym.Family.Name} : {sym.Name} in host {hostId.Value}", groupNotes, () =>
                        {
                            var (ok1, n1) = RunTx(doc!, $"Plaats {sym.Family.Name} : {sym.Name}", () =>
                            {
                                var s = (FamilySymbol)doc!.GetElement(sym.Id);
                                if (!s.IsActive) { s.Activate(); doc.Regenerate(); }
                                var h = doc.GetElement(hostId) ?? throw new InvalidOperationException("host verdwenen");
                                FamilyInstance fi = faceRef != null
                                    ? doc.Create.NewFamilyInstance(faceRef, place, refDir, s)
                                    : doc.Create.NewFamilyInstance(place, s, h, level, StructuralType.NonStructural);
                                if (fi == null) throw new InvalidOperationException("NewFamilyInstance gaf null");
                                newId = fi.Id;
                                doc.Regenerate();
                                if (flipF) { if (!fi.CanFlipFacing) throw new InvalidOperationException("flip_facing gevraagd maar de family kan niet omgedraaid worden (CanFlipFacing false)"); fi.flipFacing(); }
                                if (flipH) { if (!fi.CanFlipHand) throw new InvalidOperationException("flip_hand gevraagd maar CanFlipHand is false"); fi.flipHand(); }
                                doc.Regenerate();
                                var hb = (doc.GetElement(newId) as FamilyInstance)?.Host;
                                if (hb == null || hb.Id != hostId) throw new InvalidOperationException($"host na plaatsing {(hb == null ? "leeg" : hb.Id.Value.ToString())}, niet {hostId.Value}");
                            }, meldingen);
                            if (!ok1) { fouten.Add($"plaatsen teruggerold: {n1}"); return false; }
                            if (doc!.GetElement(newId) is not FamilyInstance) { fouten.Add("read-back: element niet gevonden na commit"); return false; }
                            if (n1 != null) groupNotes.Add(n1);
                            ZetParams(doc!, newId, prms, paramRows, fouten, meldingen, "Gehoste family: parameters");
                            return true;
                        });
                        foreach (var gn in groupNotes) fouten.Add(gn);
                        if (!kept || doc!.GetElement(newId) is not FamilyInstance placed) { row["status"] = "fout"; continue; }
                        row["element_id"] = newId.Value;
                        row["locatie"] = ReadLocation(doc!, placed, level);
                        long? hidRead = null; try { hidRead = placed.Host?.Id.Value; } catch { }
                        row["host_id_gelezen"] = hidRead;
                        if (hidRead != hostId.Value) fouten.Add($"read-back: host is {hidRead?.ToString() ?? "leeg"}, niet {hostId.Value}");
                        if (placed.Location is LocationPoint lp2)
                        {
                            var dxy = new XYZ(lp2.Point.X - place.X, lp2.Point.Y - place.Y, 0).GetLength() * MM;
                            if (dxy > 1) row["waarschuwing_locatie"] = $"locatie ligt {R(dxy)} mm (in plattegrond) van het gevraagde punt; Revit plaatst op het host-vlak";
                        }
                        try { row["flipped"] = new Dictionary<string, object?> { ["facing"] = placed.FacingFlipped, ["hand"] = placed.HandFlipped }; } catch { }
                        row["status"] = fouten.Count == 0 ? "geplaatst" : "geplaatst_met_fouten";
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); }
                }
                if (dryRun) notes.Add("dry_run: niets gewijzigd; zou_plaatsen is het plan, bestond = al aanwezig (herkend_op)");
                notes.Add("point_mm in mm, interne coördinaten; z boven het level (deuren: de dorpelhoogte komt uit de family, z telt dan niet)");
                var res = Envelope(doc!, dryRun, items.Count, results, meldingen, notes);
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    /// <summary>Zijvlak van een wand voor een vlakgebonden family: exterior/interior, of auto (het vlak het dichtst bij het
    /// punt). Geeft (referentie, punt op het vlak, naam, fout).</summary>
    private static (Reference? r, XYZ? pt, string? naam, string? err) WallFace(Wall wall, XYZ raw, string keuze)
    {
        var kandidaten = new List<(Reference r, PlanarFace f, string naam)>();
        foreach (var (slt, naam) in new[] { (ShellLayerType.Exterior, "exterior"), (ShellLayerType.Interior, "interior") })
        {
            IList<Reference> refs;
            try { refs = HostObjectUtils.GetSideFaces(wall, slt); } catch { continue; }
            foreach (var r in refs)
            {
                try { if (wall.GetGeometryObjectFromReference(r) is PlanarFace pf) kandidaten.Add((r, pf, naam)); } catch { }
            }
        }
        if (kandidaten.Count == 0) return (null, null, null, "geen vlak zijvlak van de wand gevonden (HostObjectUtils.GetSideFaces)");
        var pool = keuze == "auto" ? kandidaten : kandidaten.Where(k => k.naam == keuze).ToList();
        if (pool.Count == 0) return (null, null, null, $"geen {keuze}-zijvlak gevonden");
        double Dist((Reference r, PlanarFace f, string naam) k) => Math.Abs((raw - k.f.Origin).DotProduct(k.f.FaceNormal));
        var best = pool.OrderBy(Dist).First();
        var n = best.f.FaceNormal;
        var q = raw - n * (raw - best.f.Origin).DotProduct(n);
        return (best.r, q, best.naam, null);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // reload_link
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// reload_link — RevitLinkType herladen, zodat het hoofdmodel wijzigingen in de link ziet (bv. RE na nieuwe wanden in
    /// Bouwkundig: room bounding). Aanvulling op relink_links (dat zet links om naar bestanden in andere mappen, LoadFrom)
    /// en load_links (nieuwe links maken): dit commando houdt het pad en laadt opnieuw.
    /// params: target_document, dry_run (default TRUE), link_titles?: [naam, ...] (naam van het RevitLinkType, met of zonder
    /// ".rvt", of de Title van het gelinkte document; zonder lijst: alle niet-geneste links).
    /// Geladen link → RevitLinkType.Reload; niet geladen → Load. Buiten een transactie (eigen Revit-operatie).
    /// Resultaat per link: {index, naam, type_id, status: zou_herladen|zou_laden|herladen|geladen|fout, load_result,
    /// geladen_voor, geladen_na, status_voor, status_na, pad, fouten}; niet_gevonden: gevraagde namen zonder link.
    /// Let op: is het gelinkte model als hoofddocument open in deze sessie, dan kan Revit het laden weigeren.
    /// </summary>
    public static CommandResponse ReloadLink(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var wanted = HandlerUtil.Arr(p, "link_titles").Where(e => e.ValueKind == JsonValueKind.String).Select(e => e.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        var single = HandlerUtil.Str(p, "link_title");
        if (single != null) wanted.Add(single);

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "reload_link" };
                var notes = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                static string Kaal(string s) => s.EndsWith(".rvt", StringComparison.OrdinalIgnoreCase) ? s[..^4] : s;
                var instDocs = new Dictionary<long, string?>();
                foreach (var li in Collect<RevitLinkInstance>(doc!))
                {
                    try { var tid = li.GetTypeId().Value; if (!instDocs.ContainsKey(tid) || instDocs[tid] == null) instDocs[tid] = li.GetLinkDocument()?.Title; } catch { }
                }
                var types = Collect<RevitLinkType>(doc!).OrderBy(t => t.Name).ToList();
                var gevonden = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                int i = 0;
                foreach (var lt in types)
                {
                    string naam = lt.Name;
                    instDocs.TryGetValue(lt.Id.Value, out var ldTitle);
                    string? match = wanted.Count == 0 ? naam : wanted.FirstOrDefault(w =>
                        string.Equals(Kaal(w), Kaal(naam), StringComparison.OrdinalIgnoreCase)
                        || (ldTitle != null && string.Equals(Kaal(w), Kaal(ldTitle), StringComparison.OrdinalIgnoreCase)));
                    if (match == null) continue;
                    gevonden.Add(match);
                    bool nested = false; try { nested = lt.IsNestedLink; } catch { }
                    var fouten = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = i++, ["naam"] = naam, ["type_id"] = lt.Id.Value, ["status"] = "fout", ["fouten"] = fouten };
                    results.Add(row);
                    if (nested) { if (wanted.Count > 0) fouten.Add("geneste link: herlaad het model dat hem bevat"); else results.Remove(row); continue; }
                    bool loaded = false; try { loaded = RevitLinkType.IsLoaded(doc!, lt.Id); } catch { }
                    row["geladen_voor"] = loaded;
                    try { row["status_voor"] = lt.GetLinkedFileStatus().ToString(); } catch { }
                    try { var efr = lt.GetExternalFileReference(); row["pad"] = efr == null ? null : ModelPathUtils.ConvertModelPathToUserVisiblePath(efr.GetAbsolutePath()); } catch { }
                    row["linked_document"] = ldTitle;
                    if (dryRun) { row["status"] = loaded ? "zou_herladen" : "zou_laden"; continue; }
                    swallow.Context = $"reload_link {naam}";
                    try
                    {
                        var lr = loaded ? lt.Reload() : lt.Load();
                        row["load_result"] = lr?.LoadResult.ToString();
                        bool na = false; try { na = RevitLinkType.IsLoaded(doc!, lt.Id); } catch { }
                        row["geladen_na"] = na;
                        try { row["status_na"] = lt.GetLinkedFileStatus().ToString(); } catch { }
                        if (lr != null && lr.LoadResult == LinkLoadResultType.LinkLoaded && na) row["status"] = loaded ? "herladen" : "geladen";
                        else fouten.Add($"laden mislukt: {lr?.LoadResult.ToString() ?? "geen resultaat"}");
                    }
                    catch (Exception ex) { fouten.Add(ex.InnerException?.Message ?? ex.Message); }
                }
                var nietGevonden = wanted.Where(w => !gevonden.Contains(w)).ToList();
                if (dryRun) notes.Add("dry_run: niets geladen; zou_herladen/zou_laden is het plan");
                var res = new Dictionary<string, object?>
                {
                    ["document"] = doc!.Title,
                    ["dry_run"] = dryRun,
                    ["tellers"] = results.GroupBy(r => (string?)r["status"] ?? "?").ToDictionary(g => g.Key, g => g.Count()),
                    ["results"] = results,
                    ["niet_gevonden"] = nietGevonden,
                    ["beschikbaar"] = nietGevonden.Count > 0 ? types.Select(t => t.Name).ToList() : null,
                    ["notes"] = notes,
                };
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 1800000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }
}
