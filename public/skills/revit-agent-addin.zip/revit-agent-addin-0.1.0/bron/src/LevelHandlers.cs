using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// get_levels — enumerate every Level in a document. The views carry-over
/// mapping workbook needs the COMPLETE level set of the target (a level may exist without any view —
/// e.g. structural top/bottom-of-floor levels or Building Storey levels that have no plan yet), plus
/// the elevation of source levels so a "<nieuw aanmaken>" mapping can recreate the level at the right
/// height.
///
/// Deriving levels from view.associated_level (the first cut) was incomplete: it only sees levels that
/// already carry a plan view. This enumerates Level elements directly.
///
/// Per level we return: name, elevation (feet = Revit internal, and meters for humans), building_story
/// (LEVEL_IS_BUILDING_STORY — the reliable architectural-story flag), the level Type name, and a full
/// instance-parameter dump (name+value). The param dump is locale-proof: whatever the NL-Revit calls
/// the "Structural" flag, it is visible without guessing a BuiltInParameter that may not exist.
///
/// params: target_document.
/// </summary>
public static class LevelHandlers
{
    public static CommandResponse GetLevels(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var levels = new List<Dictionary<string, object?>>();
                foreach (var lv in new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>())
                {
                    bool? buildingStory = null;
                    try
                    {
                        var bs = lv.get_Parameter(BuiltInParameter.LEVEL_IS_BUILDING_STORY);
                        if (bs != null) buildingStory = bs.AsInteger() == 1;
                    }
                    catch { }

                    string? typeName = null;
                    try { typeName = doc.GetElement(lv.GetTypeId())?.Name; } catch { }

                    var prms = new List<Dictionary<string, object?>>();
                    try
                    {
                        foreach (Parameter par in lv.GetOrderedParameters())
                        {
                            if (par?.Definition == null) continue;
                            string? value = null;
                            try
                            {
                                value = par.AsValueString() ?? par.AsString();
                                if (value == null && par.StorageType == StorageType.Integer) value = par.AsInteger().ToString();
                            }
                            catch { }
                            prms.Add(new Dictionary<string, object?> { ["name"] = par.Definition.Name, ["value"] = value });
                        }
                    }
                    catch { }

                    levels.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(lv.Id),
                        ["name"] = lv.Name,
                        ["elevation"] = lv.Elevation,                              // Revit internal units (feet)
                        ["elevation_m"] = Math.Round(lv.Elevation * 0.3048, 4),    // meters, for humans
                        ["building_story"] = buildingStory,
                        ["type_name"] = typeName,
                        ["params"] = prms,
                    });
                }
                levels.Sort((a, b) =>
                {
                    double ea = a["elevation"] is double da ? da : 0, eb = b["elevation"] is double db ? db : 0;
                    return ea.CompareTo(eb);
                });

                return (object)new Dictionary<string, object?>
                { ["document"] = doc.Title, ["level_count"] = levels.Count, ["levels"] = levels };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
