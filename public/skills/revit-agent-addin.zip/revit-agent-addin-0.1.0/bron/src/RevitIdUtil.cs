// Shared utility for converting Revit ElementId to int across Revit versions.
// Revit 2026 changed ElementId.Value from int to long, requiring explicit downcast.
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public static class RevitIdUtil
{
    public static int Fid(ElementId id) => (int)id.Value;
}
