using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;

namespace RevitAgent.Addin;

/// <summary>
/// place_family_grid (Package layer) — place a loadable family symbol on a rectangular
/// grid in the target doc and prefill instance parameters. Coordinates are in MILLIMETRES (NLRS is metric)
/// and converted to Revit's internal feet. The symbol is loaded from family_path first when it isn't
/// already present. Each instance is placed + parameterised independently and reported.
///
/// params:
///   target_document : string (required)
///   family_symbol   : string (required) — FamilySymbol (type) name
///   family_name     : string (optional) — disambiguate when the type name repeats across families
///   family_path     : string (optional) — .rfa to load when the symbol isn't present
///   level_name      : string (optional) — host level (else the doc's first level)
///   origin_mm       : [x, y]  (default [0, 0])
///   spacing_mm      : [dx, dy] (default [1000, 1000])
///   count           : [cols, rows] (default [1, 1])
///   instance_params : { name: value }  — string/number instance parameters to set on each placed instance
///   dry_run : bool (default true) · save_first : bool (default false)
/// </summary>
public static class PlaceFamilyHandlers
{
    private const double MM = 304.8;  // mm per foot

    public static CommandResponse PlaceFamilyGrid(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        string? symName = HandlerUtil.Str(p, "family_symbol");
        string? famName = HandlerUtil.Str(p, "family_name");
        string? famPath = HandlerUtil.Str(p, "family_path");
        string? levelName = HandlerUtil.Str(p, "level_name");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool saveFirst = HandlerUtil.Bool(p, "save_first", false);
        if (target == null || symName == null)
            return new CommandResponse { Success = false, Error = "Parameters 'target_document' and 'family_symbol' are required" };

        double[] origin = Pair(p, "origin_mm", 0, 0);
        double[] spacing = Pair(p, "spacing_mm", 1000, 1000);
        int cols = 1, rows = 1;
        if (p != null && p.TryGetValue("count", out var cEl) && cEl.ValueKind == JsonValueKind.Array)
        {
            var a = cEl.EnumerateArray().ToList();
            if (a.Count > 0 && a[0].TryGetInt32(out var c0)) cols = Math.Max(1, c0);
            if (a.Count > 1 && a[1].TryGetInt32(out var c1)) rows = Math.Max(1, c1);
        }
        var instParams = new Dictionary<string, JsonElement>();
        if (p != null && p.TryGetValue("instance_params", out var ipEl) && ipEl.ValueKind == JsonValueKind.Object)
            foreach (var pr in ipEl.EnumerateObject()) instParams[pr.Name] = pr.Value;

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target) ?? throw new Exception($"target_document '{target}' is not open");

                FamilySymbol? Resolve() => new FilteredElementCollector(doc).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>()
                    .FirstOrDefault(fs => fs.Name == symName && (famName == null || fs.Family.Name == famName));

                var results = new List<Dictionary<string, object?>>();
                var positions = new List<XYZ>();
                Level? level = levelName != null
                    ? new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().FirstOrDefault(l => l.Name == levelName)
                    : new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().OrderBy(l => l.Elevation).FirstOrDefault();
                double z = level?.Elevation ?? 0.0;
                for (int r = 0; r < rows; r++)
                    for (int c = 0; c < cols; c++)
                        positions.Add(new XYZ((origin[0] + c * spacing[0]) / MM, (origin[1] + r * spacing[1]) / MM, z));

                if (dryRun)
                {
                    var sym0 = Resolve();
                    return (object)new Dictionary<string, object?>
                    {
                        ["dry_run"] = true, ["target_document"] = doc.Title,
                        ["symbol_present"] = sym0 != null, ["would_place"] = positions.Count,
                        ["level"] = level?.Name, ["needs_load"] = sym0 == null ? famPath : null
                    };
                }

                string? saved = null;
                if (saveFirst) { try { doc.Save(); saved = doc.Title; } catch (Exception ex) { throw new Exception($"save_first failed: {ex.Message}"); } }

                int placed = 0;
                using (var t = new Transaction(doc, "place family grid"))
                {
                    t.Start();
                    var sym = Resolve();
                    if (sym == null && famPath != null && doc.LoadFamily(famPath, out var fam) && fam != null)
                        sym = Resolve();
                    if (sym == null) { t.RollBack(); throw new Exception($"family_symbol '{symName}' niet gevonden (en niet te laden)"); }
                    if (!sym.IsActive) sym.Activate();

                    foreach (var xyz in positions)
                    {
                        try
                        {
                            var inst = level != null
                                ? doc.Create.NewFamilyInstance(xyz, sym, level, StructuralType.NonStructural)
                                : doc.Create.NewFamilyInstance(xyz, sym, StructuralType.NonStructural);
                            var setDone = new List<string>();
                            foreach (var (pn, pv) in instParams)
                            {
                                var prm = inst.LookupParameter(pn);
                                if (prm != null && !prm.IsReadOnly && SetParam(prm, pv)) setDone.Add(pn);
                            }
                            placed++;
                            results.Add(new() { ["element_id"] = RevitIdUtil.Fid(inst.Id), ["status"] = "placed", ["params_set"] = setDone });
                        }
                        catch (Exception ex) { results.Add(new() { ["status"] = "error", ["reason"] = ex.Message }); }
                    }
                    t.Commit();
                }
                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = false, ["target_document"] = doc.Title, ["saved_document"] = saved,
                    ["placed"] = placed, ["level"] = level?.Name, ["results"] = results
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static bool SetParam(Parameter prm, JsonElement v)
    {
        try
        {
            switch (prm.StorageType)
            {
                case StorageType.String: return prm.Set(v.ValueKind == JsonValueKind.String ? v.GetString() : v.ToString());
                case StorageType.Integer:
                    if (v.ValueKind == JsonValueKind.True) return prm.Set(1);
                    if (v.ValueKind == JsonValueKind.False) return prm.Set(0);
                    return v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var iv) && prm.Set(iv);
                case StorageType.Double:
                    return v.ValueKind == JsonValueKind.Number && prm.Set(v.GetDouble());
                default: return false;
            }
        }
        catch { return false; }
    }

    private static double[] Pair(Dictionary<string, JsonElement>? p, string key, double d0, double d1)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
        {
            var a = el.EnumerateArray().ToList();
            double x = a.Count > 0 && a[0].ValueKind == JsonValueKind.Number ? a[0].GetDouble() : d0;
            double y = a.Count > 1 && a[1].ValueKind == JsonValueKind.Number ? a[1].GetDouble() : d1;
            return new[] { x, y };
        }
        return new[] { d0, d1 };
    }
}
