using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// inventory_copy — non-destructive "what comes along" probe for cross-document element copy
/// (for example View Types, View Templates and View Filters from a source project).
///
/// Why a scratch canvas instead of a rolled-back transaction: the cross-document overload of
/// ElementTransformUtils.CopyElements commits its OWN transaction in the destination — it cannot be
/// wrapped in a caller transaction and rolled back. So we never copy into the real target.
/// Instead we copy into a disposable open document (default: the empty "Project1"), enumerate every
/// element that materialised (the full dependency drag-along Revit pulls in — filters, materials,
/// annotations, fill/line patterns the templates reference), name-diff each against the real target to
/// flag what is NEW-to-target, then delete the copied elements again so the canvas stays reusable.
/// Nothing is saved; the real target is read-only here.
///
/// params:
///   source_document  : string  (required) — title of the project to copy FROM (e.g. Bron_…)
///   target_document  : string  (optional) — title used only for the name-diff (e.g. Doel_…). When set,
///                       each dragged-in element is flagged already_in_target by class+name.
///   scratch_document : string  (optional) — title of the disposable canvas. Default: the first open
///                       non-family doc that is neither source nor target (typically "Project1").
///   mode             : string  (optional) — what to copy when source_element_ids is absent:
///                       "view_templates_and_types" (default) | "view_templates" | "view_family_types".
///   source_element_ids : [int] (optional) — explicit copy set; overrides mode.
///   cleanup          : bool    (default true) — delete the copied elements from the canvas afterwards.
/// </summary>
public static class CopyInventoryHandlers
{
    // Classes the user just cleaned up in the target and does NOT want silently re-imported. A dragged-in
    // element of one of these classes that is not already in the target is a swap/cleanup concern.
    private static readonly HashSet<string> ConcernClasses = new()
    {
        "Material", "FillPatternElement", "FilledRegionType", "LinePatternElement",
        "TextNoteType", "DimensionType", "FamilySymbol", "AnnotationSymbolType"
    };

    private sealed class UseDestinationTypesHandler : IDuplicateTypeNamesHandler
    {
        // Type-name collisions map to the canvas's existing type instead of aborting the whole copy.
        public DuplicateTypeAction OnDuplicateTypeNamesFound(DuplicateTypeNamesHandlerArgs args)
            => DuplicateTypeAction.UseDestinationTypes;
    }

    private sealed class SwallowWarnings : IFailuresPreprocessor
    {
        // Cross-document copy emits warnings (duplicate types, type-name remaps). Delete them so a
        // warning never rolls back the probe transaction; real errors still surface.
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            foreach (var f in fa.GetFailureMessages())
                if (f.GetSeverity() == FailureSeverity.Warning)
                    fa.DeleteWarning(f);
            return FailureProcessingResult.Continue;
        }
    }

    public static CommandResponse InventoryCopy(CommandRequest request)
    {
        var p = request.Params;
        string? sourceTitle = GetString(p, "source_document");
        string? targetTitle = GetString(p, "target_document");
        string? scratchTitle = GetString(p, "scratch_document");
        string mode = GetString(p, "mode") ?? "view_templates_and_types";
        bool cleanup = GetBool(p, "cleanup", true);
        var explicitIds = GetIntArray(p, "source_element_ids");

        if (sourceTitle == null)
            return new CommandResponse { Success = false, Error = "Parameter 'source_document' is required" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? src = null, tgt = null, scratch = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == sourceTitle) src = d;
                    if (targetTitle != null && d.Title == targetTitle) tgt = d;
                }
                if (src == null) throw new Exception($"source_document '{sourceTitle}' is not open");

                // Exclude source/target from the scratch choice BY TITLE — never ReferenceEquals. Each
                // `app.Application.Documents` enumeration can yield fresh managed wrappers, so a wrapper
                // from this loop is not reference-equal to src/tgt captured in the previous loop even for
                // the same logical document. Reference-based exclusion could let the target itself be chosen as
                // scratch and silently mutated.
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == sourceTitle || (targetTitle != null && d.Title == targetTitle)) continue;
                    if (d.IsFamilyDocument) continue;
                    if (scratchTitle != null) { if (d.Title == scratchTitle) { scratch = d; break; } }
                    // Zonder scratch_document alleen een nooit bewaard model als kladblok (geen pad): een proef mag
                    // nooit kopiëren en verwijderen in een echt model van de gebruiker (breedtest 25-11-2026).
                    else if (string.IsNullOrEmpty(d.PathName)) { scratch = d; break; }
                }
                if (scratch == null)
                    throw new Exception(scratchTitle != null
                        ? $"scratch_document '{scratchTitle}' not found among open projects (it must differ from source_document and target_document)"
                        : "no disposable scratch document open: open an empty, unsaved project (e.g. Project1) or pass scratch_document");
                if (tgt != null && scratch.Title == tgt.Title)
                    throw new Exception("scratch document must not be the target document");

                var ids = ResolveSourceIds(src, mode, explicitIds);
                if (ids.Count == 0)
                    throw new Exception("no source elements resolved for copy (empty selection)");

                var before = AllElementIds(scratch);

                var opts = new CopyPasteOptions();
                opts.SetDuplicateTypeNamesHandler(new UseDestinationTypesHandler());
                ICollection<ElementId> copied;
                // Cross-document CopyElements requires an open transaction in the destination (canvas).
                using (var tcopy = new Transaction(scratch, "inventory_copy probe"))
                {
                    tcopy.Start();
                    var fho = tcopy.GetFailureHandlingOptions();
                    fho.SetFailuresPreprocessor(new SwallowWarnings());
                    fho.SetClearAfterRollback(true);
                    tcopy.SetFailureHandlingOptions(fho);
                    try
                    {
                        copied = ElementTransformUtils.CopyElements(src, ids, scratch, Transform.Identity, opts);
                    }
                    catch (Exception ex)
                    {
                        tcopy.RollBack();
                        throw new Exception($"CopyElements failed: {ex.Message}");
                    }
                    tcopy.Commit();
                }

                var after = AllElementIds(scratch);
                var newIds = after.Where(id => !before.Contains(id)).ToList();

                var targetIndex = tgt != null ? BuildNameClassIndex(tgt) : null;

                var items = new List<Dictionary<string, object?>>();
                var byClass = new Dictionary<string, int>();
                var concerns = new List<Dictionary<string, object?>>();
                foreach (var nid in newIds)
                {
                    var el = scratch.GetElement(nid);
                    if (el == null || !el.IsValidObject) continue;
                    string cls = el.GetType().Name;
                    string? cat = null; try { cat = el.Category?.Name; } catch { }
                    string nm = ""; try { nm = el.Name ?? ""; } catch { }
                    bool isTemplate = false; try { isTemplate = el is View vv && vv.IsTemplate; } catch { }
                    bool inTarget = targetIndex != null && targetIndex.Contains(cls + "|" + nm);

                    byClass[cls] = byClass.GetValueOrDefault(cls) + 1;
                    var row = new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(nid),
                        ["class"] = cls,
                        ["category"] = cat,
                        ["name"] = nm,
                        ["is_template"] = isTemplate,
                        ["already_in_target"] = inTarget
                    };
                    items.Add(row);
                    if (ConcernClasses.Contains(cls) && !inTarget)
                        concerns.Add(row);
                }

                int cleaned = 0;
                if (cleanup && newIds.Count > 0)
                {
                    using var t = new Transaction(scratch, "inventory_copy cleanup");
                    t.Start();
                    foreach (var nid in newIds)
                    {
                        try
                        {
                            var el = scratch.GetElement(nid);
                            if (el != null && el.IsValidObject) { scratch.Delete(nid); cleaned++; }
                        }
                        catch { /* cascade-deleted or pinned — canvas is disposable, ignore */ }
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["source_document"] = src.Title,
                    ["target_document"] = tgt?.Title,
                    ["scratch_document"] = scratch.Title,
                    ["mode"] = explicitIds != null && explicitIds.Count > 0 ? "explicit_ids" : mode,
                    ["requested_copy_count"] = ids.Count,
                    ["directly_copied_count"] = copied.Count,
                    ["new_element_count"] = items.Count,
                    ["by_class"] = byClass.OrderByDescending(kv => kv.Value)
                                          .ToDictionary(kv => kv.Key, kv => (object?)kv.Value),
                    ["concern_count"] = concerns.Count,
                    ["drag_along_concerns"] = concerns,
                    ["elements"] = items,
                    ["cleaned_up"] = cleaned,
                    ["cleanup"] = cleanup
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>
    /// copy_elements — the real apply counterpart of inventory_copy: copies the view set from source
    /// INTO the target and commits it. Same drag-along as the probe, but it lands for real.
    /// Reports every newly-created element (the manifest), flags which ones duplicate a name that
    /// already existed in the target pre-copy (so the post-copy material/filter remediation knows what
    /// to swap), and lists the cleaned-up-category concerns. save_first writes a numbered backup first.
    ///
    /// params: source_document, target_document (required) · mode | source_element_ids ·
    ///         save_first (default false) · dry_run (default true; when true it delegates to a scratch
    ///         probe so nothing lands; use inventory_copy directly for richer probe output).
    /// </summary>
    public static CommandResponse CopyElements(CommandRequest request)
    {
        var p = request.Params;
        string? sourceTitle = GetString(p, "source_document");
        string? targetTitle = GetString(p, "target_document");
        string mode = GetString(p, "mode") ?? "view_templates";
        bool saveFirst = GetBool(p, "save_first", false);
        bool dryRun = GetBool(p, "dry_run", true);
        bool skipDuplicates = GetBool(p, "skip_duplicates", false);
        var explicitIds = GetIntArray(p, "source_element_ids");

        if (sourceTitle == null)
            return new CommandResponse { Success = false, Error = "Parameter 'source_document' is required" };
        if (targetTitle == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required (the doc to copy INTO)" };
        if (sourceTitle == targetTitle)
            return new CommandResponse { Success = false, Error = "source_document and target_document must differ" };

        // dry_run: copy_elements has no native landing-preview, and re-using a real copy as a probe is
        // forbidden (verification-recipe principle 2/3 — it is destructive + non-idempotent). Delegate to
        // the proven non-destructive inventory_copy scratch probe, which reports already_in_target per
        // element. This MUST happen here on the TCP-handler thread, BEFORE this command's own
        // MainThreadDispatcher.GetResult: InventoryCopy runs its own GetResult, and nesting one dispatch
        // inside another on the Idling-driven main thread would deadlock. 
        if (dryRun)
        {
            EnsureModeParam(request, mode);  // probe exactly the set the real copy would land
            var probe = InventoryCopy(request);
            if (probe.Success && probe.Data is Dictionary<string, object?> pd)
            {
                pd["dry_run"] = true;
                pd["note"] = "copy_elements dry_run delegated to inventory_copy (scratch probe); nothing "
                           + "landed in target. already_in_target=true means a re-copy would be a duplicate.";
            }
            return probe;
        }

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? src = null, tgt = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == sourceTitle) src = d;
                    if (d.Title == targetTitle) tgt = d;
                }
                if (src == null) throw new Exception($"source_document '{sourceTitle}' is not open");
                if (tgt == null) throw new Exception($"target_document '{targetTitle}' is not open");

                var ids = ResolveSourceIds(src, mode, explicitIds);
                if (ids.Count == 0)
                    throw new Exception("no source elements resolved for copy (empty selection)");

                // Names already present in the target BEFORE the copy — used to flag duplicates.
                var beforeNames = BuildNameClassIndex(tgt);
                var before = AllElementIds(tgt);

                // skip_duplicates makes copy idempotent: drop every source element
                // whose class|name already exists in the target, so a re-copy lands nothing instead of
                // duplicating. duplicate_of_existing alone only *flags* dupes — it never prevented them.
                var skippedExisting = new List<Dictionary<string, object?>>();
                if (skipDuplicates)
                {
                    var kept = new List<ElementId>();
                    foreach (var id in ids)
                    {
                        var se = src.GetElement(id);
                        if (se == null) { kept.Add(id); continue; }
                        string scls = se.GetType().Name;
                        string snm = ""; try { snm = se.Name ?? ""; } catch { }
                        if (!string.IsNullOrEmpty(snm) && beforeNames.Contains(scls + "|" + snm))
                            skippedExisting.Add(new Dictionary<string, object?>
                            { ["element_id"] = RevitIdUtil.Fid(id), ["class"] = scls, ["name"] = snm });
                        else kept.Add(id);
                    }
                    ids = kept;
                    if (ids.Count == 0)
                        return (object)new Dictionary<string, object?>
                        {
                            ["source_document"] = src.Title,
                            ["target_document"] = tgt.Title,
                            ["mode"] = explicitIds != null && explicitIds.Count > 0 ? "explicit_ids" : mode,
                            ["save_first"] = saveFirst,
                            ["saved_document"] = (string?)null,
                            ["skip_duplicates"] = true,
                            ["status"] = "all_already_present",
                            ["requested_copy_count"] = skippedExisting.Count,
                            ["skipped_existing_count"] = skippedExisting.Count,
                            ["skipped_existing"] = skippedExisting,
                            ["new_element_count"] = 0,
                            ["elements"] = new List<Dictionary<string, object?>>()
                        };
                }

                // Backup gate: save the target first (Revit writes a numbered backup) before any mutation.
                string? saved = null;
                if (saveFirst)
                {
                    try { tgt.Save(); saved = tgt.Title; }
                    catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                }

                var opts = new CopyPasteOptions();
                opts.SetDuplicateTypeNamesHandler(new UseDestinationTypesHandler());
                ICollection<ElementId> copied;
                using (var tcopy = new Transaction(tgt, "copy_elements view-set"))
                {
                    tcopy.Start();
                    var fho = tcopy.GetFailureHandlingOptions();
                    fho.SetFailuresPreprocessor(new SwallowWarnings());
                    fho.SetClearAfterRollback(true);
                    tcopy.SetFailureHandlingOptions(fho);
                    try
                    {
                        copied = ElementTransformUtils.CopyElements(src, ids, tgt, Transform.Identity, opts);
                    }
                    catch (Exception ex)
                    {
                        tcopy.RollBack();
                        throw new Exception($"CopyElements failed (rolled back, nothing landed): {ex.Message}");
                    }
                    tcopy.Commit();
                }

                var after = AllElementIds(tgt);
                var newIds = after.Where(id => !before.Contains(id)).ToList();

                var items = new List<Dictionary<string, object?>>();
                var byClass = new Dictionary<string, int>();
                var concerns = new List<Dictionary<string, object?>>();
                foreach (var nid in newIds)
                {
                    var el = tgt.GetElement(nid);
                    if (el == null || !el.IsValidObject) continue;
                    string cls = el.GetType().Name;
                    string? cat = null; try { cat = el.Category?.Name; } catch { }
                    string nm = ""; try { nm = el.Name ?? ""; } catch { }
                    bool isTemplate = false; try { isTemplate = el is View vv && vv.IsTemplate; } catch { }
                    bool dup = beforeNames.Contains(cls + "|" + nm);
                    byClass[cls] = byClass.GetValueOrDefault(cls) + 1;
                    var row = new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(nid),
                        ["class"] = cls,
                        ["category"] = cat,
                        ["name"] = nm,
                        ["is_template"] = isTemplate,
                        ["duplicate_of_existing"] = dup
                    };
                    items.Add(row);
                    if (ConcernClasses.Contains(cls))
                        concerns.Add(row);
                }

                return (object)new Dictionary<string, object?>
                {
                    ["source_document"] = src.Title,
                    ["target_document"] = tgt.Title,
                    ["mode"] = explicitIds != null && explicitIds.Count > 0 ? "explicit_ids" : mode,
                    ["save_first"] = saveFirst,
                    ["saved_document"] = saved,
                    ["skip_duplicates"] = skipDuplicates,
                    ["skipped_existing_count"] = skippedExisting.Count,
                    ["skipped_existing"] = skippedExisting,
                    ["requested_copy_count"] = ids.Count,
                    ["directly_copied_count"] = copied.Count,
                    ["new_element_count"] = items.Count,
                    ["by_class"] = byClass.OrderByDescending(kv => kv.Value)
                                          .ToDictionary(kv => kv.Key, kv => (object?)kv.Value),
                    ["concern_count"] = concerns.Count,
                    ["drag_along_concerns"] = concerns,
                    ["elements"] = items
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // Resolve the source copy set from an explicit id list or a mode keyword.
    private static List<ElementId> ResolveSourceIds(Document src, string mode, List<int>? explicitIds)
    {
        var ids = new List<ElementId>();
        if (explicitIds != null && explicitIds.Count > 0)
        {
            foreach (var i in explicitIds) ids.Add(new ElementId((long)i));
            return ids;
        }
        bool wantTypes = mode.Contains("type");
        bool wantTemplates = mode.Contains("template");
        if (!wantTypes && !wantTemplates)
            throw new Exception($"unknown mode '{mode}' (expected view_templates_and_types|view_templates|view_family_types)");
        if (wantTypes)
            foreach (var e in new FilteredElementCollector(src).OfClass(typeof(ViewFamilyType)))
                ids.Add(e.Id);
        if (wantTemplates)
            foreach (var v in new FilteredElementCollector(src).OfClass(typeof(View)).Cast<View>())
                if (v.IsTemplate) ids.Add(v.Id);
        return ids;
    }

    private static HashSet<ElementId> AllElementIds(Document d)
    {
        var s = new HashSet<ElementId>();
        foreach (var id in new FilteredElementCollector(d).WhereElementIsNotElementType().ToElementIds()) s.Add(id);
        foreach (var id in new FilteredElementCollector(d).WhereElementIsElementType().ToElementIds()) s.Add(id);
        return s;
    }

    private static HashSet<string> BuildNameClassIndex(Document d)
    {
        var set = new HashSet<string>();
        void Add(Element e)
        {
            try { var n = e.Name; if (!string.IsNullOrEmpty(n)) set.Add(e.GetType().Name + "|" + n); }
            catch { }
        }
        foreach (Element e in new FilteredElementCollector(d).WhereElementIsElementType()) Add(e);
        foreach (Element e in new FilteredElementCollector(d).WhereElementIsNotElementType()) Add(e);
        return set;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<int>? GetIntArray(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
        {
            var list = new List<int>();
            foreach (var item in el.EnumerateArray())
                if (item.ValueKind == JsonValueKind.Number) list.Add(item.GetInt32());
            return list;
        }
        return null;
    }

    // Ensure request.Params carries an explicit "mode" before delegating to InventoryCopy, so the probe
    // previews exactly the id set copy_elements would land (copy defaults to view_templates; inventory
    // would otherwise default to view_templates_and_types). Leaves an existing mode untouched.
    private static void EnsureModeParam(CommandRequest request, string mode)
    {
        request.Params ??= new Dictionary<string, JsonElement>();
        if (!request.Params.ContainsKey("mode"))
            request.Params["mode"] = JsonSerializer.SerializeToElement(mode);
    }

    /// <summary>
    /// diagnose_family_copy — non-destructive per-family copy probe that CAPTURES the failures a
    /// cross-document family copy raises, instead of letting Revit pop a modal dialog (which blocks the
    /// main thread and hangs the bridge). Copies each source loadable family ALONE into the disposable
    /// scratch canvas with a failure-capturing preprocessor, records which families fail and with which
    /// failure(s) + failing element names, then rolls back / deletes so nothing persists. Returns a
    /// per-family report so the reviewer can fix the offending families in a targeted way.
    /// Because every error-severity failure is handled programmatically (rollback), no
    /// dialog appears and the probe never hangs.
    ///
    /// params:
    ///   source_document    : string (required) — project to copy FROM (e.g. Bron_…)
    ///   scratch_document   : string (optional) — disposable canvas; default first open non-family doc
    ///                         that is neither source nor a family (typically "Project1").
    ///   source_element_ids : [int]  (optional) — explicit family element ids; default = every loadable
    ///                         Family in the source.
    ///   category           : string (optional) — restrict the default family set to this category name.
    ///   include_warnings   : bool   (default false) — also record Warning-severity failures.
    ///   limit              : int    (optional) — cap the number of families probed (smoke test).
    /// </summary>
    public static CommandResponse DiagnoseFamilyCopy(CommandRequest request)
    {
        var p = request.Params;
        string? sourceTitle = GetString(p, "source_document");
        string? scratchTitle = GetString(p, "scratch_document");
        string? categoryFilter = GetString(p, "category");
        bool inclWarn = GetBool(p, "include_warnings", false);
        var explicitIds = GetIntArray(p, "source_element_ids");
        int limit = 0;
        if (p != null && p.TryGetValue("limit", out var le) && le.ValueKind == JsonValueKind.Number) limit = le.GetInt32();

        if (sourceTitle == null)
            return new CommandResponse { Success = false, Error = "Parameter 'source_document' is required" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? src = null, scratch = null;
                foreach (Document d in app.Application.Documents)
                    if (d.Title == sourceTitle) src = d;
                if (src == null) throw new Exception($"source_document '{sourceTitle}' is not open");
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == sourceTitle) continue;
                    if (d.IsFamilyDocument) continue;
                    if (scratchTitle != null) { if (d.Title == scratchTitle) { scratch = d; break; } }
                    // Zonder scratch_document alleen een nooit bewaard model als kladblok (geen pad): een proef mag
                    // nooit kopiëren en verwijderen in een echt model van de gebruiker (breedtest 25-11-2026).
                    else if (string.IsNullOrEmpty(d.PathName)) { scratch = d; break; }
                }
                if (scratch == null)
                    throw new Exception(scratchTitle != null
                        ? $"scratch_document '{scratchTitle}' not found among open projects"
                        : "no disposable scratch document open (open an empty project, e.g. Project1)");

                // Resolve the family set: explicit ids, or every loadable Family (optionally category-filtered).
                var families = new List<Family>();
                if (explicitIds != null && explicitIds.Count > 0)
                {
                    foreach (var i in explicitIds)
                        if (src.GetElement(new ElementId((long)i)) is Family fam) families.Add(fam);
                }
                else
                {
                    foreach (var e in new FilteredElementCollector(src).OfClass(typeof(Family)).Cast<Family>())
                    {
                        if (categoryFilter != null)
                        {
                            string? cat = null; try { cat = e.FamilyCategory?.Name; } catch { }
                            if (!string.Equals(cat, categoryFilter, StringComparison.OrdinalIgnoreCase)) continue;
                        }
                        families.Add(e);
                    }
                    families.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                }
                if (limit > 0 && families.Count > limit) families = families.GetRange(0, limit);

                var report = new List<Dictionary<string, object?>>();
                int okCount = 0, failCount = 0;
                var byDef = new Dictionary<string, int>();

                foreach (var fam in families)
                {
                    string famName = ""; try { famName = fam.Name; } catch { }
                    string? cat = null; try { cat = fam.FamilyCategory?.Name; } catch { }
                    int symCount = 0; try { symCount = fam.GetFamilySymbolIds().Count; } catch { }

                    var before = AllElementIds(scratch);
                    var capture = new CaptureFailures(inclWarn);
                    bool threw = false; string? throwMsg = null;
                    var opts = new CopyPasteOptions();
                    opts.SetDuplicateTypeNamesHandler(new UseDestinationTypesHandler());
                    using (var t = new Transaction(scratch, "diagnose_family_copy"))
                    {
                        t.Start();
                        var fho = t.GetFailureHandlingOptions();
                        fho.SetFailuresPreprocessor(capture);
                        fho.SetClearAfterRollback(true);
                        t.SetFailureHandlingOptions(fho);
                        try
                        {
                            // Commit fires the preprocessor: a clean family commits, a failing one rolls back
                            // (ProceedWithRollBack) — either way no dialog, so the main thread never blocks.
                            ElementTransformUtils.CopyElements(src, new List<ElementId> { fam.Id }, scratch, Transform.Identity, opts);
                            t.Commit();
                        }
                        catch (Exception ex)
                        {
                            threw = true; throwMsg = ex.Message;
                            try { if (t.HasStarted() && !t.HasEnded()) t.RollBack(); } catch { }
                        }
                    }
                    // A clean copy committed — count how many symbols (types) actually materialised BEFORE
                    // cleanup, so we catch a silent failure seen in practice: a family that copies WITHOUT any
                    // error but lands with fewer/no types. (Meaningful in an EMPTY scratch; in a scratch that
                    // already holds a same-named family the duplicate-types handler merges, so landed=0 there
                    // is a merge, not a loss.) Then delete what landed so the canvas stays reusable.
                    var after = AllElementIds(scratch);
                    var newIds = after.Where(id => !before.Contains(id)).ToList();
                    int landedSym = 0; bool foundFam = false;
                    foreach (var id in newIds)
                    {
                        try { if (scratch.GetElement(id) is Family lf) { landedSym = lf.GetFamilySymbolIds().Count; foundFam = true; break; } }
                        catch { }
                    }
                    if (newIds.Count > 0)
                    {
                        using var tc = new Transaction(scratch, "diagnose cleanup");
                        tc.Start();
                        foreach (var id in newIds) { try { scratch.Delete(id); } catch { } }
                        tc.Commit();
                    }

                    var errs = capture.Failures.Where(f => f.Severity != "warning").ToList();
                    bool copyOk = !threw && errs.Count == 0;
                    // type_loss = the copy did not error but the family landed with fewer types than the source
                    // had (only asserted when a new Family actually materialised, i.e. no destination merge).
                    bool typeLoss = copyOk && foundFam && landedSym < symCount;
                    bool ok = copyOk && !typeLoss;
                    if (ok) okCount++; else failCount++;
                    foreach (var f in errs)
                        byDef[f.Description] = byDef.GetValueOrDefault(f.Description) + 1;
                    if (typeLoss)
                        byDef[$"type-loss (landde {landedSym}/{symCount} types)"] = byDef.GetValueOrDefault($"type-loss (landde {landedSym}/{symCount} types)") + 1;

                    report.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(fam.Id),
                        ["family_name"] = famName,
                        ["category"] = cat,
                        ["source_symbol_count"] = symCount,
                        ["landed_symbol_count"] = foundFam ? landedSym : (int?)null,
                        ["ok"] = ok,
                        ["type_loss"] = typeLoss,
                        ["threw"] = threw,
                        ["throw_message"] = throwMsg,
                        ["failures"] = capture.Failures.Select(f => (object)new Dictionary<string, object?>
                        {
                            ["severity"] = f.Severity,
                            ["description"] = f.Description,
                            ["failing_elements"] = f.FailingElements
                        }).ToList()
                    });
                }

                return (object)new Dictionary<string, object?>
                {
                    ["source_document"] = src.Title,
                    ["scratch_document"] = scratch.Title,
                    ["families_probed"] = report.Count,
                    ["ok"] = okCount,
                    ["failed"] = failCount,
                    ["failures_by_definition"] = byDef.OrderByDescending(kv => kv.Value)
                                                     .ToDictionary(kv => kv.Key, kv => (object?)kv.Value),
                    ["families"] = report
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // Captures failures raised during a (cross-document) copy transaction instead of letting Revit pop a
    // modal dialog. Warnings are recorded (optional) and deleted; errors are recorded and the transaction
    // is rolled back so no dialog appears and nothing persists — the reason this probe never hangs.
    private sealed class CaptureFailures : IFailuresPreprocessor
    {
        private readonly bool _inclWarn;
        public List<FailureInfo> Failures { get; } = new();
        public CaptureFailures(bool inclWarn) { _inclWarn = inclWarn; }

        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            bool anyError = false;
            foreach (var f in fa.GetFailureMessages())
            {
                var sev = f.GetSeverity();
                var names = new List<string>();
                try
                {
                    foreach (var id in f.GetFailingElementIds())
                    {
                        try { var e = fa.GetDocument().GetElement(id); if (e != null && !string.IsNullOrEmpty(e.Name)) names.Add(e.Name); }
                        catch { }
                    }
                }
                catch { }
                string sevStr = sev == FailureSeverity.Warning ? "warning"
                              : sev == FailureSeverity.Error ? "error" : sev.ToString().ToLowerInvariant();
                if (sev == FailureSeverity.Warning)
                {
                    if (_inclWarn)
                        Failures.Add(new FailureInfo { Severity = sevStr, Description = f.GetDescriptionText(), FailingElements = names });
                    try { fa.DeleteWarning(f); } catch { }
                }
                else
                {
                    anyError = true;
                    Failures.Add(new FailureInfo { Severity = sevStr, Description = f.GetDescriptionText(), FailingElements = names });
                }
            }
            // An error can't be deleted like a warning -> roll back so no modal dialog appears.
            return anyError ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
        }
    }

    private sealed class FailureInfo
    {
        public string Severity = "";
        public string Description = "";
        public List<string> FailingElements = new();
    }

    /// <summary>
    /// transfer_family — robustly transfer loadable families source -> target via the LOAD path
    /// (EditFamily -> SaveAs .rfa -> LoadFamily) instead of ElementTransformUtils.CopyElements. A raw
    /// cross-document copy drops the symbols of hosted/nested families (they land as a typeless shell);
    /// LoadFamily brings the family with ALL its
    /// types. The family loads under its SOURCE name; a same-named family in the target is only
    /// overwritten with overwrite=true. Reconciling to the NLRS target name is a separate rename step.
    ///
    /// params:
    ///   source_document    : string (required) — project to transfer FROM
    ///   target_document    : string (required) — project to load INTO
    ///   source_element_ids : [int]  (optional) — family element ids in the source; OR
    ///   family_names       : [str]  (optional) — family names in the source to transfer
    ///   category           : string (optional) — restrict a default (all-families) run to one category
    ///   save_first         : bool   (default false) — save a target backup before the first load
    ///   overwrite          : bool   (default false) — overwrite a same-named family already in target
    ///   dry_run            : bool   (default true) — resolve + report the set WITHOUT loading anything
    /// </summary>
    public static CommandResponse TransferFamily(CommandRequest request)
    {
        var p = request.Params;
        string? sourceTitle = GetString(p, "source_document");
        string? targetTitle = GetString(p, "target_document");
        string? categoryFilter = GetString(p, "category");
        bool saveFirst = GetBool(p, "save_first", false);
        bool overwrite = GetBool(p, "overwrite", false);
        bool dryRun = GetBool(p, "dry_run", true);
        var explicitIds = GetIntArray(p, "source_element_ids");
        var famNames = GetStringArray(p, "family_names");

        if (sourceTitle == null) return new CommandResponse { Success = false, Error = "Parameter 'source_document' is required" };
        if (targetTitle == null) return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };
        if (sourceTitle == targetTitle) return new CommandResponse { Success = false, Error = "source_document and target_document must differ" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? src = null, tgt = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == sourceTitle) src = d;
                    if (d.Title == targetTitle) tgt = d;
                }
                if (src == null) throw new Exception($"source_document '{sourceTitle}' is not open");
                if (tgt == null) throw new Exception($"target_document '{targetTitle}' is not open");

                // Resolve the family set: explicit ids, names, or every loadable Family (optionally by category).
                var families = new List<Family>();
                if (explicitIds != null && explicitIds.Count > 0)
                {
                    foreach (var i in explicitIds)
                        if (src.GetElement(new ElementId((long)i)) is Family fam) families.Add(fam);
                }
                else if (famNames != null && famNames.Count > 0)
                {
                    var want = new HashSet<string>(famNames, StringComparer.OrdinalIgnoreCase);
                    foreach (var e in new FilteredElementCollector(src).OfClass(typeof(Family)).Cast<Family>())
                        if (want.Contains(e.Name)) families.Add(e);
                }
                else
                {
                    foreach (var e in new FilteredElementCollector(src).OfClass(typeof(Family)).Cast<Family>())
                    {
                        if (categoryFilter != null)
                        {
                            string? cat = null; try { cat = e.FamilyCategory?.Name; } catch { }
                            if (!string.Equals(cat, categoryFilter, StringComparison.OrdinalIgnoreCase)) continue;
                        }
                        families.Add(e);
                    }
                }

                var report = new List<Dictionary<string, object?>>();
                int loadedCount = 0, failCount = 0;

                if (dryRun)
                {
                    foreach (var fam in families)
                    {
                        int sc = 0; try { sc = fam.GetFamilySymbolIds().Count; } catch { }
                        report.Add(new Dictionary<string, object?>
                        { ["family_name"] = SafeName(fam), ["source_symbol_count"] = sc, ["loaded"] = false });
                    }
                    return (object)new Dictionary<string, object?>
                    {
                        ["source_document"] = src.Title, ["target_document"] = tgt.Title, ["dry_run"] = true,
                        ["families"] = report, ["count"] = report.Count
                    };
                }

                string? saved = null;
                if (saveFirst)
                {
                    try { tgt.Save(); saved = tgt.Title; }
                    catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                }

                var loadOpts = new OverwriteFamilyLoadOptions(overwrite);

                // EditFamily/LoadFamily are NOT covered by a transaction failure preprocessor — they can pop
                // modal dialogs (load warnings, missing refs) that block the main thread and hang the bridge.
                // The shared scope accepts every dialog (IDOK) so nothing blocks, attributes it to the family
                // being loaded, and surfaces notable ones in the response.
                using var swallow = new DialogSwallowScope(app);
                foreach (var fam in families)
                {
                    string famName = SafeName(fam);
                    swallow.Context = famName;
                    int srcSym = 0; try { srcSym = fam.GetFamilySymbolIds().Count; } catch { }
                    // System/OOTB families (e.g. Rectangular Mullion) are not editable -> can't go via the
                    // load path; report + skip instead of throwing.
                    bool editable = true; try { editable = fam.IsEditable; } catch { }
                    if (!editable)
                    {
                        failCount++;
                        report.Add(new Dictionary<string, object?>
                        { ["family_name"] = famName, ["source_symbol_count"] = srcSym, ["loaded"] = false,
                          ["error"] = "family is not editable (system/OOTB) — skipped" });
                        continue;
                    }
                    Document? famDoc = null;
                    try
                    {
                        famDoc = src.EditFamily(fam);               // open the family definition in memory
                        // Load the in-memory family document STRAIGHT into the target. The file-based path
                        // (SaveAs .rfa -> tgt.LoadFamily(path)) silently returned false in the bridge context;
                        // this overload works and needs no temp file.
                        Family loaded = famDoc.LoadFamily(tgt, loadOpts);
                        int typeCount = 0; string? loadedName = null;
                        if (loaded != null) { try { typeCount = loaded.GetFamilySymbolIds().Count; } catch { } loadedName = SafeName(loaded); }
                        bool ok = loaded != null;
                        if (ok) loadedCount++; else failCount++;
                        report.Add(new Dictionary<string, object?>
                        {
                            ["family_name"] = famName, ["source_symbol_count"] = srcSym,
                            ["loaded"] = ok, ["loaded_name"] = loadedName, ["loaded_type_count"] = typeCount
                        });
                    }
                    catch (Exception ex)
                    {
                        failCount++;
                        report.Add(new Dictionary<string, object?>
                        { ["family_name"] = famName, ["source_symbol_count"] = srcSym, ["loaded"] = false, ["error"] = ex.Message });
                    }
                    finally { if (famDoc != null) { try { famDoc.Close(false); } catch { } } }
                }

                var outDict = new Dictionary<string, object?>
                {
                    ["source_document"] = src.Title, ["target_document"] = tgt.Title,
                    ["saved_document"] = saved, ["overwrite"] = overwrite,
                    ["loaded"] = loadedCount, ["failed"] = failCount, ["count"] = report.Count,
                    ["families"] = report
                };
                swallow.WriteTo(outDict);
                return (object)outDict;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static string SafeName(Element e) { try { return e.Name ?? ""; } catch { return ""; } }

    private static List<string>? GetStringArray(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
        {
            var list = new List<string>();
            foreach (var item in el.EnumerateArray())
                if (item.ValueKind == JsonValueKind.String) { var s = item.GetString(); if (!string.IsNullOrWhiteSpace(s)) list.Add(s); }
            return list;
        }
        return null;
    }

    // Overwrite a same-named family already loaded in the target (so a typeless shell is replaced by the
    // full family), overwriting parameter values too.
    private sealed class OverwriteFamilyLoadOptions : IFamilyLoadOptions
    {
        private readonly bool _overwrite;
        public OverwriteFamilyLoadOptions(bool overwrite) { _overwrite = overwrite; }
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        {
            overwriteParameterValues = _overwrite;
            return _overwrite;
        }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        {
            source = FamilySource.Family;
            overwriteParameterValues = _overwrite;
            return _overwrite;
        }
    }
}
