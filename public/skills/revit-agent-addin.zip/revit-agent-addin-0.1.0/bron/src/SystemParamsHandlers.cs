using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// enum_system_family_parameters — type-parameters of SYSTEM-family types (Walls/Floors/Roofs/Ceilings/
/// Stairs/Railings/… : model-category ElementTypes that are NOT loadable FamilySymbols), for the unified
/// Family Parameters tab. System families have no FamilyManager, hence no
/// formulas — the formula columns are locked on these rows. Value-editing is per TYPE (element_id-based).
///
/// "Alle type-parameters" can explode the tab, so the reviewer maintains an Ignored-Builtin-Parameters
/// list on the _overzicht tab; that list is passed here as ignore_params and filtered SERVER-SIDE so the
/// payload stays small.
///
/// params: target_document, ignore_params:[names] (optional).
/// </summary>
public static class SystemParamsHandlers
{
    public static CommandResponse EnumSystemFamilyParameters(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        var ignore = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (p != null && p.TryGetValue("ignore_params", out var ig) && ig.ValueKind == JsonValueKind.Array)
            foreach (var x in ig.EnumerateArray())
                if (x.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(x.GetString()))
                    ignore.Add(x.GetString()!.Trim());

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var types = new List<Dictionary<string, object?>>();
                foreach (Element el in new FilteredElementCollector(doc).WhereElementIsElementType())
                {
                    if (el is FamilySymbol) continue;            // loadable -> al in enum_family_parameters
                    if (el is not ElementType et) continue;
                    var cat = et.Category;
                    if (cat == null || cat.CategoryType != CategoryType.Model) continue;  // alleen model system-families

                    var plist = new List<Dictionary<string, object?>>();
                    try
                    {
                        foreach (Parameter par in et.GetOrderedParameters())
                        {
                            if (par?.Definition == null) continue;
                            var pname = par.Definition.Name;
                            if (ignore.Contains(pname)) continue;  // server-side ignore-filter
                            bool isShared = false; string? guid = null;
                            try { isShared = par.IsShared; if (isShared) guid = par.GUID.ToString(); } catch { }
                            string? value = null;
                            try
                            {
                                if (par.StorageType == StorageType.ElementId)
                                { var vid = par.AsElementId(); value = (vid != null && vid != ElementId.InvalidElementId) ? doc.GetElement(vid)?.Name : null; }
                                else
                                {
                                    value = par.AsValueString() ?? par.AsString();
                                    if (value == null && par.StorageType == StorageType.Integer) value = par.AsInteger().ToString();
                                }
                            }
                            catch { }
                            plist.Add(new Dictionary<string, object?>
                            {
                                ["name"] = pname, ["is_shared"] = isShared, ["guid"] = guid,
                                ["spec"] = SafeSpec(par), ["is_instance"] = false,  // type-niveau gelezen
                                ["value"] = value, ["read_only"] = par.IsReadOnly,
                            });
                        }
                    }
                    catch { }
                    if (plist.Count == 0) continue;
                    types.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(et.Id), ["type_name"] = et.Name,
                        ["category"] = cat.Name, ["params"] = plist,
                    });
                }

                return (object)new Dictionary<string, object?>
                { ["document"] = doc.Title, ["type_count"] = types.Count, ["types"] = types };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static string? SafeSpec(Parameter par)
    {
        try { return par.Definition.GetDataType().TypeId; } catch { return null; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
