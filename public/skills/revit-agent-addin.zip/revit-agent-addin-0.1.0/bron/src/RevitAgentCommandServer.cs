using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public class CommandRequest
{
    [JsonPropertyName("command")]
    public string Command { get; set; } = "";
    [JsonPropertyName("params")]
    public Dictionary<string, JsonElement>? Params { get; set; }
    [JsonPropertyName("token")]
    public string? Token { get; set; }
}

public class CommandResponse
{
    [JsonPropertyName("success")] public bool Success { get; set; }
    [JsonPropertyName("data")] public object? Data { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
}

public class ElementNotFoundException(string message) : Exception(message);

/// <summary>Eén opdracht van de bridge: naam, korte uitleg, of hij het model wijzigt, of hij dry_run kent.</summary>
public record CommandInfo(string Name, bool Schrijft, bool DryRun, string Uitleg, Func<CommandRequest, CommandResponse> Handler);

/// <summary>
/// De bridge: een TcpListener op 127.0.0.1 (alleen de eigen computer). Per verbinding één regel JSON heen
/// ({"command","params","token"}) en één regel JSON terug ({"success","data","error"}).
///
/// Poort: omgevingsvariabele REVIT_AGENT_PORT, anders 9877; bezet, dan de volgende vrije tot +5.
/// Token: bij elke start nieuw en willekeurig; samen met de poort geschreven naar
/// %APPDATA%\RevitAgent\bridge.json. Een verzoek zonder het juiste token wordt geweigerd, behalve ping.
/// </summary>
public class RevitAgentCommandServer : IDisposable
{
    public const string AddinVersie = "0.1.0";
    private const int StandaardPoort = 9877;
    /// <summary>Grens op één verzoekregel; ruim genoeg voor bulk-opdrachten.</summary>
    private const int MaxRegelBytes = 16 * 1024 * 1024;
    /// <summary>Grens op het aantal verbindingen dat tegelijk open is.</summary>
    private const int MaxVerbindingen = 8;
    private static readonly SemaphoreSlim _verbindingen = new(MaxVerbindingen, MaxVerbindingen);

    private TcpListener? _listener;
    private readonly CancellationTokenSource _cts = new();
    public int Port { get; private set; }
    private static string _token = "";

    private RevitAgentCommandServer() { }

    public static string BridgeJsonPad => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RevitAgent", "bridge.json");

    /// <summary>Start op de eerste vrije poort vanaf REVIT_AGENT_PORT (of 9877), tot +5. Schrijft bridge.json.</summary>
    public static RevitAgentCommandServer StartOpVrijePoort()
    {
        int basis = StandaardPoort;
        var env = Environment.GetEnvironmentVariable("REVIT_AGENT_PORT");
        if (!string.IsNullOrWhiteSpace(env) && int.TryParse(env, out var ep) && ep > 0 && ep < 65536) basis = ep;
        else if (InterneAddinAanwezig())
        {
            // De interne addin van bimforce (RevitAgentAddin) luistert vast op 9877 en zoekt geen andere poort.
            // Laat 9877 dan aan hem, ook als deze addin eerder laadt.
            basis = StandaardPoort + 1;
            MainThreadDispatcher.Log("[start] interne addin gevonden; 9877 blijft voor hem vrij");
        }

        Exception? laatste = null;
        for (int poort = basis; poort <= basis + 5; poort++)
        {
            var srv = new RevitAgentCommandServer();
            try
            {
                srv._listener = new TcpListener(IPAddress.Loopback, poort);
                srv._listener.Start();
                srv.Port = poort;
            }
            catch (SocketException ex)
            {
                laatste = ex;
                MainThreadDispatcher.Log($"[start] poort {poort} bezet, volgende proberen");
                continue;
            }
            _token = NieuwToken();
            SchrijfBridgeJson(poort, _token);
            _ = Task.Run(() => srv.ListenLoopAsync(srv._cts.Token));
            MainThreadDispatcher.Log($"[start] bridge luistert op 127.0.0.1:{poort}");
            return srv;
        }
        throw new InvalidOperationException($"geen vrije poort tussen {basis} en {basis + 5}", laatste);
    }

    private static bool InterneAddinAanwezig()
    {
        try
        {
            var jaar = RevitBridge.ControlledApp?.VersionNumber;
            if (string.IsNullOrEmpty(jaar)) return false;
            foreach (var basisMap in new[] { Environment.SpecialFolder.ApplicationData, Environment.SpecialFolder.CommonApplicationData })
            {
                var pad = Path.Combine(Environment.GetFolderPath(basisMap), "Autodesk", "Revit", "Addins", jaar, "RevitAgentAddin.addin");
                if (File.Exists(pad)) return true;
            }
        }
        catch { }
        return false;
    }

    private static string NieuwToken()
    {
        var b = RandomNumberGenerator.GetBytes(24);
        return Convert.ToHexString(b).ToLowerInvariant();
    }

    private static void SchrijfBridgeJson(int poort, string token)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(BridgeJsonPad)!);
            var json = JsonSerializer.Serialize(new Dictionary<string, object?>()
            {
                ["port"] = poort, ["token"] = token, ["addin_version"] = AddinVersie,
                ["revit_version"] = RevitBridge.ControlledApp?.VersionNumber,
                ["pid"] = Environment.ProcessId, ["started_utc"] = DateTime.UtcNow.ToString("O"),
            });
            File.WriteAllText(BridgeJsonPad, json, new UTF8Encoding(false));
        }
        catch (Exception ex) { MainThreadDispatcher.Log($"[start] bridge.json schrijven mislukte: {ex.Message}"); }
    }

    private async Task ListenLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                var client = await _listener!.AcceptTcpClientAsync(ct).ConfigureAwait(false);
                if (!_verbindingen.Wait(0))
                {
                    // Te veel open verbindingen: deze meteen sluiten, niets lezen.
                    MainThreadDispatcher.Log($"[bridge] meer dan {MaxVerbindingen} verbindingen tegelijk; verbinding gesloten");
                    client.Dispose();
                    continue;
                }
                _ = Task.Run(async () =>
                {
                    try { await HandleClientAsync(client, ct).ConfigureAwait(false); }
                    finally { _verbindingen.Release(); }
                });
            }
            catch (OperationCanceledException) { break; }
            catch (ObjectDisposedException) { break; }
            catch (Exception ex) { MainThreadDispatcher.Log($"[bridge] accept-fout: {ex.Message}"); }
        }
    }

    private static async Task HandleClientAsync(TcpClient client, CancellationToken ct)
    {
        using (client)
        {
            var stream = client.GetStream();
            var utf8NoBom = new UTF8Encoding(false);
            using var writer = new StreamWriter(stream, utf8NoBom) { AutoFlush = true };

            string? line;
            try
            {
                using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                timeoutCts.CancelAfter(10000);
                line = await LeesRegelAsync(stream, utf8NoBom, timeoutCts.Token).ConfigureAwait(false);
            }
            catch { return; }
            if (line == null)
            {
                MainThreadDispatcher.Log($"[bridge] verzoek langer dan {MaxRegelBytes / (1024 * 1024)} MB; verbinding gesloten");
                return;
            }

            if (string.IsNullOrWhiteSpace(line)) return;

            CommandResponse response;
            try
            {
                var request = JsonSerializer.Deserialize<CommandRequest>(line);
                response = request != null
                    ? ExecuteCommand(request)
                    : new CommandResponse() { Success = false, Error = "Invalid request" };
            }
            catch (JsonException ex)
            {
                response = new CommandResponse() { Success = false, Error = $"JSON parse error: {ex.Message}" };
            }
            catch (Exception ex)
            {
                response = new CommandResponse() { Success = false, Error = $"Unhandled: {ex.Message}" };
            }

            string json;
            try { json = JsonSerializer.Serialize(response, new JsonSerializerOptions() { WriteIndented = false }); }
            catch (Exception ex) { json = JsonSerializer.Serialize(new CommandResponse() { Success = false, Error = $"Antwoord niet te serialiseren: {ex.Message}" }); }
            try
            {
                await writer.WriteAsync(json + "\n").ConfigureAwait(false);
                await writer.FlushAsync().ConfigureAwait(false);
            }
            catch { /* client weg */ }
        }
    }

    /// <summary>Leest één regel (tot '\n' of het einde van de verbinding) van hooguit MaxRegelBytes.
    /// Null als de regel te lang is; wat er na de grens nog komt, wordt niet gelezen.</summary>
    private static async Task<string?> LeesRegelAsync(Stream stream, Encoding enc, CancellationToken ct)
    {
        using var buf = new MemoryStream();
        var blok = new byte[64 * 1024];
        while (true)
        {
            int n = await stream.ReadAsync(blok.AsMemory(0, blok.Length), ct).ConfigureAwait(false);
            if (n == 0) return enc.GetString(buf.GetBuffer(), 0, (int)buf.Length).TrimEnd('\r');
            int eind = Array.IndexOf(blok, (byte)'\n', 0, n);
            int deel = eind >= 0 ? eind : n;
            if (buf.Length + deel > MaxRegelBytes) return null;
            buf.Write(blok, 0, deel);
            if (eind >= 0) return enc.GetString(buf.GetBuffer(), 0, (int)buf.Length).TrimEnd('\r');
        }
    }

    private static bool TokenKlopt(string? gegeven)
    {
        if (string.IsNullOrEmpty(_token) || string.IsNullOrEmpty(gegeven)) return false;
        var a = Encoding.UTF8.GetBytes(gegeven);
        var b = Encoding.UTF8.GetBytes(_token);
        return a.Length == b.Length && CryptographicOperations.FixedTimeEquals(a, b);
    }

    // ────────────────────────────────────────────────────────────────────────
    // Opdrachtenlijst. tools/opdrachten_lijst.py leest deze regels om references/opdrachten.md te maken:
    // houd de vorm Reg("naam", schrijft, dry_run, "uitleg", handler) aan, één per regel.
    // ────────────────────────────────────────────────────────────────────────
    private static readonly List<CommandInfo> _opdrachten = new();
    private static readonly Dictionary<string, CommandInfo> _perNaam = new(StringComparer.Ordinal);
    private static void Reg(string naam, bool schrijft, bool dryRun, string uitleg, Func<CommandRequest, CommandResponse> h)
    {
        var ci = new CommandInfo(naam, schrijft, dryRun, uitleg, h);
        _opdrachten.Add(ci); _perNaam[naam] = ci;
    }

    public static IReadOnlyList<CommandInfo> Opdrachten => _opdrachten;

    static RevitAgentCommandServer()
    {
        // ── bridge en sessie ──
        Reg("ping", false, false, "Leeft de bridge? Werkt zonder token; geeft de versie van de addin.", _ => Ok(new { status = "alive", addin_version = AddinVersie }));
        Reg("list_commands", false, false, "Alle opdrachten met korte uitleg, of ze schrijven en of ze dry_run kennen.", ListCommands);
        Reg("get_info", false, false, "Versie en build van Revit.", _ => GetAppInfo());
        Reg("get_diagnostics", false, false, "Stand van de dispatcher en de laatste logregels van de addin.", _ => GetDiagnostics());
        Reg("reset_counters", false, false, "Tellers en log van de dispatcher leegmaken.", _ => { MainThreadDispatcher.ResetCounters(); return Ok("counters reset"); });

        // ── documenten ──
        Reg("get_open_documents", false, false, "Welke modellen en families staan open (titel, pad, onbewaard werk).", _ => GetOpenDocuments());
        Reg("open_document", false, false, "Een .rvt of .rfa openen op de achtergrond (zonder venster), ook met ontbrekende links.", DocumentHandlers.OpenDocument);
        Reg("open_document_ui", false, false, "Een model openen en tonen in Revit (met venster), ook met ontbrekende links.", DocumentHandlers.OpenDocumentUi);
        Reg("save_document", true, false, "Een open model bewaren. Alleen als de gebruiker erom vraagt.", DocumentHandlers.SaveDocument);
        Reg("save_document_as", true, false, "Een open model bewaren onder een nieuwe naam. Alleen als de gebruiker erom vraagt.", MiscDocHandlers.SaveDocumentAs);
        Reg("close_document", true, false, "Een open model sluiten (standaard zonder bewaren). Alleen als de gebruiker erom vraagt.", MiscDocHandlers.CloseDocument);
        Reg("new_project", true, false, "Een nieuw, leeg project maken (optioneel uit een sjabloon). Wordt niet bewaard.", NewProject);
        Reg("get_worksets", false, false, "Worksets van een model met open/dicht.", MiscDocHandlers.GetWorksets);
        Reg("list_link_instances", false, false, "Revit-links in een model: naam, pad, geladen of niet.", MepModelHandlers.ListLinkInstances);
        Reg("load_links", true, true, "Revit-links toevoegen uit paden of een map (plaatsing origin of shared).", DocumentHandlers.LoadLinks);
        Reg("reload_link", true, true, "Een Revit-link opnieuw laden, eventueel vanaf een ander pad.", MepModelHandlers.ReloadLink);

        // ── elementen lezen ──
        Reg("list_type_catalog", false, false, "De type_id's die query_elements en get_element_detail kennen.", ListTypeCatalog);
        Reg("query_elements", false, false, "Alle elementen van één soort (type_id uit list_type_catalog), zoals wall_type of materials.", QueryElements);
        Reg("get_element_detail", false, false, "Alle eigenschappen en parameters van één element (type_id + element_id).", GetElementDetail);
        Reg("query_category_instances", false, false, "Instanties van een categorie met familie, type en gevraagde parameters.", MiscDocHandlers.QueryCategoryInstances);
        Reg("get_family_instances", false, false, "Family-instanties met hun parameters (begrensd met limit).", GetFamilyInstances);
        Reg("get_families_loaded", false, false, "Geladen families per categorie met aantal types.", GetFamiliesLoaded);
        Reg("get_family_detail", false, false, "Eén familie met haar types en parameters.", GetFamilyDetail);
        Reg("get_levels", false, false, "Alle levels met hoogte (voet en meter) en parameters.", LevelHandlers.GetLevels);
        Reg("get_door_room_relations", false, false, "Per deur de ruimte aan beide kanten (van/naar).", DoorRoomHandlers.GetDoorRoomRelations);
        Reg("get_room_geometry", false, false, "Grenslijnen en hoogte van ruimten.", MepModelHandlers.GetRoomGeometry);
        Reg("change_element_type", true, true, "Elementen een ander type geven (op id of naam).", DocumentHandlers.ChangeElementType);
        Reg("rename_element", true, true, "Elementen (types, views, materialen) hernoemen. Standaard eerst als proef.", WriteHandlers.RenameElements);
        Reg("delete_element", true, true, "Elementen verwijderen; met expected_name als controle. Standaard eerst als proef.", WriteHandlers.DeleteElements);

        // ── parameters ──
        Reg("read_parameter_values", false, false, "Parameterwaarden lezen voor een categorie of een lijst elementen, met telling gevuld/leeg/ontbreekt.", ModelDataHandlers.ReadParameterValues);
        Reg("set_parameter_value", true, true, "Eén parameter op een element of type zetten.", SetValueHandlers.SetParameterValue);
        Reg("set_parameter_values_bulk", true, true, "Veel parameterwaarden tegelijk zetten, in batches, met voorbeeld bij dry_run.", ModelDataHandlers.SetParameterValuesBulk);
        Reg("list_parameter_bindings", false, false, "Alle project- en shared parameters met hun categorieën en groep.", ModelDataHandlers.ListParameterBindings);
        Reg("bind_shared_parameters", true, true, "Shared parameters uit een bestand aan categorieën binden (nieuw of uitbreiden).", ModelDataHandlers.BindSharedParameters);
        Reg("unbind_shared_parameters", true, true, "Bindingen van shared parameters weghalen.", MiscDocHandlers.UnbindSharedParameters);
        Reg("set_parameter_binding", true, true, "Een parameterbinding aanpassen (categorieën, instance/type, groep).", BindingHandlers.SetParameterBinding);
        Reg("mirror_parameter_binding", true, true, "De binding van een parameter overnemen op een andere parameter.", BindingHandlers.MirrorParameterBinding);
        Reg("report_parameter_usage", false, false, "Waar een parameter gebruikt wordt (bindingen, filters, schedules, families).", ParameterUsageHandlers.ReportParameterUsage);
        Reg("swap_parameter", true, true, "Een project-parameter vervangen door een andere en de waarden overzetten.", SwapHandlers.SwapParameter);
        Reg("couple_builtin_parameter", true, true, "Waarden van een ingebouwde parameter naar een eigen parameter kopiëren.", CoupleBuiltinHandlers.CoupleBuiltinParameter);
        Reg("enum_system_family_parameters", false, false, "Parameters van systeemfamilies (wanden, vloeren, ...) per type.", SystemParamsHandlers.EnumSystemFamilyParameters);

        // ── families ──
        Reg("load_family", true, true, "Een .rfa laden in een project, met keuze voor overschrijven van waarden.", MiscDocHandlers.LoadFamily);
        Reg("enum_family_parameters", false, false, "Parameters binnen families (opent de familie op de achtergrond).", EnumFamilyParamsHandlers.EnumFamilyParameters);
        Reg("enum_nested_families", false, false, "Geneste families binnen families.", EnumNestedFamiliesHandlers.EnumNestedFamilies);
        Reg("rename_nested_families", true, true, "Geneste families hernoemen in hun moederfamilies.", RenameNestedFamiliesHandlers.RenameNestedFamilies);
        Reg("rename_nested_families_rfa", true, true, "Geneste families hernoemen in een .rfa-bestand.", NestedFamilyHandlers.RenameNestedFamilies);
        Reg("swap_family_parameter", true, true, "Een parameter in families vervangen door een (shared) parameter.", SwapFamilyHandlers.SwapFamilyParameter);
        Reg("rename_family_parameter", true, true, "Een family-parameter hernoemen.", RenameFamilyParamHandlers.RenameFamilyParameter);
        Reg("delete_family_parameter", true, true, "Een family-parameter verwijderen.", DeleteFamilyParamHandlers.DeleteFamilyParameter);
        Reg("set_family_formula", true, true, "Een formule op een family-parameter zetten.", SetFormulaHandlers.SetFamilyFormula);
        Reg("set_family_type_values", true, true, "Waarden per type in een familie zetten.", FamilyTypeValuesHandlers.SetFamilyTypeValues);
        Reg("set_family_param_kind", true, true, "Een family-parameter instance of type maken.", FamilyParamKindHandlers.SetFamilyParamKind);
        Reg("delete_family_types", true, true, "Types uit een familie verwijderen.", FamilyParamKindHandlers.DeleteFamilyTypes);
        Reg("copy_family_type", true, true, "Een type in een familie dupliceren.", FamilyParamKindHandlers.CopyFamilyType);
        Reg("rename_family_materials", true, true, "Materialen binnen families hernoemen.", RenameFamilyMaterialsHandlers.RenameFamilyMaterials);
        Reg("export_families_to_folder", false, true, "Families uit het project als .rfa naar een map bewaren (het project blijft gelijk); een bestaand bestand alleen overschrijven met overwrite=true.", ExportFamiliesHandlers.ExportFamiliesToFolder);
        Reg("place_family_instances", true, true, "Family-instanties plaatsen op punten (mm), met level en rotatie.", MepModelHandlers.PlaceFamilyInstances);
        Reg("place_family_grid", true, true, "Alle types van families in een raster plaatsen (catalogus-view).", PlaceFamilyHandlers.PlaceFamilyGrid);
        Reg("place_hosted_family", true, true, "Een family in een host plaatsen (deur of raam in een wand).", MepModelHandlers.PlaceHostedFamily);

        // ── kopiëren tussen modellen ──
        Reg("inventory_copy", false, false, "Vooraf nagaan wat kopiëren tussen twee open modellen zou doen.", CopyInventoryHandlers.InventoryCopy);
        Reg("copy_elements", true, true, "Elementen (types, materialen, views, ...) van het ene naar het andere open model kopiëren.", CopyInventoryHandlers.CopyElements);
        Reg("diagnose_family_copy", false, false, "Nagaan waarom het kopiëren van een familie mislukt.", CopyInventoryHandlers.DiagnoseFamilyCopy);
        Reg("transfer_family", true, true, "Een familie van het ene naar het andere open model overzetten; een familie met dezelfde naam alleen overschrijven met overwrite=true.", CopyInventoryHandlers.TransferFamily);

        // ── materialen ──
        Reg("get_materials", false, false, "Alle materialen met naam, klasse, kleur, patronen en assets.", MaterialHandlers.GetMaterials);
        Reg("create_material", true, true, "Een nieuw materiaal maken (naam, klasse, kleur, optioneel patronen).", MaterialHandlers.CreateMaterial);
        Reg("duplicate_material", true, true, "Een materiaal dupliceren onder een nieuwe naam, optioneel met nieuwe klasse of kleur.", MaterialHandlers.DuplicateMaterial);
        Reg("set_material_class", true, true, "De klasse (Material Class) van materialen zetten.", MaterialClassHandlers.SetMaterialClass);
        Reg("set_material_fill_pattern", true, true, "Oppervlakte- en snijpatronen van een materiaal zetten.", MaterialPatternHandlers.SetMaterialFillPattern);
        Reg("replace_material", true, true, "Een materiaal overal vervangen door een ander (types, families, parameters).", ReplaceMaterialHandlers.ReplaceMaterial);
        Reg("enum_material_parameters", false, false, "Parameters van materialen.", MaterialParamsHandlers.EnumMaterialParameters);
        Reg("enum_material_usage", false, false, "Waar elk materiaal gebruikt wordt.", MaterialParamsHandlers.EnumMaterialUsage);
        Reg("asset_rename", true, true, "Een appearance-, physical- of thermal-asset hernoemen.", AssetHandlers.AssetRename);
        Reg("asset_swap", true, true, "Een materiaal een ander asset geven.", AssetHandlers.AssetSwap);

        // ── views, sheets, filters ──
        Reg("get_view_structure", false, false, "Views, view templates en view types met hun samenhang.", ViewTypeHandlers.GetViewStructure);
        Reg("create_views", true, true, "Views maken (plattegrond, plafond, doorsnede, 3D, drafting), optioneel met template.", CreateViewHandlers.CreateViews);
        Reg("assign_view_template", true, true, "Een view template aan views koppelen.", ViewTypeHandlers.AssignViewTemplate);
        Reg("relink_type_templates", true, true, "De standaard-template van view types opnieuw koppelen.", ViewTypeHandlers.RelinkTypeTemplates);
        Reg("set_view_property", true, true, "Een eigenschap van een view zetten (schaal, detailniveau, ...).", ViewPropertyHandlers.SetViewProperty);
        Reg("get_filter_rules", false, false, "De regels van view filters.", FilterHandlers.GetFilterRules);
        Reg("create_filter", true, true, "Een view filter maken met categorieën en regels.", FilterHandlers.CreateFilter);
        Reg("repoint_filter_parameter", true, true, "De parameter in filterregels vervangen.", FilterHandlers.RepointFilterParameter);
        Reg("assign_view_filter", true, true, "Een filter aan een view of template hangen, met zichtbaarheid en overrides.", ViewFilterHandlers.AssignViewFilter);
        Reg("set_line_style_graphics", true, true, "Dikte, kleur en patroon van lijnstijlen zetten.", SetLineStyleHandlers.SetLineStyleGraphics);
        Reg("query_filled_region_types", false, false, "Filled region types met hun patronen.", FilledRegionHandlers.QueryFilledRegionTypes);
        Reg("create_filled_region_type", true, true, "Een filled region type maken.", FilledRegionHandlers.CreateFilledRegionType);
        Reg("get_sheet_detail", false, false, "Eén sheet: viewports, schedules en titleblock met parameters.", DocumentHandlers.GetSheetDetail);
        Reg("create_sheet", true, true, "Een sheet maken (nummer, naam, titleblock), optioneel met views op een positie.", SheetHandlers.CreateSheet);
        Reg("export_views_image", false, false, "Views als PNG exporteren naar een map.", DocumentHandlers.ExportViewsImage);

        // ── modelleren ──
        Reg("create_walls", true, true, "Wanden maken langs lijnen (mm), met type, level en hoogte.", MepModelHandlers.CreateWalls);
        Reg("create_room", true, true, "Een ruimte plaatsen op een punt of binnen begrenzing, met naam en nummer.", RoomHandlers.CreateRoom);
        Reg("create_shaft_opening", true, true, "Een schachtsparing maken tussen twee levels.", MepModelHandlers.CreateShaftOpening);

        // ── installaties (MEP) ──
        Reg("list_mep_types", false, false, "Leiding-, kanaal- en systeemtypes.", MepModelHandlers.ListMepTypes);
        Reg("create_mep_runs", true, true, "Leidingen of kanalen tekenen langs punten.", MepModelHandlers.CreateMepRuns);
        Reg("connect_to_pipe", true, true, "Een element aansluiten op een leiding.", MepModelHandlers.ConnectToPipe);
        Reg("get_connectors", false, false, "Connectoren van een element met positie en status.", MepModelHandlers.GetConnectors);
        Reg("cap_open_ends", true, true, "Open einden van leidingen afdoppen.", MepModelHandlers.CapOpenEnds);
        Reg("insert_pipe_accessory", true, true, "Een appendage in een leiding zetten.", MepModelHandlers.InsertPipeAccessory);
        Reg("duplicate_mep_type", true, true, "Een leiding- of kanaaltype dupliceren.", MepModelHandlers.DuplicateMepType);

        // ── IFC ──
        Reg("export_ifc", true, true, "IFC exporteren met een export-setup of opties; schrijft een bestand. Met keep_guids=true zet hij de IfcGUID-parameters in het model (een transactie, model daarna gewijzigd); zonder keep_guids blijft het model ongewijzigd.", ExportIfcHandlers.ExportIfc);
        Reg("get_ifc_export_setups", false, false, "De IFC-exportsetups die in het model bewaard zijn, met psetbestand en mappingtabel.", IfcSetupHandlers.GetIfcExportSetups);
        Reg("create_ifc_export_views", true, true, "3D-views voor IFC-export maken per bouwlaag of deel.", IfcExportViewHandlers.CreateIfcExportViews);
    }

    private static CommandResponse ExecuteCommand(CommandRequest request)
    {
        var cmd = request.Command ?? "";
        if (cmd != "ping" && !TokenKlopt(request.Token))
            return Err("Geen geldig token. De client leest het token uit %APPDATA%\\RevitAgent\\bridge.json; "
                     + "die wordt bij elke start van Revit opnieuw geschreven.");
        if (_perNaam.TryGetValue(cmd, out var ci))
        {
            try
            {
                var resp = ci.Handler(request);
                // Veel handlers melden een fout als data {"error": "..."} zonder "ok". Zet dan ok=false, zodat
                // elke client het als fout herkent (breedtest 25-11-2026, o.a. create_ifc_export_views).
                if (resp.Success && resp.Data is IDictionary<string, object?> d && !d.ContainsKey("ok")
                    && d.TryGetValue("error", out var fout) && fout is string fs && !string.IsNullOrWhiteSpace(fs))
                    d["ok"] = false;
                return resp;
            }
            catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
        }
        return new CommandResponse() { Success = false, Error = $"Unknown command: {cmd}" };
    }

    private static CommandResponse ListCommands(CommandRequest request)
    {
        return Ok(new
        {
            addin_version = AddinVersie,
            count = _opdrachten.Count,
            commands = _opdrachten.Select(c => new { name = c.Name, beschrijving = c.Uitleg, schrijft = c.Schrijft, dry_run = c.DryRun })
        });
    }

    // Een leeg project, bv. als kladblok voor inventory_copy. Wordt niet bewaard.
    private static CommandResponse NewProject(CommandRequest request)
    {
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                string? template = HandlerUtil.Str(request.Params, "template");
                var doc = string.IsNullOrWhiteSpace(template) ? app.Application.NewProjectDocument(UnitSystem.Metric)
                                                              : app.Application.NewProjectDocument(template);
                return (object)new { title = doc.Title, is_family = doc.IsFamilyDocument, template = template };
            });
            return Ok(result);
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    private static CommandResponse GetAppInfo()
    {
        var app = RevitBridge.ControlledApp;
        if (app == null) return Ok(new { available = false });

        return Ok(new
        {
            available = true,
            version = app.VersionNumber,
            build = app.VersionBuild,
            name = app.VersionName,
            addin_version = AddinVersie,
        });
    }

    private static CommandResponse GetOpenDocuments()
    {
        try
        {
            var result = MainThreadDispatcher.GetResult(app =>
            {
                var docs = new List<object>();
                foreach (Document doc in app.Application.Documents)
                {
                    docs.Add(new
                    {
                        title = doc.Title,
                        path = doc.PathName ?? "",
                        is_modified = doc.IsModified,
                        is_family = doc.IsFamilyDocument,
                        is_linked = doc.IsLinked,
                        is_workshared = doc.IsWorkshared,
                        is_active = app.ActiveUIDocument?.Document?.Equals(doc) == true,
                    });
                }
                return docs;
            });
            return Ok(result);
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    private static CommandResponse GetDiagnostics()
    {
        return Ok(new
        {
            has_app = MainThreadDispatcher.HasApp,
            total_enqueued = MainThreadDispatcher.TotalEnqueued,
            last_queue_status = MainThreadDispatcher.LastQueueStatus,
            assembly_location = System.Reflection.Assembly.GetExecutingAssembly().Location,
            addin_version = AddinVersie,
            log = MainThreadDispatcher.GetLog().TakeLast(100).ToArray()
        });
    }

    private static CommandResponse GetFamiliesLoaded(CommandRequest request)
    {
        var target = TargetDoc(request);
        try
        {
            var result = MainThreadDispatcher.GetResult(app =>
            {
                var families = new List<object>();
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;
                    foreach (Family family in new FilteredElementCollector(doc).OfClass(typeof(Family)))
                    {
                        var famCat = FamilyCategory(doc, family);
                        var catId = famCat?.Id.Value ?? 0;
                        var catName = famCat?.Name;
                        if (string.IsNullOrEmpty(catName))
                            catName = catId != 0 ? ((BuiltInCategory)catId).ToString() : "Uncategorized";
                        families.Add(new
                        {
                            name = family.Name,
                            category = catName,
                            category_id = catId,
                            type_count = family.GetFamilySymbolIds().Count,
                            document = doc.Title
                        });
                    }
                }
                return families;
            });
            return Ok(result);
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    private static Category? FamilyCategory(Document doc, Family family)
    {
        var famCat = family.FamilyCategory ?? family.Category;
        if (famCat == null)
        {
            var symbolIds = family.GetFamilySymbolIds();
            if (symbolIds.Count > 0)
                famCat = (doc.GetElement(symbolIds.First()) as FamilySymbol)?.Category;
        }
        return famCat;
    }

    private static CommandResponse GetFamilyDetail(CommandRequest request)
    {
        var familyName = HandlerUtil.Str(request.Params, "name");
        if (string.IsNullOrWhiteSpace(familyName))
            return Err("Parameter 'name' is required");
        var target = TargetDoc(request);

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;
                    foreach (Family family in new FilteredElementCollector(doc).OfClass(typeof(Family)))
                    {
                        if (!family.Name.Equals(familyName, StringComparison.OrdinalIgnoreCase))
                            continue;

                        var famCat = FamilyCategory(doc, family);
                        var catName = famCat?.Name;
                        if (string.IsNullOrEmpty(catName))
                            catName = famCat != null ? ((BuiltInCategory)famCat.Id.Value).ToString() : "Uncategorized";

                        var types = new List<object>();
                        foreach (var symbolId in family.GetFamilySymbolIds())
                        {
                            if (doc.GetElement(symbolId) is not FamilySymbol symbol) continue;
                            var typeParams = new List<object>();
                            foreach (Parameter param in symbol.Parameters)
                            {
                                if (param == null) continue;
                                typeParams.Add(new
                                {
                                    name = param.Definition?.Name ?? "?",
                                    value = GetParamDisplayValue(param),
                                    type = param.StorageType.ToString(),
                                    is_read_only = param.IsReadOnly
                                });
                            }
                            types.Add(new
                            {
                                name = symbol.Name,
                                element_id = symbolId.Value,
                                parameter_count = typeParams.Count,
                                parameters = typeParams
                            });
                        }

                        var familyParams = new List<object>();
                        foreach (Parameter param in family.Parameters)
                        {
                            if (param == null) continue;
                            familyParams.Add(new
                            {
                                name = param.Definition?.Name ?? "?",
                                value = GetParamDisplayValue(param),
                                type = param.StorageType.ToString(),
                                is_read_only = param.IsReadOnly
                            });
                        }

                        return (object)new
                        {
                            name = family.Name,
                            category = catName,
                            category_id = famCat?.Id.Value ?? 0,
                            document = doc.Title,
                            is_editable = family.IsEditable,
                            is_in_place = family.IsInPlace,
                            type_count = types.Count,
                            family_parameters = familyParams,
                            types = types
                        };
                    }
                }
                throw new ElementNotFoundException($"Family '{familyName}' not found");
            });
            return Ok(result);
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    internal static string GetParamDisplayValue(Parameter p)
    {
        if (p == null) return "";
        try
        {
            var vs = p.AsValueString();
            if (!string.IsNullOrEmpty(vs)) return vs;
            var s = p.AsString();
            if (!string.IsNullOrEmpty(s)) return s;
            if (p.StorageType == StorageType.Integer) return p.AsInteger().ToString();
            if (p.StorageType == StorageType.Double) return p.AsDouble().ToString("F3");
            if (p.StorageType == StorageType.ElementId) return p.AsElementId().Value.ToString();
            return "";
        }
        catch { return ""; }
    }

    private static CommandResponse GetFamilyInstances(CommandRequest request)
    {
        int limit = 500;
        if (request.Params?.TryGetValue("limit", out var limitEl) == true && limitEl.ValueKind == JsonValueKind.Number) limit = limitEl.GetInt32();
        var skipCategories = HandlerUtil.Str(request.Params, "skip_categories") ?? "Curtain Panels,Curtain Wall Mullions";
        var skipList = skipCategories.Split(',').Select(s => s.Trim()).ToHashSet();
        var target = TargetDoc(request);

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var allInstances = new List<object>();
                var totalCount = 0;
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;
                    foreach (FamilyInstance fi in new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)))
                    {
                        totalCount++;
                        var catName = fi.Category?.Name;
                        if (string.IsNullOrEmpty(catName)) catName = "Uncategorized";
                        if (skipList.Contains(catName)) continue;
                        var instParams = new List<object>();
                        foreach (Parameter p in fi.Parameters)
                        {
                            if (p == null) continue;
                            instParams.Add(new
                            {
                                name = p.Definition?.Name ?? "?",
                                value = GetParamDisplayValue(p),
                                type = p.StorageType.ToString(),
                                is_read_only = p.IsReadOnly
                            });
                        }
                        allInstances.Add(new
                        {
                            element_id = fi.Id.Value,
                            family = fi.Symbol?.Family?.Name ?? "?",
                            type = fi.Symbol?.Name ?? "?",
                            category = catName,
                            level = doc.GetElement(fi.LevelId)?.Name ?? "",
                            host = fi.Host?.Name ?? "",
                            mark = GetParamDisplayValue(fi.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)),
                            comments = GetParamDisplayValue(fi.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)),
                            document = doc.Title,
                            parameter_count = instParams.Count,
                            parameters = instParams
                        });
                        if (allInstances.Count >= limit) break;
                    }
                    if (allInstances.Count >= limit) break;
                }
                return (object)new { total_instances = totalCount, returned = allInstances.Count, limit, instances = allInstances };
            }, timeoutMs: 120000);
            return Ok(result);
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    private static CommandResponse QueryElements(CommandRequest request)
    {
        var typeId = HandlerUtil.Str(request.Params, "type_id");
        if (string.IsNullOrWhiteSpace(typeId))
            return Err("Parameter 'type_id' is required (zie list_type_catalog)");
        var entry = TypeCatalog.Get(typeId);
        if (entry == null)
            return Err($"Unknown type_id: {typeId}");

        var perDocErrors = new List<Dictionary<string, object?>>();
        // target_document beperkt de vraag tot één open model; element-id's botsen tussen modellen.
        string? targetDoc = TargetDoc(request);
        try
        {
            var result = MainThreadDispatcher.GetResult<List<Dictionary<string, object?>>>(app =>
            {
                var allResults = new List<Dictionary<string, object?>>();
                foreach (Document doc in app.Application.Documents)
                {
                    if (targetDoc != null && doc.Title != targetDoc) continue;
                    try
                    {
                        var rows = DispatchQuery(entry, doc, request.Params);
                        foreach (var row in rows) row["document_title"] = doc.Title;
                        allResults.AddRange(rows);
                    }
                    catch (Exception ex) when (ex is NotSupportedException or NotImplementedException) { throw; }
                    // Een type_id uit de catalogus zonder uitwerking gaf "count 0" met de fout verstopt in errors
                    // (breedtest 25-11-2026: 12 type_id's). Meld het als fout van de opdracht.
                    catch (ArgumentException ex) when (ex.Message.StartsWith("Unknown Pattern-"))
                    {
                        throw new NotImplementedException($"type_id '{typeId}' staat in list_type_catalog, maar is in deze versie van de addin niet uitgewerkt");
                    }
                    catch (Exception ex)
                    {
                        perDocErrors.Add(new Dictionary<string, object?>() { ["document"] = doc.Title, ["error"] = ex.Message });
                    }
                }
                return allResults;
            }, timeoutMs: 120000);
            return Ok(new { type_id = typeId, pattern = entry.Pattern, count = result!.Count, elements = result, errors = perDocErrors });
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    private static CommandResponse GetElementDetail(CommandRequest request)
    {
        var typeId = HandlerUtil.Str(request.Params, "type_id");
        long elementId = 0;
        if (request.Params?.TryGetValue("element_id", out var eid) == true && eid.ValueKind == JsonValueKind.Number)
            elementId = eid.GetInt64();
        if (string.IsNullOrWhiteSpace(typeId) || elementId == 0)
            return Err("Parameters 'type_id' and 'element_id' are required");
        var entry = TypeCatalog.Get(typeId);
        if (entry == null)
            return Err($"Unknown type_id: {typeId}");
        var target = TargetDoc(request);

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Exception? lastError = null;
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;
                    try { return DispatchDetail(entry, doc, elementId); }
                    catch (Exception ex) when (ex is NotSupportedException or NotImplementedException) { throw; }
                    catch (ElementNotFoundException) { continue; }
                    catch (Exception ex) { lastError = ex; }
                }
                if (lastError != null) throw lastError;
                throw new ElementNotFoundException($"Element {elementId} not found for type '{typeId}'");
            });
            return Ok(result);
        }
        catch (Exception ex)
        {
            return Err($"Failed: {Unwrap(ex)}");
        }
    }

    private static CommandResponse ListTypeCatalog(CommandRequest request)
    {
        var pattern = HandlerUtil.Str(request.Params, "pattern");
        var entries = pattern != null ? TypeCatalog.ByPattern(pattern) : TypeCatalog.All.Values;
        return Ok(new
        {
            count = entries.Count(),
            types = entries.Select(e => new
            {
                type_id = e.TypeId,
                pattern = e.Pattern,
                revit_class = e.RevitClass,
                nlrs_chapter = e.NlrsChapter,
                nlrs_relevance = e.NlrsRelevance,
                is_reference = e.IsReference,
                discipline = e.Discipline
            })
        });
    }

    private static List<Dictionary<string, object?>> DispatchQuery(TypeCatalogEntry entry, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        return entry.Pattern switch
        {
            "A" => PatternA_Handlers.Query(entry.TypeId, doc, extraParams),
            "B" => PatternB_Handlers.Query(entry.TypeId, doc, extraParams),
            "C" => PatternC_Handlers.Query(entry.TypeId, doc, extraParams),
            "D" => PatternD_Handlers.Query(entry.TypeId, doc, extraParams),
            "E" => PatternE_Handlers.Query(entry.TypeId, doc, extraParams),
            "F" => PatternF_Handlers.Query(entry.TypeId, doc, extraParams),
            "G" => PatternG_Handlers.Query(entry.TypeId, doc, extraParams),
            _ => throw new NotImplementedException($"Pattern {entry.Pattern} not yet implemented")
        };
    }

    private static object? DispatchDetail(TypeCatalogEntry entry, Document doc, long elementId)
    {
        return entry.Pattern switch
        {
            "A" => PatternA_Handlers.Detail(entry.TypeId, doc, elementId),
            "B" => PatternB_Handlers.Detail(entry.TypeId, doc, elementId),
            "C" => PatternC_Handlers.Detail(entry.TypeId, doc, elementId),
            "D" => PatternD_Handlers.Detail(entry.TypeId, doc, elementId),
            "E" => PatternE_Handlers.Detail(entry.TypeId, doc, elementId),
            "F" => PatternF_Handlers.Detail(entry.TypeId, doc, elementId),
            "G" => PatternG_Handlers.Detail(entry.TypeId, doc, elementId),
            _ => throw new NotImplementedException($"Pattern {entry.Pattern} detail not yet implemented")
        };
    }

    private static string? TargetDoc(CommandRequest request) => HandlerUtil.Str(request.Params, "target_document");

    private static CommandResponse Ok(object? data) => new() { Success = true, Data = data };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    /// <summary>De dispatcher verpakt fouten als "Main thread error"; geef de echte melding terug.</summary>
    private static string Unwrap(Exception ex) => ex.InnerException?.Message ?? ex.Message;

    public void Dispose()
    {
        _cts.Cancel();
        try { _listener?.Stop(); } catch { }
        try
        {
            // bridge.json alleen weghalen als hij nog van deze Revit is
            if (File.Exists(BridgeJsonPad) && File.ReadAllText(BridgeJsonPad).Contains($"\"pid\":{Environment.ProcessId}"))
                File.Delete(BridgeJsonPad);
        }
        catch { }
    }
}
