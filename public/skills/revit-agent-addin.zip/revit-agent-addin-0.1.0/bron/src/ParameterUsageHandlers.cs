using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// report_parameter_usage — read-only introspection of shared-parameter binding + usage
/// Answers "in welke categorieën/families/types/elementen zit een
/// gegeven shared parameter, en wat is z'n datatype" — input voor de SP-remediation-Excel én
/// de bind-stap van een latere swap_parameter.
///
/// Three Revit-API layers, combined:
///   1. doc.ParameterBindings  → categorie-niveau, alleen project-params (instant).
///   2. ElementType.Parameters met p.IsShared/p.GUID → family/type-niveau, GEEN family openen.
///   3. instance-scan (achter scan_instances-flag) → instance-niveau, duur op echte projecten.
///
/// params:
///   guids            : [string]  optioneel — filter tot deze shared-param-GUIDs (anders alle).
///   target_document  : string    optioneel — scope op doc-Title (id-collision/Project1-guard).
///   scan_instances   : bool       default false — ook FamilyInstances/elementen scannen.
/// </summary>
public static class ParameterUsageHandlers
{
    public static CommandResponse ReportParameterUsage(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool scanInstances = GetBool(p, "scan_instances", false);

        var wantGuids = new HashSet<string>();
        if (p != null && p.TryGetValue("guids", out var garr) && garr.ValueKind == JsonValueKind.Array)
            foreach (var item in garr.EnumerateArray())
                if (item.ValueKind == JsonValueKind.String)
                {
                    var g = item.GetString();
                    if (!string.IsNullOrWhiteSpace(g)) wantGuids.Add(g.Trim().ToLowerInvariant());
                }
        bool filtered = wantGuids.Count > 0;

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var docResults = new List<Dictionary<string, object?>>();

                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;

                    // ── 1. SharedParameterElement map: guid → record (name, definition, datatype, id) ──
                    var byGuid = new Dictionary<string, ParamRecord>();
                    foreach (var sp in new FilteredElementCollector(doc)
                                 .OfClass(typeof(SharedParameterElement))
                                 .Cast<SharedParameterElement>()
                                 .Where(e => e.IsValidObject))
                    {
                        string guid;
                        try { guid = sp.GuidValue.ToString().ToLowerInvariant(); } catch { continue; }
                        if (filtered && !wantGuids.Contains(guid)) continue;

                        InternalDefinition? def = null;
                        string? dataType = null;
                        try
                        {
                            def = sp.GetDefinition();
                            try { dataType = def?.GetDataType()?.TypeId; } catch { }
                        }
                        catch { }

                        var rec = new ParamRecord
                        {
                            Guid = guid,
                            Name = sp.Name,
                            ElementId = RevitIdUtil.Fid(sp.Id),
                            DataType = dataType,
                        };

                        // ── project-parameter binding (categorie-niveau) ──
                        if (def != null)
                        {
                            try
                            {
                                var binding = doc.ParameterBindings.get_Item(def);
                                if (binding is ElementBinding eb)
                                {
                                    rec.Bound = true;
                                    rec.BindingKind = binding is InstanceBinding ? "instance"
                                                    : binding is TypeBinding ? "type" : "element";
                                    foreach (Category c in eb.Categories)
                                        if (c != null) rec.BindingCategories.Add(c.Name);
                                }
                            }
                            catch { }
                        }
                        byGuid[guid] = rec;
                    }

                    // ── 2. type-level usage scan (FamilySymbol + system types) ──
                    ScanParameters(doc, byGuid, wantGuids, filtered, isType: true);

                    // ── 3. optional instance-level usage scan ──
                    if (scanInstances)
                        ScanParameters(doc, byGuid, wantGuids, filtered, isType: false);

                    // requested-but-absent GUIDs (only meaningful when filtering)
                    var notFound = filtered
                        ? wantGuids.Where(g => !byGuid.ContainsKey(g)).ToList()
                        : new List<string>();

                    docResults.Add(new Dictionary<string, object?>
                    {
                        ["document"] = doc.Title,
                        ["scanned_instances"] = scanInstances,
                        ["parameter_count"] = byGuid.Count,
                        ["parameters"] = byGuid.Values
                            .OrderBy(r => r.Name)
                            .Select(r => r.ToDict())
                            .ToList(),
                        ["not_found_guids"] = notFound,
                    });
                }

                return (object)new Dictionary<string, object?>
                {
                    ["target_document"] = target,
                    ["documents"] = docResults,
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>Scan every element type (isType=true) or instance (false) for shared params and
    /// record the family/category/type where each target GUID appears.</summary>
    private static void ScanParameters(
        Document doc, Dictionary<string, ParamRecord> byGuid,
        HashSet<string> wantGuids, bool filtered, bool isType)
    {
        var collector = new FilteredElementCollector(doc);
        collector = isType ? collector.WhereElementIsElementType() : collector.WhereElementIsNotElementType();

        foreach (var elem in collector)
        {
            if (elem == null || !elem.IsValidObject) continue;
            var cat = elem.Category?.Name ?? "";
            string? family = (elem as FamilySymbol)?.Family?.Name;
            var typeName = elem.Name;

            foreach (Parameter par in elem.Parameters)
            {
                if (par?.Definition == null) continue;
                bool shared;
                try { shared = par.IsShared; } catch { continue; }
                if (!shared) continue;
                string g;
                try { g = par.GUID.ToString().ToLowerInvariant(); } catch { continue; }
                if (filtered && !wantGuids.Contains(g)) continue;

                if (!byGuid.TryGetValue(g, out var rec))
                {
                    // a shared param used on a type but with no SharedParameterElement collected
                    // (filtered-out or edge case) — only track when not filtering them away.
                    if (filtered && !wantGuids.Contains(g)) continue;
                    rec = new ParamRecord { Guid = g, Name = par.Definition.Name, ElementId = 0 };
                    byGuid[g] = rec;
                }

                var usage = new UsageHit { Family = family, Category = cat, TypeName = typeName };
                if (isType) rec.AddTypeUsage(usage); else rec.AddInstanceUsage(usage);
            }
        }
    }

    private sealed class UsageHit
    {
        public string? Family;
        public string Category = "";
        public string TypeName = "";
        public string Key() => $"{Family}|{Category}|{TypeName}";
    }

    private sealed class ParamRecord
    {
        public string Guid = "";
        public string Name = "";
        public int ElementId;
        public string? DataType;
        public bool Bound;
        public string? BindingKind;
        public List<string> BindingCategories = new();

        private readonly Dictionary<string, UsageHit> _typeUsage = new();
        private readonly Dictionary<string, UsageHit> _instanceUsage = new();
        private int _instanceHits;

        public void AddTypeUsage(UsageHit u) => _typeUsage.TryAdd(u.Key(), u);
        public void AddInstanceUsage(UsageHit u) { _instanceUsage.TryAdd(u.Key(), u); _instanceHits++; }

        public Dictionary<string, object?> ToDict() => new()
        {
            ["guid"] = Guid,
            ["name"] = Name,
            ["element_id"] = ElementId,
            ["data_type"] = DataType,
            ["binding"] = new Dictionary<string, object?>
            {
                ["bound"] = Bound,
                ["kind"] = BindingKind,
                ["categories"] = BindingCategories.Distinct().OrderBy(c => c).ToList(),
            },
            ["type_usage_count"] = _typeUsage.Count,
            ["type_usage"] = _typeUsage.Values
                .OrderBy(u => u.Family).ThenBy(u => u.TypeName)
                .Select(u => new Dictionary<string, object?>
                {
                    ["family"] = u.Family,
                    ["category"] = u.Category,
                    ["type_name"] = u.TypeName,
                }).ToList(),
            ["instance_usage_count"] = _instanceHits,
            ["instance_usage"] = _instanceUsage.Values
                .OrderBy(u => u.Family).ThenBy(u => u.TypeName)
                .Select(u => new Dictionary<string, object?>
                {
                    ["family"] = u.Family,
                    ["category"] = u.Category,
                    ["type_name"] = u.TypeName,
                }).ToList(),
        };
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
