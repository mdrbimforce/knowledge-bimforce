using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// create_views — create views in a target document from a carry-over plan.
/// Phase 1: level-driven plans (FloorPlan/CeilingPlan/EngineeringPlan) + AreaPlan + 3D (isometric).
/// Phase 2a (this build): Section/Detail at SOURCE coordinates (CropBox read cross-doc) + Drafting
/// views (cross-doc CopyElements, view-to-view — content preserved). Phase 2b (todo): Elevation
/// (ElevationMarker + host-plan + direction-index, needs live calibration), Schedule, Legend.
///
/// Mirrors the WriteHandlers safety model: dry_run (default TRUE here — creation is destructive-ish, so
/// opt-in), save_first (doc.Save -> numbered backup before any mutation), one Transaction, per-item
/// status rows, target_document scope. View names are unique project-wide, so a name that already exists
/// is reported "exists" and skipped (idempotent re-runs).
///
/// Section/Detail/Drafting need the SOURCE document open too (source_document) — their geometry/content
/// is read cross-doc via source_element_id (BoundingBoxXYZ is pure geometry, document-independent;
/// drafting content is copied with ElementTransformUtils.CopyElements). 
///
/// params:
///   target_document : string (required)
///   source_document : string (required for sections/details/drafting)
///   dry_run    : bool (default true)
///   save_first : bool (default false)
///   plans    : [{ source_name, target_name?, view_type (FloorPlan|CeilingPlan|EngineeringPlan), target_level, view_type_name?, source_element_id? }]
///   area_plans : [{ source_name, target_name?, target_level, source_element_id }]
///   threed   : [{ source_name, view_type_name?, source_element_id? }]
///   sections : [{ source_name, target_name?, view_type_name?, source_element_id }]
///   details  : [{ source_name, target_name?, view_type_name?, source_element_id }]
///   drafting : [{ source_name, view_type_name?, source_element_id }]
///   elevations : [{ source_name, target_name?, view_type_name?, source_element_id? }]
/// Nieuw maken zonder bron kan voor plans, threed en elevations (een aanzicht komt bij de oorsprong in de eerste
/// plattegrond). Sections, details en drafting kopiëren altijd een view uit een ander open model
/// (source_document + source_element_id); een doorsnede op eigen coördinaten kan deze opdracht niet.
/// source_name is de naam van de nieuwe view (of target_name als die er is).
/// </summary>
public static class CreateViewHandlers
{
    public static CommandResponse CreateViews(CommandRequest request)
    {
        var p = request.Params;
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        bool saveAfter = GetBool(p, "save_after", false); // alleen bewaren als de gebruiker het vraagt
        string? target = GetString(p, "target_document");
        if (target == null)
            return new CommandResponse { Success = false, Error = "target_document is required" };

        // Optional: copy view parameters (e.g. hoofd_map/sub_map — Project Browser organisation) from the
        // SOURCE view to each new view. View templates are intentionally NOT assigned here — those run via
        // the rename workbook, keeping the processes cleanly separated (review).
        string? sourceDoc = GetString(p, "source_document");
        var copyParams = new List<string>();
        if (p != null && p.TryGetValue("copy_params", out var cpArr) && cpArr.ValueKind == JsonValueKind.Array)
            foreach (var it in cpArr.EnumerateArray())
                if (it.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(it.GetString()))
                    copyParams.Add(it.GetString()!.Trim());

        var plans = ParseArray(p, "plans");
        var threed = ParseArray(p, "threed");
        var areaPlans = ParseArray(p, "area_plans");
        var sections = ParseArray(p, "sections");
        var details = ParseArray(p, "details");
        var drafting = ParseArray(p, "drafting");
        var elevations = ParseArray(p, "elevations");
        if (plans.Count == 0 && threed.Count == 0 && areaPlans.Count == 0
            && sections.Count == 0 && details.Count == 0 && drafting.Count == 0 && elevations.Count == 0)
            return new CommandResponse { Success = false, Error = "nothing to create (need plans/area_plans/threed/sections/details/drafting/elevations)" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (d.Title == target) { doc = d; break; } }
                if (doc == null) return (object)new Dictionary<string, object?> { ["error"] = $"target_document '{target}' not open" };

                Document? srcDoc = null;
                if (sourceDoc != null)
                    foreach (Document d in app.Application.Documents) { if (d.Title == sourceDoc) { srcDoc = d; break; } }

                // Copy the requested view-params from a source view (by element id) onto a freshly created
                // view. Handles every storage type: String set directly; Integer (e.g. Discipline enum) and
                // Double by value; ElementId (e.g. Phase) resolved by NAME in the target (phases/levels are
                // doc-level, carried with the template). Read-only params (Discipline on Structural Plans) are
                // skipped gracefully. Phase/Discipline resolve via their BuiltInParameter so UI-localisation
                // can't break the name lookup.
                Parameter? ResolveParam(Element el, string name)
                {
                    if (name == "Phase") { var bp = el.get_Parameter(BuiltInParameter.VIEW_PHASE); if (bp != null) return bp; }
                    if (name == "Discipline") { var bp = el.get_Parameter(BuiltInParameter.VIEW_DISCIPLINE); if (bp != null) return bp; }
                    return el.LookupParameter(name);
                }
                List<string> CopyParams(int srcId, View dst)
                {
                    var done = new List<string>();
                    if (srcDoc == null || copyParams.Count == 0 || srcId == 0) return done;
                    if (srcDoc.GetElement(new ElementId((long)srcId)) is not View sv) return done;
                    foreach (var pn in copyParams)
                    {
                        try
                        {
                            var sp = ResolveParam(sv, pn);
                            var dp = ResolveParam(dst, pn);
                            if (sp == null || dp == null || dp.IsReadOnly || !sp.HasValue) continue;
                            switch (sp.StorageType)
                            {
                                case StorageType.String: dp.Set(sp.AsString() ?? ""); done.Add(pn); break;
                                case StorageType.Integer: dp.Set(sp.AsInteger()); done.Add(pn); break;
                                case StorageType.Double: dp.Set(sp.AsDouble()); done.Add(pn); break;
                                case StorageType.ElementId:
                                    var srcEl = srcDoc.GetElement(sp.AsElementId());
                                    if (srcEl != null)
                                    {
                                        var match = new FilteredElementCollector(doc).OfClass(srcEl.GetType())
                                            .FirstOrDefault(e => e.Name == srcEl.Name);
                                        if (match != null) { dp.Set(match.Id); done.Add(pn); }
                                    }
                                    break;
                            }
                        }
                        catch { }
                    }
                    return done;
                }

                // Standard crop/clip defaults for section-family views (sections/details/elevations): Crop
                // View off, Crop Region Visible off, Annotation Crop off, Far Clipping = No clip. Set on both
                // newly created and already-existing views so a re-run cleans up earlier batches too.
                // Far-clip int = 0 (No clip) — verify on first elevation.
                int ApplyViewDefaults(View v)
                {
                    int n = 0;
                    try { v.CropBoxActive = false; n++; } catch { }
                    try { v.CropBoxVisible = false; } catch { }
                    try { var ap = v.get_Parameter(BuiltInParameter.VIEWER_ANNOTATION_CROP_ACTIVE); if (ap != null && !ap.IsReadOnly) ap.Set(0); } catch { }
                    try { var fc = v.get_Parameter(BuiltInParameter.VIEWER_BOUND_FAR_CLIPPING); if (fc != null && !fc.IsReadOnly) fc.Set(0); } catch { }
                    return n;
                }

                // Index existing non-template views by name (project-wide unique) + the levels and VFTs.
                var existingNames = new HashSet<string>(StringComparer.Ordinal);
                foreach (var v in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>())
                    if (!v.IsTemplate) existingNames.Add(v.Name);
                // AreaPlan view names are scheme-scoped (the same name repeats across schemes and may
                // coexist with a same-named floor plan) — index existing area plans by (scheme, name).
                var existingAreaByScheme = new HashSet<(string, string)>();
                foreach (var v in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>())
                    if (v is ViewPlan apv && !apv.IsTemplate && apv.ViewType == ViewType.AreaPlan && apv.AreaScheme != null)
                        existingAreaByScheme.Add((apv.AreaScheme.Name, apv.Name));
                var levelByName = new Dictionary<string, Level>(StringComparer.Ordinal);
                foreach (var lv in new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>())
                    levelByName[lv.Name] = lv;
                var vfts = new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>().ToList();
                var areaSchemeByName = new Dictionary<string, AreaScheme>(StringComparer.Ordinal);
                foreach (var a in new FilteredElementCollector(doc).OfClass(typeof(AreaScheme)).Cast<AreaScheme>())
                    areaSchemeByName[a.Name] = a;

                ViewFamilyType? PickVft(ViewFamily fam, string? preferName)
                {
                    var of = vfts.Where(v => v.ViewFamily == fam).ToList();
                    if (preferName != null)
                    {
                        var m = of.FirstOrDefault(v => v.Name == preferName);
                        if (m != null) return m;
                    }
                    return of.FirstOrDefault();
                }

                var results = new List<Dictionary<string, object?>>();
                bool actionable = false;
                // Target view-names that should get the section-family crop/clip defaults (sections/details/
                // elevations) — collected for both create and exists, applied at the end of the transaction.
                var defaultTargetNames = new List<string>();

                // Resolve everything first (so dry_run reports exactly what a real run would do, and so the
                // save-first backup only happens when there is genuinely something to create).
                var planJobs = new List<(string name, string tname, ViewFamilyType vft, Level level, int srcId)>();
                foreach (var j in plans)
                {
                    var name = Str(j, "source_name");
                    var tname = Str(j, "target_name");
                    if (string.IsNullOrWhiteSpace(tname)) tname = name;
                    var vtype = Str(j, "view_type");
                    var tlevel = Str(j, "target_level");
                    var vtName = Str(j, "view_type_name");
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    if (existingNames.Contains(tname)) { results.Add(Row(name, "exists", null, $"view-naam '{tname}' bestaat al in target")); continue; }
                    var fam = vtype switch
                    {
                        "FloorPlan" => ViewFamily.FloorPlan,
                        "CeilingPlan" => ViewFamily.CeilingPlan,
                        "EngineeringPlan" => ViewFamily.StructuralPlan,
                        _ => (ViewFamily?)null,
                    };
                    if (fam == null) { results.Add(Row(name, "skipped", null, $"view_type '{vtype}' niet in fase 1")); continue; }
                    if (string.IsNullOrWhiteSpace(tlevel) || !levelByName.TryGetValue(tlevel, out var lvl))
                    { results.Add(Row(name, "error", null, $"target_level '{tlevel}' niet gevonden")); continue; }
                    var vft = PickVft(fam.Value, vtName);
                    if (vft == null) { results.Add(Row(name, "error", null, $"geen ViewFamilyType voor {fam}")); continue; }
                    planJobs.Add((name, tname, vft, lvl, IntOf(j, "source_element_id")));
                    actionable = true;
                }

                var threedJobs = new List<(string name, ViewFamilyType vft, int srcId)>();
                foreach (var j in threed)
                {
                    var name = Str(j, "source_name");
                    var vtName = Str(j, "view_type_name");
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    if (existingNames.Contains(name)) { results.Add(Row(name, "exists", null, "view-naam bestaat al in target")); continue; }
                    var vft = PickVft(ViewFamily.ThreeDimensional, vtName);
                    if (vft == null) { results.Add(Row(name, "error", null, "geen 3D ViewFamilyType")); continue; }
                    threedJobs.Add((name, vft, IntOf(j, "source_element_id")));
                    actionable = true;
                }

                var areaJobs = new List<(string name, string tname, AreaScheme scheme, Level level, int srcId)>();
                foreach (var j in areaPlans)
                {
                    var name = Str(j, "source_name");
                    var tname = Str(j, "target_name");
                    if (string.IsNullOrWhiteSpace(tname)) tname = name;
                    var tlevel = Str(j, "target_level");
                    int srcId = IntOf(j, "source_element_id");
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    if (string.IsNullOrWhiteSpace(tlevel) || !levelByName.TryGetValue(tlevel, out var lvl))
                    { results.Add(Row(name, "error", null, $"target_level '{tlevel}' niet gevonden")); continue; }
                    // An area plan belongs to an AreaScheme — read the source plan's scheme and match it by
                    // name in the target (schemes are template-level, carried over with the template).
                    string? schemeName = null;
                    if (srcDoc != null && srcId != 0 && srcDoc.GetElement(new ElementId((long)srcId)) is ViewPlan svp && svp.AreaScheme != null)
                        schemeName = svp.AreaScheme.Name;
                    if (schemeName == null) { results.Add(Row(name, "error", lvl.Name, "bron-AreaScheme onbekend (source_document/_element_id nodig)")); continue; }
                    if (!areaSchemeByName.TryGetValue(schemeName, out var scheme))
                    { results.Add(Row(name, "error", lvl.Name, $"AreaScheme '{schemeName}' niet in target")); continue; }
                    if (existingAreaByScheme.Contains((scheme.Name, tname)))
                    { results.Add(Row(name, "exists", lvl.Name, $"area plan '{tname}' bestaat al in scheme '{scheme.Name}'")); continue; }
                    areaJobs.Add((name, tname, scheme, lvl, srcId));
                    actionable = true;
                }

                // Source view (cross-doc) by element id — geometry/content lives in the source template.
                View? SrcView(int id)
                {
                    if (srcDoc == null || id == 0) return null;
                    return srcDoc.GetElement(new ElementId((long)id)) as View;
                }
                // A BoundingBoxXYZ is pure geometry (origin/direction/extents via its Transform) and is
                // document-independent — clone the source view's CropBox so the new view lands at the same
                // world coordinates. Repositioning in the target afterwards is trivial.
                BoundingBoxXYZ? CloneBox(BoundingBoxXYZ? s)
                {
                    if (s == null) return null;
                    return new BoundingBoxXYZ { Transform = s.Transform, Min = s.Min, Max = s.Max };
                }

                // ── Sections + Details: ViewSection.CreateSection/CreateDetail at the source box ──
                var sectionJobs = new List<(string name, string tname, ViewFamilyType vft, BoundingBoxXYZ box, int srcId, bool detail)>();
                foreach (var (arr, isDetail, fam) in new[] { (sections, false, ViewFamily.Section), (details, true, ViewFamily.Detail) })
                {
                    foreach (var j in arr)
                    {
                        var name = Str(j, "source_name");
                        var tname = Str(j, "target_name");
                        if (string.IsNullOrWhiteSpace(tname)) tname = name;
                        var vtName = Str(j, "view_type_name");
                        int srcId = IntOf(j, "source_element_id");
                        if (string.IsNullOrWhiteSpace(name)) continue;
                        defaultTargetNames.Add(tname);   // crop/clip defaults whether it's created now or already exists
                        if (existingNames.Contains(tname)) { results.Add(Row(name, "exists", null, $"view-naam '{tname}' bestaat al in target")); continue; }
                        if (srcDoc == null || srcId == 0) { results.Add(Row(name, "error", null, "source_document + source_element_id vereist voor source-coord plaatsing")); continue; }
                        var sv = SrcView(srcId);
                        if (sv == null) { results.Add(Row(name, "error", null, $"bron-view id {srcId} niet gevonden in source")); continue; }
                        var box = CloneBox(sv.CropBox);
                        if (box == null) { results.Add(Row(name, "error", null, "bron-view heeft geen CropBox (geen geometrie om op te plaatsen)")); continue; }
                        var vft = PickVft(fam, vtName);
                        if (vft == null) { results.Add(Row(name, "error", null, $"geen ViewFamilyType voor {fam}")); continue; }
                        sectionJobs.Add((name, tname, vft, box, srcId, isDetail));
                        actionable = true;
                    }
                }

                // ── Drafting views: ViewDrafting.Create + cross-doc CopyElements (content preserved) ──
                var draftingJobs = new List<(string name, ViewFamilyType vft, View srcView, List<ElementId> elems)>();
                foreach (var j in drafting)
                {
                    var name = Str(j, "source_name");
                    var vtName = Str(j, "view_type_name");
                    int srcId = IntOf(j, "source_element_id");
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    if (existingNames.Contains(name)) { results.Add(Row(name, "exists", null, "view-naam bestaat al in target")); continue; }
                    if (srcDoc == null || srcId == 0) { results.Add(Row(name, "error", null, "source_document + source_element_id vereist voor drafting-copy")); continue; }
                    var sv = SrcView(srcId);
                    if (sv == null) { results.Add(Row(name, "error", null, $"bron-view id {srcId} niet gevonden in source")); continue; }
                    var vft = PickVft(ViewFamily.Drafting, vtName);
                    if (vft == null) { results.Add(Row(name, "error", null, "geen Drafting ViewFamilyType")); continue; }
                    var elems = new FilteredElementCollector(srcDoc, sv.Id).WhereElementIsNotElementType().ToElementIds().ToList();
                    draftingJobs.Add((name, vft, sv, elems));
                    actionable = true;
                }

                // ── Elevations: an elevation needs an ElevationMarker hosted in a plan + a facing direction.
                // We create the marker at index 0, then ROTATE the marker so the elevation's ViewDirection
                // matches the source elevation's — calibration-free (no need to know the index->direction map).
                // Markers are spread along +X near the origin; repositioning in the target is trivial.
                ElementId hostPlanId = ElementId.InvalidElementId;
                if (elevations.Count > 0)
                {
                    var host = new FilteredElementCollector(doc).OfClass(typeof(ViewPlan)).Cast<ViewPlan>()
                        .FirstOrDefault(v => !v.IsTemplate && v.ViewType == ViewType.FloorPlan && v.GenLevel != null);
                    if (host != null) hostPlanId = host.Id;
                }
                var elevationJobs = new List<(string name, string tname, ViewFamilyType vft, XYZ origin, int scale, XYZ? srcDir, int srcId)>();
                int elevIdx = 0;
                foreach (var j in elevations)
                {
                    var name = Str(j, "source_name");
                    var tname = Str(j, "target_name");
                    if (string.IsNullOrWhiteSpace(tname)) tname = name;
                    var vtName = Str(j, "view_type_name");
                    int srcId = IntOf(j, "source_element_id");
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    defaultTargetNames.Add(tname);   // crop/clip defaults whether it's created now or already exists
                    if (existingNames.Contains(tname)) { results.Add(Row(name, "exists", null, $"view-naam '{tname}' bestaat al in target")); continue; }
                    if (hostPlanId == ElementId.InvalidElementId) { results.Add(Row(name, "error", null, "geen host-FloorPlan in target om elevation-marker in te plaatsen")); continue; }
                    var vft = PickVft(ViewFamily.Elevation, vtName);
                    if (vft == null) { results.Add(Row(name, "error", null, "geen Elevation ViewFamilyType")); continue; }
                    var sv = SrcView(srcId);
                    int scale = 100; XYZ? srcDir = null;
                    if (sv != null) { try { scale = sv.Scale; } catch { } try { srcDir = sv.ViewDirection; } catch { } }
                    var origin = new XYZ(elevIdx * 10.0, 0, 0);
                    elevationJobs.Add((name, tname, vft, origin, scale, srcDir, srcId));
                    elevIdx++;
                    actionable = true;
                }

                if (dryRun)
                {
                    foreach (var j in planJobs) results.Add(Row(j.name, "would_create", j.level.Name, null));
                    foreach (var j in areaJobs) results.Add(Row(j.name, "would_create", j.level.Name, $"scheme={j.scheme.Name}"));
                    foreach (var j in threedJobs) results.Add(Row(j.name, "would_create", null, null));
                    foreach (var j in sectionJobs) results.Add(Row(j.name, "would_create", null, j.detail ? "detail" : "section"));
                    foreach (var j in draftingJobs) results.Add(Row(j.name, "would_create", null, $"drafting, {j.elems.Count} elementen te kopieren"));
                    foreach (var j in elevationJobs) results.Add(Row(j.name, "would_create", null, j.srcDir != null ? "elevation (richting uit bron)" : "elevation (geen bron-richting)"));
                    if (defaultTargetNames.Count > 0) results.Add(Row("(view-defaults)", "would_set_defaults", null, $"{defaultTargetNames.Distinct().Count()} sections/details/elevations: crop+annotation+farclip uit"));
                    return (object)Summary(dryRun, saveFirst, target, null, results);
                }

                string? savedDoc = null;
                if (saveFirst && actionable)
                {
                    try { doc.Save(); savedDoc = doc.Title; }
                    catch (Exception ex)
                    {
                        foreach (var j in planJobs) results.Add(Row(j.name, "save_failed", null, ex.Message));
                        foreach (var j in areaJobs) results.Add(Row(j.name, "save_failed", null, ex.Message));
                        foreach (var j in threedJobs) results.Add(Row(j.name, "save_failed", null, ex.Message));
                        foreach (var j in sectionJobs) results.Add(Row(j.name, "save_failed", null, ex.Message));
                        foreach (var j in draftingJobs) results.Add(Row(j.name, "save_failed", null, ex.Message));
                        foreach (var j in elevationJobs) results.Add(Row(j.name, "save_failed", null, ex.Message));
                        return (object)Summary(dryRun, saveFirst, target, savedDoc, results);
                    }
                }

                using (var t = new Transaction(doc, "NLRS create views"))
                {
                    t.Start();
                    foreach (var j in planJobs)
                    {
                        try
                        {
                            var vp = ViewPlan.Create(doc, j.vft.Id, j.level.Id);
                            try { vp.Name = j.tname; } catch (Exception ex) { results.Add(Row(j.name, "created_name_failed", j.level.Name, $"aangemaakt maar naam '{j.tname}' mislukt: {ex.Message}")); continue; }
                            var prow = Row(j.name, "created", j.level.Name, null);
                            prow["copied_params"] = CopyParams(j.srcId, vp);
                            results.Add(prow);
                        }
                        catch (Exception ex) { results.Add(Row(j.name, "error", j.level.Name, ex.Message)); }
                    }
                    foreach (var j in areaJobs)
                    {
                        try
                        {
                            var ap = ViewPlan.CreateAreaPlan(doc, j.scheme.Id, j.level.Id);
                            try { ap.Name = j.tname; } catch (Exception ex) { results.Add(Row(j.name, "created_name_failed", j.level.Name, $"aangemaakt maar naam '{j.tname}' mislukt: {ex.Message}")); continue; }
                            var arow = Row(j.name, "created", j.level.Name, null);
                            arow["copied_params"] = CopyParams(j.srcId, ap);
                            results.Add(arow);
                        }
                        catch (Exception ex) { results.Add(Row(j.name, "error", j.level.Name, ex.Message)); }
                    }
                    foreach (var j in threedJobs)
                    {
                        try
                        {
                            var v3 = View3D.CreateIsometric(doc, j.vft.Id);
                            try { v3.Name = j.name; } catch (Exception ex) { results.Add(Row(j.name, "created_name_failed", null, $"aangemaakt maar naam mislukt: {ex.Message}")); continue; }
                            var t3row = Row(j.name, "created", null, null);
                            t3row["copied_params"] = CopyParams(j.srcId, v3);
                            results.Add(t3row);
                        }
                        catch (Exception ex) { results.Add(Row(j.name, "error", null, ex.Message)); }
                    }
                    foreach (var j in sectionJobs)
                    {
                        try
                        {
                            var vs = j.detail ? ViewSection.CreateDetail(doc, j.vft.Id, j.box)
                                              : ViewSection.CreateSection(doc, j.vft.Id, j.box);
                            try { vs.Name = j.tname; } catch (Exception ex) { results.Add(Row(j.name, "created_name_failed", null, $"aangemaakt maar naam '{j.tname}' mislukt: {ex.Message}")); continue; }
                            var srow = Row(j.name, "created", null, j.detail ? "detail" : "section");
                            srow["copied_params"] = CopyParams(j.srcId, vs);
                            results.Add(srow);
                        }
                        catch (Exception ex) { results.Add(Row(j.name, "error", null, ex.Message)); }
                    }
                    foreach (var j in elevationJobs)
                    {
                        try
                        {
                            var marker = ElevationMarker.CreateElevationMarker(doc, j.vft.Id, j.origin, j.scale);
                            var elev = marker.CreateElevation(doc, hostPlanId, 0);
                            // Rotate the marker so the new elevation looks the same way as the source. The
                            // index->direction map is unknown, so we measure the created direction and rotate
                            // by the signed XY angle to the source ViewDirection — calibration-free, best-effort.
                            if (j.srcDir != null)
                            {
                                try
                                {
                                    doc.Regenerate();
                                    var cur = elev.ViewDirection;
                                    var c = new XYZ(cur.X, cur.Y, 0);
                                    var d = new XYZ(j.srcDir.X, j.srcDir.Y, 0);
                                    if (c.GetLength() > 1e-6 && d.GetLength() > 1e-6)
                                    {
                                        c = c.Normalize(); d = d.Normalize();
                                        double ang = Math.Atan2(c.X * d.Y - c.Y * d.X, c.X * d.X + c.Y * d.Y);
                                        if (Math.Abs(ang) > 1e-4)
                                        {
                                            var axis = Line.CreateBound(j.origin, j.origin + XYZ.BasisZ);
                                            ElementTransformUtils.RotateElement(doc, marker.Id, axis, ang);
                                            doc.Regenerate();
                                        }
                                    }
                                }
                                catch { /* direction-match is best-effort; an unrotated elevation still lands */ }
                            }
                            try { elev.Name = j.tname; } catch (Exception ex) { results.Add(Row(j.name, "created_name_failed", null, $"aangemaakt maar naam '{j.tname}' mislukt: {ex.Message}")); continue; }
                            var erow = Row(j.name, "created", null, "elevation");
                            erow["copied_params"] = CopyParams(j.srcId, elev);
                            results.Add(erow);
                        }
                        catch (Exception ex) { results.Add(Row(j.name, "error", null, ex.Message)); }
                    }
                    // Apply the section-family crop/clip defaults to every targeted section/detail/elevation
                    // (newly created above + already-existing). Regenerate so just-made views resolve by name.
                    if (defaultTargetNames.Count > 0)
                    {
                        doc.Regenerate();
                        var byName = new Dictionary<string, View>(StringComparer.Ordinal);
                        foreach (var v in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>())
                            if (!v.IsTemplate && !byName.ContainsKey(v.Name)) byName[v.Name] = v;
                        int defaulted = 0;
                        foreach (var nm in defaultTargetNames.Distinct())
                            if (byName.TryGetValue(nm, out var dv)) { ApplyViewDefaults(dv); defaulted++; }
                        results.Add(Row("(view-defaults)", "defaults_applied", null, $"{defaulted} sections/details/elevations: crop+annotation+farclip uit"));
                    }
                    t.Commit();
                }

                // Drafting views run in their OWN transaction: ElementTransformUtils.CopyElements is
                // cross-document and needs a warning-swallower (the templates share line/fill patterns that
                // otherwise prompt). It can't be rolled back across the dispatch, so it follows the main commit.
                if (draftingJobs.Count > 0)
                {
                    var opts = new CopyPasteOptions();
                    opts.SetDuplicateTypeNamesHandler(new UseDestinationTypesHandler());
                    using var td = new Transaction(doc, "NLRS create drafting views");
                    td.Start();
                    var fho = td.GetFailureHandlingOptions();
                    fho.SetFailuresPreprocessor(new SwallowWarnings());
                    fho.SetClearAfterRollback(true);
                    td.SetFailureHandlingOptions(fho);
                    foreach (var j in draftingJobs)
                    {
                        try
                        {
                            var vd = ViewDrafting.Create(doc, j.vft.Id);
                            try { vd.Name = j.name; } catch (Exception ex) { results.Add(Row(j.name, "created_name_failed", null, $"aangemaakt maar naam mislukt: {ex.Message}")); continue; }
                            int copied = 0;
                            if (j.elems.Count > 0)
                            {
                                try
                                {
                                    var c = ElementTransformUtils.CopyElements(j.srcView, j.elems, vd, Transform.Identity, opts);
                                    copied = c?.Count ?? 0;
                                }
                                catch (Exception ex) { results.Add(Row(j.name, "created", null, $"view aangemaakt maar copy faalde: {ex.Message}")); continue; }
                            }
                            results.Add(Row(j.name, "created", null, $"drafting, {copied} elementen gekopieerd"));
                        }
                        catch (Exception ex) { results.Add(Row(j.name, "error", null, ex.Message)); }
                    }
                    td.Commit();
                }

                // Save AFTER creating so the new views persist when the template is closed. (save_first
                // already wrote the pre-edit backup; this commits the result.) Only when something was made.
                string? savedAfter = null;
                if (saveAfter && !dryRun && results.Any(r => (string?)r["status"] is "created" or "defaults_applied"))
                {
                    try { doc.Save(); savedAfter = doc.Title; }
                    catch (Exception ex) { savedAfter = $"SAVE FAILED: {ex.Message}"; }
                }
                var summary = Summary(dryRun, saveFirst, target, savedDoc, results);
                summary["saved_after"] = savedAfter;
                return (object)summary;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Summary(bool dryRun, bool saveFirst, string? target, string? savedDoc,
                                                       List<Dictionary<string, object?>> results) => new()
    {
        ["dry_run"] = dryRun,
        ["save_first"] = saveFirst,
        ["target_document"] = target,
        ["saved_document"] = savedDoc,
        ["count"] = results.Count,
        ["created"] = results.Count(r => (string?)r["status"] == "created"),
        ["would_create"] = results.Count(r => (string?)r["status"] == "would_create"),
        ["exists"] = results.Count(r => (string?)r["status"] == "exists"),
        ["errors"] = results.Count(r => (string?)r["status"] is "error" or "save_failed" or "created_name_failed"),
        ["results"] = results,
    };

    private static Dictionary<string, object?> Row(string name, string status, string? level, string? error) => new()
    {
        ["source_name"] = name, ["status"] = status, ["target_level"] = level, ["error"] = error,
    };

    private static List<JsonElement> ParseArray(Dictionary<string, JsonElement>? p, string key)
    {
        var list = new List<JsonElement>();
        if (p != null && p.TryGetValue(key, out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
                if (it.ValueKind == JsonValueKind.Object) list.Add(it);
        return list;
    }

    private static string Str(JsonElement o, string key) =>
        o.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String ? (el.GetString() ?? "") : "";

    private static int IntOf(JsonElement o, string key) =>
        o.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.Number ? el.GetInt32() : 0;

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    // Cross-doc copy helpers (drafting views). Mirror CopyInventoryHandlers' private versions — type-name
    // collisions map to the destination's existing type; warnings are deleted so they don't roll back.
    private sealed class UseDestinationTypesHandler : IDuplicateTypeNamesHandler
    {
        public DuplicateTypeAction OnDuplicateTypeNamesFound(DuplicateTypeNamesHandlerArgs args)
            => DuplicateTypeAction.UseDestinationTypes;
    }

    private sealed class SwallowWarnings : IFailuresPreprocessor
    {
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            foreach (var f in fa.GetFailureMessages())
                if (f.GetSeverity() == FailureSeverity.Warning)
                    fa.DeleteWarning(f);
            return FailureProcessingResult.Continue;
        }
    }
}
