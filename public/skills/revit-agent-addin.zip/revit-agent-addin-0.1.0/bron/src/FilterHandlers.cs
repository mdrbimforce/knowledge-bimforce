using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// Filter introspection. After copying the source's view templates into the target,
/// the dragged-in ParameterFilterElements still reference the OLD shared parameters
/// (FireRating/IsExternal/LoadBearing) that an earlier swap renamed to NLRS names. To repoint them
/// we first need to SEE their rule structure — which parameter each rule targets, the rule type, value
/// and (for string rules) the evaluator. This command is read-only; the repoint write builds on it.
///
/// get_filter_rules params:
///   target_document : string (optional) — scope to one open doc by Title (ids collide between docs)
///   name_contains   : string (optional) — only filters whose name contains this (case-insensitive)
///   param_name      : string (optional) — only filters that reference a parameter with this name
/// </summary>
public static class FilterHandlers
{
    public static CommandResponse GetFilterRules(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? nameContains = GetString(p, "name_contains");
        string? paramName = GetString(p, "param_name");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var filters = new List<Dictionary<string, object?>>();
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;
                    foreach (var pfe in new FilteredElementCollector(doc).OfClass(typeof(ParameterFilterElement)).Cast<ParameterFilterElement>())
                    {
                        if (nameContains != null && !pfe.Name.ToLowerInvariant().Contains(nameContains.ToLowerInvariant()))
                            continue;

                        var cats = new List<string?>();
                        try
                        {
                            foreach (var cid in pfe.GetCategories())
                            {
                                var c = Category.GetCategory(doc, cid);
                                cats.Add(c?.Name ?? cid.ToString());
                            }
                        }
                        catch { }

                        var rules = new List<Dictionary<string, object?>>();
                        try
                        {
                            FlattenRules(pfe.GetElementFilter(), doc, rules, false);
                        }
                        catch (Exception ex)
                        {
                            rules.Add(new() { ["error"] = $"rule-introspection failed: {ex.Message}" });
                        }

                        if (paramName != null && !rules.Any(r => string.Equals((string?)r.GetValueOrDefault("param_name"), paramName, StringComparison.OrdinalIgnoreCase)))
                            continue;

                        // logic tells the consumer how to REBUILD the filter: "and" (flat AND — the
                        // flattened rules recombine faithfully), "or" (a top-level OR of single-rule
                        // branches — rebuild as LogicalOrFilter), or "complex" (nested AND/OR — a flat
                        // rule list cannot faithfully rebuild it, so create_filter must SKIP it). Without
                        // this an OR filter was silently rebuilt as AND.
                        string logic = "and";
                        try { logic = ClassifyLogic(pfe.GetElementFilter()); } catch { }

                        filters.Add(new Dictionary<string, object?>
                        {
                            ["element_id"] = RevitIdUtil.Fid(pfe.Id),
                            ["name"] = pfe.Name,
                            ["document"] = doc.Title,
                            ["categories"] = cats,
                            ["logic"] = logic,
                            ["rule_count"] = rules.Count,
                            ["rules"] = rules
                        });
                    }
                }
                // distinct parameters referenced across the returned filters (repoint planning aid)
                var paramHits = new Dictionary<string, int>();
                foreach (var f in filters)
                    foreach (var r in (List<Dictionary<string, object?>>)f["rules"]!)
                    {
                        var pn = (string?)r.GetValueOrDefault("param_name");
                        if (pn != null) paramHits[pn] = paramHits.GetValueOrDefault(pn) + 1;
                    }
                return (object)new Dictionary<string, object?>
                {
                    ["filter_count"] = filters.Count,
                    ["parameters_referenced"] = paramHits.OrderByDescending(kv => kv.Value)
                                                         .ToDictionary(kv => kv.Key, kv => (object?)kv.Value),
                    ["filters"] = filters
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // Classify the filter tree so create_filter knows how to rebuild it from the flat rule list:
    //   "and"     — no OR anywhere; the flattened rules recombine as one ElementParameterFilter (AND).
    //   "or"      — a top-level LogicalOrFilter whose branches are each a single-rule ElementParameterFilter;
    //               rebuild as a LogicalOrFilter of one-rule filters (the flat list is one rule per branch).
    //   "complex" — any deeper nesting (AND of ORs, OR of multi-rule ANDs, …) a flat list can't reconstruct.
    private static string ClassifyLogic(ElementFilter ef)
    {
        if (!ContainsOr(ef)) return "and";
        if (ef is LogicalOrFilter lof
            && lof.GetFilters().All(f => f is ElementParameterFilter e && e.GetRules().Count == 1))
            return "or";
        return "complex";
    }

    private static bool ContainsOr(ElementFilter ef)
    {
        switch (ef)
        {
            case LogicalOrFilter: return true;
            case LogicalAndFilter laf: return laf.GetFilters().Any(ContainsOr);
            default: return false;
        }
    }

    // Walk the ElementFilter tree (LogicalAnd/Or nest ElementParameterFilters) and describe each rule.
    private static void FlattenRules(ElementFilter ef, Document doc, List<Dictionary<string, object?>> outRules, bool inverted)
    {
        switch (ef)
        {
            case ElementParameterFilter epf:
                foreach (var rule in epf.GetRules())
                    outRules.Add(DescribeRule(rule, doc, inverted));
                break;
            case LogicalAndFilter laf:
                foreach (var sub in laf.GetFilters()) FlattenRules(sub, doc, outRules, inverted);
                break;
            case LogicalOrFilter lof:
                foreach (var sub in lof.GetFilters()) FlattenRules(sub, doc, outRules, inverted);
                break;
            default:
                outRules.Add(new() { ["unhandled_filter"] = ef.GetType().Name });
                break;
        }
    }

    private static Dictionary<string, object?> DescribeRule(FilterRule rule, Document doc, bool inverted)
    {
        // FilterInverseRule wraps another rule (e.g. "not equals", "does not contain").
        if (rule is FilterInverseRule inv)
            return DescribeRule(inv.GetInnerRule(), doc, !inverted);

        var d = new Dictionary<string, object?> { ["rule_type"] = rule.GetType().Name, ["inverted"] = inverted };
        try
        {
            var pid = rule.GetRuleParameter();
            d["param_id"] = pid.Value > 0 ? (object)RevitIdUtil.Fid(pid) : pid.Value.ToString();
            if (pid.Value > 0)
                d["param_name"] = doc.GetElement(pid)?.Name;
            else
            {
                // builtin parameter (negative id) — readable label via LabelUtils (e.g.
                // -1002500 shows as a raw id, should read "Assembly Code"). Falls back to the
                // raw id string if the id doesn't map to a known BuiltInParameter (e.g. version drift).
                string? label = null;
                try { label = LabelUtils.GetLabelFor((BuiltInParameter)pid.Value); } catch { }
                d["param_name"] = label ?? pid.Value.ToString();
            }
        }
        catch (Exception ex) { d["param_error"] = ex.Message; }

        try
        {
            switch (rule)
            {
                case FilterStringRule fsr:
                    d["value"] = fsr.RuleString;
                    d["evaluator"] = fsr.GetEvaluator()?.GetType().Name;
                    break;
                case FilterDoubleRule fdr:
                    d["value"] = fdr.RuleValue;
                    break;
                case FilterIntegerRule fir:
                    d["value"] = fir.RuleValue;
                    break;
                case FilterElementIdRule feir:
                    d["value"] = feir.RuleValue.Value;
                    break;
            }
        }
        catch (Exception ex) { d["value_error"] = ex.Message; }
        return d;
    }

    /// <summary>
    /// repoint_filter_parameter — rewrite filter rules that target an OLD shared parameter to target a
    /// NEW one, keeping operator + value (e.g. copied filters that reference
    /// FireRating/IsExternal/LoadBearing which were swapped to brandwerendheid_eis/buiten/dragend).
    ///
    /// Only flat-AND filter structures are rewritten (single ElementParameterFilter or a LogicalAndFilter
    /// of them). Unmatched rules are preserved as-is (their original objects are reused — no lossy
    /// reconstruction). A filter using OR or a matched rule we cannot safely rebuild (inverse / unknown
    /// string evaluator) is SKIPPED and reported, never partially rewritten.
    ///
    /// params:
    ///   target_document : string (required) — doc to rewrite (ids collide between docs)
    ///   mappings        : [{source, target}]  — param names; source=old, target=new (canonical)
    ///   dry_run         : bool (default true)
    ///   save_first      : bool (default false) — numbered backup before any write
    ///   delete_source   : bool (default false) — delete the (now unreferenced) source params after
    /// </summary>
    public static CommandResponse RepointFilterParameter(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        bool deleteSource = GetBool(p, "delete_source", false);
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };

        var mappings = new List<(string src, string tgt)>();
        if (p != null && p.TryGetValue("mappings", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
                if (it.ValueKind == JsonValueKind.Object
                    && it.TryGetProperty("source", out var s) && it.TryGetProperty("target", out var t)
                    && s.GetString() is string ss && t.GetString() is string tt)
                    mappings.Add((ss, tt));
        if (mappings.Count == 0)
            return new CommandResponse { Success = false, Error = "Parameter 'mappings':[{source,target}] is required" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                    if (d.Title == target) { doc = d; break; }
                if (doc == null) throw new Exception($"target_document '{target}' is not open");

                // Resolve source/target parameter names -> SharedParameterElement ids in this doc.
                var spByName = new Dictionary<string, ElementId>(StringComparer.OrdinalIgnoreCase);
                foreach (var sp in new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>())
                    spByName[sp.Name] = sp.Id;

                var srcToTgt = new Dictionary<ElementId, ElementId>();
                var srcIds = new Dictionary<string, ElementId>();
                var resolveErrors = new List<string>();
                foreach (var (src, tgt) in mappings)
                {
                    if (!spByName.TryGetValue(src, out var sid)) { resolveErrors.Add($"source '{src}' not found as shared parameter"); continue; }
                    if (!spByName.TryGetValue(tgt, out var tid)) { resolveErrors.Add($"target '{tgt}' not found as shared parameter"); continue; }
                    srcToTgt[sid] = tid;
                    srcIds[src] = sid;
                }
                if (srcToTgt.Count == 0)
                    // No source param resolved — almost always because a prior repoint already deleted the
                    // source shared parameters. That is the idempotent "already done" state, not a failure
                    // so return a clean success with affected=0 + the reasons, so a re-run
                    // and a consumer that loops over filters both see a no-op instead of a hard Exception.
                    return (object)new Dictionary<string, object?>
                    {
                        ["dry_run"] = dryRun,
                        ["target_document"] = doc.Title,
                        ["saved_document"] = (string?)null,
                        ["resolve_errors"] = resolveErrors,
                        ["filters_affected"] = 0,
                        ["filters_skipped"] = 0,
                        ["source_params_deleted"] = new List<string>(),
                        ["status"] = "no_op_no_mappings_resolved",
                        ["results"] = new List<Dictionary<string, object?>>()
                    };

                var results = new List<Dictionary<string, object?>>();
                string? saved = null;
                bool anyChange = false;

                // First pass (read-only): determine which filters need rewriting + whether each is safe.
                var plan = new List<(ParameterFilterElement pfe, List<FilterRule> rebuilt, int changed, string? skip)>();
                foreach (var pfe in new FilteredElementCollector(doc).OfClass(typeof(ParameterFilterElement)).Cast<ParameterFilterElement>())
                {
                    var flat = new List<FilterRule>();
                    if (!TryCollectFlatRules(pfe.GetElementFilter(), flat))
                    {
                        if (RefsAnySource(pfe.GetElementFilter(), srcToTgt.Keys.ToHashSet()))
                            plan.Add((pfe, new(), 0, "complex structure (OR/nested) — manual"));
                        continue;
                    }
                    int changed = 0; string? skip = null;
                    var rebuilt = new List<FilterRule>();
                    foreach (var rule in flat)
                    {
                        if (rule is FilterInverseRule)
                        {
                            var innerPid = SafeParam(((FilterInverseRule)rule).GetInnerRule());
                            if (innerPid != null && srcToTgt.ContainsKey(innerPid)) { skip = "inverse rule on source param — manual"; break; }
                            rebuilt.Add(rule); continue;
                        }
                        var pid = SafeParam(rule);
                        if (pid != null && srcToTgt.TryGetValue(pid, out var newPid))
                        {
                            FilterRule? nr;
                            try { nr = RebuildWithParam(rule, newPid); }
                            catch (Exception ex) { skip = $"rule rebuild unsupported: {ex.Message}"; break; }
                            rebuilt.Add(nr); changed++;
                        }
                        else rebuilt.Add(rule);  // unmatched — keep original object
                    }
                    if (skip != null) { plan.Add((pfe, new(), 0, skip)); continue; }
                    if (changed > 0) plan.Add((pfe, rebuilt, changed, null));
                }

                int wouldChange = plan.Count(x => x.changed > 0);
                if (!dryRun && wouldChange > 0 && saveFirst)
                {
                    try { doc.Save(); saved = doc.Title; }
                    catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                }

                if (!dryRun && wouldChange > 0)
                {
                    using var t = new Transaction(doc, "repoint filter parameters");
                    t.Start();
                    foreach (var (pfe, rebuilt, changed, skip) in plan)
                    {
                        if (changed == 0) continue;
                        try { pfe.SetElementFilter(new ElementParameterFilter(rebuilt)); anyChange = true; }
                        catch (Exception ex)
                        {
                            results.Add(new() { ["filter"] = pfe.Name, ["status"] = "error", ["error"] = ex.Message });
                        }
                    }
                    t.Commit();
                }

                foreach (var (pfe, rebuilt, changed, skip) in plan)
                {
                    if (results.Any(r => (string?)r.GetValueOrDefault("filter") == pfe.Name)) continue;  // already error-logged
                    results.Add(new()
                    {
                        ["filter"] = pfe.Name,
                        ["status"] = skip != null ? "skipped" : (dryRun ? "would_repoint" : "repointed"),
                        ["rules_changed"] = changed,
                        ["reason"] = skip
                    });
                }

                // Optionally delete the now-unreferenced source parameters.
                var deleted = new List<string>();
                if (!dryRun && deleteSource && anyChange)
                {
                    using var t = new Transaction(doc, "delete repointed source params");
                    t.Start();
                    foreach (var (name, sid) in srcIds)
                    {
                        try { if (doc.GetElement(sid)?.IsValidObject == true) { doc.Delete(sid); deleted.Add(name); } }
                        catch (Exception ex) { results.Add(new() { ["filter"] = $"(delete {name})", ["status"] = "delete_error", ["error"] = ex.Message }); }
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["target_document"] = doc.Title,
                    ["saved_document"] = saved,
                    ["resolve_errors"] = resolveErrors,
                    ["filters_affected"] = wouldChange,
                    ["filters_skipped"] = plan.Count(x => x.skip != null),
                    ["source_params_deleted"] = deleted,
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>
    /// create_filter — create ParameterFilterElements from a reviewed spec. Mirrors the
    /// get_filter_rules output so a source filter can be re-created in the target: name + category UI-names + a flat
    /// AND of rules (param_name + evaluator + value). Rules resolve their parameter by shared-parameter name
    /// in the target doc; a rule whose parameter or evaluator can't be resolved makes the whole filter SKIP
    /// (reported, never partially built). An existing filter with the same name is skipped as a duplicate.
    ///
    /// params:
    ///   target_document : string (required)
    ///   filters : [{ name, categories:[UI name], rules:[{param_name, evaluator, value, inverted?}] }]
    ///   dry_run : bool (default true) · save_first : bool (default false)
    /// param_name: de naam van een shared parameter, of voor een ingebouwde parameter het negatieve id zoals
    /// get_filter_rules het toont (bv. "-1010106" voor Comments) of de BuiltInParameter-naam
    /// (ALL_MODEL_INSTANCE_COMMENTS; pas na de build van 25-11-2026 of later). De gewone naam "Comments" werkt niet.
    /// evaluator: FilterStringEquals (standaard), FilterStringContains, FilterStringBeginsWith, FilterStringEndsWith;
    /// een getal als value geeft een gelijk-aan-regel.
    /// </summary>
    public static CommandResponse CreateFilter(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };
        if (p == null || !p.TryGetValue("filters", out var farr) || farr.ValueKind != JsonValueKind.Array)
            return new CommandResponse { Success = false, Error = "Parameter 'filters' (array) is required" };
        var specs = farr.EnumerateArray().Where(f => f.ValueKind == JsonValueKind.Object).ToList();

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                    if (d.Title == target) { doc = d; break; }
                if (doc == null) throw new Exception($"target_document '{target}' is not open");

                // lookups: category UI-name -> Id, shared-parameter name -> Id, existing filter names.
                var catByName = new Dictionary<string, ElementId>(StringComparer.OrdinalIgnoreCase);
                foreach (Category c in doc.Settings.Categories)
                    if (c.AllowsBoundParameters) catByName[c.Name] = c.Id;
                var spByName = new Dictionary<string, ElementId>(StringComparer.OrdinalIgnoreCase);
                foreach (var sp in new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>())
                    spByName[sp.Name] = sp.Id;
                var existing = new HashSet<string>(
                    new FilteredElementCollector(doc).OfClass(typeof(ParameterFilterElement)).Cast<ParameterFilterElement>()
                        .Select(f => f.Name), StringComparer.OrdinalIgnoreCase);

                // Plan (read-only): validate + build each filter's pieces; a spec that can't be built cleanly skips.
                var plan = new List<(string name, List<ElementId> cats, List<FilterRule> rules, string logic)>();
                var results = new List<Dictionary<string, object?>>();
                foreach (var f in specs)
                {
                    string name = f.TryGetProperty("name", out var nEl) ? (nEl.GetString() ?? "") : "";
                    if (string.IsNullOrWhiteSpace(name)) { results.Add(Row("(leeg)", "skipped", "geen naam")); continue; }
                    if (existing.Contains(name)) { results.Add(Row(name, "skipped", "bestaat al in target")); continue; }

                    // logic drives the rebuild (get_filter_rules classifies the source): "complex" (nested
                    // AND/OR) can't be faithfully rebuilt from a flat rule list, so SKIP it instead of
                    // silently creating a wrong (flat-AND) filter.
                    string logic = (f.TryGetProperty("logic", out var lgEl) ? lgEl.GetString() : null) ?? "and";
                    if (logic == "complex")
                    { results.Add(Row(name, "skipped", "geneste AND/OR-structuur — niet automatisch te herbouwen")); continue; }

                    // Build the rules FIRST, so an "All" filter with rules can be scoped to exactly the
                    // categories those rule-parameters are filterable on (Revit rejects a rule referencing a
                    // parameter that doesn't apply to a category).
                    var rules = new List<FilterRule>();
                    string? ruleErr = null;
                    if (f.TryGetProperty("rules", out var rEl) && rEl.ValueKind == JsonValueKind.Array)
                        foreach (var r in rEl.EnumerateArray())
                        {
                            var nr = BuildRuleFromSpec(r, spByName, out var why);
                            if (nr == null) { ruleErr = why; break; }
                            rules.Add(nr);
                        }
                    if (ruleErr != null) { results.Add(Row(name, "skipped", ruleErr)); continue; }

                    var cats = new List<ElementId>();
                    string? catErr = null;
                    bool wantsAll = false;
                    if (f.TryGetProperty("categories", out var cEl) && cEl.ValueKind == JsonValueKind.Array)
                        foreach (var c in cEl.EnumerateArray())
                            if (c.GetString() is string cn)
                            {
                                if (cn.Equals("All", StringComparison.OrdinalIgnoreCase) || cn == "*") wantsAll = true;
                                else if (catByName.TryGetValue(cn, out var cid)) cats.Add(cid);
                                else catErr = $"onbekende categorie '{cn}'";
                            }
                    // "All": every filterable category for a rule-less filter; for a filter WITH rules, only
                    // the categories on which its rule-parameters are filterable (scope to the
                    // parameter's bound categories; auto-expands to new categories per Revit version).
                    if (wantsAll)
                        cats.AddRange(rules.Count > 0
                            ? CategoriesForRules(doc, rules, catByName.Values.ToList())
                            : catByName.Values);
                    cats = cats.Distinct().ToList();
                    if (cats.Count == 0)
                    { results.Add(Row(name, "skipped", catErr ?? "geen categorie waar de regel-parameter geldt")); continue; }
                    plan.Add((name, cats, rules, logic));
                }

                string? saved = null;
                if (!dryRun && plan.Count > 0 && saveFirst)
                {
                    try { doc.Save(); saved = doc.Title; }
                    catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                }
                if (!dryRun && plan.Count > 0)
                {
                    using var t = new Transaction(doc, "create view filters");
                    t.Start();
                    foreach (var (name, cats, rules, logic) in plan)
                    {
                        try
                        {
                            var ef = BuildElementFilter(rules, logic);
                            var pfe = ef != null
                                ? ParameterFilterElement.Create(doc, name, cats, ef)
                                : ParameterFilterElement.Create(doc, name, cats);
                            results.Add(Row(name, "created", null, RevitIdUtil.Fid(pfe.Id)));
                        }
                        catch (Exception ex) { results.Add(Row(name, "error", ex.Message)); }
                    }
                    t.Commit();
                }
                else
                    foreach (var (name, cats, rules, logic) in plan)
                        results.Add(Row(name, "would_create", $"{cats.Count} cat, {rules.Count} rules ({logic})"));

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["target_document"] = doc.Title,
                    ["saved_document"] = saved,
                    ["created"] = results.Count(r => (string?)r["status"] == "created"),
                    ["would_create"] = results.Count(r => (string?)r["status"] == "would_create"),
                    ["skipped"] = results.Count(r => (string?)r["status"] == "skipped"),
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Row(string name, string status, string? reason, object? id = null)
        => new() { ["filter"] = name, ["status"] = status, ["reason"] = reason, ["element_id"] = id };

    // For an "All" filter that has rules, keep only the categories on which every rule-parameter is
    // filterable (ParameterFilterUtilities.GetFilterableParametersInCommon). This is "all categories the
    // parameter is bound to" — Revit rejects a rule on a category where its parameter doesn't apply.
    private static List<ElementId> CategoriesForRules(Document doc, List<FilterRule> rules, List<ElementId> allFilterable)
    {
        var ruleParams = new HashSet<ElementId>();
        foreach (var r in rules)
        {
            try { ruleParams.Add((r is FilterInverseRule inv ? inv.GetInnerRule() : r).GetRuleParameter()); }
            catch { }
        }
        if (ruleParams.Count == 0) return allFilterable;
        var kept = new List<ElementId>();
        foreach (var cat in allFilterable)
        {
            try
            {
                var filterable = ParameterFilterUtilities.GetFilterableParametersInCommon(doc, new List<ElementId> { cat });
                if (ruleParams.All(p => filterable.Contains(p))) kept.Add(cat);
            }
            catch { }
        }
        return kept;
    }

    // Recombine the flat rule list into the right ElementFilter. "or" -> a LogicalOrFilter of one-rule
    // ElementParameterFilters (get_filter_rules only tags a top-level OR of single-rule branches as "or",
    // so one rule per branch is faithful); anything else -> a single AND ElementParameterFilter.
    private static ElementFilter? BuildElementFilter(List<FilterRule> rules, string logic)
    {
        if (rules.Count == 0) return null;
        if (logic == "or")
            return new LogicalOrFilter(rules.Select(r => (ElementFilter)new ElementParameterFilter(r)).ToList());
        return new ElementParameterFilter(rules);
    }

    // Build one FilterRule from a spec {param_name, evaluator, value, inverted?}. Returns null + a reason
    // when the parameter (shared-param name) or the evaluator/value can't be resolved.
    private static FilterRule? BuildRuleFromSpec(JsonElement r, Dictionary<string, ElementId> spByName, out string? why)
    {
        why = null;
        string? pn = r.TryGetProperty("param_name", out var pnEl) ? pnEl.GetString() : null;
        ElementId pid;
        if (pn != null && spByName.TryGetValue(pn, out var sid))
            pid = sid;                                        // shared parameter by name
        else if (pn != null && long.TryParse(pn, out var pv))
            pid = new ElementId(pv);                          // builtin parameter (negative id from get_filter_rules)
        else if (pn != null && Enum.TryParse<BuiltInParameter>(pn, false, out var bip) && bip != BuiltInParameter.INVALID)
            pid = new ElementId(bip);                         // builtin parameter op enumnaam, bv. ALL_MODEL_INSTANCE_COMMENTS
        else
        {
            why = $"parameter '{pn}' niet gevonden als shared parameter, builtin-id (bv. -1010106) of BuiltInParameter-naam "
                + "(bv. ALL_MODEL_INSTANCE_COMMENTS) in target";
            return null;
        }
        string ev = (r.TryGetProperty("evaluator", out var eEl) ? eEl.GetString() : null) ?? "";
        bool inverted = r.TryGetProperty("inverted", out var iEl) && iEl.ValueKind == JsonValueKind.True;
        r.TryGetProperty("value", out var vEl);

        FilterRule? rule = null;
        try
        {
            if (ev.StartsWith("FilterString") || vEl.ValueKind == JsonValueKind.String)
            {
                string val = vEl.ValueKind == JsonValueKind.String ? (vEl.GetString() ?? "") : "";
                rule = ev switch
                {
                    "FilterStringContains" => ParameterFilterRuleFactory.CreateContainsRule(pid, val),
                    "FilterStringBeginsWith" => ParameterFilterRuleFactory.CreateBeginsWithRule(pid, val),
                    "FilterStringEndsWith" => ParameterFilterRuleFactory.CreateEndsWithRule(pid, val),
                    _ => ParameterFilterRuleFactory.CreateEqualsRule(pid, val),   // FilterStringEquals / default
                };
            }
            else if (vEl.ValueKind == JsonValueKind.Number)
            {
                if (vEl.TryGetInt32(out var iv)) rule = ParameterFilterRuleFactory.CreateEqualsRule(pid, iv);
                else rule = ParameterFilterRuleFactory.CreateEqualsRule(pid, vEl.GetDouble(), 1e-6);
            }
            else { why = $"waarde-type niet ondersteund voor '{pn}'"; return null; }
        }
        catch (Exception ex) { why = $"regel-opbouw '{pn}': {ex.Message}"; return null; }

        if (inverted && rule != null) rule = new FilterInverseRule(rule);
        return rule;
    }

    // null if the rule's parameter can't be read (e.g. nested/unsupported).
    private static ElementId? SafeParam(FilterRule rule)
    {
        try { return rule.GetRuleParameter(); } catch { return null; }
    }

    // True if any rule in the filter (unwrapping inverse rules) targets the given parameter.
    public static bool FilterReferencesParam(ElementFilter ef, ElementId paramId)
    {
        var flat = new List<FilterRule>();
        try { CollectAllRules(ef, flat); } catch { return false; }
        foreach (var r in flat)
        {
            var rr = r is FilterInverseRule inv ? inv.GetInnerRule() : r;
            var pid = SafeParam(rr);
            if (pid != null && pid == paramId) return true;
        }
        return false;
    }

    private static bool RefsAnySource(ElementFilter ef, HashSet<ElementId> sources)
    {
        var flat = new List<FilterRule>();
        try { CollectAllRules(ef, flat); } catch { return false; }
        foreach (var r in flat)
        {
            var rr = r is FilterInverseRule inv ? inv.GetInnerRule() : r;
            var pid = SafeParam(rr);
            if (pid != null && sources.Contains(pid)) return true;
        }
        return false;
    }

    private static void CollectAllRules(ElementFilter ef, List<FilterRule> outRules)
    {
        switch (ef)
        {
            case ElementParameterFilter epf: outRules.AddRange(epf.GetRules()); break;
            case LogicalAndFilter laf: foreach (var s in laf.GetFilters()) CollectAllRules(s, outRules); break;
            case LogicalOrFilter lof: foreach (var s in lof.GetFilters()) CollectAllRules(s, outRules); break;
        }
    }

    // Only a flat AND of ElementParameterFilters is safe to rebuild as one ElementParameterFilter.
    private static bool TryCollectFlatRules(ElementFilter ef, List<FilterRule> rules)
    {
        switch (ef)
        {
            case ElementParameterFilter epf: rules.AddRange(epf.GetRules()); return true;
            case LogicalAndFilter laf:
                foreach (var s in laf.GetFilters()) if (!TryCollectFlatRules(s, rules)) return false;
                return true;
            default: return false;  // OR / unknown — not safe to flatten
        }
    }

    // Recreate a rule with the same operator + value but a different parameter. Throws if the
    // operator can't be determined (string rules expose their evaluator; integer/double rules don't —
    // for those we assume Equals, which is what yes/no filters use).
    private static FilterRule RebuildWithParam(FilterRule rule, ElementId newParam)
    {
        switch (rule)
        {
            case FilterStringRule fsr:
                var ev = fsr.GetEvaluator();
                var val = fsr.RuleString;
                return ev switch
                {
                    FilterStringContains => ParameterFilterRuleFactory.CreateContainsRule(newParam, val),
                    FilterStringEquals => ParameterFilterRuleFactory.CreateEqualsRule(newParam, val),
                    FilterStringBeginsWith => ParameterFilterRuleFactory.CreateBeginsWithRule(newParam, val),
                    FilterStringEndsWith => ParameterFilterRuleFactory.CreateEndsWithRule(newParam, val),
                    _ => throw new NotSupportedException($"string evaluator {ev?.GetType().Name}")
                };
            case FilterIntegerRule fir:
                return ParameterFilterRuleFactory.CreateEqualsRule(newParam, fir.RuleValue);
            case FilterDoubleRule fdr:
                return ParameterFilterRuleFactory.CreateEqualsRule(newParam, fdr.RuleValue, fdr.Epsilon);
            case FilterElementIdRule feir:
                return ParameterFilterRuleFactory.CreateEqualsRule(newParam, feir.RuleValue);
            default:
                throw new NotSupportedException(rule.GetType().Name);
        }
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
