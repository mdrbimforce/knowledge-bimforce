using System.Globalization;
using System.Reflection;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// Datavelden in onderwijsmodellen: vier commando's om shared parameters te
/// binden, waarden in bulk te schrijven en te lezen, en de bindingen te inventariseren.
///
/// Gemeenschappelijk: target_document (Title van een open document, verplicht). Schrijvende commando's hebben
/// dry_run (default TRUE) en tellen op basis van read-back na commit, nooit op returnwaarden. Elke Transaction
/// staat in try/finally (RollBack als niet gecommit) met een failure-preprocessor die warnings weggooit en bij
/// errors terugrolt, zodat er geen modale dialoog verschijnt.
/// </summary>
public static class ModelDataHandlers
{
    // ═══════════════════════════════════════════════════════════════════════
    // 1. bind_shared_parameters
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// bind_shared_parameters — bind shared parameters uit een SP-bestand aan categorieën.
    /// Zoekt de definitie op GUID (voorkeur) of naam. Bestaande binding: alleen ontbrekende categorieën erbij
    /// (ReInsert, zelfde soort en groep; nooit categorieën weg, nooit instance↔type omzetten). Parameter met
    /// dezelfde naam maar een andere GUID in het document: niet binden, status "conflict".
    /// SharedParametersFilename wordt altijd in finally hersteld.
    ///
    /// params: target_document, shared_param_file (verplicht),
    ///         bindings:[{name?, guid?, categories:["OST_Doors",...], instance (default true),
    ///                    group ("Data" | "IdentityData" | "IfcParameters" | "PG_IDENTITY_DATA" ...; default Data)}],
    ///         dry_run (default TRUE).
    /// Rapport per binding: {name, guid, status: nieuw|uitgebreid|al_gebonden|conflict|niet_in_bestand|fout,
    ///                       categorieen_toegevoegd, categorieen_onbekend, notes}.
    /// </summary>
    public static CommandResponse BindSharedParameters(CommandRequest request)
    {
        var p = request.Params;
        string? target = Str(p, "target_document");
        string? spf = Str(p, "shared_param_file");
        bool dryRun = Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        if (spf == null) return Err("shared_param_file is verplicht");
        if (!System.IO.File.Exists(spf)) return Err($"shared_param_file bestaat niet: {spf}");

        var specs = new List<BindSpec>();
        foreach (var it in Arr(p, "bindings"))
        {
            if (it.ValueKind != JsonValueKind.Object) continue;
            var cats = new List<string>();
            if (it.TryGetProperty("categories", out var ce) && ce.ValueKind == JsonValueKind.Array)
                foreach (var c in ce.EnumerateArray())
                    if (c.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(c.GetString())) cats.Add(c.GetString()!.Trim());
            specs.Add(new BindSpec(PStr(it, "name"), PStr(it, "guid"), cats, PBool(it, "instance") ?? true, PStr(it, "group")));
        }
        if (specs.Count == 0) return Err("bindings:[{name|guid, categories:[...], instance?, group?}] is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument; bindingen bestaan alleen in projecten");

                var notes = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                string? prevSpf = null;
                bool spfSwapped = false;
                try
                {
                    DefinitionFile? df;
                    try
                    {
                        prevSpf = app.Application.SharedParametersFilename;
                        app.Application.SharedParametersFilename = spf;
                        spfSwapped = true;
                        df = app.Application.OpenSharedParameterFile();
                    }
                    catch (Exception ex) { return (object)Fail($"shared_param_file kon niet geopend worden: {ex.Message}"); }
                    if (df == null) return (object)Fail($"shared_param_file kon niet geopend worden: {spf}");

                    var create = app.Application.Create;
                    var bindings = doc.ParameterBindings;
                    var catByName = new Dictionary<string, Category>(StringComparer.OrdinalIgnoreCase);
                    foreach (Category c in doc.Settings.Categories) catByName[c.Name] = c;

                    foreach (var s in specs)
                    {
                        var row = new Dictionary<string, object?>
                        {
                            ["name"] = s.Name, ["guid"] = s.Guid, ["status"] = null,
                            ["categorieen_toegevoegd"] = new List<string>(), ["categorieen_onbekend"] = new List<string>(),
                            ["notes"] = new List<string>(),
                        };
                        results.Add(row);
                        var rnotes = (List<string>)row["notes"]!;
                        var added = (List<string>)row["categorieen_toegevoegd"]!;
                        var unknown = (List<string>)row["categorieen_onbekend"]!;
                        try
                        {
                            var ed = FindExternal(df, s.Guid, s.Name);
                            if (ed == null) { row["status"] = "niet_in_bestand"; continue; }
                            row["name"] = ed.Name; row["guid"] = ed.GUID.ToString();
                            if (s.Name != null && !s.Name.Equals(ed.Name, StringComparison.Ordinal))
                                rnotes.Add($"opgegeven naam '{s.Name}' wijkt af van de naam in het bestand '{ed.Name}' (gevonden op GUID)");

                            // Naamconflict: zelfde naam, andere GUID (shared) of een niet-shared projectparameter.
                            var conflict = FindNameConflict(doc, ed);
                            if (conflict != null) { row["status"] = "conflict"; rnotes.Add(conflict); continue; }

                            // Categorieën resolven.
                            var wanted = new List<Category>();
                            foreach (var cn in s.Categories)
                            {
                                var cat = ResolveCategory(doc, catByName, cn);
                                if (cat == null || !cat.AllowsBoundParameters) unknown.Add(cn);
                                else if (!wanted.Any(w => w.Id == cat.Id)) wanted.Add(cat);
                            }

                            var spe = FindSpe(doc, ed.GUID);
                            var existing = spe != null ? bindings.get_Item(spe.GetDefinition()) as ElementBinding : null;
                            ForgeTypeId group = ParseGroup(s.Group, rnotes);

                            if (existing != null)
                            {
                                bool existingIsType = existing is TypeBinding;
                                if (existingIsType == s.Instance)
                                    rnotes.Add($"bestaande binding is {(existingIsType ? "type" : "instance")}, gevraagd {(s.Instance ? "instance" : "type")}: soort niet omgezet");
                                var existingGroup = spe!.GetDefinition().GetGroupTypeId();
                                if (s.Group != null && existingGroup != null && existingGroup.TypeId != group.TypeId)
                                    rnotes.Add($"bestaande groep '{GroupLabel(existingGroup)}' behouden (gevraagd '{GroupLabel(group)}')");
                                var missing = wanted.Where(c => !existing.Categories.Contains(c)).ToList();
                                if (missing.Count == 0) { row["status"] = "al_gebonden"; continue; }
                                if (dryRun) { row["status"] = "uitgebreid"; added.AddRange(missing.Select(CatLabel)); continue; }

                                var set = create.NewCategorySet();
                                foreach (Category c in existing.Categories) set.Insert(c);
                                foreach (var c in missing) set.Insert(c);
                                Binding nb = existingIsType ? create.NewTypeBinding(set) : create.NewInstanceBinding(set);
                                var def = spe.GetDefinition();
                                var (ok, txNote) = RunTx(doc, $"Bind {ed.Name} (uitbreiden)", () =>
                                {
                                    if (!bindings.ReInsert(def, nb, existingGroup ?? GroupTypeId.Data))
                                        throw new InvalidOperationException("ReInsert gaf false");
                                });
                                if (txNote != null) rnotes.Add(txNote);
                                // read-back
                                var rb = ReadBackBinding(doc, ed.GUID);
                                var landed = missing.Where(c => rb != null && rb.Categories.Contains(c)).ToList();
                                added.AddRange(landed.Select(CatLabel));
                                if (!ok || landed.Count != missing.Count)
                                {
                                    row["status"] = "fout";
                                    rnotes.Add($"read-back: {landed.Count}/{missing.Count} categorieën toegevoegd");
                                }
                                else row["status"] = "uitgebreid";
                            }
                            else
                            {
                                if (wanted.Count == 0) { row["status"] = "fout"; rnotes.Add("geen geldige categorieën om aan te binden"); continue; }
                                if (dryRun) { row["status"] = "nieuw"; added.AddRange(wanted.Select(CatLabel)); continue; }
                                var set = create.NewCategorySet();
                                foreach (var c in wanted) set.Insert(c);
                                Binding nb = s.Instance ? create.NewInstanceBinding(set) : create.NewTypeBinding(set);
                                var (ok, txNote) = RunTx(doc, $"Bind {ed.Name}", () =>
                                {
                                    if (!bindings.Insert(ed, nb, group))
                                        throw new InvalidOperationException("Insert gaf false");
                                });
                                if (txNote != null) rnotes.Add(txNote);
                                var rb = ReadBackBinding(doc, ed.GUID);
                                var landed = wanted.Where(c => rb != null && rb.Categories.Contains(c)).ToList();
                                added.AddRange(landed.Select(CatLabel));
                                if (!ok || rb == null || landed.Count != wanted.Count)
                                {
                                    row["status"] = "fout";
                                    rnotes.Add($"read-back: binding {(rb == null ? "niet gevonden" : $"{landed.Count}/{wanted.Count} categorieën")}");
                                }
                                else
                                {
                                    row["status"] = "nieuw";
                                    if ((rb is TypeBinding) == s.Instance) rnotes.Add("read-back: soort van de binding wijkt af van gevraagd");
                                }
                            }
                        }
                        catch (Exception ex) { row["status"] = "fout"; rnotes.Add(ex.Message); }
                    }

                    // Instance-parameters mogen per groepslid verschillen, anders weigert Revit elke waarde op een
                    // element in een modelgroep. Alleen aanzetten, nooit uit. Aparte lus:
                    // in de lus hierboven springen de 'continue's over alles wat na het try-blok staat.
                    for (int i = 0; i < specs.Count && i < results.Count; i++)
                    {
                        var s = specs[i]; var row = results[i]; var rnotes = (List<string>)row["notes"]!;
                        try
                        {
                            string? st = row["status"] as string;
                            if (!dryRun && s.Instance && (st == "nieuw" || st == "uitgebreid" || st == "al_gebonden")
                                && row["guid"] is string gs && Guid.TryParse(gs, out var gg)
                                && FindSpe(doc, gg)?.GetDefinition() is InternalDefinition idef && !idef.VariesAcrossGroups)
                            {
                                var (vok, vnote) = RunTx(doc, $"Vary {idef.Name}", () => idef.SetAllowVaryBetweenGroups(doc, true));
                                rnotes.Add(vok ? "varieert nu per groepslid" : $"varieren per groep aanzetten mislukt: {vnote}");
                            }
                        }
                        catch (Exception ex) { rnotes.Add($"varieren per groep: {ex.Message}"); }
                    }
                }
                finally
                {
                    if (spfSwapped)
                    {
                        try { app.Application.SharedParametersFilename = prevSpf ?? ""; }
                        catch (Exception ex) { notes.Add($"SharedParametersFilename terugzetten mislukt ({prevSpf}): {ex.Message}"); }
                    }
                }

                if (dryRun) notes.Add("dry_run: niets gewijzigd; status is de geplande uitkomst");
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["shared_param_file"] = spf,
                    ["tellers"] = results.GroupBy(r => (string?)r["status"] ?? "?").ToDictionary(g => g.Key, g => g.Count()),
                    ["results"] = results,
                    ["notes"] = notes,
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private record BindSpec(string? Name, string? Guid, List<string> Categories, bool Instance, string? Group);

    private static ExternalDefinition? FindExternal(DefinitionFile df, string? guid, string? name)
    {
        ExternalDefinition? byName = null;
        foreach (DefinitionGroup g in df.Groups)
            foreach (Definition d in g.Definitions)
            {
                if (d is not ExternalDefinition ed) continue;
                if (guid != null && ed.GUID.ToString().Equals(guid.Trim().Trim('{', '}'), StringComparison.OrdinalIgnoreCase)) return ed;
                if (byName == null && name != null && ed.Name.Equals(name, StringComparison.Ordinal)) byName = ed;
            }
        return guid == null ? byName : null;
    }

    private static SharedParameterElement? FindSpe(Document doc, Guid guid)
    {
        try { return SharedParameterElement.Lookup(doc, guid); } catch { return null; }
    }

    private static ElementBinding? ReadBackBinding(Document doc, Guid guid)
    {
        var spe = FindSpe(doc, guid);
        return spe == null ? null : doc.ParameterBindings.get_Item(spe.GetDefinition()) as ElementBinding;
    }

    /// <summary>Zelfde naam, andere identiteit: een shared parameter met een andere GUID of een niet-shared
    /// projectparameter. Geeft de reden terug, of null als er geen conflict is.</summary>
    private static string? FindNameConflict(Document doc, ExternalDefinition ed)
    {
        foreach (var sp in new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>())
        {
            if (!sp.Name.Equals(ed.Name, StringComparison.OrdinalIgnoreCase)) continue;
            Guid g; try { g = sp.GuidValue; } catch { continue; }
            if (g != ed.GUID) return $"shared parameter '{sp.Name}' bestaat al met GUID {g} (bestand: {ed.GUID})";
        }
        var it = doc.ParameterBindings.ForwardIterator();
        it.Reset();
        while (it.MoveNext())
        {
            if (it.Key is not Definition d || !d.Name.Equals(ed.Name, StringComparison.OrdinalIgnoreCase)) continue;
            if (d is InternalDefinition idf && doc.GetElement(idf.Id) is SharedParameterElement) continue; // hierboven al getoetst
            return $"projectparameter (niet shared) '{d.Name}' is al gebonden";
        }
        return null;
    }

    private static Category? ResolveCategory(Document doc, Dictionary<string, Category> byName, string name)
    {
        Category? cat = null;
        if (name.StartsWith("OST_", StringComparison.OrdinalIgnoreCase) && Enum.TryParse<BuiltInCategory>(name, true, out var bic))
        { try { cat = Category.GetCategory(doc, bic); } catch { cat = null; } }
        if (cat == null) byName.TryGetValue(name, out cat);
        return cat;
    }

    private static string CatLabel(Category c)
    {
        try { var b = c.BuiltInCategory; if (b != BuiltInCategory.INVALID) return b.ToString(); } catch { }
        return c.Name;
    }

    private static Dictionary<string, ForgeTypeId>? _groupsByName;

    /// <summary>GroupTypeId-eigenschapnaam ("Data", "IdentityData", "Ifc"), alias "IfcParameters", of een oude
    /// BuiltInParameterGroup-naam ("PG_IDENTITY_DATA" → IdentityData). Onbekend of leeg → Data (met note).</summary>
    private static ForgeTypeId ParseGroup(string? name, List<string> notes)
    {
        if (string.IsNullOrWhiteSpace(name)) return GroupTypeId.Data;
        if (_groupsByName == null)
        {
            var map = new Dictionary<string, ForgeTypeId>(StringComparer.OrdinalIgnoreCase);
            foreach (var pi in typeof(GroupTypeId).GetProperties(BindingFlags.Public | BindingFlags.Static))
            {
                if (pi.PropertyType != typeof(ForgeTypeId)) continue;
                try { if (pi.GetValue(null) is ForgeTypeId f) map[pi.Name] = f; } catch { }
            }
            _groupsByName = map;
        }
        var key = name.Trim();
        if (key.StartsWith("PG_", StringComparison.OrdinalIgnoreCase)) key = key.Substring(3);
        key = key.Replace("_", "").Replace(" ", "");
        if (key.Equals("IfcParameters", StringComparison.OrdinalIgnoreCase)) key = "Ifc";
        if (_groupsByName.TryGetValue(key, out var gid)) return gid;
        notes.Add($"groep '{name}' onbekend; Data gebruikt");
        return GroupTypeId.Data;
    }

    private static string GroupLabel(ForgeTypeId g)
    {
        try { return LabelUtils.GetLabelForGroup(g); } catch { return g.TypeId; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 2. set_parameter_values_bulk
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// set_parameter_values_bulk — schrijf waarden op instanties of op hun type, in batches (één transactie per batch).
    /// Waarde per StorageType: String → Set(string); Integer → Yes/No (bool, ja/nee, true/false, 1/0) of int;
    /// Double → string = SetValueString (met eenheid, project-display-eenheden), getal = in de display-eenheid van de
    /// parameter (UnitUtils.ConvertToInternalUnits met Parameter.GetUnitTypeId); ElementId → geweigerd.
    /// target "type": schrijft op het ElementType; dezelfde type+param+waarde één keer, tegenstrijdige waarden = conflict
    /// (niets geschreven voor dat type+param). Groepsleden met een parameter die niet per groep mag variëren: fout
    /// group_member (geen schrijfpoging, geen modale dialoog). Read-back na commit bepaalt "geschreven".
    ///
    /// params: target_document, edits:[{element_id, param | guid, value, target: "instance"|"type"}],
    ///         only_if_empty (default false), dry_run (default TRUE), batch_size (default 500).
    /// Rapport: {gevraagd, geschreven, overgeslagen_niet_leeg, ongewijzigd_al_gelijk, type_dubbel_samengevoegd,
    ///           fouten:[{element_id, param, reden}] (max 200), fouten_totaal, per_param:{naam:{geschreven, fout}}}.
    /// </summary>
    public static CommandResponse SetParameterValuesBulk(CommandRequest request)
    {
        var p = request.Params;
        string? target = Str(p, "target_document");
        bool dryRun = Bool(p, "dry_run", true);
        bool onlyIfEmpty = Bool(p, "only_if_empty", false);
        int batchSize = Math.Max(1, Int(p, "batch_size") ?? 500);
        if (target == null) return Err("target_document is verplicht");

        var edits = new List<BulkEdit>();
        int idx = 0;
        foreach (var it in Arr(p, "edits"))
        {
            idx++;
            if (it.ValueKind != JsonValueKind.Object) { edits.Add(new BulkEdit(idx, null, null, null, default, false, "edit is geen object")); continue; }
            long? eid = PLong(it, "element_id");
            string? pn = PStr(it, "param");
            string? guid = PStr(it, "guid");
            string tgt = (PStr(it, "target") ?? "instance").ToLowerInvariant();
            bool hasVal = it.TryGetProperty("value", out var ve) && ve.ValueKind is JsonValueKind.String or JsonValueKind.Number or JsonValueKind.True or JsonValueKind.False;
            string? err = eid == null ? "element_id ontbreekt"
                        : (pn == null && guid == null) ? "param of guid ontbreekt"
                        : !hasVal ? "value ontbreekt of is geen string/getal/bool"
                        : tgt is not ("instance" or "type") ? $"target '{tgt}' onbekend (instance|type)"
                        : null;
            edits.Add(new BulkEdit(idx, eid, pn, guid, hasVal ? ve.Clone() : default, tgt == "type", err));
        }
        if (edits.Count == 0) return Err("edits:[{element_id, param|guid, value, target?}] is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");

                var notes = new List<string>();
                var fouten = new List<Dictionary<string, object?>>();
                var perParam = new Dictionary<string, Dictionary<string, int>>(StringComparer.Ordinal);
                void Tally(string param, string key)
                {
                    if (!perParam.TryGetValue(param, out var d)) perParam[param] = d = new Dictionary<string, int> { ["geschreven"] = 0, ["fout"] = 0 };
                    d[key]++;
                }
                void Fout(long? elId, string param, string reden) { fouten.Add(new() { ["element_id"] = elId, ["param"] = param, ["reden"] = reden }); Tally(param, "fout"); }

                // ── plan: per edit host + parameter + gewenste waarde ──
                var candidates = new List<Candidate>();
                foreach (var e in edits)
                {
                    string plabel = e.Param ?? e.Guid ?? "?";
                    if (e.Error != null) { Fout(e.ElementId, plabel, e.Error); continue; }
                    var el = doc.GetElement(new ElementId(e.ElementId!.Value));
                    if (el == null || !el.IsValidObject) { Fout(e.ElementId, plabel, "element niet gevonden"); continue; }
                    Element? host = el;
                    if (e.IsType)
                    {
                        var tid = el.GetTypeId();
                        host = tid != ElementId.InvalidElementId ? doc.GetElement(tid) as ElementType : null;
                        if (host == null) { Fout(e.ElementId, plabel, "element heeft geen type"); continue; }
                    }
                    var par = FindParam(host!, e.Param, e.Guid);
                    if (par == null)
                    {
                        string hint = "";
                        if (!e.IsType && el.GetTypeId() != ElementId.InvalidElementId && doc.GetElement(el.GetTypeId()) is Element ty && FindParam(ty, e.Param, e.Guid) != null)
                            hint = " (staat wel op het type: gebruik target \"type\")";
                        Fout(e.ElementId, plabel, $"parameter ontbreekt op {(e.IsType ? "type" : "instance")}{hint}");
                        continue;
                    }
                    plabel = par.Definition?.Name ?? plabel;
                    if (par.IsReadOnly) { Fout(e.ElementId, plabel, "parameter is read-only"); continue; }
                    if (!e.IsType && el.GroupId != ElementId.InvalidElementId
                        && !(par.Definition is InternalDefinition idf && idf.VariesAcrossGroups))
                    { Fout(e.ElementId, plabel, "group_member: element zit in een modelgroep en de parameter mag niet per groep variëren"); continue; }
                    var (desired, setString, convErr) = ConvertValue(doc, par, e.Value);
                    if (convErr != null) { Fout(e.ElementId, plabel, convErr); continue; }
                    candidates.Add(new Candidate(e, host!.Id, ParamKey(par), plabel, par.StorageType, desired!, setString));
                }

                // ── type-dedup en conflicten ──
                int dubbel = 0;
                var writes = new List<Candidate>();
                foreach (var grp in candidates.GroupBy(c => c.Edit.IsType ? $"T|{c.HostId.Value}|{c.ParamKey}" : $"I|{c.Edit.Index}"))
                {
                    var list = grp.ToList();
                    if (list.Count == 1) { writes.Add(list[0]); continue; }
                    bool allSame = list.All(c => SameValue(c.StorageType, c.Desired, list[0].Desired));
                    if (allSame) { writes.Add(list[0]); dubbel += list.Count - 1; continue; }
                    var typeName = doc.GetElement(list[0].HostId)?.Name;
                    var waarden = string.Join(" / ", list.Select(c => FormatDesired(c)).Distinct());
                    foreach (var c in list)
                        Fout(c.Edit.ElementId, c.ParamLabel, $"conflict: tegenstrijdige waarden voor type '{typeName}' (id {list[0].HostId.Value}): {waarden}");
                }

                // ── only_if_empty en al-gelijk ──
                int nietLeeg = 0, gelijk = 0;
                var todo = new List<Candidate>();
                var preview = new List<Dictionary<string, object?>>();
                foreach (var c in writes)
                {
                    var par = FindParamByKey(doc.GetElement(c.HostId), c.ParamKey);
                    if (par == null) { Fout(c.Edit.ElementId, c.ParamLabel, "parameter verdwenen tijdens plan"); continue; }
                    if (onlyIfEmpty && !IsEmpty(par)) { nietLeeg++; continue; }
                    if (Equal(par, c.StorageType, c.Desired)) { gelijk++; continue; }
                    todo.Add(c);
                    if (dryRun && preview.Count < 50)
                        preview.Add(new() { ["element_id"] = c.Edit.ElementId, ["host_id"] = c.HostId.Value, ["target"] = c.Edit.IsType ? "type" : "instance",
                                            ["param"] = c.ParamLabel, ["huidig"] = DisplayValue(par), ["nieuw"] = FormatDesired(c) });
                }

                int geschreven = 0, batches = 0;
                var failureMeldingen = new List<string>();
                if (!dryRun)
                {
                    for (int start = 0; start < todo.Count; start += batchSize)
                    {
                        var batch = todo.Skip(start).Take(batchSize).ToList();
                        batches++;
                        var setFailed = new HashSet<Candidate>();
                        var (ok, txNote) = RunTx(doc, $"Bulk parameterwaarden {batches}", () =>
                        {
                            foreach (var c in batch)
                            {
                                try
                                {
                                    var par = FindParamByKey(doc.GetElement(c.HostId), c.ParamKey);
                                    if (par == null) { setFailed.Add(c); Fout(c.Edit.ElementId, c.ParamLabel, "parameter niet gevonden bij schrijven"); continue; }
                                    if (!WriteValue(par, c)) { setFailed.Add(c); Fout(c.Edit.ElementId, c.ParamLabel, "Set gaf false"); }
                                }
                                catch (Exception ex) { setFailed.Add(c); Fout(c.Edit.ElementId, c.ParamLabel, $"exception bij Set: {ex.Message}"); }
                            }
                        }, failureMeldingen);
                        if (txNote != null) notes.Add($"batch {batches}: {txNote}");
                        foreach (var c in batch)
                        {
                            if (setFailed.Contains(c)) continue;
                            if (!ok) { Fout(c.Edit.ElementId, c.ParamLabel, $"batch {batches} niet gecommit: {txNote}"); continue; }
                            var par = FindParamByKey(doc.GetElement(c.HostId), c.ParamKey);
                            if (par == null) { Fout(c.Edit.ElementId, c.ParamLabel, "read-back: parameter niet gevonden"); continue; }
                            if (!Equal(par, c.StorageType, c.Desired))
                            { Fout(c.Edit.ElementId, c.ParamLabel, $"read-back wijkt af: huidig '{DisplayValue(par)}', gewenst '{FormatDesired(c)}'"); continue; }
                            geschreven++;
                            Tally(c.ParamLabel, "geschreven");
                        }
                    }
                }
                else notes.Add("dry_run: niets gewijzigd; zou_schrijven is het plan");
                if (dubbel > 0) notes.Add($"{dubbel} edits op hetzelfde type met dezelfde waarde samengevoegd");

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["only_if_empty"] = onlyIfEmpty,
                    ["gevraagd"] = edits.Count,
                    ["zou_schrijven"] = todo.Count,
                    ["geschreven"] = geschreven,
                    ["overgeslagen_niet_leeg"] = nietLeeg,
                    ["ongewijzigd_al_gelijk"] = gelijk,
                    ["type_dubbel_samengevoegd"] = dubbel,
                    ["batches"] = batches,
                    ["fouten"] = fouten.Take(200).ToList(),
                    ["fouten_totaal"] = fouten.Count,
                    ["per_param"] = perParam,
                    ["voorbeeld"] = dryRun ? preview : null,
                    ["failure_meldingen"] = failureMeldingen.Take(100).ToList(),
                    ["notes"] = notes,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private record BulkEdit(int Index, long? ElementId, string? Param, string? Guid, JsonElement Value, bool IsType, string? Error);

    private sealed record Candidate(BulkEdit Edit, ElementId HostId, string ParamKey, string ParamLabel, StorageType StorageType, object Desired, string? SetString);

    private static Parameter? FindParam(Element host, string? name, string? guid)
    {
        if (guid != null && Guid.TryParse(guid.Trim().Trim('{', '}'), out var g))
        {
            try { var byGuid = host.get_Parameter(g); if (byGuid != null) return byGuid; } catch { }
            return null;
        }
        return name != null ? host.LookupParameter(name) : null;
    }

    /// <summary>Stabiele sleutel om een parameter na regeneratie opnieuw te vinden: GUID (shared), anders id van
    /// de definitie (projectparameter / built-in), anders de naam.</summary>
    private static string ParamKey(Parameter par)
    {
        try { if (par.IsShared) return "g:" + par.GUID; } catch { }
        if (par.Definition is InternalDefinition idf)
        {
            if (idf.BuiltInParameter != BuiltInParameter.INVALID) return "b:" + (long)idf.BuiltInParameter;
            if (idf.Id != ElementId.InvalidElementId) return "d:" + idf.Id.Value;
        }
        return "n:" + par.Definition?.Name;
    }

    private static Parameter? FindParamByKey(Element? host, string key)
    {
        if (host == null || !host.IsValidObject) return null;
        var v = key.Substring(2);
        switch (key[0])
        {
            case 'g': return Guid.TryParse(v, out var g) ? host.get_Parameter(g) : null;
            case 'b': return long.TryParse(v, out var b) ? host.get_Parameter((BuiltInParameter)b) : null;
            case 'd':
                if (!long.TryParse(v, out var d)) return null;
                foreach (Parameter par in host.Parameters)
                    if (par.Definition is InternalDefinition idf && idf.Id.Value == d) return par;
                return null;
            default: return host.LookupParameter(v);
        }
    }

    private static bool IsYesNo(Parameter par)
    {
        try { return par.Definition?.GetDataType()?.TypeId == SpecTypeId.Boolean.YesNo.TypeId; } catch { return false; }
    }

    /// <summary>JSON-waarde → gewenste opgeslagen waarde (string / int / double intern). setString != null betekent
    /// schrijven via SetValueString (Double met eenheidstekst).</summary>
    private static (object? desired, string? setString, string? error) ConvertValue(Document doc, Parameter par, JsonElement v)
    {
        switch (par.StorageType)
        {
            case StorageType.String:
                return v.ValueKind switch
                {
                    JsonValueKind.String => (v.GetString() ?? "", null, null),
                    JsonValueKind.Number => (v.GetRawText(), null, null),
                    JsonValueKind.True => ("true", null, null),
                    JsonValueKind.False => ("false", null, null),
                    _ => (null, null, "waarde niet bruikbaar voor tekstparameter"),
                };
            case StorageType.Integer:
                if (IsYesNo(par))
                {
                    int? yn = v.ValueKind switch
                    {
                        JsonValueKind.True => 1,
                        JsonValueKind.False => 0,
                        JsonValueKind.Number => v.TryGetInt32(out var n) && (n == 0 || n == 1) ? n : null,
                        JsonValueKind.String => (v.GetString() ?? "").Trim().ToLowerInvariant() switch
                        {
                            "ja" or "yes" or "true" or "1" or "waar" => 1,
                            "nee" or "no" or "false" or "0" or "onwaar" => 0,
                            _ => null,
                        },
                        _ => null,
                    };
                    return yn == null ? (null, null, $"'{Raw(v)}' is geen ja/nee-waarde") : (yn.Value, null, null);
                }
                if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var iv)) return (iv, null, null);
                if (v.ValueKind == JsonValueKind.String && int.TryParse((v.GetString() ?? "").Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var sv)) return (sv, null, null);
                if (v.ValueKind == JsonValueKind.True) return (1, null, null);
                if (v.ValueKind == JsonValueKind.False) return (0, null, null);
                return (null, null, $"'{Raw(v)}' is geen geheel getal");
            case StorageType.Double:
            {
                ForgeTypeId? spec = null;
                try { spec = par.Definition?.GetDataType(); } catch { }
                if (v.ValueKind == JsonValueKind.Number)
                {
                    double d = v.GetDouble();
                    if (spec != null && UnitUtils.IsMeasurableSpec(spec))
                    {
                        try { return (UnitUtils.ConvertToInternalUnits(d, par.GetUnitTypeId()), null, null); }
                        catch (Exception ex) { return (null, null, $"eenheidsconversie mislukt: {ex.Message}"); }
                    }
                    return (d, null, null);
                }
                if (v.ValueKind == JsonValueKind.String)
                {
                    var s = (v.GetString() ?? "").Trim();
                    if (s.Length == 0) return (null, null, "lege waarde voor een getalparameter");
                    if (spec != null)
                    {
                        try
                        {
                            if (UnitFormatUtils.TryParse(doc.GetUnits(), spec, s, out double parsed)) return (parsed, s, null);
                        }
                        catch { }
                    }
                    return (null, null, $"'{s}' niet te parsen als waarde met eenheid");
                }
                return (null, null, $"'{Raw(v)}' is geen getal");
            }
            case StorageType.ElementId:
                return (null, null, "ElementId-parameter: niet ondersteund in bulk-schrijven");
            default:
                return (null, null, $"StorageType {par.StorageType} niet ondersteund");
        }
    }

    private static bool WriteValue(Parameter par, Candidate c)
    {
        switch (c.StorageType)
        {
            case StorageType.String: return par.Set((string)c.Desired);
            case StorageType.Integer: return par.Set((int)c.Desired);
            case StorageType.Double:
                if (c.SetString != null) { try { if (par.SetValueString(c.SetString)) return true; } catch { } }
                return par.Set((double)c.Desired);
            default: return false;
        }
    }

    private static bool SameValue(StorageType st, object a, object b) => st switch
    {
        StorageType.String => string.Equals((string)a, (string)b, StringComparison.Ordinal),
        StorageType.Integer => (int)a == (int)b,
        StorageType.Double => DblEq((double)a, (double)b),
        _ => false,
    };

    private static bool Equal(Parameter par, StorageType st, object desired)
    {
        try
        {
            return st switch
            {
                StorageType.String => string.Equals(par.AsString() ?? "", (string)desired, StringComparison.Ordinal),
                StorageType.Integer => par.HasValue && par.AsInteger() == (int)desired,
                StorageType.Double => par.HasValue && DblEq(par.AsDouble(), (double)desired),
                _ => false,
            };
        }
        catch { return false; }
    }

    private static bool DblEq(double a, double b) => Math.Abs(a - b) <= 1e-6 * Math.Max(1.0, Math.Abs(b));

    private static bool IsEmpty(Parameter par)
    {
        if (!par.HasValue) return true;
        return par.StorageType == StorageType.String && string.IsNullOrEmpty(par.AsString());
    }

    private static string FormatDesired(Candidate c) => c.SetString ?? c.Desired switch
    {
        double d => d.ToString("G10", CultureInfo.InvariantCulture) + " (intern)",
        _ => Convert.ToString(c.Desired, CultureInfo.InvariantCulture) ?? "",
    };

    private static string? DisplayValue(Parameter par)
    {
        try { return par.AsValueString() ?? par.AsString(); } catch { return null; }
    }

    private static string Raw(JsonElement v) => v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : v.GetRawText();

    // ═══════════════════════════════════════════════════════════════════════
    // 3. read_parameter_values
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// read_parameter_values — bulk lezen voor inventaris en controle (alleen lezen).
    /// Selectie: categories:["OST_Doors", ...] (of UI-namen) of element_ids:[...]. Parameters: params:[namen], eerst op de
    /// instantie, dan op het type (bron "instance"|"type"). include_all (default false): alle parameters met waarde
    /// (instance + type), gecapt op 500 rijen. Paginering met limit (default 5000) en offset, gesorteerd op element-id.
    ///
    /// Rij: {element_id, unique_id, category, family, type, level, ifc_guid, values:{naam:{value, raw, bron}}}.
    /// summary per param (over de hele selectie, niet alleen de pagina): {met_waarde, zonder_waarde, ontbreekt}.
    /// </summary>
    public static CommandResponse ReadParameterValues(CommandRequest request)
    {
        var p = request.Params;
        string? target = Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");
        var categories = Arr(p, "categories").Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!.Trim()).Where(s => s.Length > 0).ToList();
        var ids = Arr(p, "element_ids").Select(JLong).Where(x => x != null).Select(x => x!.Value).ToList();
        var pnames = Arr(p, "params").Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();
        bool includeAll = Bool(p, "include_all", false);
        int limit = Math.Max(1, Int(p, "limit") ?? 5000);
        int offset = Math.Max(0, Int(p, "offset") ?? 0);
        if (categories.Count == 0 && ids.Count == 0) return Err("categories:[...] of element_ids:[...] is verplicht");
        if (pnames.Count == 0 && !includeAll) return Err("params:[namen] is verplicht (of include_all: true)");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                var notes = new List<string>();

                var elements = new List<Element>();
                if (ids.Count > 0)
                {
                    foreach (var id in ids.Distinct())
                    {
                        var el = doc.GetElement(new ElementId(id));
                        if (el == null) notes.Add($"element {id} niet gevonden");
                        else elements.Add(el);
                    }
                }
                else
                {
                    var catByName = new Dictionary<string, Category>(StringComparer.OrdinalIgnoreCase);
                    foreach (Category c in doc.Settings.Categories) catByName[c.Name] = c;
                    var bics = new List<BuiltInCategory>();
                    foreach (var cn in categories)
                    {
                        var cat = ResolveCategory(doc, catByName, cn);
                        BuiltInCategory b = BuiltInCategory.INVALID;
                        try { if (cat != null) b = cat.BuiltInCategory; } catch { }
                        if (b == BuiltInCategory.INVALID) notes.Add($"categorie '{cn}' onbekend");
                        else if (!bics.Contains(b)) bics.Add(b);
                    }
                    if (bics.Count == 0) return (object)Fail("geen bekende categorieën");
                    elements = new FilteredElementCollector(doc).WhereElementIsNotElementType()
                        .WherePasses(new ElementMulticategoryFilter(bics)).ToElements().ToList();
                }
                elements = elements.OrderBy(e => e.Id.Value).ToList();

                int effLimit = limit;
                if (includeAll && effLimit > 500) { effLimit = 500; notes.Add("include_all: limit gecapt op 500"); }

                // summary over de hele selectie
                var summary = pnames.ToDictionary(n => n, _ => new Dictionary<string, int> { ["met_waarde"] = 0, ["zonder_waarde"] = 0, ["ontbreekt"] = 0 });
                var typeCache = new Dictionary<long, Element?>();
                Element? TypeOf(Element el)
                {
                    var tid = el.GetTypeId();
                    if (tid == ElementId.InvalidElementId) return null;
                    if (!typeCache.TryGetValue(tid.Value, out var t)) typeCache[tid.Value] = t = doc.GetElement(tid);
                    return t;
                }
                foreach (var el in elements)
                {
                    var ty = TypeOf(el);
                    foreach (var n in pnames)
                    {
                        var par = el.LookupParameter(n) ?? ty?.LookupParameter(n);
                        if (par == null) summary[n]["ontbreekt"]++;
                        else if (HasRealValue(par)) summary[n]["met_waarde"]++;
                        else summary[n]["zonder_waarde"]++;
                    }
                }

                var rows = new List<Dictionary<string, object?>>();
                foreach (var el in elements.Skip(offset).Take(effLimit))
                {
                    var ty = TypeOf(el);
                    var values = new Dictionary<string, object?>(StringComparer.Ordinal);
                    foreach (var n in pnames)
                    {
                        var ip = el.LookupParameter(n);
                        var tp = ip == null ? ty?.LookupParameter(n) : null;
                        var par = ip ?? tp;
                        values[n] = par == null ? null : ValueObj(doc, par, ip != null ? "instance" : "type");
                    }
                    if (includeAll)
                    {
                        foreach (Parameter par in el.Parameters)
                        {
                            var nm = par.Definition?.Name;
                            if (nm == null || values.ContainsKey(nm) || !HasRealValue(par)) continue;
                            values[nm] = ValueObj(doc, par, "instance");
                        }
                        if (ty != null)
                            foreach (Parameter par in ty.Parameters)
                            {
                                var nm = par.Definition?.Name;
                                if (nm == null || values.ContainsKey(nm) || !HasRealValue(par)) continue;
                                values[nm] = ValueObj(doc, par, "type");
                            }
                    }
                    rows.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = el.Id.Value,
                        ["unique_id"] = el.UniqueId,
                        ["category"] = el.Category?.Name,
                        ["family"] = FamilyName(el, ty),
                        ["type"] = ty?.Name,
                        ["level"] = LevelName(doc, el),
                        ["ifc_guid"] = IfcGuid(el),
                        ["values"] = values,
                    });
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["totaal"] = elements.Count,
                    ["offset"] = offset,
                    ["limit"] = effLimit,
                    ["teruggegeven"] = rows.Count,
                    ["volgende_offset"] = offset + rows.Count < elements.Count ? offset + rows.Count : null,
                    ["summary"] = summary,
                    ["summary_scope"] = "hele selectie",
                    ["rows"] = rows,
                    ["notes"] = notes,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static bool HasRealValue(Parameter par)
    {
        try
        {
            if (!par.HasValue) return false;
            return par.StorageType switch
            {
                StorageType.String => !string.IsNullOrEmpty(par.AsString()),
                StorageType.ElementId => par.AsElementId() != ElementId.InvalidElementId,
                _ => true,
            };
        }
        catch { return false; }
    }

    private static Dictionary<string, object?> ValueObj(Document doc, Parameter par, string bron)
    {
        object? raw = null; string? val = null;
        try
        {
            raw = par.StorageType switch
            {
                StorageType.String => par.AsString(),
                StorageType.Integer => par.HasValue ? par.AsInteger() : null,
                StorageType.Double => par.HasValue ? par.AsDouble() : null,
                StorageType.ElementId => par.AsElementId()?.Value,
                _ => null,
            };
            val = par.AsValueString() ?? par.AsString();
            if (val == null && par.StorageType == StorageType.ElementId)
            {
                var id = par.AsElementId();
                if (id != null && id != ElementId.InvalidElementId) val = doc.GetElement(id)?.Name;
            }
        }
        catch { }
        return new Dictionary<string, object?> { ["value"] = val, ["raw"] = raw, ["bron"] = bron };
    }

    private static string? FamilyName(Element el, Element? ty)
    {
        if (el is FamilyInstance fi) { try { return fi.Symbol?.FamilyName; } catch { } }
        return (ty as ElementType)?.FamilyName;
    }

    private static string? LevelName(Document doc, Element el)
    {
        try
        {
            var lid = el.LevelId;
            if (lid != null && lid != ElementId.InvalidElementId) return doc.GetElement(lid)?.Name;
            foreach (var bip in new[] { BuiltInParameter.FAMILY_LEVEL_PARAM, BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM,
                                        BuiltInParameter.SCHEDULE_LEVEL_PARAM, BuiltInParameter.RBS_START_LEVEL_PARAM })
            {
                var par = el.get_Parameter(bip);
                if (par != null && par.StorageType == StorageType.ElementId)
                {
                    var id = par.AsElementId();
                    if (id != ElementId.InvalidElementId) return doc.GetElement(id)?.Name;
                }
            }
        }
        catch { }
        return null;
    }

    private static string? IfcGuid(Element el)
    {
        try
        {
            var s = el.get_Parameter(BuiltInParameter.IFC_GUID)?.AsString();
            if (!string.IsNullOrEmpty(s)) return s;
            s = el.LookupParameter("IfcGUID")?.AsString();
            if (!string.IsNullOrEmpty(s)) return s;
            s = el.LookupParameter("IFC GUID")?.AsString();
            return string.IsNullOrEmpty(s) ? null : s;
        }
        catch { return null; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 4. list_parameter_bindings
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// list_parameter_bindings — alle project- en shared-parameterbindingen van een document (alleen lezen).
    /// params: target_document.
    /// Rij: {name, guid (alleen shared), shared, instance_or_type, group, group_id, data_type, varies_across_groups,
    ///       categories:[OST_-naam of UI-naam]}.
    /// </summary>
    public static CommandResponse ListParameterBindings(CommandRequest request)
    {
        var p = request.Params;
        string? target = Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                var rows = new List<Dictionary<string, object?>>();
                var it = doc.ParameterBindings.ForwardIterator();
                it.Reset();
                while (it.MoveNext())
                {
                    if (it.Key is not Definition def) continue;
                    var binding = it.Current as ElementBinding;
                    string? guid = null; bool? vary = null;
                    if (def is InternalDefinition idf)
                    {
                        try { vary = idf.VariesAcrossGroups; } catch { }
                        if (doc.GetElement(idf.Id) is SharedParameterElement spe) { try { guid = spe.GuidValue.ToString(); } catch { } }
                    }
                    ForgeTypeId? grp = null; try { grp = def.GetGroupTypeId(); } catch { }
                    string? dataType = null; try { dataType = def.GetDataType()?.TypeId; } catch { }
                    var cats = new List<string>();
                    // Een binding kan een categorie bevatten die Revit als NULL teruggeeft:
                    // per categorie afvangen, anders valt het hele overzicht weg
                    if (binding != null)
                    {
                        try
                        {
                            var ci = binding.Categories.ForwardIterator();
                            while (ci.MoveNext())
                            {
                                try { if (ci.Current is Category c) cats.Add(CatLabel(c)); else cats.Add("(null)"); }
                                catch { cats.Add("(null)"); }
                            }
                        }
                        catch (Exception ex) { cats.Add("(fout: " + ex.Message + ")"); }
                    }
                    cats.Sort(StringComparer.Ordinal);
                    rows.Add(new Dictionary<string, object?>
                    {
                        ["name"] = def.Name,
                        ["guid"] = guid,
                        ["shared"] = guid != null,
                        ["instance_or_type"] = binding is TypeBinding ? "type" : binding is InstanceBinding ? "instance" : "onbekend",
                        ["group"] = grp != null ? GroupLabel(grp) : null,
                        ["group_id"] = grp?.TypeId,
                        ["data_type"] = dataType,
                        ["varies_across_groups"] = vary,
                        ["categories"] = cats,
                    });
                }
                rows = rows.OrderBy(r => (string?)r["name"], StringComparer.OrdinalIgnoreCase).ToList();
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["aantal"] = rows.Count,
                    ["aantal_shared"] = rows.Count(r => (bool?)r["shared"] == true),
                    ["bindings"] = rows,
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Transacties en failures
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>Warnings weg (DeleteWarning), errors → terugrollen; nooit een modale dialoog.</summary>
    private sealed class StilleFailures : IFailuresPreprocessor
    {
        public readonly List<string> Meldingen = new();
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            bool error = false;
            foreach (var f in fa.GetFailureMessages())
            {
                string desc; try { desc = f.GetDescriptionText(); } catch { desc = "?"; }
                string ids = "";
                try { var fe = f.GetFailingElementIds(); if (fe.Count > 0) ids = " [ids " + string.Join(",", fe.Take(20).Select(x => x.Value)) + "]"; } catch { }
                FailureSeverity sev; try { sev = f.GetSeverity(); } catch { sev = FailureSeverity.Error; }
                if (sev == FailureSeverity.Warning) { Meldingen.Add("warning: " + desc + ids); try { fa.DeleteWarning(f); } catch { } }
                else { Meldingen.Add("error: " + desc + ids); error = true; }
            }
            return error ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
        }
    }

    /// <summary>Voert body uit in één transactie met StilleFailures; RollBack in finally als niet gecommit.
    /// Geeft (gecommit, note) terug; note bevat de reden bij een rollback of de failure-meldingen.</summary>
    private static (bool committed, string? note) RunTx(Document doc, string name, Action body, List<string>? meldingenOut = null)
    {
        var pp = new StilleFailures();
        using var t = new Transaction(doc, name);
        string? note = null;
        bool committed = false;
        try
        {
            var fho = t.GetFailureHandlingOptions();
            fho.SetFailuresPreprocessor(pp);
            fho.SetClearAfterRollback(true);
            fho.SetForcedModalHandling(false);
            t.SetFailureHandlingOptions(fho);
            if (t.Start() != TransactionStatus.Started) return (false, "transactie kon niet starten");
            body();
            var st = t.Commit();
            committed = st == TransactionStatus.Committed;
            if (!committed) note = $"commit-status {st}";
        }
        catch (Exception ex) { note = ex.Message; }
        finally
        {
            try { if (t.HasStarted() && !t.HasEnded()) t.RollBack(); } catch { }
        }
        if (pp.Meldingen.Count > 0)
        {
            meldingenOut?.AddRange(pp.Meldingen);
            if (!committed) note = (note ?? "teruggerold") + "; " + string.Join(" | ", pp.Meldingen.Take(5));
        }
        return (committed, note);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JSON-helpers
    // ═══════════════════════════════════════════════════════════════════════

    private static string? Str(Dictionary<string, JsonElement>? p, string key) => HandlerUtil.Str(p, key);
    private static bool Bool(Dictionary<string, JsonElement>? p, string key, bool dflt) => HandlerUtil.Bool(p, key, dflt);
    private static List<JsonElement> Arr(Dictionary<string, JsonElement>? p, string key) => HandlerUtil.Arr(p, key);

    // HandlerUtil.Str geeft null voor getallen: numerieke params apart lezen.
    private static int? Int(Dictionary<string, JsonElement>? p, string key)
    {
        if (p == null || !p.TryGetValue(key, out var el)) return null;
        if (el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        if (el.ValueKind == JsonValueKind.String && int.TryParse(el.GetString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var s)) return s;
        return null;
    }

    private static long? JLong(JsonElement el)
    {
        if (el.ValueKind == JsonValueKind.Number && el.TryGetInt64(out var v)) return v;
        if (el.ValueKind == JsonValueKind.String && long.TryParse(el.GetString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var s)) return s;
        return null;
    }

    private static long? PLong(JsonElement o, string key) => o.TryGetProperty(key, out var el) ? JLong(el) : null;
    private static string? PStr(JsonElement o, string key) => HandlerUtil.Str(o, key);
    private static bool? PBool(JsonElement o, string key) => HandlerUtil.Bool(o, key);

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
}
