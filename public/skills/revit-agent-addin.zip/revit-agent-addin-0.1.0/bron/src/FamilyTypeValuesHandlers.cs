using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_family_type_values — lees/schrijf parameterwaarden PER TYPE in het family-document (FamilyManager) en hernoem
/// types, met LoadFamily terug naar het project (nodig voor bv. vertaalde typenamen/omschrijvingen die alleen op de
/// project-symbols stonden, gingen verloren bij een latere LoadFamily met overwriteParameterValues en zaten niet in de
/// geexporteerde .rfa's). Werkt per family; dry_run rapporteert per type de HUIDIGE waarden van de gevraagde
/// parameters zodat een script project- en family-stand kan vergelijken.
///
/// params:
///   target_document : scope op Title
///   family          : familynaam in het project (verplicht)
///   params          : [parameternamen of GUIDs] om te rapporteren (optioneel)
///   edits           : [{type, param_name|guid, value}]  — value als UI-tekst; text-params via Set(string), overige via SetValueString
///   rename_types    : {oude_typenaam: nieuwe_typenaam} (optioneel; na de edits)
///   dry_run (default TRUE), save_first (default false), dialog_ok / dialog_result
/// </summary>
public static class FamilyTypeValuesHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Project; overwriteParameterValues = true; return true; }   // Project: FamilySource.Family bracht bij herladen de geneste kopieën als dubbel-typen " 1" binnen en verhing exemplaren
    }

    private record TypeEdit(string Type, string? ParamName, string? Guid, string Value);

    public static CommandResponse SetFamilyTypeValues(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? famName = GetString(p, "family");
        string? rfaPath = GetString(p, "rfa_path");   // optioneel: family-doc rechtstreeks van schijf bewerken (Save) i.p.v. EditFamily/LoadFamily
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        bool dialogOk = GetBool(p, "dialog_ok", false);
        int dialogResult = GetInt(p, "dialog_result", 1);
        bool forceReload = GetBool(p, "force_reload", false);   // LoadFamily ook zonder edits (waarden uit het family-doc terug in het project)
        var reportParams = GetStringList(p, "params") ?? new List<string>();
        var edits = new List<TypeEdit>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? t = Prop(it, "type"), pn = Prop(it, "param_name"), g = Prop(it, "guid");
                string? v = it.TryGetProperty("value", out var vEl) ? (vEl.ValueKind == JsonValueKind.String ? vEl.GetString() : vEl.ToString()) : null;
                if (string.IsNullOrWhiteSpace(t) || (pn == null && g == null) || v == null) continue;
                edits.Add(new TypeEdit(t!, pn, g, v));
            }
        var renames = new Dictionary<string, string>(StringComparer.Ordinal);
        if (p != null && p.TryGetValue("rename_types", out var rn) && rn.ValueKind == JsonValueKind.Object)
            foreach (var kv in rn.EnumerateObject())
                if (kv.Value.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(kv.Value.GetString())) renames[kv.Name] = kv.Value.GetString()!;
        if (string.IsNullOrWhiteSpace(famName)) return Err("'family' is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                Family? fam = null;
                if (rfaPath == null)
                {
                    fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                        .FirstOrDefault(f => f.IsValidObject && !f.IsInPlace && f.IsEditable && f.Name.Equals(famName, StringComparison.OrdinalIgnoreCase));
                    if (fam == null) return (object)Fail($"family niet gevonden of niet editable: {famName}");
                }
                else if (!System.IO.File.Exists(rfaPath)) return (object)Fail($"rfa_path bestaat niet: {rfaPath}");

                bool savedBackup = false;
                if (!dryRun && saveFirst && (edits.Count > 0 || renames.Count > 0))
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, aborted: {ex.Message}"); }
                }

                string famLabel = fam?.Name ?? System.IO.Path.GetFileNameWithoutExtension(rfaPath!);   // Family-element kan na LoadFamily ongeldig zijn -> naam vooraf vastleggen
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.BlindResult = dialogResult; swallow.Context = famLabel;
                Document? fdoc = null;
                var types = new List<Dictionary<string, object?>>();
                var results = new List<Dictionary<string, object?>>();
                int applied = 0, failed = 0;
                try
                {
                    MainThreadDispatcher.Log($"set_family_type_values: opening family '{famLabel}'");
                    fdoc = rfaPath != null ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                    var fm = fdoc.FamilyManager;
                    var byName = new Dictionary<string, FamilyParameter>(StringComparer.OrdinalIgnoreCase);
                    var byGuid = new Dictionary<string, FamilyParameter>(StringComparer.OrdinalIgnoreCase);
                    foreach (FamilyParameter fp in fm.Parameters)
                    {
                        if (fp?.Definition == null) continue;
                        byName[fp.Definition.Name] = fp;
                        try { if (fp.IsShared) byGuid[fp.GUID.ToString()] = fp; } catch { }
                    }
                    FamilyParameter? Find(string? name, string? guid)
                        => guid != null && byGuid.TryGetValue(guid, out var a) ? a : (name != null && byName.TryGetValue(name, out var b) ? b : null);
                    string? ElName(ElementId? id)
                    {
                        if (id == null || id == ElementId.InvalidElementId) return null;
                        var el = fdoc.GetElement(id);
                        if (el is FamilySymbol fs) { try { return fs.Family.Name + " : " + fs.Name; } catch { return fs.Name; } }
                        return el?.Name ?? id.ToString();
                    }
                    ElementId? ElByName(string v)
                    {
                        v = v.Trim();
                        if (long.TryParse(v, out var lv)) return new ElementId(lv);
                        var syms = new FilteredElementCollector(fdoc).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>().ToList();
                        var sym = syms.FirstOrDefault(x => string.Equals(x.Family.Name + " : " + x.Name, v, StringComparison.OrdinalIgnoreCase))
                               ?? syms.FirstOrDefault(x => string.Equals(x.Name, v, StringComparison.OrdinalIgnoreCase));
                        if (sym != null) return sym.Id;
                        var mat = new FilteredElementCollector(fdoc).OfClass(typeof(Material)).Cast<Material>().FirstOrDefault(m => string.Equals(m.Name, v, StringComparison.OrdinalIgnoreCase));
                        return mat?.Id;
                    }
                    string? Read(FamilyType t, FamilyParameter fp)
                    {
                        try
                        {
                            if (!t.HasValue(fp)) return null;
                            return fp.StorageType switch
                            {
                                StorageType.String => t.AsString(fp),
                                StorageType.Integer => t.AsInteger(fp)?.ToString(),
                                StorageType.Double => t.AsValueString(fp),
                                StorageType.ElementId => ElName(t.AsElementId(fp)),
                                _ => t.AsValueString(fp),
                            };
                        }
                        catch { return null; }
                    }

                    // FamilyType-objecten zijn snapshots die na een Set/rename ongeldig raken ("referenced object is not valid"):
                    // per type opnieuw ophalen op naam, nooit een lijst van FamilyType hergebruiken.
                    var typeNames = fm.Types.Cast<FamilyType>().Select(x => x.Name).ToList();
                    FamilyType Fresh(string name) => fm.Types.Cast<FamilyType>().First(x => x.Name == name);
                    bool anyOk = false;
                    var pre = new MiscDocHandlers.LoadFailurePreprocessor();
                    using (var tr = new Transaction(fdoc, "Revit Agent: set family type values"))
                    {
                        tr.Start();
                        try { tr.SetFailureHandlingOptions(tr.GetFailureHandlingOptions().SetFailuresPreprocessor(pre).SetClearAfterRollback(true)); } catch { }
                        foreach (var typeName in typeNames.ToList())
                        {
                            var t = Fresh(typeName);
                            var row = new Dictionary<string, object?> { ["type"] = t.Name };
                            var vals = new Dictionary<string, object?>();
                            foreach (var rp in reportParams) { var fp = Find(rp, rp); vals[rp] = fp == null ? null : Read(t, fp); }
                            row["values"] = vals;
                            var myEdits = edits.Where(e => e.Type.Equals(t.Name, StringComparison.Ordinal)).ToList();
                            if (myEdits.Count > 0 || renames.ContainsKey(t.Name))
                            {
                                fm.CurrentType = t;
                                foreach (var e in myEdits)
                                {
                                    var info = new Dictionary<string, object?> { ["type"] = t.Name, ["param"] = e.ParamName ?? e.Guid, ["value"] = e.Value };
                                    var fp = Find(e.ParamName, e.Guid);
                                    if (fp == null) { info["status"] = "not_found"; results.Add(info); continue; }
                                    if (fp.IsDeterminedByFormula) { info["status"] = "formula_driven"; results.Add(info); continue; }
                                    if (fp.IsReadOnly) { info["status"] = "read_only"; results.Add(info); continue; }
                                    string? cur = Read(Fresh(typeName), fp); info["current"] = cur;
                                    if ((cur ?? "") == e.Value) { info["status"] = "unchanged"; results.Add(info); continue; }
                                    if (dryRun) { info["status"] = "would_set"; results.Add(info); continue; }
                                    try
                                    {
                                        if (fp.StorageType == StorageType.String) fm.Set(fp, e.Value);
                                        else if (fp.StorageType == StorageType.Integer && int.TryParse(e.Value, out var iv)) fm.Set(fp, iv);
                                        else if (fp.StorageType == StorageType.ElementId)
                                        {
                                            var eid = ElByName(e.Value);
                                            if (eid == null) throw new Exception($"element '{e.Value}' niet gevonden in het family-doc (family type 'Family : Type' of materiaalnaam)");
                                            fm.Set(fp, eid);
                                        }
                                        else fm.SetValueString(fp, e.Value);
                                        info["status"] = "set"; anyOk = true; applied++;
                                    }
                                    catch (Exception ex) { info["status"] = "error"; info["error"] = ex.Message; failed++; }
                                    results.Add(info);
                                }
                                if (renames.TryGetValue(t.Name, out var newName) && newName != t.Name)
                                {
                                    var info = new Dictionary<string, object?> { ["type"] = t.Name, ["rename_to"] = newName };
                                    if (typeNames.Contains(newName)) { info["status"] = "name_exists"; }
                                    else if (dryRun) { info["status"] = "would_rename"; }
                                    else
                                    {
                                        try { fm.RenameCurrentType(newName); typeNames[typeNames.IndexOf(typeName)] = newName; info["status"] = "renamed"; anyOk = true; applied++; }
                                        catch (Exception ex) { info["status"] = "error"; info["error"] = ex.Message; failed++; }
                                    }
                                    results.Add(info);
                                }
                            }
                            types.Add(row);
                        }
                        if (!dryRun && anyOk) { var st = tr.Commit(); if (st != TransactionStatus.Committed) { anyOk = false; results.Add(new Dictionary<string, object?> { ["type"] = "*", ["status"] = "rolled_back", ["failures"] = pre.Messages }); } else if (pre.Messages.Count > 0) results.Add(new Dictionary<string, object?> { ["type"] = "*", ["status"] = "failures_resolved", ["failures"] = pre.Messages }); } else tr.RollBack();
                    }
                    if (!dryRun && (anyOk || forceReload))
                    {
                        if (rfaPath != null) { fdoc.Save(); results.Add(new Dictionary<string, object?> { ["type"] = "*", ["status"] = "saved_rfa" }); }
                        else { fdoc.LoadFamily(doc, new FamLoadOpts()); results.Add(new Dictionary<string, object?> { ["type"] = "*", ["status"] = "reloaded" }); }
                    }
                    fdoc.Close(false);
                }
                catch (Exception ex)
                {
                    failed++;
                    results.Add(new Dictionary<string, object?> { ["family"] = famLabel, ["status"] = "error", ["error"] = ex.Message });
                    try { fdoc?.Close(false); } catch { }
                }
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["family"] = famLabel, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup,
                    ["applied"] = applied, ["failed"] = failed, ["types"] = types, ["results"] = results, ["notable_dialogs"] = swallow.NotableReport(),
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static string? Prop(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String) { var s = el.GetString(); return string.IsNullOrWhiteSpace(s) ? null : s; }
        return null;
    }
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) return el.GetString();
        return null;
    }
    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).ToList();
        return null;
    }
}
