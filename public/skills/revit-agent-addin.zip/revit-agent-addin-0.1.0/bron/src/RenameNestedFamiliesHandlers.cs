using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// rename_nested_families — write-back for the reviewed Nested Families tab.
/// Renames the families NESTED (depth-1) inside loadable families, reusing the
/// EditFamily -> edit -> LoadFamily(overwrite) round-trip (same primitive as swap_family_parameter /
/// transfer_family). A renamed nested family's parent is reloaded into the project in-memory; the project
/// .rvt/.rte is only written when save=true (default false — a roundtrip test shouldn't silently persist).
///
/// RECURSIVE: renames at ANY nesting depth. Per node the child family document is
/// opened (EditFamily), its descendants are renamed, and the modified child is loaded back up
/// (LoadFamily) so the change persists into its host — repeated up to the project. Order per node:
/// rename-self-first (transaction in the host doc, ElementId stable) THEN recurse, so the self-rename
/// never runs on a reference invalidated by a child LoadFamily. A depth cap + per-path visited-set guard
/// against runaway/cyclic families. The client batches the `families` (roots) so no single main-thread op
/// exceeds the ~590s cap. Modal dialogs are auto-dismissed (DialogBoxShowing) so a problem family can't
/// hang the bridge.
///
/// params:
///   renames         : [{old, new}] — the (nested-family-name -> new-name) map from the reviewed tab
///   families        : [parent names] — the root loadable families to process THIS call (client batches them)
///   dry_run         : bool (default TRUE)
///   save            : bool (default FALSE) — persist the project after a live run
///   max_depth       : int (default 5)
///   target_document : scope by doc Title
/// </summary>
public static class RenameNestedFamiliesHandlers
{
    private sealed class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }

    public static CommandResponse RenameNestedFamilies(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool save = GetBool(p, "save", false);
        int maxDepth = GetInt(p, "max_depth", 5);
        var families = GetStringList(p, "families");
        var renameMap = GetRenameMap(p);   // old (lower) -> new

        if (renameMap.Count == 0) return Err("renames is required ([{old,new}])");
        if (families == null || families.Count == 0)
            return Err("families is required (the parent families to process this batch)");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var want = families.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                var parents = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable
                                && want.Contains(f.Name.ToLowerInvariant())).ToList();

                // Auto-dismiss modal dialogs during EditFamily/LoadFamily so a problem family can't block the
                // main thread; notable ones surface per-family in the response (shared scope).
                // Attributed to the ROOT parent being processed.
                using var swallow = new DialogSwallowScope(app);

                var results = new List<Dictionary<string, object?>>();
                int renamed = 0, wouldRename = 0, failed = 0, parentsChanged = 0;

                // Rename flagged families nested inside hostDoc at ANY depth. Self-rename first (host-doc
                // transaction, ElementId stable) then recurse, so the self-rename never runs on a ref
                // invalidated by a child LoadFamily. `path` is the DFS ancestor set (cycle guard) — NOT a
                // global visited set: a non-shared nested family has its own copy per parent, each of which
                // must be renamed, so we deliberately re-descend shared names under different parents.
                bool RenameInDoc(Document hostDoc, string hostName, int depth, HashSet<string> path)
                {
                    if (depth > maxDepth) return false;
                    bool changed = false;
                    var nested = new FilteredElementCollector(hostDoc).OfClass(typeof(Family)).Cast<Family>()
                        .Where(f => f.IsValidObject && !string.IsNullOrWhiteSpace(f.Name)
                                    && !f.Name.Equals(hostName, StringComparison.OrdinalIgnoreCase)).ToList();
                    foreach (var nf in nested)
                    {
                        string nfName = nf.Name;
                        // 1. rename nf itself if flagged
                        if (renameMap.TryGetValue(nfName.ToLowerInvariant(), out var newName)
                            && !newName.Equals(nfName, StringComparison.Ordinal))
                        {
                            var info = new Dictionary<string, object?>
                            { ["parent"] = hostName, ["old"] = nfName, ["new"] = newName, ["depth"] = depth };
                            if (dryRun) { info["action"] = "would_rename"; wouldRename++; results.Add(info); }
                            else
                            {
                                try
                                {
                                    using var t = new Transaction(hostDoc, "NLRS rename nested family");
                                    t.Start(); nf.Name = newName; t.Commit();   // collision -> throws, caught
                                    info["action"] = "renamed"; renamed++; changed = true; nfName = newName;
                                }
                                catch (Exception ex) { info["action"] = "failed"; info["error"] = ex.Message; failed++; }
                                results.Add(info);
                            }
                        }
                        // 2. recurse into nf's descendants (cycle-guarded), load the modified child back up
                        if (depth < maxDepth && nf.IsEditable && !nf.IsInPlace
                            && path.Add(nfName.ToLowerInvariant()))
                        {
                            Document? nfDoc = null;
                            try
                            {
                                nfDoc = hostDoc.EditFamily(nf);
                                if (RenameInDoc(nfDoc, nfName, depth + 1, path) && !dryRun)
                                { nfDoc.LoadFamily(hostDoc, new FamLoadOpts()); changed = true; }
                                nfDoc.Close(false);
                            }
                            catch (Exception ex)
                            {
                                failed++;
                                results.Add(new Dictionary<string, object?>
                                { ["parent"] = hostName, ["family"] = nfName, ["depth"] = depth + 1,
                                  ["action"] = "error", ["error"] = ex.Message });
                                try { nfDoc?.Close(false); } catch { }
                            }
                            path.Remove(nfName.ToLowerInvariant());
                        }
                    }
                    return changed;
                }

                foreach (var parent in parents)
                {
                    MainThreadDispatcher.Log($"rename_nested_families: editing root '{parent.Name}'");
                    swallow.Context = parent.Name;
                    Document? fdoc = null;
                    try
                    {
                        fdoc = doc.EditFamily(parent);
                        var path = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                        { parent.Name.ToLowerInvariant() };
                        bool changed = RenameInDoc(fdoc, parent.Name, 1, path);
                        if (changed && !dryRun) { fdoc.LoadFamily(doc, new FamLoadOpts()); parentsChanged++; }
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        failed++;
                        results.Add(new Dictionary<string, object?>
                        { ["parent"] = parent.Name, ["action"] = "error", ["error"] = ex.Message });
                        try { fdoc?.Close(false); } catch { }
                    }
                }

                bool saved = false;
                if (!dryRun && save && parentsChanged > 0)
                {
                    try { doc.Save(); saved = true; }
                    catch (Exception ex) { return (object)Fail($"renames applied in-memory but project Save failed: {ex.Message}"); }
                }

                var outDict = new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved"] = saved,
                    ["parents_processed"] = parents.Count, ["parents_changed"] = parentsChanged,
                    ["renamed"] = renamed, ["would_rename"] = wouldRename, ["failed"] = failed,
                    ["results"] = results,
                };
                swallow.WriteTo(outDict);
                return (object)outDict;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── helpers ──────────────────────────────────────────────────────
    private static Dictionary<string, string> GetRenameMap(Dictionary<string, JsonElement>? p)
    {
        var map = new Dictionary<string, string>();
        if (p != null && p.TryGetValue("renames", out var el) && el.ValueKind == JsonValueKind.Array)
            foreach (var r in el.EnumerateArray())
            {
                if (r.ValueKind != JsonValueKind.Object) continue;
                string? o = r.TryGetProperty("old", out var oe) && oe.ValueKind == JsonValueKind.String ? oe.GetString() : null;
                string? n = r.TryGetProperty("new", out var ne) && ne.ValueKind == JsonValueKind.String ? ne.GetString() : null;
                if (!string.IsNullOrWhiteSpace(o) && !string.IsNullOrWhiteSpace(n))
                    map[o!.Trim().ToLowerInvariant()] = n!.Trim();
            }
        return map;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number
            && el.TryGetInt32(out var v)) return v;
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                     .Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        return null;
    }
}
