using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// assign_view_filter — add a ParameterFilterElement to views + set its visibility and
/// (optionally) its override graphics. Fill patterns in the overrides are referenced BY NAME and resolved
/// against the target doc, so this consumes the FillPatterns merge name-map.
///
/// params:
///   target_document : string (required)
///   assignments : [{ view_name | view_id, filter_name, visible?, overrides?:{
///       surface_fg_pattern, surface_bg_pattern, cut_fg_pattern, cut_bg_pattern,   // FillPatternElement names
///       surface_fg_color, cut_fg_color, line_color,                               // "RRGGBB"
///       line_weight, halftone, surface_transparency (0-100) } }]
///   dry_run : bool (default true) · save_first : bool (default false)
/// </summary>
public static class ViewFilterHandlers
{
    public static CommandResponse AssignViewFilter(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool saveFirst = HandlerUtil.Bool(p, "save_first", false);
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };
        var items = HandlerUtil.Arr(p, "assignments");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target) ?? throw new Exception($"target_document '{target}' is not open");
                var filtersByName = new FilteredElementCollector(doc).OfClass(typeof(ParameterFilterElement))
                    .Cast<ParameterFilterElement>().GroupBy(f => f.Name).ToDictionary(g => g.Key, g => g.First().Id);

                var results = new List<Dictionary<string, object?>>();
                int applied = 0;
                string? saved = null;

                void Apply(bool commit)
                {
                    foreach (var a in items)
                    {
                        string? fname = HandlerUtil.Str(a, "filter_name");
                        var view = HandlerUtil.FindView(doc, HandlerUtil.Str(a, "view_id"), HandlerUtil.Str(a, "view_name"));
                        // ook VIEW TEMPLATES op naam vinden: filter-visibility hoort
                        // vaak juist op de template te wijzigen — FindView slaat templates over
                        if (view == null && HandlerUtil.Str(a, "view_name") is { } vn0)
                            view = new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
                                .FirstOrDefault(v0 => v0.IsTemplate
                                    && v0.Name.Equals(vn0, StringComparison.OrdinalIgnoreCase));
                        string vlabel = HandlerUtil.Str(a, "view_name") ?? HandlerUtil.Str(a, "view_id") ?? "(view?)";
                        if (view == null) { results.Add(Row(vlabel, fname, "skipped", "view niet gevonden")); continue; }
                        if (fname == null || !filtersByName.TryGetValue(fname, out var fid))
                        { results.Add(Row(vlabel, fname, "skipped", "filter niet gevonden in target")); continue; }

                        if (!commit) { results.Add(Row(view.Name, fname, "would_assign", null)); continue; }
                        try
                        {
                            if (!view.GetFilters().Contains(fid)) view.AddFilter(fid);
                            var vis = HandlerUtil.Bool(a, "visible");
                            if (vis.HasValue) view.SetFilterVisibility(fid, vis.Value);
                            if (a.TryGetProperty("overrides", out var ov) && ov.ValueKind == JsonValueKind.Object)
                                view.SetFilterOverrides(fid, BuildOverrides(doc, ov));
                            applied++;
                            results.Add(Row(view.Name, fname, "assigned", null));
                        }
                        catch (Exception ex) { results.Add(Row(view.Name, fname, "error", ex.Message)); }
                    }
                }

                if (dryRun) { Apply(false); }
                else
                {
                    if (saveFirst) { try { doc.Save(); saved = doc.Title; } catch (Exception ex) { throw new Exception($"save_first failed: {ex.Message}"); } }
                    using var t = new Transaction(doc, "assign view filters");
                    t.Start(); Apply(true); t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun, ["target_document"] = doc.Title, ["saved_document"] = saved,
                    ["assigned"] = applied, ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static OverrideGraphicSettings BuildOverrides(Document doc, JsonElement ov)
    {
        var ogs = new OverrideGraphicSettings();
        void Pat(string key, Action<ElementId> setId)
        {
            var n = HandlerUtil.Str(ov, key);
            if (n != null) { var id = HandlerUtil.FillPatternIdByName(doc, n); if (id != ElementId.InvalidElementId) setId(id); }
        }
        Pat("surface_fg_pattern", id => ogs.SetSurfaceForegroundPatternId(id));
        Pat("surface_bg_pattern", id => ogs.SetSurfaceBackgroundPatternId(id));
        Pat("cut_fg_pattern", id => ogs.SetCutForegroundPatternId(id));
        Pat("cut_bg_pattern", id => ogs.SetCutBackgroundPatternId(id));
        if (HandlerUtil.Colour(ov, "surface_fg_color") is Color sc) ogs.SetSurfaceForegroundPatternColor(sc);
        if (HandlerUtil.Colour(ov, "cut_fg_color") is Color cc) ogs.SetCutForegroundPatternColor(cc);
        if (HandlerUtil.Colour(ov, "line_color") is Color lc) ogs.SetProjectionLineColor(lc);
        if (HandlerUtil.Int(ov, "line_weight") is int lw && lw >= 1 && lw <= 16) ogs.SetProjectionLineWeight(lw);
        if (HandlerUtil.Bool(ov, "halftone") is bool ht) ogs.SetHalftone(ht);
        // surface_transparency: 0-100. Zonder dit veld verdween bij een
        // kleurwijziging de transparantie van het filter en dekte de vulling de inhoud van de box af.
        if (HandlerUtil.Int(ov, "surface_transparency") is int tr && tr >= 0 && tr <= 100) ogs.SetSurfaceTransparency(tr);
        return ogs;
    }

    private static Dictionary<string, object?> Row(string view, string? filter, string status, string? reason)
        => new() { ["view"] = view, ["filter"] = filter, ["status"] = status, ["reason"] = reason };
}
