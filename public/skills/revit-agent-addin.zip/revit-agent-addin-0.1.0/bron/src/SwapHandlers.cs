using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// swap_parameter — replace a (wrong/legacy) parameter by a canonical NLRS shared parameter while
/// preserving values. PROJECT-parameter path first; family-parameter swap
/// (EditFamily + formula/geometry coupling) is an explicit follow-up (spec).
///
/// Steps (project-level), per the design:
///   1. resolve target = an NLRS SharedParameterElement already in the doc (by GUID) → its definition.
///   2. resolve source = a shared param (by GUID) or a built-in (by BuiltInParameter name).
///   3. bind target to the SAME categories + instance/type as the source (group from target's def).
///   4. copy value source→target per element (only when storage types match).
///   5. delete the source — only if it's a shared/project param; a built-in cannot be deleted.
///
/// params:
///   source_guid       : string   shared-param source (GUID)            ┐ exactly one
///   source_builtin    : string   built-in source (BuiltInParameter)    ┘ of these
///   target_guid       : string   canonical NLRS shared param (must already exist in the doc)
///   categories        : [string] optional override of category UI-names (required for a built-in
///                                 source, since built-ins have no ParameterBindings entry)
///   target_document   : string   scope by doc Title
///   dry_run           : bool      default TRUE (destructive op — opt in to the write)
/// </summary>
public static class SwapHandlers
{
    public static CommandResponse SwapParameter(CommandRequest request)
    {
        var p = request.Params;
        string? sourceGuid = GetString(p, "source_guid");
        string? sourceBuiltin = GetString(p, "source_builtin");
        string? targetGuid = GetString(p, "target_guid");
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);   // safe default: report, don't mutate
        var catOverride = GetStringList(p, "categories");
        string? sharedParamFile = GetString(p, "shared_param_file");  // NLRS .txt — used when target not in doc

        if (string.IsNullOrWhiteSpace(targetGuid))
            return Err("target_guid is required (canonical NLRS shared parameter GUID, must exist in the doc)");
        if (string.IsNullOrWhiteSpace(sourceGuid) && string.IsNullOrWhiteSpace(sourceBuiltin))
            return Err("provide either source_guid (shared) or source_builtin (BuiltInParameter name)");
        // source_guid == target_guid would resolve both to the same SharedParameterElement — step 5
        // would then delete the very definition step 1 just bound as the target. No-op instead of
        // silently destroying the parameter (found via code review, never
        // exercised live because of its destructiveness).
        if (!string.IsNullOrWhiteSpace(sourceGuid) &&
            string.Equals(sourceGuid.Trim(), targetGuid.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            return new CommandResponse
            {
                Success = true,
                Data = new Dictionary<string, object?>
                {
                    ["status"] = "skipped",
                    ["reason"] = "source_guid and target_guid are identical — swap would delete the shared parameter it just bound as target",
                    ["source_guid"] = sourceGuid,
                    ["target_guid"] = targetGuid,
                }
            };
        }

        BuiltInParameter bip = BuiltInParameter.INVALID;
        if (!string.IsNullOrWhiteSpace(sourceBuiltin) &&
            !Enum.TryParse(sourceBuiltin, out bip))
            return Err($"source_builtin '{sourceBuiltin}' is not a valid BuiltInParameter name");
        bool builtinSource = !string.IsNullOrWhiteSpace(sourceBuiltin);

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");

                string? prevSpf = null; bool spfSet = false;
                try
                {
                // ── 1. target: an NLRS SharedParameterElement already in the doc, else imported from
                //    the shared-parameter file (OpenSharedParameterFile -> ExternalDefinition by GUID). ──
                var targetSp = FindSharedParam(doc, targetGuid!);
                string targetName;
                Definition? targetDef = targetSp?.GetDefinition();
                bool targetFromFile = false;
                if (targetDef != null)
                {
                    targetName = targetSp!.Name;
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(sharedParamFile))
                        return (object)Fail($"target GUID {targetGuid} is not in {doc.Title}; pass 'shared_param_file' (NLRS .txt) to import it");
                    if (!System.IO.File.Exists(sharedParamFile))
                        return (object)Fail($"shared_param_file not found: {sharedParamFile}");
                    prevSpf = app.Application.SharedParametersFilename;
                    app.Application.SharedParametersFilename = sharedParamFile;
                    spfSet = true;
                    var extDef = FindExternalDefinition(app.Application, targetGuid!);
                    if (extDef == null)
                        return (object)Fail($"target GUID {targetGuid} not found in shared_param_file {System.IO.Path.GetFileName(sharedParamFile)}");
                    targetDef = extDef;
                    targetName = extDef.Name;
                    targetFromFile = true;
                }
                var targetSpec = SafeSpec(targetDef);

                // ── 2. source: definition/binding (shared) or builtin spec ──
                SharedParameterElement? sourceSp = null;
                InternalDefinition? sourceDef = null;
                Binding? sourceBinding = null;
                string? sourceName;
                string? sourceSpec = null;
                bool sourceIsInstance = true;
                var srcCategories = new List<Category>();

                if (builtinSource)
                {
                    sourceName = bip.ToString();
                    if (catOverride == null || catOverride.Count == 0)
                        return (object)Fail("a built-in source needs an explicit 'categories' list (built-ins have no ParameterBindings entry)");
                    foreach (var cn in catOverride)
                    {
                        var cat = FindCategory(doc, cn);
                        if (cat != null) srcCategories.Add(cat);
                    }
                }
                else
                {
                    sourceSp = FindSharedParam(doc, sourceGuid!);
                    if (sourceSp == null)
                        return (object)Fail($"source GUID {sourceGuid} not found as a SharedParameterElement in {doc.Title}");
                    sourceName = sourceSp.Name;
                    sourceDef = sourceSp.GetDefinition();
                    sourceSpec = SafeSpec(sourceDef);
                    if (sourceDef != null)
                    {
                        sourceBinding = doc.ParameterBindings.get_Item(sourceDef);
                        if (sourceBinding is InstanceBinding) sourceIsInstance = true;
                        else if (sourceBinding is TypeBinding) sourceIsInstance = false;
                        if (sourceBinding is ElementBinding eb)
                            foreach (Category c in eb.Categories) if (c != null) srcCategories.Add(c);
                    }
                    if (catOverride != null && catOverride.Count > 0)
                    {
                        srcCategories.Clear();
                        foreach (var cn in catOverride)
                        {
                            var cat = FindCategory(doc, cn);
                            if (cat != null) srcCategories.Add(cat);
                        }
                    }
                }

                if (srcCategories.Count == 0)
                    return (object)Fail("could not determine any categories to bind/copy (source not project-bound? pass 'categories')");

                // storage-type compatibility (string/double/int/elementid) — derived from the specs.
                bool specMatch = sourceSpec != null && sourceSpec == targetSpec;

                var report = new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["source"] = new Dictionary<string, object?>
                    {
                        ["name"] = sourceName, ["guid"] = sourceGuid, ["builtin"] = builtinSource ? sourceBuiltin : null,
                        ["spec"] = sourceSpec, ["binding"] = sourceIsInstance ? "instance" : "type",
                    },
                    ["target"] = new Dictionary<string, object?>
                    {
                        ["name"] = targetName, ["guid"] = targetGuid, ["spec"] = targetSpec,
                        ["from_file"] = targetFromFile,
                    },
                    ["categories"] = srcCategories.Select(c => c.Name).OrderBy(n => n).ToList(),
                    ["spec_match"] = specMatch,
                };

                // ── plan the value-copy: which elements carry a source value ──
                bool isInstance = sourceIsInstance;
                var elems = CollectBound(doc, srcCategories, isInstance);
                int withValue = 0, copyable = 0;
                foreach (var e in elems)
                {
                    var sp = builtinSource ? e.get_Parameter(bip)
                                           : e.get_Parameter(System.Guid.Parse(sourceGuid!));
                    if (sp == null || !HasValue(sp)) continue;
                    withValue++;
                    var tp = e.get_Parameter(System.Guid.Parse(targetGuid!));
                    // target param only exists on the element once bound; in dry-run it may be null.
                    if (specMatch) copyable++;
                }
                report["elements_in_categories"] = elems.Count;
                report["elements_with_source_value"] = withValue;
                report["source_deletable"] = !builtinSource;  // built-ins cannot be deleted

                if (dryRun)
                {
                    report["planned"] = new Dictionary<string, object?>
                    {
                        ["bind_target"] = !IsBound(doc, targetDef),
                        ["copy_values"] = specMatch ? withValue : 0,
                        ["copy_blocked_reason"] = specMatch ? null : $"storage/spec mismatch (source {sourceSpec} != target {targetSpec})",
                        ["delete_source"] = !builtinSource,
                    };
                    return (object)report;
                }

                // ── EXECUTE (single transaction) ──
                if (!specMatch)
                    return (object)Fail($"refusing to swap: spec mismatch (source {sourceSpec} != target {targetSpec}); value-copy would be unsafe");

                // save-first backup gate (mirrors rename/delete): Revit writes a numbered backup before
                // any mutation, so a bad swap is recoverable (the workflow relies on this).
                bool saveFirst = GetBool(p, "save_first", false);
                if (saveFirst)
                {
                    try { doc.Save(); report["saved_backup"] = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, swap aborted: {ex.Message}"); }
                }

                using (var t = new Transaction(doc, $"NLRS swap {sourceName} -> {targetName}"))
                {
                    t.Start();
                    // 3. bind target to the same categories + instance/type, group from its own def.
                    //    Already bound (e.g. IfcName bound twice, from two shared parameter files): extend
                    //    the target's categories with the source's, so no source value lands on an element
                    //    without the target parameter.
                    if (IsBound(doc, targetDef) && doc.ParameterBindings.get_Item(targetDef) is ElementBinding tb)
                    {
                        var catSet = doc.Application.Create.NewCategorySet();
                        var namen = new HashSet<string>();
                        foreach (Category c in tb.Categories) if (c != null) { catSet.Insert(c); namen.Add(c.Name); }
                        var extra = srcCategories.Where(c => !namen.Contains(c.Name)).ToList();
                        foreach (var c in extra) catSet.Insert(c);
                        if (extra.Count > 0)
                        {
                            Binding nb = tb is InstanceBinding ? doc.Application.Create.NewInstanceBinding(catSet)
                                                               : doc.Application.Create.NewTypeBinding(catSet);
                            bool okx = doc.ParameterBindings.ReInsert(targetDef, nb, targetDef.GetGroupTypeId());
                            report["target_categories_added"] = extra.Select(c => c.Name).OrderBy(n => n).ToList();
                            if (!okx) { t.RollBack(); return (object)Fail("ParameterBindings.ReInsert failed while extending target categories"); }
                        }
                    }
                    else if (!IsBound(doc, targetDef))
                    {
                        var catSet = doc.Application.Create.NewCategorySet();
                        foreach (var c in srcCategories) catSet.Insert(c);
                        Binding newBinding = isInstance
                            ? doc.Application.Create.NewInstanceBinding(catSet)
                            : doc.Application.Create.NewTypeBinding(catSet);
                        var grp = targetDef.GetGroupTypeId();
                        bool ok = doc.ParameterBindings.Insert(targetDef, newBinding, grp)
                               || doc.ParameterBindings.ReInsert(targetDef, newBinding, grp);
                        report["bound_target"] = ok;
                        if (!ok) { t.RollBack(); return (object)Fail("ParameterBindings.Insert/ReInsert failed for target"); }
                    }

                    // 4. copy values source -> target per element.
                    int copied = 0, skipped = 0, keptTarget = 0;
                    var conflicts = new List<object>();
                    foreach (var e in CollectBound(doc, srcCategories, isInstance))
                    {
                        var sp = builtinSource ? e.get_Parameter(bip)
                                               : e.get_Parameter(System.Guid.Parse(sourceGuid!));
                        var tp = e.get_Parameter(System.Guid.Parse(targetGuid!));
                        if (sp == null || tp == null || tp.IsReadOnly || !HasValue(sp)) { skipped++; continue; }
                        // target had its own value already (it was bound before): keep it, report a difference
                        if (HasValue(tp))
                        {
                            keptTarget++;
                            string? sv = sp.AsValueString() ?? sp.AsString(), tv = tp.AsValueString() ?? tp.AsString();
                            if (sv != tv && conflicts.Count < 50) conflicts.Add(new { element_id = e.Id.Value, source = sv, target = tv });
                            continue;
                        }
                        if (CopyValue(sp, tp)) copied++; else skipped++;
                    }
                    report["values_copied"] = copied;
                    report["values_skipped"] = skipped;
                    report["values_kept_target"] = keptTarget;
                    report["value_conflicts"] = conflicts;

                    // 5. delete the source (shared only — a built-in cannot be removed).
                    if (!builtinSource && sourceSp != null)
                    {
                        try { doc.Delete(sourceSp.Id); report["source_deleted"] = true; }
                        catch (Exception ex) { report["source_deleted"] = false; report["source_delete_error"] = ex.Message; }
                    }
                    else report["source_deleted"] = false;

                    t.Commit();
                }
                report["saved"] = false;  // caller decides when to Save (no implicit save here)
                return (object)report;
                }
                finally
                {
                    // restore the user's shared-parameter file setting (we may have repointed it for import)
                    if (spfSet) try { app.Application.SharedParametersFilename = prevSpf; } catch { }
                }
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── helpers ──────────────────────────────────────────────────────

    private static SharedParameterElement? FindSharedParam(Document doc, string guid)
    {
        var g = guid.Trim().ToLowerInvariant();
        foreach (var sp in new FilteredElementCollector(doc)
                     .OfClass(typeof(SharedParameterElement))
                     .Cast<SharedParameterElement>()
                     .Where(e => e.IsValidObject))
        {
            try { if (sp.GuidValue.ToString().ToLowerInvariant() == g) return sp; } catch { }
        }
        return null;
    }

    /// <summary>Find an ExternalDefinition by GUID in the currently-open shared-parameter file
    /// (caller must have set Application.SharedParametersFilename first).</summary>
    private static ExternalDefinition? FindExternalDefinition(Autodesk.Revit.ApplicationServices.Application app, string guid)
    {
        var g = guid.Trim().ToLowerInvariant();
        DefinitionFile? df;
        try { df = app.OpenSharedParameterFile(); } catch { return null; }
        if (df == null) return null;
        foreach (DefinitionGroup grp in df.Groups)
            foreach (Definition d in grp.Definitions)
                if (d is ExternalDefinition ed)
                {
                    try { if (ed.GUID.ToString().ToLowerInvariant() == g) return ed; } catch { }
                }
        return null;
    }

    private static Category? FindCategory(Document doc, string nameOrBic)
    {
        foreach (Category c in doc.Settings.Categories)
        {
            if (c.Name.Equals(nameOrBic, StringComparison.OrdinalIgnoreCase)) return c;
            try { if (((BuiltInCategory)c.Id.Value).ToString().Equals(nameOrBic, StringComparison.OrdinalIgnoreCase)) return c; } catch { }
        }
        return null;
    }

    private static bool IsBound(Document doc, Definition def)
    {
        try { return doc.ParameterBindings.get_Item(def) != null; } catch { return false; }
    }

    private static string? SafeSpec(Definition? def)
    {
        try { return def?.GetDataType()?.TypeId; } catch { return null; }
    }

    private static List<Element> CollectBound(Document doc, List<Category> cats, bool instance)
    {
        var ids = new List<ElementId>(cats.Select(c => c.Id));
        if (ids.Count == 0) return new List<Element>();
        var filter = new ElementMulticategoryFilter(ids);
        var col = new FilteredElementCollector(doc).WherePasses(filter);
        col = instance ? col.WhereElementIsNotElementType() : col.WhereElementIsElementType();
        return col.Where(e => e != null && e.IsValidObject).ToList();
    }

    private static bool HasValue(Parameter p)
    {
        try
        {
            switch (p.StorageType)
            {
                case StorageType.String: return !string.IsNullOrEmpty(p.AsString());
                case StorageType.Integer: return p.HasValue;
                case StorageType.Double: return p.HasValue;
                case StorageType.ElementId: return p.AsElementId() != null && p.AsElementId().Value > 0;
                default: return false;
            }
        }
        catch { return false; }
    }

    private static bool CopyValue(Parameter src, Parameter dst)
    {
        try
        {
            if (src.StorageType != dst.StorageType) return false;
            switch (src.StorageType)
            {
                case StorageType.String: return dst.Set(src.AsString() ?? "");
                case StorageType.Integer: return dst.Set(src.AsInteger());
                case StorageType.Double: return dst.Set(src.AsDouble());
                case StorageType.ElementId: return dst.Set(src.AsElementId());
                default: return false;
            }
        }
        catch { return false; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };

    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                     .Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        return null;
    }
}
