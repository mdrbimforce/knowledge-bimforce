// Pattern F: project-level definitions. Heterogeneous — not a uniform FEC.OfClass set.
//   shared_parameter      → FEC.OfClass(SharedParameterElement)        (clean)
//   project_information    → FEC.OfClass(ProjectInfo) (singleton)      (clean)
//   project_parameter      → Document.ParameterBindings (BindingMap)   (query-only, element_id=null)
//   classification_system  → virtual (NL-SfB / assembly codes)         (NOT collectable — validator-layer)
//
// Bulk fan-out, with the same contract as the other patterns.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public static class PatternF_Handlers
{
    private static string Owner(Document doc) => BasePatternHandlers.ResolveOwner(doc);

    private static Dictionary<string, object?> NullIdStub(string revitClass, string name, string owner) => new()
    {
        ["element_id"] = null,
        ["revit_class"] = revitClass,
        ["builtin_category"] = null,
        ["name"] = name,
        ["parent_id"] = null,
        ["document_owner"] = owner,
        ["pattern"] = "F"
    };

    // ── project_parameter: bindings have no ElementId — element_id is null ─────

    private static List<Dictionary<string, object?>> QueryProjectParameters(Document doc, string owner)
    {
        var list = new List<Dictionary<string, object?>>();
        var map = doc.ParameterBindings;
        var it = map.ForwardIterator();
        it.Reset();
        while (it.MoveNext())
        {
            var def = it.Key;
            if (def == null) continue;
            list.Add(NullIdStub("ParameterBinding", def.Name, owner));
        }
        return list;
    }

    // ── shared_parameter: stub + guid (Revit identifies shared params by GUID, not name; a name
    //    can recur with different GUIDs). Conformance is a lookup against the canonical
    //    NlrsSharedParameter list by GUID, so the guid must travel in the query stub. ──────────

    private static List<Dictionary<string, object?>> QuerySharedParameters(Document doc, string owner)
    {
        var list = new List<Dictionary<string, object?>>();
        foreach (var sp in new FilteredElementCollector(doc)
                     .OfClass(typeof(SharedParameterElement))
                     .Cast<SharedParameterElement>()
                     .Where(e => e.IsValidObject))
        {
            var stub = BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(sp.Id), "SharedParameterElement", null, sp.Name, null, owner, "F");
            try { stub["guid"] = sp.GuidValue.ToString(); } catch { stub["guid"] = null; }
            list.Add(stub);
        }
        return list;
    }

    // ── Query dispatch ────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> Query(string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        var owner = Owner(doc);
        return typeId switch
        {
            "shared_parameter"      => QuerySharedParameters(doc, owner),
            "project_information"   => BasePatternHandlers.Query<ProjectInfo>(doc, owner, "F"),
            "project_parameter"     => QueryProjectParameters(doc, owner),
            "classification_system" => throw new NotSupportedException(
                "classification_system is virtual (NL-SfB / assembly codes live outside the model). " +
                "It is resolved in the validator-layer, not the collection-layer."),
            _ => throw new ArgumentException($"Unknown Pattern-F type: {typeId}")
        };
    }

    // ── Detail dispatch ───────────────────────────────────────────────

    public static Dictionary<string, object?> Detail(string typeId, Document doc, long elementId)
    {
        var owner = Owner(doc);
        return typeId switch
        {
            "shared_parameter" => BasePatternHandlers.Detail<SharedParameterElement>(
                doc, elementId, owner,
                sp =>
                {
                    var props = BasePatternHandlers.DumpParameters(sp);
                    try { props["guid"] = sp.GuidValue.ToString(); } catch { }
                    return props;
                },
                pattern: "F",
                relationships: null,
                metadata: BasePatternHandlers.MetadataEnvelope(isSystemFamily: false)),

            "project_information" => BasePatternHandlers.Detail<ProjectInfo>(
                doc, elementId, owner,
                BasePatternHandlers.DumpParameters,
                pattern: "F",
                relationships: null,
                metadata: BasePatternHandlers.MetadataEnvelope(isSystemFamily: false)),

            "project_parameter" => throw new NotSupportedException(
                "project_parameter is query-only: bindings have no ElementId. " +
                "All binding data is returned by query_elements(type_id='project_parameter')."),

            "classification_system" => throw new NotSupportedException(
                "classification_system is virtual — resolved in the validator-layer, not here."),

            _ => throw new NotImplementedException($"Pattern F detail for {typeId} not yet implemented")
        };
    }
}
