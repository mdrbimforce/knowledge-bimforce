using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// relink_type_templates. Copying ViewFamilyTypes across documents drops
/// their DefaultTemplateId (the source template id is meaningless in the target). Since the templates
/// were copied too (by name), we re-establish each type's default template by matching the SOURCE type's
/// template NAME to a target template of the same name.
///
/// params:
///   source_document : string (required) — the project the types came from; read its
///                     ViewFamilyType -> DefaultTemplate name map.
///   target_document : string (required) — where the types now live; set DefaultTemplateId.
///   dry_run         : bool (default true)
///   save_first      : bool (default false)
/// </summary>
public static class ViewTypeHandlers
{
    public static CommandResponse RelinkTypeTemplates(CommandRequest request)
    {
        var p = request.Params;
        string? sourceTitle = GetString(p, "source_document");
        string? targetTitle = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        if (sourceTitle == null || targetTitle == null)
            return new CommandResponse { Success = false, Error = "Parameters 'source_document' and 'target_document' are required" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? src = null, tgt = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == sourceTitle) src = d;
                    if (d.Title == targetTitle) tgt = d;
                }
                if (src == null) throw new Exception($"source_document '{sourceTitle}' is not open");
                if (tgt == null) throw new Exception($"target_document '{targetTitle}' is not open");

                // Source: ViewFamilyType name -> its default template's NAME.
                var srcTypeToTemplateName = new Dictionary<string, string>();
                foreach (var vft in new FilteredElementCollector(src).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>())
                {
                    var tid = vft.DefaultTemplateId;
                    if (tid == null || tid == ElementId.InvalidElementId || tid.Value <= 0) continue;
                    if (src.GetElement(tid) is View tpl && tpl.IsTemplate)
                        srcTypeToTemplateName[vft.Name] = tpl.Name;
                }

                // Target: template NAME -> id.
                var tgtTemplateByName = new Dictionary<string, ElementId>();
                foreach (var v in new FilteredElementCollector(tgt).OfClass(typeof(View)).Cast<View>())
                    if (v.IsTemplate) tgtTemplateByName[v.Name] = v.Id;

                var plan = new List<(ViewFamilyType vft, ElementId tplId, string tplName)>();
                var results = new List<Dictionary<string, object?>>();
                foreach (var vft in new FilteredElementCollector(tgt).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>())
                {
                    if (!srcTypeToTemplateName.TryGetValue(vft.Name, out var tplName)) continue;  // no source mapping
                    var row = new Dictionary<string, object?> { ["type"] = vft.Name, ["template"] = tplName };
                    if (!tgtTemplateByName.TryGetValue(tplName, out var tplId))
                    { row["status"] = "skipped"; row["reason"] = "template not found in target"; results.Add(row); continue; }
                    if (vft.DefaultTemplateId == tplId)
                    { row["status"] = "already_linked"; results.Add(row); continue; }
                    if (!vft.IsValidDefaultTemplate(tplId))
                    { row["status"] = "skipped"; row["reason"] = "template not valid for this type"; results.Add(row); continue; }
                    row["status"] = dryRun ? "would_link" : "linked";
                    plan.Add((vft, tplId, tplName));
                    results.Add(row);
                }

                string? saved = null;
                if (!dryRun && plan.Count > 0)
                {
                    if (saveFirst)
                    {
                        try { tgt.Save(); saved = tgt.Title; }
                        catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                    }
                    using var t = new Transaction(tgt, "relink type templates");
                    t.Start();
                    foreach (var (vft, tplId, tplName) in plan)
                    {
                        try { vft.DefaultTemplateId = tplId; }
                        catch (Exception ex)
                        {
                            var row = results.First(r => (string?)r["type"] == vft.Name);
                            row["status"] = "error"; row["error"] = ex.Message;
                        }
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["source_document"] = src.Title,
                    ["target_document"] = tgt.Title,
                    ["saved_document"] = saved,
                    ["source_types_with_template"] = srcTypeToTemplateName.Count,
                    ["target_templates"] = tgtTemplateByName.Count,
                    ["linked"] = results.Count(r => (string?)r["status"] is "would_link" or "linked"),
                    ["already_linked"] = results.Count(r => (string?)r["status"] == "already_linked"),
                    ["skipped"] = results.Count(r => (string?)r["status"] == "skipped"),
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>
    /// assign_view_template — set View.ViewTemplateId on actual (non-template) views, by name. The
    /// view-INSTANCE counterpart of relink_type_templates (which sets a view TYPE's default template).
    /// After a cross-document view copy the copied views lose their ViewTemplateId; this re-establishes it.
    ///
    /// params:
    ///   target_document : string (required)
    ///   mode            : "mirror_from_source" (default) | "explicit"
    ///   source_document : string (required for mirror) — for each target view, the same-named source
    ///                     view's applied ViewTemplate NAME is read, and the target template of that same
    ///                     name is assigned (analogous to relink's name-match).
    ///   assignments     : [{view_name|view_id, template_name}]  (explicit mode)
    ///   view_types      : [string] (optional) — restrict to these ViewType names (e.g. Elevation, Section)
    ///   only_unset      : bool (default true) — only assign where the view currently has NO template
    ///                     (never silently overwrite a template the user already set)
    ///   dry_run         : bool (default true)
    ///   save_first      : bool (default false) — numbered backup before any write
    /// </summary>
    public static CommandResponse AssignViewTemplate(CommandRequest request)
    {
        var p = request.Params;
        string? targetTitle = GetString(p, "target_document");
        string mode = GetString(p, "mode") ?? "mirror_from_source";
        string? sourceTitle = GetString(p, "source_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        bool onlyUnset = GetBool(p, "only_unset", true);
        if (targetTitle == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };

        var viewTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (p != null && p.TryGetValue("view_types", out var vtArr) && vtArr.ValueKind == JsonValueKind.Array)
            foreach (var e in vtArr.EnumerateArray())
                if (e.ValueKind == JsonValueKind.String && e.GetString() is string s) viewTypes.Add(s);

        var explicitAssign = new List<(string? name, int? id, string template)>();
        if (p != null && p.TryGetValue("assignments", out var aArr) && aArr.ValueKind == JsonValueKind.Array)
            foreach (var it in aArr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                if (!it.TryGetProperty("template_name", out var tn) || tn.ValueKind != JsonValueKind.String) continue;
                string? vn = it.TryGetProperty("view_name", out var vnEl) && vnEl.ValueKind == JsonValueKind.String ? vnEl.GetString() : null;
                int? vid = it.TryGetProperty("view_id", out var vidEl) && vidEl.ValueKind == JsonValueKind.Number ? vidEl.GetInt32() : (int?)null;
                explicitAssign.Add((vn, vid, tn.GetString()!));
            }

        bool mirror = mode == "mirror_from_source";
        if (mirror && sourceTitle == null)
            return new CommandResponse { Success = false, Error = "mode mirror_from_source requires 'source_document'" };
        if (!mirror && explicitAssign.Count == 0)
            return new CommandResponse { Success = false, Error = "mode explicit requires 'assignments':[{view_name|view_id, template_name}]" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? tgt = null, src = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (d.Title == targetTitle) tgt = d;
                    if (sourceTitle != null && d.Title == sourceTitle) src = d;
                }
                if (tgt == null) throw new Exception($"target_document '{targetTitle}' is not open");
                if (mirror && src == null) throw new Exception($"source_document '{sourceTitle}' is not open");

                var tplByName = new Dictionary<string, ElementId>();
                foreach (var v in new FilteredElementCollector(tgt).OfClass(typeof(View)).Cast<View>())
                    if (v.IsTemplate) tplByName[v.Name] = v.Id;

                var srcViewToTpl = new Dictionary<string, string>();
                if (mirror)
                    foreach (var v in new FilteredElementCollector(src).OfClass(typeof(View)).Cast<View>())
                    {
                        if (v.IsTemplate) continue;
                        var tid = v.ViewTemplateId;
                        if (tid != null && tid != ElementId.InvalidElementId && tid.Value > 0
                            && src!.GetElement(tid) is View tpl)
                            srcViewToTpl[v.Name] = tpl.Name;
                    }

                bool HasTemplate(View v) =>
                    v.ViewTemplateId != null && v.ViewTemplateId != ElementId.InvalidElementId && v.ViewTemplateId.Value > 0;

                var plan = new List<(View view, ElementId tplId, Dictionary<string, object?> row)>();
                var results = new List<Dictionary<string, object?>>();

                if (mirror)
                {
                    foreach (var v in new FilteredElementCollector(tgt).OfClass(typeof(View)).Cast<View>())
                    {
                        if (v.IsTemplate) continue;
                        var vt = v.ViewType.ToString();
                        if (vt is "Internal" or "ProjectBrowser" or "SystemBrowser" or "Undefined") continue;
                        if (viewTypes.Count > 0 && !viewTypes.Contains(vt)) continue;
                        var row = new Dictionary<string, object?>
                        { ["view"] = v.Name, ["view_type"] = vt, ["element_id"] = RevitIdUtil.Fid(v.Id) };
                        if (!srcViewToTpl.TryGetValue(v.Name, out var stplName))
                        { row["status"] = "skipped"; row["reason"] = "no same-named source view with a template"; results.Add(row); continue; }
                        row["template"] = stplName;
                        if (onlyUnset && HasTemplate(v))
                        { row["status"] = "skipped"; row["reason"] = "view already has a template (only_unset)"; results.Add(row); continue; }
                        if (!tplByName.TryGetValue(stplName, out var tplId))
                        { row["status"] = "skipped"; row["reason"] = "source template not found in target"; results.Add(row); continue; }
                        if (v.ViewTemplateId == tplId) { row["status"] = "already"; results.Add(row); continue; }
                        row["status"] = dryRun ? "would_assign" : "assigned";
                        plan.Add((v, tplId, row));
                        results.Add(row);
                    }
                }
                else
                {
                    foreach (var (name, id, tplName) in explicitAssign)
                    {
                        View? v = id.HasValue
                            ? tgt.GetElement(new ElementId((long)id.Value)) as View
                            : new FilteredElementCollector(tgt).OfClass(typeof(View)).Cast<View>()
                                .FirstOrDefault(x => !x.IsTemplate && x.Name == name);
                        var row = new Dictionary<string, object?> { ["view"] = name ?? (object?)id, ["template"] = tplName };
                        if (v == null) { row["status"] = "skipped"; row["reason"] = "view not found"; results.Add(row); continue; }
                        row["element_id"] = RevitIdUtil.Fid(v.Id); row["view_type"] = v.ViewType.ToString();
                        if (!tplByName.TryGetValue(tplName, out var tplId))
                        { row["status"] = "skipped"; row["reason"] = "template not found in target"; results.Add(row); continue; }
                        if (onlyUnset && HasTemplate(v))
                        { row["status"] = "skipped"; row["reason"] = "view already has a template (only_unset)"; results.Add(row); continue; }
                        if (v.ViewTemplateId == tplId) { row["status"] = "already"; results.Add(row); continue; }
                        row["status"] = dryRun ? "would_assign" : "assigned";
                        plan.Add((v, tplId, row));
                        results.Add(row);
                    }
                }

                string? saved = null;
                if (!dryRun && plan.Count > 0)
                {
                    if (saveFirst)
                    {
                        try { tgt.Save(); saved = tgt.Title; }
                        catch (Exception ex) { throw new Exception($"save_first failed (no backup, aborted): {ex.Message}"); }
                    }
                    using var t = new Transaction(tgt, "assign view templates");
                    t.Start();
                    foreach (var (v, tplId, row) in plan)
                    {
                        try { v.ViewTemplateId = tplId; }
                        catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["mode"] = mode,
                    ["target_document"] = tgt.Title,
                    ["source_document"] = src?.Title,
                    ["saved_document"] = saved,
                    ["view_types_filter"] = viewTypes.Count > 0 ? viewTypes.ToList() : null,
                    ["only_unset"] = onlyUnset,
                    ["assigned"] = results.Count(r => (string?)r["status"] is "would_assign" or "assigned"),
                    ["already"] = results.Count(r => (string?)r["status"] == "already"),
                    ["skipped"] = results.Count(r => (string?)r["status"] == "skipped"),
                    ["errors"] = results.Count(r => (string?)r["status"] == "error"),
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>
    /// get_view_structure — read-only report for an Excel export: view templates with the
    /// filters applied to them, view types with their default template, and (the
    /// complete non-template-view enumeration) the ACTUAL views —
    /// plans/elevations/sections/etc. — with the view template applied to each and that view's own
    /// filter set, level, discipline, scale, detail level and whether it sits on a sheet. Doc-scoped
    /// (target_document). include_views=false skips the (potentially large) view enumeration.
    /// </summary>
    public static CommandResponse GetViewStructure(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool includeViews = GetBool(p, "include_views", true);
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var templates = new List<Dictionary<string, object?>>();
                var types = new List<Dictionary<string, object?>>();
                var schemes = new List<Dictionary<string, object?>>();
                var views = new List<Dictionary<string, object?>>();
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;

                    foreach (var v in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>())
                    {
                        if (!v.IsTemplate) continue;
                        var fnames = new List<string?>();
                        try
                        {
                            foreach (var fid in v.GetFilters())
                                fnames.Add(doc.GetElement(fid)?.Name);
                        }
                        catch { }
                        // Extra context columns for the View Templates review tab.
                        // A View Template IS a View (IsTemplate=true), so its own Scale/DetailLevel/etc.
                        // ARE the defaults it hands down; read them the same way as a real view.
                        int? tplScale = null; try { tplScale = v.Scale; } catch { }
                        string? tplDetail = null; try { tplDetail = v.DetailLevel.ToString(); } catch { }
                        // "Does THIS template enforce X on views that use it?" — first use of
                        // GetNonControlledTemplateParameterIds in the addin; to verify live.
                        bool? vgModel = BasePatternHandlers.TemplateEnforces(v, BuiltInParameter.VIS_GRAPHICS_MODEL);
                        bool? vgAnnotation = BasePatternHandlers.TemplateEnforces(v, BuiltInParameter.VIS_GRAPHICS_ANNOTATION);
                        bool? vgImport = BasePatternHandlers.TemplateEnforces(v, BuiltInParameter.VIS_GRAPHICS_IMPORT);
                        bool? vgFilters = BasePatternHandlers.TemplateEnforces(v, BuiltInParameter.VIS_GRAPHICS_FILTERS);
                        bool? modelDisplay = BasePatternHandlers.TemplateEnforces(v, BuiltInParameter.MODEL_GRAPHICS_STYLE);
                        templates.Add(new Dictionary<string, object?>
                        {
                            ["element_id"] = RevitIdUtil.Fid(v.Id),
                            ["name"] = v.Name,
                            ["view_type"] = v.ViewType.ToString(),
                            ["document"] = doc.Title,
                            ["applied_filters"] = fnames.Where(n => n != null).ToList(),
                            ["scale"] = tplScale,
                            ["detail_level"] = tplDetail,
                            ["discipline"] = BasePatternHandlers.SafeParamValue(v, "Discipline"),
                            ["phase_filter"] = BasePatternHandlers.PhaseFilterName(v),
                            ["show_hidden_lines"] = BasePatternHandlers.SafeParamValue(v, "Show Hidden Lines"),
                            ["hoofd_map"] = BasePatternHandlers.SafeParamValue(v, "hoofd_map"),
                            ["sub_map"] = BasePatternHandlers.SafeParamValue(v, "sub_map"),
                            ["vg_model"] = vgModel,
                            ["vg_annotation"] = vgAnnotation,
                            ["vg_import"] = vgImport,
                            ["vg_filters"] = vgFilters,
                            ["model_display"] = modelDisplay
                        });
                    }

                    foreach (var vft in new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType)).Cast<ViewFamilyType>())
                    {
                        string? tpl = null;
                        try
                        {
                            var tid = vft.DefaultTemplateId;
                            if (tid != null && tid != ElementId.InvalidElementId && tid.Value > 0)
                                tpl = doc.GetElement(tid)?.Name;
                        }
                        catch { }
                        types.Add(new Dictionary<string, object?>
                        {
                            ["element_id"] = RevitIdUtil.Fid(vft.Id),
                            ["name"] = vft.Name,
                            ["view_family"] = vft.ViewFamily.ToString(),
                            ["document"] = doc.Title,
                            ["default_template"] = tpl
                        });
                    }

                    // Area schemes defined in this document. An area plan belongs to exactly one scheme;
                    // create_views matches the source plan's scheme by NAME in the target, so this list
                    // tells us whether the target template carries all expected schemes (BVO/NVO/VVO/GO/VG/VR)
                    // or only a subset — the root-cause check for the all-plans-collapse-to-one-scheme bug.
                    try
                    {
                        foreach (var a in new FilteredElementCollector(doc).OfClass(typeof(AreaScheme)).Cast<AreaScheme>())
                            schemes.Add(new Dictionary<string, object?>
                            {
                                ["element_id"] = RevitIdUtil.Fid(a.Id),
                                ["name"] = a.Name,
                                ["document"] = doc.Title
                            });
                    }
                    catch { }

                    if (!includeViews) continue;

                    // Which views are placed on a sheet (for the rename report / cleanup triage).
                    var placedViewIds = new HashSet<long>();
                    try
                    {
                        foreach (Viewport vp in new FilteredElementCollector(doc).OfClass(typeof(Viewport)).Cast<Viewport>())
                            placedViewIds.Add(vp.ViewId.Value);
                    }
                    catch { }

                    foreach (var v in new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>())
                    {
                        if (v.IsTemplate) continue;
                        // Skip Revit's internal/system non-user views; keep every real user view (plans,
                        // elevations, sections, 3D, drafting, legends, schedules, sheets) and tag view_type
                        // so the consumer can filter. This is the full enumeration.
                        var vt = v.ViewType;
                        if (vt is ViewType.Internal or ViewType.ProjectBrowser or ViewType.SystemBrowser or ViewType.Undefined)
                            continue;

                        string? tplName = null;
                        try
                        {
                            var tid = v.ViewTemplateId;
                            if (tid != null && tid != ElementId.InvalidElementId && tid.Value > 0)
                                tplName = doc.GetElement(tid)?.Name;
                        }
                        catch { }

                        var fnames = new List<string?>();
                        try { foreach (var fid in v.GetFilters()) fnames.Add(doc.GetElement(fid)?.Name); }
                        catch { }

                        string? level = null;
                        try { if (v is ViewPlan vp2) level = vp2.GenLevel?.Name; } catch { }
                        // Area plans carry an AreaScheme; expose it so the consumer can verify each plan
                        // landed in its intended scheme (the all-plans-to-VR bug) without name-guessing.
                        string? areaScheme = null;
                        try { if (v is ViewPlan avp && avp.ViewType == ViewType.AreaPlan && avp.AreaScheme != null) areaScheme = avp.AreaScheme.Name; } catch { }
                        string? discipline = null;
                        try { discipline = v.get_Parameter(BuiltInParameter.VIEW_DISCIPLINE)?.AsValueString(); } catch { }
                        int? scale = null;
                        try { scale = v.Scale; } catch { }
                        string? detail = null;
                        try { detail = v.DetailLevel.ToString(); } catch { }
                        // The view's ViewFamilyType NAME (not the ViewType enum) — needed to measure which
                        // view TYPES are actually used (type-usage cleanup) and for the rename report.
                        string? vtypeName = null;
                        try { vtypeName = doc.GetElement(v.GetTypeId())?.Name; } catch { }

                        // Extra context columns for the Views review tab. Crop View /
                        // Annotation Crop are direct properties/builtins (confirmed elsewhere in the addin
                        // — ViewPropertyHandlers.cs / CreateViewHandlers.cs); Section Box only exists on
                        // View3D; the rest go through SafeParamValue (LookupParameter-by-UI-name), which
                        // degrades to null rather than guessing when a name doesn't resolve.
                        bool? cropActive = null; try { cropActive = v.CropBoxActive; } catch { }
                        bool? annotationCrop = null;
                        try { annotationCrop = v.get_Parameter(BuiltInParameter.VIEWER_ANNOTATION_CROP_ACTIVE)?.AsInteger() == 1; } catch { }
                        bool? sectionBox = null;
                        try { if (v is View3D v3d) sectionBox = v3d.IsSectionBoxActive; } catch { }

                        views.Add(new Dictionary<string, object?>
                        {
                            ["element_id"] = RevitIdUtil.Fid(v.Id),
                            ["name"] = v.Name,
                            ["view_type"] = vt.ToString(),
                            ["view_type_name"] = vtypeName,
                            ["document"] = doc.Title,
                            ["view_template"] = tplName,
                            ["applied_filters"] = fnames.Where(n => n != null).ToList(),
                            ["associated_level"] = level,
                            ["area_scheme"] = areaScheme,
                            ["discipline"] = discipline,
                            ["scale"] = scale,
                            ["detail_level"] = detail,
                            ["on_sheet"] = placedViewIds.Contains(v.Id.Value),
                            ["phase"] = BasePatternHandlers.SafeParamValue(v, "Phase"),
                            ["phase_controlled"] = BasePatternHandlers.IsControlledByTemplate(v, "Phase"),
                            ["phase_filter"] = BasePatternHandlers.PhaseFilterName(v),
                            ["phase_filter_controlled"] = BasePatternHandlers.IsControlledByTemplate(v, "Phase Filter"),
                            ["title_on_sheet"] = BasePatternHandlers.SafeParamValue(v, "Title on Sheet"),
                            ["title_on_sheet_controlled"] = BasePatternHandlers.IsControlledByTemplate(v, "Title on Sheet"),
                            ["color_scheme"] = BasePatternHandlers.SafeParamValue(v, "Color Scheme"),
                            ["color_scheme_controlled"] = BasePatternHandlers.IsControlledByTemplate(v, "Color Scheme"),
                            ["crop_view"] = cropActive,
                            ["annotation_crop"] = annotationCrop,
                            ["scope_box"] = BasePatternHandlers.SafeParamValue(v, "Scope Box"),
                            ["scope_box_controlled"] = BasePatternHandlers.IsControlledByTemplate(v, "Scope Box"),
                            ["section_box"] = sectionBox,
                            ["hoofd_map"] = BasePatternHandlers.SafeParamValue(v, "hoofd_map"),
                            ["sub_map"] = BasePatternHandlers.SafeParamValue(v, "sub_map"),
                            // Referencing Sheet/Detail (Identity Data — read-only,
                            // set on a view when it's the target of a callout/section/elevation marker elsewhere)
                            // + the "View to Sheet Positioning" cluster (Saved Position/View Anchor/View Position
                            // X/Y — Revit's per-view memory of where it sat on a sheet). Genuinely new parameter
                            // names in this addin; same graceful SafeParamValue fallback as the rest — null means
                            // "not set/not applicable for this view", not a lookup failure. to verify
                            // against a live document before trusting the output (no prior precedent for these).
                            ["referencing_sheet"] = BasePatternHandlers.SafeParamValue(v, "Referencing Sheet"),
                            ["referencing_detail"] = BasePatternHandlers.SafeParamValue(v, "Referencing Detail"),
                            ["saved_position"] = BasePatternHandlers.SafeParamValue(v, "Saved Position"),
                            ["view_anchor"] = BasePatternHandlers.SafeParamValue(v, "View Anchor"),
                            ["view_position_x"] = BasePatternHandlers.SafeParamValue(v, "View Position X"),
                            ["view_position_y"] = BasePatternHandlers.SafeParamValue(v, "View Position Y")
                        });
                    }
                }
                return (object)new Dictionary<string, object?>
                {
                    ["template_count"] = templates.Count,
                    ["type_count"] = types.Count,
                    ["scheme_count"] = schemes.Count,
                    ["view_count"] = views.Count,
                    ["templates"] = templates,
                    ["types"] = types,
                    ["area_schemes"] = schemes,
                    ["views"] = views
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
