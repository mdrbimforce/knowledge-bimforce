using System.Globalization;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// Materialen lezen, maken en dupliceren.
///
/// get_materials      params: target_document · name_contains (optioneel)
/// create_material    params: target_document · name · material_class · color ("#RRGGBB" of "R,G,B") · transparency (0-100)
///                            · surface_pattern / surface_pattern_color · cut_pattern / cut_pattern_color · dry_run (true)
/// duplicate_material params: target_document · source (bestaande naam) · name (nieuwe naam) · duplicate_assets (false)
///                            · en dezelfde optionele velden als create_material · dry_run (true)
/// Een dry_run doet het echt binnen een transactie en draait die terug: het antwoord laat zien wat er zou komen.
/// </summary>
public static class MaterialHandlers
{
    /// <summary>get_materials: alle materialen. params: target_document · name_contains (optioneel).
    /// Per materiaal: element_id, name, material_class, material_category, color ("R,G,B"), transparency, shininess,
    /// surface_pattern(+_color), cut_pattern(+_color), achtergrondpatronen, appearance/structural/thermal_asset.</summary>
    public static CommandResponse GetMaterials(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");
        var contains = HandlerUtil.Str(p, "name_contains");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)DocumentHandlers.Fail($"target_document '{target}' is niet open");
                var rows = new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>()
                    .Where(m => contains == null || m.Name.IndexOf(contains, StringComparison.OrdinalIgnoreCase) >= 0)
                    .OrderBy(m => m.Name, StringComparer.OrdinalIgnoreCase)
                    .Select(m => Beschrijf(doc, m)).ToList();
                return (object)new Dictionary<string, object?>() { ["document"] = doc.Title, ["count"] = rows.Count, ["materials"] = rows };
            }, timeoutMs: 120000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    /// <summary>create_material: params target_document · name · material_class · color ("#RRGGBB" of "R,G,B")
    /// · transparency (0-100) · surface_pattern / surface_pattern_color · cut_pattern / cut_pattern_color
    /// (patroon = naam van een fill pattern) · dry_run (true).</summary>
    public static CommandResponse CreateMaterial(CommandRequest request) => Maak(request, dupliceer: false);

    /// <summary>duplicate_material: params target_document · source (bestaande naam) · name (nieuwe naam)
    /// · duplicate_assets (false: de kopie deelt de appearance asset met de bron; true: eigen kopie)
    /// · en optioneel dezelfde velden als create_material · dry_run (true).</summary>
    public static CommandResponse DuplicateMaterial(CommandRequest request) => Maak(request, dupliceer: true);

    private static CommandResponse Maak(CommandRequest request, bool dupliceer)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        var name = HandlerUtil.Str(p, "name");
        var source = HandlerUtil.Str(p, "source");
        if (target == null || name == null) return Err("target_document en name zijn verplicht");
        if (dupliceer && source == null) return Err("source (naam van het bestaande materiaal) is verplicht");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool dupAssets = HandlerUtil.Bool(p, "duplicate_assets", false);
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)DocumentHandlers.Fail($"target_document '{target}' is niet open");
                if (HandlerUtil.MaterialByName(doc, name) != null) return (object)DocumentHandlers.Fail($"materiaal '{name}' bestaat al");
                Material? bron = null;
                if (dupliceer)
                {
                    bron = HandlerUtil.MaterialByName(doc, source!);
                    if (bron == null) return (object)DocumentHandlers.Fail($"bronmateriaal '{source}' niet gevonden");
                }
                var notes = new List<string>();
                Dictionary<string, object?> beschrijving;
                List<string> meldingen;
                using (var t = new Transaction(doc, dupliceer ? "Revit Agent: materiaal dupliceren" : "Revit Agent: materiaal maken"))
                {
                    t.Start();
                    var fv = HandlerUtil.ZetFailureVerzamelaar(t);
                    Material m;
                    if (dupliceer)
                    {
                        m = bron!.Duplicate(name);
                        if (dupAssets && m.AppearanceAssetId != ElementId.InvalidElementId
                            && doc.GetElement(m.AppearanceAssetId) is AppearanceAssetElement ae)
                        {
                            var nieuwNaam = UniekeAssetNaam(doc, name);
                            m.AppearanceAssetId = ae.Duplicate(nieuwNaam).Id;
                            notes.Add($"appearance asset gedupliceerd als '{nieuwNaam}'");
                        }
                        else if (m.AppearanceAssetId != ElementId.InvalidElementId)
                            notes.Add("deelt de appearance asset met het bronmateriaal (duplicate_assets: true maakt een eigen kopie)");
                    }
                    else
                    {
                        m = (Material)doc.GetElement(Material.Create(doc, name));
                    }
                    ZetEigenschappen(doc, m, p, notes);
                    doc.Regenerate();
                    beschrijving = Beschrijf(doc, m);
                    meldingen = fv.Meldingen;
                    if (dryRun) t.RollBack();
                    else if (t.Commit() != TransactionStatus.Committed) return (object)DocumentHandlers.Fail("transactie teruggedraaid: " + string.Join("; ", fv.Meldingen));
                }
                if (dryRun) beschrijving["element_id"] = null;
                return (object)new Dictionary<string, object?>()
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["status"] = dryRun ? "zou maken" : "gemaakt",
                    ["material"] = beschrijving, ["notes"] = notes, ["meldingen"] = meldingen,
                };
            }, timeoutMs: 120000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    private static string UniekeAssetNaam(Document doc, string basis)
    {
        var namen = new FilteredElementCollector(doc).OfClass(typeof(AppearanceAssetElement)).Select(e => e.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (!namen.Contains(basis)) return basis;
        for (int i = 2; ; i++) if (!namen.Contains($"{basis} ({i})")) return $"{basis} ({i})";
    }

    private static void ZetEigenschappen(Document doc, Material m, Dictionary<string, JsonElement>? p, List<string> notes)
    {
        var klasse = HandlerUtil.Str(p, "material_class");
        if (klasse != null) m.MaterialClass = klasse;
        var kleur = Kleur(HandlerUtil.Str(p, "color"));
        if (kleur != null) m.Color = kleur;
        else if (HandlerUtil.Str(p, "color") != null) notes.Add("color niet herkend; gebruik #RRGGBB of R,G,B");
        var tr = HandlerUtil.Int(p, "transparency");
        if (tr != null) m.Transparency = Math.Clamp(tr.Value, 0, 100);

        void Patroon(string sleutel, Action<ElementId> zet, string kleurSleutel, Action<Color> zetKleur)
        {
            var naam = HandlerUtil.Str(p, sleutel);
            if (naam != null)
            {
                var id = HandlerUtil.FillPatternIdByName(doc, naam);
                if (id == ElementId.InvalidElementId) notes.Add($"{sleutel}: vulpatroon '{naam}' niet gevonden");
                else zet(id);
            }
            var c = Kleur(HandlerUtil.Str(p, kleurSleutel));
            if (c != null) zetKleur(c);
        }
        Patroon("surface_pattern", id => m.SurfaceForegroundPatternId = id, "surface_pattern_color", c => m.SurfaceForegroundPatternColor = c);
        Patroon("cut_pattern", id => m.CutForegroundPatternId = id, "cut_pattern_color", c => m.CutForegroundPatternColor = c);
    }

    internal static Color? Kleur(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        s = s.Trim();
        if (s.Contains(','))
        {
            var d = s.Split(',').Select(x => x.Trim()).ToArray();
            if (d.Length == 3 && byte.TryParse(d[0], out var r) && byte.TryParse(d[1], out var g) && byte.TryParse(d[2], out var b))
                return new Color(r, g, b);
            return null;
        }
        s = s.TrimStart('#');
        if (s.Length != 6 || !int.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out _)) return null;
        return new Color(byte.Parse(s[..2], NumberStyles.HexNumber), byte.Parse(s.Substring(2, 2), NumberStyles.HexNumber),
                         byte.Parse(s.Substring(4, 2), NumberStyles.HexNumber));
    }

    private static string? Rgb(Color? c)
    {
        try { return c != null && c.IsValid ? $"{c.Red},{c.Green},{c.Blue}" : null; } catch { return null; }
    }

    private static string? Naam(Document doc, ElementId id)
        => id == null || id == ElementId.InvalidElementId ? null : doc.GetElement(id)?.Name;

    internal static Dictionary<string, object?> Beschrijf(Document doc, Material m)
    {
        var d = new Dictionary<string, object?>()
        {
            ["element_id"] = m.Id.Value,
            ["name"] = m.Name,
            ["material_class"] = m.MaterialClass,
            ["material_category"] = m.MaterialCategory,
            ["color"] = Rgb(m.Color),
            ["transparency"] = m.Transparency,
            ["shininess"] = m.Shininess,
        };
        try
        {
            d["surface_pattern"] = Naam(doc, m.SurfaceForegroundPatternId);
            d["surface_pattern_color"] = Rgb(m.SurfaceForegroundPatternColor);
            d["surface_background_pattern"] = Naam(doc, m.SurfaceBackgroundPatternId);
            d["cut_pattern"] = Naam(doc, m.CutForegroundPatternId);
            d["cut_pattern_color"] = Rgb(m.CutForegroundPatternColor);
            d["cut_background_pattern"] = Naam(doc, m.CutBackgroundPatternId);
        }
        catch { }
        d["appearance_asset"] = Naam(doc, m.AppearanceAssetId);
        d["structural_asset"] = Naam(doc, m.StructuralAssetId);
        d["thermal_asset"] = Naam(doc, m.ThermalAssetId);
        try { d["use_render_appearance"] = m.UseRenderAppearanceForShading; } catch { }
        return d;
    }

    private static CommandResponse Ok(object? data) => new() { Success = true, Data = data };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static string Unwrap(Exception ex) => ex.InnerException?.Message ?? ex.Message;
}
