using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_view_property — the
/// `update` verb on views: scale / detail level / discipline / crop / far-clip / phase / phase filter.
/// Each property is set independently and reported per-view; a property a view doesn't support (e.g.
/// scale on a schedule, or phase on a view type that has none) is skipped with a reason, never fatal.
///
/// params:
///   target_document : string (required)
///   edits : [{ view_name | view_id, scale?, detail_level?(coarse|medium|fine),
///              discipline?(architectural|structural|mechanical|electrical|plumbing|coordination),
///              crop_active?, crop_visible?, far_clip_active?, phase?(name), phase_filter?(name) }]
///   dry_run : bool (default true) · save_first : bool (default false)
/// </summary>
public static class ViewPropertyHandlers
{
    public static CommandResponse SetViewProperty(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool saveFirst = HandlerUtil.Bool(p, "save_first", false);
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };
        var edits = HandlerUtil.Arr(p, "edits");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target) ?? throw new Exception($"target_document '{target}' is not open");
                var results = new List<Dictionary<string, object?>>();
                int changed = 0;
                string? saved = null;

                ElementId? FindPhaseId(string name) =>
                    doc.Phases.Cast<Phase>().FirstOrDefault(ph => ph.Name.Equals(name, StringComparison.OrdinalIgnoreCase))?.Id;
                ElementId? FindPhaseFilterId(string name) =>
                    new FilteredElementCollector(doc).OfClass(typeof(PhaseFilter)).Cast<PhaseFilter>()
                        .FirstOrDefault(pf => pf.Name.Equals(name, StringComparison.OrdinalIgnoreCase))?.Id;

                void Apply(bool commit)
                {
                    foreach (var e in edits)
                    {
                        var view = HandlerUtil.FindView(doc, HandlerUtil.Str(e, "view_id"), HandlerUtil.Str(e, "view_name"));
                        string vlabel = HandlerUtil.Str(e, "view_name") ?? HandlerUtil.Str(e, "view_id") ?? "(view?)";
                        if (view == null) { results.Add(new() { ["view"] = vlabel, ["status"] = "skipped", ["reason"] = "view niet gevonden" }); continue; }
                        var done = new List<string>(); var fail = new List<string>();

                        void Try(string label, Action act) { try { if (commit) act(); done.Add(label); } catch (Exception ex) { fail.Add($"{label}: {ex.Message}"); } }

                        if (HandlerUtil.Int(e, "scale") is int sc) Try($"scale={sc}", () => view.Scale = sc);
                        if (HandlerUtil.Str(e, "detail_level") is string dl && ParseDetail(dl) is ViewDetailLevel vdl)
                            Try($"detail={dl}", () => view.DetailLevel = vdl);
                        if (HandlerUtil.Str(e, "discipline") is string di && ParseDiscipline(di) is ViewDiscipline vdi)
                            Try($"discipline={di}", () => view.Discipline = vdi);
                        // transparency (3D Graphic Display Options, bv. 30% zoals op de
                        // sheets): surface transparency van de Graphic Display Options.
                        if (HandlerUtil.Int(e, "transparency") is int tp)
                            Try($"transparency={tp}", () =>
                            {
                                var vdm = view.GetViewDisplayModel()
                                          ?? throw new Exception("graphic display options niet ondersteund voor dit view-type");
                                vdm.Transparency = Math.Clamp(tp, 0, 100);
                                view.SetViewDisplayModel(vdm);
                            });
                        if (HandlerUtil.Bool(e, "crop_active") is bool ca) Try($"crop_active={ca}", () => view.CropBoxActive = ca);
                        if (HandlerUtil.Bool(e, "crop_visible") is bool cv) Try($"crop_visible={cv}", () => view.CropBoxVisible = cv);
                        if (HandlerUtil.Bool(e, "far_clip_active") is bool fc)
                            Try($"far_clip_active={fc}", () =>
                            {
                                var prm = view.get_Parameter(BuiltInParameter.VIEWER_BOUND_ACTIVE_FAR)
                                          ?? throw new Exception("far-clip niet ondersteund");
                                prm.Set(fc ? 1 : 0);
                            });
                        if (HandlerUtil.Str(e, "phase") is string phName)
                            Try($"phase={phName}", () =>
                            {
                                var phId = FindPhaseId(phName) ?? throw new Exception($"phase '{phName}' niet gevonden");
                                var prm = view.get_Parameter(BuiltInParameter.VIEW_PHASE)
                                          ?? throw new Exception("phase niet ondersteund voor dit view-type");
                                prm.Set(phId);
                            });
                        if (HandlerUtil.Str(e, "phase_filter") is string pfName)
                            Try($"phase_filter={pfName}", () =>
                            {
                                var prm = view.get_Parameter(BuiltInParameter.VIEW_PHASE_FILTER)
                                          ?? throw new Exception("phase filter niet ondersteund voor dit view-type");
                                // Wordt de parameter door het view template beheerd, dan is hij op
                                // de view read-only. Alleen DEZE parameter loskoppelen (niet het
                                // hele template) houdt de wijziging bij de views die hem nodig
                                // hebben; andere views met hetzelfde template blijven ongemoeid.
                                if (prm.IsReadOnly && view.ViewTemplateId != ElementId.InvalidElementId)
                                {
                                    var nc = view.GetNonControlledTemplateParameterIds().ToList();
                                    var pid = new ElementId(BuiltInParameter.VIEW_PHASE_FILTER);
                                    if (!nc.Contains(pid))
                                    { nc.Add(pid); view.SetNonControlledTemplateParameterIds(nc); }
                                    prm = view.get_Parameter(BuiltInParameter.VIEW_PHASE_FILTER) ?? prm;
                                }
                                // "none" = géén fase-filtering, zoals veel aanzichten al staan:
                                // een view mét filter verbergt elementen uit een andere fase, en
                                // zit zo'n element in een assembly, dan is zijn fase read-only en
                                // is de view de enige plek waar dit nog te herstellen is.
                                if (pfName.Equals("none", StringComparison.OrdinalIgnoreCase))
                                { prm.Set(ElementId.InvalidElementId); return; }
                                var pfId = FindPhaseFilterId(pfName) ?? throw new Exception($"phase filter '{pfName}' niet gevonden");
                                prm.Set(pfId);
                            });

                        if (commit && done.Count > 0) changed++;
                        results.Add(new()
                        {
                            ["view"] = view.Name,
                            ["status"] = fail.Count > 0 && done.Count == 0 ? "error" : (dryRun ? "would_update" : "updated"),
                            ["applied"] = done, ["failed"] = fail
                        });
                    }
                }

                if (dryRun) Apply(false);
                else
                {
                    if (saveFirst) { try { doc.Save(); saved = doc.Title; } catch (Exception ex) { throw new Exception($"save_first failed: {ex.Message}"); } }
                    using var t = new Transaction(doc, "set view properties");
                    t.Start(); Apply(true); t.Commit();
                }
                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun, ["target_document"] = doc.Title, ["saved_document"] = saved,
                    ["updated"] = changed, ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static ViewDetailLevel? ParseDetail(string s) => s.ToLowerInvariant() switch
    {
        "coarse" => ViewDetailLevel.Coarse,
        "medium" => ViewDetailLevel.Medium,
        "fine" => ViewDetailLevel.Fine,
        _ => null
    };

    private static ViewDiscipline? ParseDiscipline(string s) => s.ToLowerInvariant() switch
    {
        "architectural" => ViewDiscipline.Architectural,
        "structural" => ViewDiscipline.Structural,
        "mechanical" => ViewDiscipline.Mechanical,
        "electrical" => ViewDiscipline.Electrical,
        "plumbing" => ViewDiscipline.Plumbing,
        "coordination" => ViewDiscipline.Coordination,
        _ => null
    };
}
