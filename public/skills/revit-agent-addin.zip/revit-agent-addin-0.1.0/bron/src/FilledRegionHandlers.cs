using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// FilledRegionType read + create. A FilledRegionType has no public constructor — a new
/// one is made by Duplicate off any existing type, then its foreground pattern (by name) + colour +
/// masking are set. Fill patterns are referenced BY NAME (FillPatterns name-map).
///
/// query_filled_region_types params: target_document
/// create_filled_region_type params:
///   target_document : string (required)
///   types : [{ name, fg_pattern?, fg_color?, bg_pattern?, is_masking? }]
///   dry_run : bool (default true) · save_first : bool (default false)
/// </summary>
public static class FilledRegionHandlers
{
    public static CommandResponse QueryFilledRegionTypes(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var types = new List<Dictionary<string, object?>>();
                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;
                    var patName = new Dictionary<long, string>();
                    foreach (var fp in new FilteredElementCollector(doc).OfClass(typeof(FillPatternElement)).Cast<FillPatternElement>())
                        patName[fp.Id.Value] = fp.Name;
                    foreach (var frt in new FilteredElementCollector(doc).OfClass(typeof(FilledRegionType)).Cast<FilledRegionType>())
                    {
                        types.Add(new Dictionary<string, object?>
                        {
                            ["element_id"] = RevitIdUtil.Fid(frt.Id),
                            ["name"] = frt.Name,
                            ["document"] = doc.Title,
                            ["fg_pattern"] = patName.GetValueOrDefault(frt.ForegroundPatternId.Value),
                            ["bg_pattern"] = patName.GetValueOrDefault(frt.BackgroundPatternId.Value),
                            ["fg_color"] = Hex(frt.ForegroundPatternColor),
                            ["is_masking"] = frt.IsMasking
                        });
                    }
                }
                return (object)new Dictionary<string, object?> { ["type_count"] = types.Count, ["filled_region_types"] = types };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    public static CommandResponse CreateFilledRegionType(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool saveFirst = HandlerUtil.Bool(p, "save_first", false);
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };
        var specs = HandlerUtil.Arr(p, "types");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target) ?? throw new Exception($"target_document '{target}' is not open");
                var all = new FilteredElementCollector(doc).OfClass(typeof(FilledRegionType)).Cast<FilledRegionType>().ToList();
                var template = all.FirstOrDefault() ?? throw new Exception("geen bestaande FilledRegionType om te dupliceren");
                var existing = new HashSet<string>(all.Select(t => t.Name), StringComparer.OrdinalIgnoreCase);

                var results = new List<Dictionary<string, object?>>();
                int created = 0;
                string? saved = null;

                void Apply(bool commit)
                {
                    foreach (var s in specs)
                    {
                        string? name = HandlerUtil.Str(s, "name");
                        if (name == null) { results.Add(new() { ["name"] = "(leeg)", ["status"] = "skipped", ["reason"] = "geen naam" }); continue; }
                        if (existing.Contains(name)) { results.Add(new() { ["name"] = name, ["status"] = "skipped", ["reason"] = "bestaat al" }); continue; }
                        string? fgName = HandlerUtil.Str(s, "fg_pattern");
                        var fgId = fgName != null ? HandlerUtil.FillPatternIdByName(doc, fgName) : ElementId.InvalidElementId;
                        if (fgName != null && fgId == ElementId.InvalidElementId)
                        { results.Add(new() { ["name"] = name, ["status"] = "skipped", ["reason"] = $"patroon '{fgName}' niet gevonden" }); continue; }

                        if (!commit) { results.Add(new() { ["name"] = name, ["status"] = "would_create", ["reason"] = null }); continue; }
                        try
                        {
                            var frt = (FilledRegionType)template.Duplicate(name);
                            if (fgId != ElementId.InvalidElementId) frt.ForegroundPatternId = fgId;
                            var bgName = HandlerUtil.Str(s, "bg_pattern");
                            if (bgName != null) { var bg = HandlerUtil.FillPatternIdByName(doc, bgName); if (bg != ElementId.InvalidElementId) frt.BackgroundPatternId = bg; }
                            if (HandlerUtil.Colour(s, "fg_color") is Color c) frt.ForegroundPatternColor = c;
                            if (HandlerUtil.Bool(s, "is_masking") is bool mask) frt.IsMasking = mask;
                            existing.Add(name); created++;
                            results.Add(new() { ["name"] = name, ["status"] = "created", ["element_id"] = RevitIdUtil.Fid(frt.Id) });
                        }
                        catch (Exception ex) { results.Add(new() { ["name"] = name, ["status"] = "error", ["reason"] = ex.Message }); }
                    }
                }

                if (dryRun) Apply(false);
                else
                {
                    if (saveFirst) { try { doc.Save(); saved = doc.Title; } catch (Exception ex) { throw new Exception($"save_first failed: {ex.Message}"); } }
                    using var t = new Transaction(doc, "create filled region types");
                    t.Start(); Apply(true); t.Commit();
                }
                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun, ["target_document"] = doc.Title, ["saved_document"] = saved,
                    ["created"] = created, ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static string? Hex(Color c) => c != null && c.IsValid ? $"{c.Red:X2}{c.Green:X2}{c.Blue:X2}" : null;
}
