using Autodesk.Revit.ApplicationServices;

namespace RevitAgent.Addin;

public static class RevitBridge
{
    public static ControlledApplication? ControlledApp { get; set; }

    public static string GetVersion()
    {
        if (ControlledApp == null) return "unknown";
        return $"{ControlledApp.VersionNumber}.{ControlledApp.SubVersionNumber} ({ControlledApp.VersionBuild})";
    }
}
