using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// rename_family_materials — hernoem Material-elementen BINNEN loadable families (bv. NLRS_n6_kunststof
/// zwart_gen_el -> DU_n6_Kunststoff schwarz_gen_el in de vertaalde bibliotheek). Materialen in een family-document zijn
/// eigen kopieën; een project-rename (rename_element op het Material) raakt de .rfa niet. Per family: EditFamily ->
/// Material.Name = nieuw in een transactie -> LoadFamily terug (overwrite) -> Close(false). Bestaat de nieuwe naam al
/// in het family-doc, dan wordt de rename overgeslagen (name_exists). Combineer met rename_element op de
/// projectmaterialen zodat LoadFamily op naam koppelt en geen dubbele materialen aanmaakt.
///
/// params:
///   target_document : scope op Title
///   families        : [namen] (verplicht)
///   renames         : {oude_naam: nieuwe_naam}  (verplicht; case-insensitief op oude naam)
///   dry_run         : bool (default TRUE)
///   save_first      : bool (default false)
///   dialog_ok / dialog_result : zie DialogSwallowScope
/// </summary>
public static class RenameFamilyMaterialsHandlers
{
    /// <summary>Geneste (bewerkbare) family terug in het host-family-doc laden: eigen versie gebruiken, anders komt de hernoemde materiaalnaam niet mee.</summary>
    private class FamLoadOptsOwn : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Project; overwriteParameterValues = true; return true; }   // Project: FamilySource.Family bracht bij herladen de geneste kopieën als dubbel-typen " 1" binnen en verhing exemplaren
    }

    public static CommandResponse RenameFamilyMaterials(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        bool dialogOk = GetBool(p, "dialog_ok", false);
        bool nested = GetBool(p, "nested", true);   // ook geneste (bewerkbare) families in het family-doc verwerken
        int dialogResult = GetInt(p, "dialog_result", 1);
        var families = GetStringList(p, "families") ?? new List<string>();
        string? rfaPath = GetString(p, "rfa_path");   // rfa-modus: family-doc van schijf bewerken en Save, geen EditFamily/LoadFamily (deurfamilies)
        bool fromDisk = !string.IsNullOrWhiteSpace(rfaPath);
        if (fromDisk && !System.IO.File.Exists(rfaPath)) return Err($"rfa_path bestaat niet: {rfaPath}");
        if (fromDisk && families.Count == 0) families.Add(System.IO.Path.GetFileNameWithoutExtension(rfaPath!));
        var renames = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (p != null && p.TryGetValue("renames", out var rn) && rn.ValueKind == JsonValueKind.Object)
            foreach (var kv in rn.EnumerateObject())
                if (kv.Value.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(kv.Value.GetString())) renames[kv.Name] = kv.Value.GetString()!;
        if (families.Count == 0 || renames.Count == 0) return Err("families:[...] en renames:{oud: nieuw} zijn verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, aborted: {ex.Message}"); }
                }

                var want = families.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                var fams = fromDisk ? new List<Family?> { null } : new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable && want.Contains(f.Name.ToLowerInvariant())).Cast<Family?>().ToList();
                var results = new List<Dictionary<string, object?>>();
                int applied = 0, failed = 0;

                var famNamesLower = fromDisk ? want.ToHashSet() : fams.Select(f => f!.Name.ToLowerInvariant()).ToHashSet();   // vóór LoadFamily vastleggen
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.BlindResult = dialogResult;
                foreach (var fam in fams)
                {
                    string famLabel; try { famLabel = fromDisk ? System.IO.Path.GetFileNameWithoutExtension(rfaPath!) : fam!.Name; } catch { results.Add(new Dictionary<string, object?> { ["family"] = "<ongeldig Family-element>", ["status"] = "error", ["error"] = "Family-element ongeldig (edit-doc open of herladen?)" }); failed++; continue; }
                    swallow.Context = famLabel;
                    Document? fdoc = null;
                    var row = new Dictionary<string, object?> { ["family"] = famLabel };
                    try
                    {
                        MainThreadDispatcher.Log($"rename_family_materials: opening family '{famLabel}'");
                        fdoc = fromDisk ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                        var changes = new List<Dictionary<string, object?>>();
                        int matCount = 0;
                        bool anyOk = ProcessDoc(fdoc, renames, dryRun, nested, 0, changes, ref matCount, ref applied, ref failed);
                        if (!dryRun && anyOk) { if (fromDisk) fdoc.Save(); else fdoc.LoadFamily(doc, new FamLoadOpts()); }
                        fdoc.Close(false);
                        if (fromDisk) row["saved_rfa"] = !dryRun && anyOk;
                        row["materials_in_family"] = matCount; row["changes"] = changes; row["status"] = changes.Count == 0 ? "no_match" : (dryRun ? "dry_run" : "done");
                    }
                    catch (Exception ex)
                    {
                        failed++; row["status"] = "error"; row["error"] = ex.Message;
                        try { fdoc?.Close(false); } catch { }
                    }
                    results.Add(row);
                }
                foreach (var n in want)
                    if (!famNamesLower.Contains(n))
                        results.Add(new Dictionary<string, object?> { ["family"] = n, ["status"] = "family_not_found" });

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup,
                    ["applied"] = applied, ["failed"] = failed, ["notable_dialogs"] = swallow.NotableReport(), ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>Materialen in één family-doc hernoemen; bestaat de doelnaam al -> samenvoegen (geometrie MATERIAL_ID_PARAM en
    /// materiaal-typeparameters omhangen, oude verwijderen). Daarna recursief de geneste bewerkbare families (EditFamily in het
    /// family-doc, terugladen met overschrijven). Geeft true als er iets gewijzigd is.</summary>
    private static bool ProcessDoc(Document fdoc, Dictionary<string, string> renames, bool dryRun, bool nested, int depth,
                                   List<Dictionary<string, object?>> changes, ref int matCount, ref int applied, ref int failed)
    {
        var mats = new FilteredElementCollector(fdoc).OfClass(typeof(Material)).Cast<Material>().ToList();
        matCount += mats.Count;
        var byName = mats.ToDictionary(m => m.Name, m => m, StringComparer.OrdinalIgnoreCase);
        bool anyOk = false;
        string label = depth == 0 ? "" : $"[nested {depth}: {fdoc.Title}] ";
        using (var t = new Transaction(fdoc, "Revit Agent: rename family materials"))
        {
            t.Start();
            foreach (var m in mats)
            {
                if (!renames.TryGetValue(m.Name, out var newName) || newName == m.Name) continue;
                var ch = new Dictionary<string, object?> { ["old"] = label + m.Name, ["new"] = newName };
                if (byName.TryGetValue(newName, out var target) && target.Id != m.Id)
                {
                    if (dryRun) { ch["status"] = "would_merge"; changes.Add(ch); continue; }
                    try
                    {
                        int geo = 0, tv = 0;
                        foreach (var el in new FilteredElementCollector(fdoc).WhereElementIsNotElementType().ToElements())
                        {
                            Parameter? mp = null; try { mp = el.get_Parameter(BuiltInParameter.MATERIAL_ID_PARAM); } catch { }
                            if (mp != null && !mp.IsReadOnly && mp.StorageType == StorageType.ElementId && mp.AsElementId() == m.Id) { try { mp.Set(target.Id); geo++; } catch { } }
                        }
                        var fm = fdoc.FamilyManager;
                        var idParams = fm.GetParameters().Where(fp => fp.StorageType == StorageType.ElementId).ToList();
                        foreach (var tn in fm.Types.Cast<FamilyType>().Select(x => x.Name).ToList())
                            foreach (var fp in idParams)
                            {
                                try
                                {
                                    var ft = fm.Types.Cast<FamilyType>().First(x => x.Name == tn);
                                    if (ft.AsElementId(fp) == m.Id) { fm.CurrentType = ft; fm.Set(fp, target.Id); tv++; }
                                }
                                catch { }
                            }
                        fdoc.Delete(m.Id);
                        ch["status"] = "merged"; ch["geometry"] = geo; ch["type_values"] = tv; anyOk = true; applied++;
                    }
                    catch (Exception ex) { ch["status"] = "error"; ch["error"] = ex.Message; failed++; }
                    changes.Add(ch); continue;
                }
                if (dryRun) { ch["status"] = "would_rename"; changes.Add(ch); continue; }
                try { m.Name = newName; byName[newName] = m; ch["status"] = "renamed"; anyOk = true; applied++; }
                catch (Exception ex) { ch["status"] = "error"; ch["error"] = ex.Message; failed++; }
                changes.Add(ch);
            }
            if (!dryRun && anyOk) t.Commit(); else t.RollBack();
        }
        if (nested && depth < 3)
        {
            foreach (var nf in new FilteredElementCollector(fdoc).OfClass(typeof(Family)).Cast<Family>().Where(f => f.IsEditable).ToList())
            {
                Document? nd = null; string nn; try { nn = nf.Name; } catch { continue; }
                var before = changes.Count;
                try
                {
                    nd = fdoc.EditFamily(nf);
                    bool nOk = ProcessDoc(nd, renames, dryRun, nested, depth + 1, changes, ref matCount, ref applied, ref failed);
                    if (!dryRun && nOk) { nd.LoadFamily(fdoc, new FamLoadOptsOwn()); anyOk = true; }
                }
                catch (Exception ex) { changes.Add(new Dictionary<string, object?> { ["old"] = $"[nested {depth + 1}: {nn}]", ["status"] = "nested_error", ["error"] = ex.Message }); }
                finally { try { nd?.Close(false); } catch { } }
            }
        }
        return anyOk;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) return el.GetString();
        return null;
    }
    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).ToList();
        return null;
    }
}
