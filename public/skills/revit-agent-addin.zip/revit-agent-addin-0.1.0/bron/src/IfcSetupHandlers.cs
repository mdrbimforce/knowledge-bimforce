using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;

namespace RevitAgent.Addin;

/// <summary>
/// get_ifc_export_setups: de IFC-exportsetups die in het model bewaard zijn (alleen lezen).
/// params: target_document · raw (false: met true komen ook alle velden van elke setup mee).
/// De IFC-exporter van Autodesk bewaart zijn setups in extensible storage (DataStorage-elementen) van het model,
/// per setup als sleutel/waarde-lijst of als JSON-tekst. Deze opdracht leest elk schema met "IFC" en "Config" in de naam.
/// Per setup: name, ifc_version, user_pset_file (eigen psetbestand), parameter_mapping_file (mappingtabel),
/// export_user_defined_psets / export_user_defined_parameter_mapping (aan/uit), en de bron (schema).
/// Let op: de vorm verschilt per versie van de IFC-exporter; wat niet herkend wordt, staat onder raw.
/// IfcExportAs per family of type lees je met read_parameter_values (params ["IfcExportAs", "IfcExportType"]).
/// </summary>
public static class IfcSetupHandlers
{
    public static CommandResponse GetIfcExportSetups(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        if (target == null) return new CommandResponse { Success = false, Error = "target_document is verplicht" };
        bool raw = HandlerUtil.Bool(p, "raw", false);
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)DocumentHandlers.Fail($"target_document '{target}' is niet open");
                var schemas = Schema.ListSchemas().Where(s =>
                    s.SchemaName.IndexOf("IFC", StringComparison.OrdinalIgnoreCase) >= 0 &&
                    s.SchemaName.IndexOf("Config", StringComparison.OrdinalIgnoreCase) >= 0).ToList();
                var setups = new List<Dictionary<string, object?>>();
                var notes = new List<string>();
                foreach (var ds in new FilteredElementCollector(doc).OfClass(typeof(DataStorage)).Cast<DataStorage>())
                {
                    foreach (var schema in schemas)
                    {
                        Entity ent;
                        try { ent = ds.GetEntity(schema); } catch { continue; }
                        if (ent == null || !ent.IsValid()) continue;
                        var velden = LeesVelden(ent, schema, notes);
                        // Eén veld met JSON (nieuwere exporters) of losse velden (oudere)
                        foreach (var v in velden.Values.OfType<string>().Where(s => s.TrimStart().StartsWith("{")))
                        {
                            try
                            {
                                var dict = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(v);
                                if (dict != null)
                                    foreach (var kv in dict) if (!velden.ContainsKey(kv.Key)) velden[kv.Key] = kv.Value.ValueKind == JsonValueKind.String ? kv.Value.GetString() : kv.Value.GetRawText();
                            }
                            catch { }
                        }
                        string? Veld(params string[] namen) => namen.Select(n => velden.FirstOrDefault(kv => string.Equals(kv.Key, n, StringComparison.OrdinalIgnoreCase)).Value?.ToString())
                                                                     .FirstOrDefault(x => !string.IsNullOrEmpty(x));
                        var setup = new Dictionary<string, object?>
                        {
                            ["name"] = Veld("Name", "ConfigName"),
                            ["ifc_version"] = Veld("IFCVersion", "IfcVersion"),
                            ["export_user_defined_psets"] = Veld("ExportUserDefinedPsets"),
                            ["user_pset_file"] = Veld("ExportUserDefinedPsetsFileName"),
                            ["export_user_defined_parameter_mapping"] = Veld("ExportUserDefinedParameterMapping"),
                            ["parameter_mapping_file"] = Veld("ExportUserDefinedParameterMappingFileName"),
                            ["schema"] = schema.SchemaName,
                            ["data_storage_id"] = ds.Id.Value,
                        };
                        if (raw) setup["raw"] = velden;
                        setups.Add(setup);
                    }
                }
                if (schemas.Count == 0) notes.Add("geen IFC-configuratieschema geladen in deze Revit-sessie; open eenmaal het IFC-exportvenster of er zijn geen setups bewaard");
                return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["count"] = setups.Count, ["setups"] = setups, ["notes"] = notes };
            }, timeoutMs: 60000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> LeesVelden(Entity ent, Schema schema, List<string> notes)
    {
        var uit = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in schema.ListFields())
        {
            try
            {
                if (f.ContainerType == ContainerType.Simple && f.ValueType == typeof(string))
                    uit[f.FieldName] = ent.Get<string>(f);
                else if (f.ContainerType == ContainerType.Map && f.KeyType == typeof(string) && f.ValueType == typeof(string))
                    foreach (var kv in ent.Get<IDictionary<string, string>>(f)) uit[kv.Key] = kv.Value;
                else if (f.ContainerType == ContainerType.Simple && f.ValueType == typeof(bool))
                    uit[f.FieldName] = ent.Get<bool>(f).ToString();
                else if (f.ContainerType == ContainerType.Simple && f.ValueType == typeof(int))
                    uit[f.FieldName] = ent.Get<int>(f).ToString();
            }
            catch (Exception ex) { notes.Add($"{schema.SchemaName}.{f.FieldName}: {ex.Message}"); }
        }
        return uit;
    }
}
