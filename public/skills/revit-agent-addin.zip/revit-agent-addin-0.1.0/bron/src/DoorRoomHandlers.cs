using System.Globalization;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace RevitAgent.Addin;

/// <summary>
/// get_door_room_relations — per deur de van- en naar-ruimte in een op te geven fase, alleen lezen.
/// Nodig omdat FromRoom en
/// ToRoom van een deur voor de laatste fase gelden, terwijl de rooms vaak in een eerdere fase staan (bv. NLRS_nieuw).
///
/// params: target_document (verplicht), phase? (naam of element-id; standaard de fase met de meeste rooms in het
/// document, anders in de geladen links, anders 'NLRS_nieuw', anders de laatste fase), include_links? (default TRUE),
/// category? ('Doors' (default) of 'Windows'), element_ids? [id, ...] (filter), geometrie? ('terugval' (default):
/// alleen punten toetsen als FromRoom of ToRoom in het document leeg is; 'altijd': altijd, ook tegen de links;
/// 'nooit'), offset_mm? (default 300), probe_height_mm? (default 1000).
///
/// Per deur: element_id, unique_id, family, type, mark, level, phase_created, location_mm, facing, host {element_id,
/// wall_type, wanddikte_mm, function, is_external_param, buitenwand}, from_room / to_room (get_FromRoom(fase) /
/// get_ToRoom(fase), alleen rooms in het document), en bij de geometrische toets zijden {plus, min}: per zijde het
/// punt (deurlocatie ± FacingOrientation × (wanddikte/2 + offset), op de hoogte van de deurlocatie + probe_height) en
/// de rooms die het punt bevatten (Document.GetRoomAtPoint(punt, fase) in het document en per RevitLinkInstance in
/// de link, met de inverse van de totale transformatie en de fase van de link met dezelfde naam, anders de laatste).
/// van / naar: de effectieve ruimte (bron 'api', anders 'geometrie' met eerst een room in het document, dan een
/// room in een link). Aanname bij de terugval: de ToRoom ligt aan de kant van FacingOrientation (plus); staat er
/// één API-room, dan bepaalt die welke zijde 'van' is.
/// Een room-verwijzing: id, unique_id, number, name, level, phase, document, link_instance_id, link_titel, ifc_guid,
/// ifc_guid_bron ('parameter' = IfcGUID/IFC GUID op de room, 'export_id' = ExportUtils.GetExportId omgezet naar de
/// IFC-base64-vorm, zoals de Revit IFC-exporter het doet zonder opgeslagen IfcGUID).
/// Geen transacties. Onbekende fase = weigering met de bestaande fasen; links die niet geladen zijn in notes.
/// </summary>
public static class DoorRoomHandlers
{
    private const double MM = 304.8;

    private const string StandaardFase = "NLRS_nieuw";

    private sealed class LinkCtx
    {
        public RevitLinkInstance Inst = null!;
        public Document Doc = null!;
        public Transform Inv = null!;
        public Phase? Fase;
        public int RoomsInFase;
    }

    public static CommandResponse GetDoorRoomRelations(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");
        string? phaseArg = RawStr(p, "phase");
        bool includeLinks = HandlerUtil.Bool(p, "include_links", true);
        string cat = HandlerUtil.Str(p, "category") ?? "Doors";
        string geometrie = (HandlerUtil.Str(p, "geometrie") ?? "terugval").ToLowerInvariant();
        if (geometrie is not ("terugval" or "altijd" or "nooit"))
            return Err($"geometrie '{geometrie}' onbekend (wel: terugval, altijd, nooit)");
        double offsetMm = TopNum(p, "offset_mm") ?? 300.0;
        double probeMm = TopNum(p, "probe_height_mm") ?? 1000.0;
        var idFilter = HandlerUtil.Arr(p, "element_ids").Select(NumEl).Where(v => v != null)
            .Select(v => (long)v!.Value).ToHashSet();

        BuiltInCategory bic;
        switch (cat.Trim().ToLowerInvariant())
        {
            case "doors": case "ost_doors": case "deuren": bic = BuiltInCategory.OST_Doors; break;
            case "windows": case "ost_windows": case "ramen": bic = BuiltInCategory.OST_Windows; break;
            default: return Err($"category '{cat}' onbekend (wel: Doors, Windows)");
        }

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                var notes = new List<string>();
                var phases = doc.Phases.Cast<Phase>().ToList();
                if (phases.Count == 0) return (object)Fail("het document heeft geen fasen");

                // ── links ───────────────────────────────────────────────────────
                var links = new List<LinkCtx>();
                var linkRows = new List<Dictionary<string, object?>>();
                if (includeLinks)
                {
                    foreach (var li in new FilteredElementCollector(doc).OfClass(typeof(RevitLinkInstance))
                                 .Cast<RevitLinkInstance>().OrderBy(l => l.Id.Value))
                    {
                        Document? ld = null;
                        try { ld = li.GetLinkDocument(); } catch { }
                        if (ld == null)
                        {
                            notes.Add($"link {li.Id.Value} ({SafeStr(() => li.Name)}) is niet geladen; overgeslagen");
                            linkRows.Add(new Dictionary<string, object?> { ["element_id"] = li.Id.Value, ["titel"] = null, ["geladen"] = false });
                            continue;
                        }
                        Transform inv;
                        try { inv = li.GetTotalTransform().Inverse; }
                        catch (Exception ex) { notes.Add($"link {li.Id.Value}: transformatie niet leesbaar ({ex.Message}); overgeslagen"); continue; }
                        links.Add(new LinkCtx { Inst = li, Doc = ld, Inv = inv });
                    }
                }

                // ── fase ────────────────────────────────────────────────────────
                Phase? phase = null;
                string faseBron;
                if (phaseArg != null)
                {
                    phase = phases.FirstOrDefault(f => f.Name.Equals(phaseArg, StringComparison.OrdinalIgnoreCase));
                    if (phase == null && long.TryParse(phaseArg, NumberStyles.Integer, CultureInfo.InvariantCulture, out var pid))
                        phase = phases.FirstOrDefault(f => f.Id.Value == pid);
                    if (phase == null)
                        return (object)Fail($"fase '{phaseArg}' niet gevonden (wel: {string.Join(", ", phases.Select(f => $"{f.Name} (id {f.Id.Value})"))})");
                    faseBron = "opgegeven";
                }
                else
                {
                    var perFase = RoomsPerPhaseName(doc);
                    if (perFase.Count > 0)
                    {
                        var top = perFase.OrderByDescending(kv => kv.Value).First().Key;
                        phase = phases.FirstOrDefault(f => f.Name == top);
                        faseBron = $"meeste rooms in het document ({perFase[top]})";
                    }
                    else
                    {
                        var som = new Dictionary<string, int>();
                        foreach (var l in links)
                            foreach (var kv in RoomsPerPhaseName(l.Doc))
                                som[kv.Key] = som.GetValueOrDefault(kv.Key) + kv.Value;
                        var top = som.Where(kv => phases.Any(f => f.Name == kv.Key))
                            .OrderByDescending(kv => kv.Value).Select(kv => kv.Key).FirstOrDefault();
                        phase = top == null ? null : phases.FirstOrDefault(f => f.Name == top);
                        faseBron = top == null ? "" : $"meeste rooms in de links ({som[top]})";
                    }
                    if (phase == null)
                    {
                        phase = phases.FirstOrDefault(f => f.Name == StandaardFase);
                        faseBron = $"standaard {StandaardFase}";
                    }
                    if (phase == null) { phase = phases.Last(); faseBron = "laatste fase (geen rooms gevonden)"; }
                }

                foreach (var l in links)
                {
                    var lph = l.Doc.Phases.Cast<Phase>().ToList();
                    l.Fase = lph.FirstOrDefault(f => f.Name == phase.Name) ?? lph.LastOrDefault();
                    if (l.Fase != null && l.Fase.Name != phase.Name)
                        notes.Add($"link {l.Inst.Id.Value} ({l.Doc.Title}) heeft geen fase '{phase.Name}'; gebruikt '{l.Fase.Name}' (laatste)");
                    l.RoomsInFase = l.Fase == null ? 0 : CountRooms(l.Doc, l.Fase.Id);
                    linkRows.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = l.Inst.Id.Value, ["titel"] = l.Doc.Title, ["geladen"] = true,
                        ["fase"] = l.Fase?.Name, ["rooms_in_fase"] = l.RoomsInFase,
                    });
                }
                int eigenRooms = CountRooms(doc, phase.Id);

                // ── deuren ──────────────────────────────────────────────────────
                var deuren = new List<Dictionary<string, object?>>();
                int nApiEen = 0, nApiBeide = 0, nTerugval = 0, nGeomBeide = 0, nGeenHost = 0, nBuitenwand = 0, nGeenRuimte = 0;
                var roomCache = new Dictionary<string, Dictionary<string, object?>>();

                foreach (var d in new FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType()
                             .OfType<FamilyInstance>().OrderBy(x => x.Id.Value))
                {
                    if (idFilter.Count > 0 && !idFilter.Contains(d.Id.Value)) continue;
                    var row = new Dictionary<string, object?>
                    {
                        ["element_id"] = d.Id.Value,
                        ["unique_id"] = d.UniqueId,
                        ["family"] = SafeStr(() => d.Symbol?.FamilyName),
                        ["type"] = SafeStr(() => d.Symbol?.Name),
                        ["mark"] = SafeStr(() => d.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString()),
                        ["level"] = SafeStr(() => doc.GetElement(d.LevelId)?.Name),
                        ["phase_created"] = SafeStr(() => doc.GetElement(d.CreatedPhaseId)?.Name),
                    };
                    deuren.Add(row);

                    XYZ? loc = (d.Location as LocationPoint)?.Point;
                    XYZ facing = XYZ.Zero;
                    try { facing = d.FacingOrientation; } catch { }
                    row["location_mm"] = loc == null ? null : Mm3(loc);
                    row["facing"] = Vec(facing);

                    // host
                    double dikte = 0;
                    if (d.Host is Wall w)
                    {
                        try { dikte = w.Width; } catch { }
                        string? func = null; bool? isExtPar = null;
                        try { func = w.WallType?.Function.ToString(); } catch { }
                        isExtPar = IsExternalParam(w) ?? IsExternalParam(w.WallType);
                        bool buiten = func == nameof(WallFunction.Exterior) || isExtPar == true;
                        if (buiten) nBuitenwand++;
                        row["host"] = new Dictionary<string, object?>
                        {
                            ["element_id"] = w.Id.Value, ["wall_type"] = SafeStr(() => w.WallType?.Name),
                            ["wanddikte_mm"] = R(dikte * MM), ["function"] = func,
                            ["is_external_param"] = isExtPar, ["buitenwand"] = buiten,
                        };
                    }
                    else
                    {
                        nGeenHost++;
                        row["host"] = d.Host == null ? null : new Dictionary<string, object?>
                        {
                            ["element_id"] = d.Host.Id.Value, ["category"] = SafeStr(() => d.Host.Category?.Name),
                            ["wanddikte_mm"] = null, ["function"] = null, ["buitenwand"] = null,
                        };
                    }

                    // API in de fase
                    Room? from = null, to = null;
                    try { from = d.get_FromRoom(phase); } catch { }
                    try { to = d.get_ToRoom(phase); } catch { }
                    var fromRef = from == null ? null : RoomRef(doc, from, null, "api", roomCache);
                    var toRef = to == null ? null : RoomRef(doc, to, null, "api", roomCache);
                    row["from_room"] = fromRef;
                    row["to_room"] = toRef;
                    if (from != null && to != null) nApiBeide++;
                    else if (from != null || to != null) nApiEen++;

                    // geometrie
                    bool doeGeom = geometrie == "altijd" || (geometrie == "terugval" && (from == null || to == null));
                    List<Dictionary<string, object?>>? plusRooms = null, minRooms = null;
                    if (doeGeom && loc != null && !facing.IsZeroLength())
                    {
                        var dir = new XYZ(facing.X, facing.Y, 0);
                        if (dir.IsZeroLength()) dir = facing;
                        dir = dir.Normalize();
                        double afstand = dikte / 2 + offsetMm / MM;
                        var basis = new XYZ(loc.X, loc.Y, loc.Z + probeMm / MM);
                        var pPlus = basis + dir * afstand;
                        var pMin = basis - dir * afstand;
                        plusRooms = Probe(doc, phase, links, pPlus, roomCache);
                        minRooms = Probe(doc, phase, links, pMin, roomCache);
                        row["zijden"] = new Dictionary<string, object?>
                        {
                            ["plus"] = new Dictionary<string, object?> { ["punt_mm"] = Mm3(pPlus), ["rooms"] = plusRooms },
                            ["min"] = new Dictionary<string, object?> { ["punt_mm"] = Mm3(pMin), ["rooms"] = minRooms },
                        };
                        if (plusRooms.Count > 0 && minRooms.Count > 0) nGeomBeide++;
                    }
                    else if (doeGeom)
                    {
                        row["zijden"] = null;
                        notes.Add($"deur {d.Id.Value}: geen locatiepunt of FacingOrientation; geometrische toets overgeslagen");
                    }

                    // effectief van / naar
                    Dictionary<string, object?>? van = fromRef, naar = toRef;
                    bool terugval = false;
                    if ((van == null || naar == null) && (plusRooms != null || minRooms != null))
                    {
                        var plus = Kies(plusRooms); var min = Kies(minRooms);
                        // welke zijde is 'van'? Staat er één API-room, dan bepaalt die het; anders plus = naar (aanname)
                        bool plusIsNaar = true;
                        if (fromRef != null && Zelfde(fromRef, plus)) plusIsNaar = false;
                        else if (toRef != null && Zelfde(toRef, min)) plusIsNaar = false;
                        var geoVan = plusIsNaar ? min : plus;
                        var geoNaar = plusIsNaar ? plus : min;
                        if (van == null && geoVan != null && !Zelfde(geoVan, naar)) { van = geoVan; terugval = true; }
                        if (naar == null && geoNaar != null && !Zelfde(geoNaar, van)) { naar = geoNaar; terugval = true; }
                    }
                    if (terugval) nTerugval++;
                    if (van == null && naar == null) nGeenRuimte++;
                    row["van"] = van;
                    row["naar"] = naar;
                    row["terugval"] = terugval;
                    row["een_zijde_zonder_ruimte"] = (van == null) != (naar == null);
                }

                if (idFilter.Count > 0)
                {
                    var gevonden = deuren.Select(r => (long)r["element_id"]!).ToHashSet();
                    var mis = idFilter.Where(i => !gevonden.Contains(i)).Take(50).ToList();
                    if (mis.Count > 0) notes.Add($"element_ids niet gevonden in categorie {cat}: {string.Join(", ", mis)}");
                }
                if (eigenRooms == 0 && links.All(l => l.RoomsInFase == 0))
                    notes.Add($"geen rooms in fase '{phase.Name}' in het document of de geladen links; van/naar blijven leeg");
                notes.Add("from_room/to_room: FamilyInstance.get_FromRoom/get_ToRoom in de gekozen fase, alleen rooms in het document zelf");
                notes.Add("zijden: plus = deurlocatie + FacingOrientation × (wanddikte/2 + offset), min = tegengesteld; hoogte = deurlocatie + probe_height");
                notes.Add("terugval-aanname: ToRoom aan de plus-zijde, tenzij één API-room de zijde vastlegt; toetsen op een bekende deur");
                notes.Add("ifc_guid: IfcGUID-parameter als die er is, anders ExportUtils.GetExportId → IFC-base64; vergelijk met de IFC-export van het model met de rooms");

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["fase"] = new Dictionary<string, object?> { ["id"] = phase.Id.Value, ["naam"] = phase.Name, ["bron"] = faseBron },
                    ["geometrie"] = geometrie,
                    ["offset_mm"] = offsetMm,
                    ["probe_height_mm"] = probeMm,
                    ["rooms_in_fase_document"] = eigenRooms,
                    ["links"] = linkRows,
                    ["tellers"] = new Dictionary<string, object?>
                    {
                        ["deuren"] = deuren.Count, ["api_beide"] = nApiBeide, ["api_een"] = nApiEen,
                        ["terugval_gebruikt"] = nTerugval, ["geometrie_beide_zijden"] = nGeomBeide,
                        ["zonder_ruimte"] = nGeenRuimte, ["host_geen_wand"] = nGeenHost, ["in_buitenwand"] = nBuitenwand,
                    },
                    ["deuren"] = deuren,
                    ["notes"] = notes,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // helpers
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>Rooms die het punt bevatten: eerst het document zelf, dan elke link (punt via de inverse transformatie).</summary>
    private static List<Dictionary<string, object?>> Probe(Document doc, Phase phase, List<LinkCtx> links, XYZ pt,
        Dictionary<string, Dictionary<string, object?>> cache)
    {
        var uit = new List<Dictionary<string, object?>>();
        try
        {
            var r = doc.GetRoomAtPoint(pt, phase);
            if (r != null) uit.Add(RoomRef(doc, r, null, "geometrie", cache));
        }
        catch { }
        foreach (var l in links)
        {
            if (l.Fase == null || l.RoomsInFase == 0) continue;
            try
            {
                var r = l.Doc.GetRoomAtPoint(l.Inv.OfPoint(pt), l.Fase);
                if (r != null) uit.Add(RoomRef(l.Doc, r, l.Inst, "geometrie", cache));
            }
            catch { }
        }
        return uit;
    }

    /// <summary>Eerste keus: room in het document, anders de eerste link-room.</summary>
    private static Dictionary<string, object?>? Kies(List<Dictionary<string, object?>>? rooms)
        => rooms == null || rooms.Count == 0 ? null
           : rooms.FirstOrDefault(r => r["link_instance_id"] == null) ?? rooms[0];

    private static bool Zelfde(Dictionary<string, object?>? a, Dictionary<string, object?>? b)
        => a != null && b != null && Equals(a["unique_id"], b["unique_id"]) && Equals(a["document"], b["document"]);

    private static Dictionary<string, object?> RoomRef(Document rdoc, Room r, RevitLinkInstance? li, string bron,
        Dictionary<string, Dictionary<string, object?>> cache)
    {
        string key = rdoc.Title + "|" + r.UniqueId + "|" + (li?.Id.Value.ToString(CultureInfo.InvariantCulture) ?? "-");
        if (!cache.TryGetValue(key, out var basis))
        {
            var (guid, gbron) = RoomIfcGuid(rdoc, r);
            basis = new Dictionary<string, object?>
            {
                ["id"] = r.Id.Value,
                ["unique_id"] = r.UniqueId,
                ["number"] = SafeStr(() => r.Number),
                ["name"] = SafeStr(() => r.get_Parameter(BuiltInParameter.ROOM_NAME)?.AsString()),
                ["level"] = SafeStr(() => r.Level?.Name),
                ["phase"] = SafeStr(() => rdoc.GetElement(r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId() ?? ElementId.InvalidElementId)?.Name),
                ["document"] = rdoc.Title,
                ["link_instance_id"] = li?.Id.Value,
                ["link_titel"] = li == null ? null : rdoc.Title,
                ["ifc_guid"] = guid,
                ["ifc_guid_bron"] = gbron,
            };
            cache[key] = basis;
        }
        return new Dictionary<string, object?>(basis) { ["bron"] = bron };
    }

    private static (string? guid, string? bron) RoomIfcGuid(Document rdoc, Room r)
    {
        try
        {
            var s = r.get_Parameter(BuiltInParameter.IFC_GUID)?.AsString();
            if (string.IsNullOrWhiteSpace(s)) s = r.LookupParameter("IfcGUID")?.AsString();
            if (string.IsNullOrWhiteSpace(s)) s = r.LookupParameter("IFC GUID")?.AsString();
            if (!string.IsNullOrWhiteSpace(s)) return (s.Trim(), "parameter");
        }
        catch { }
        try { return (ToIfcGuid(ExportUtils.GetExportId(rdoc, r.Id)), "export_id"); }
        catch { return (null, null); }
    }

    private const string IfcChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$";

    /// <summary>GUID → 22 tekens IFC-base64 (zelfde als ifcopenshell.guid.compress en GUIDUtil.ConvertToIFCGuid van
    /// de Revit IFC-exporter): de 16 bytes in hex-volgorde, eerst 1 byte in 2 tekens, dan 5 × 3 bytes in 4 tekens.</summary>
    internal static string ToIfcGuid(Guid g)
    {
        var hex = g.ToString("N");
        var b = new byte[16];
        for (int i = 0; i < 16; i++) b[i] = byte.Parse(hex.Substring(i * 2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
        var num = new ulong[6];
        num[0] = b[0];
        for (int k = 0; k < 5; k++) num[k + 1] = ((ulong)b[1 + 3 * k] << 16) | ((ulong)b[2 + 3 * k] << 8) | b[3 + 3 * k];
        var buf = new char[22];
        int offset = 0;
        for (int i = 0; i < 6; i++)
        {
            int len = i == 0 ? 2 : 4;
            for (int j = 0; j < len; j++)
            {
                buf[offset + len - j - 1] = IfcChars[(int)(num[i] % 64)];
                num[i] /= 64;
            }
            offset += len;
        }
        return new string(buf);
    }

    private static bool? IsExternalParam(Element? e)
    {
        if (e == null) return null;
        try
        {
            var par = e.LookupParameter("IsExternal");
            if (par == null || !par.HasValue || par.StorageType != StorageType.Integer) return null;
            return par.AsInteger() == 1;
        }
        catch { return null; }
    }

    private static Dictionary<string, int> RoomsPerPhaseName(Document d)
    {
        var uit = new Dictionary<string, int>();
        foreach (var r in new FilteredElementCollector(d).OfCategory(BuiltInCategory.OST_Rooms)
                     .WhereElementIsNotElementType().OfType<Room>())
        {
            string? naam = null;
            try { naam = d.GetElement(r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId() ?? ElementId.InvalidElementId)?.Name; } catch { }
            if (naam == null) continue;
            uit[naam] = uit.GetValueOrDefault(naam) + 1;
        }
        return uit;
    }

    private static int CountRooms(Document d, ElementId phaseId)
        => new FilteredElementCollector(d).OfCategory(BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()
               .OfType<Room>().Count(r => r.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId() == phaseId);

    private static string? RawStr(Dictionary<string, JsonElement>? p, string key)
    {
        if (p == null || !p.TryGetValue(key, out var el)) return null;
        if (el.ValueKind == JsonValueKind.String) { var s = el.GetString(); return string.IsNullOrWhiteSpace(s) ? null : s.Trim(); }
        if (el.ValueKind == JsonValueKind.Number) return el.GetRawText();
        return null;
    }

    private static double? NumEl(JsonElement el)
    {
        if (el.ValueKind == JsonValueKind.Number) return el.GetDouble();
        if (el.ValueKind == JsonValueKind.String && double.TryParse(el.GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) return d;
        return null;
    }

    private static double? TopNum(Dictionary<string, JsonElement>? p, string key)
        => p != null && p.TryGetValue(key, out var el) ? NumEl(el) : null;

    private static string? SafeStr(Func<string?> f) { try { return f(); } catch { return null; } }
    private static double R(double v) => Math.Round(v, 1);
    private static double[] Mm3(XYZ q) => new[] { R(q.X * MM), R(q.Y * MM), R(q.Z * MM) };
    private static double[] Vec(XYZ v) => new[] { Math.Round(v.X, 6), Math.Round(v.Y, 6), Math.Round(v.Z, 6) };
    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
}
