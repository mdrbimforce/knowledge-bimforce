using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB.Structure;

namespace RevitAgent.Addin;

/// <summary>
/// Leidingwerk-aanvullingen voor de NLRS Onderwijsmodellen:
///
///   get_connectors        — alleen lezen: per connector positie, richting, maat, domein, systeemclassificatie, verbonden met.
///   cap_open_ends         — open leidingeinden afdoppen met het Caps-onderdeel uit de routing preference (generiek).
///   insert_pipe_accessory — appendage (afsluiter, ontluchter, aftapper) in een bestaande leiding zetten (knippen + aansluiten).
///   duplicate_mep_type    — PipeType of PipingSystemType dupliceren (routing preferences gaan mee), met typeparameters.
///
/// Gemeenschappelijk: target_document (verplicht); schrijvende commando's dry_run (default TRUE), één TransactionGroup per
/// item met de stille failure-preprocessor (warnings weg, errors → terugrollen), read-back na commit,
/// dialogs_dismissed/dialogs_notable. Coördinaten in mm, interne coördinaten, z absoluut (zoals connect_to_pipe en
/// get_pipe_geometry).
/// </summary>
public static partial class MepModelHandlers
{
    // ═══════════════════════════════════════════════════════════════════════
    // get_connectors
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// get_connectors — alleen lezen. params: target_document, element_ids:[...].
    /// Per element: {element_id, categorie, family, type, connectors:[{index (Connector.Id), connector_type, domein, vorm,
    /// origin_mm (z absoluut), richting (BasisZ), diameter_mm | breedte_mm + hoogte_mm, systeemclassificatie
    /// (PipeSystemType / DuctSystemType / ElectricalSystemType), flow_direction, systeem (MEPSystem-naam), systeemtype
    /// (PipingSystemType-naam), beschrijving, is_connected, verbonden_met:[owner-ids, alleen leidingen/kanalen/fittingen/
    /// appendages/equipment], verbonden_details:[{id, categorie}]}], open_connectors (aantal vrije End-connectors)}.
    /// </summary>
    public static CommandResponse GetConnectors(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");
        var ids = HandlerUtil.Arr(p, "element_ids").Select(e => e.ValueKind == JsonValueKind.Number && e.TryGetInt64(out var v) ? v
                                                                : e.ValueKind == JsonValueKind.String && long.TryParse(e.GetString(), out var s) ? s : (long?)null).ToList();
        if (ids.Count == 0) return Err("element_ids:[...] is verplicht");
        if (ids.Any(x => x == null)) return Err("element_ids bevat een waarde die geen id is");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                var rows = new List<Dictionary<string, object?>>();
                foreach (var id in ids)
                {
                    var el = doc.GetElement(new ElementId(id!.Value));
                    var row = new Dictionary<string, object?> { ["element_id"] = id };
                    rows.Add(row);
                    if (el == null) { row["fout"] = "niet gevonden"; continue; }
                    row["categorie"] = el.Category?.Name;
                    if (el is FamilyInstance fi) { row["family"] = fi.Symbol?.FamilyName; row["type"] = fi.Symbol?.Name; }
                    else row["type"] = doc.GetElement(el.GetTypeId())?.Name;
                    var cl = new List<Dictionary<string, object?>>();
                    row["connectors"] = cl;
                    int open = 0;
                    var all = AllConnectors(el).ToList();
                    if (all.Count == 0) row["fout"] = "geen connectors (geen MEPCurve of MEP-family)";
                    foreach (var c in all.OrderBy(c => c.Id)) { var r = ConnectorRow(doc, c); cl.Add(r); if (r["connector_type"] as string == "End" && r["is_connected"] is false) open++; }
                    row["open_connectors"] = open;
                }
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["aantal"] = rows.Count,
                    ["elementen"] = rows,
                    ["notes"] = new List<string>
                    {
                        "origin_mm in mm, interne coördinaten, z absoluut; richting = BasisZ van het connectorstelsel (wijst naar buiten)",
                        "verbonden_met: eigenaars van AllRefs, zonder het eigen element en zonder het MEP-systeem",
                    },
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> ConnectorRow(Document doc, Connector c)
    {
        var r = new Dictionary<string, object?> { ["index"] = c.Id };
        T? Try<T>(Func<T> f) { try { return f(); } catch { return default; } }
        r["connector_type"] = Try(() => c.ConnectorType.ToString());
        var dom = Try(() => c.Domain);
        r["domein"] = dom.ToString();
        var shape = Try(() => c.Shape);
        r["vorm"] = shape.ToString();
        var o = Try(() => c.Origin);
        r["origin_mm"] = o == null ? null : Mm3(o);
        var z = Try(() => c.CoordinateSystem?.BasisZ);
        r["richting"] = z == null ? null : Vec(z);
        if (shape == ConnectorProfileType.Round) r["diameter_mm"] = Try(() => (double?)R(c.Radius * 2 * MM));
        else if (shape is ConnectorProfileType.Rectangular or ConnectorProfileType.Oval)
        { r["breedte_mm"] = Try(() => (double?)R(c.Width * MM)); r["hoogte_mm"] = Try(() => (double?)R(c.Height * MM)); }
        if (dom == Domain.DomainPiping) r["systeemclassificatie"] = Try(() => c.PipeSystemType.ToString());
        else if (dom == Domain.DomainHvac) r["systeemclassificatie"] = Try(() => c.DuctSystemType.ToString());
        else if (dom == Domain.DomainElectrical) r["systeemclassificatie"] = Try(() => c.ElectricalSystemType.ToString());
        if (dom is Domain.DomainPiping or Domain.DomainHvac) r["flow_direction"] = Try(() => c.Direction.ToString());
        var sys = Try(() => c.MEPSystem);
        r["systeem"] = sys?.Name;
        r["systeemtype"] = sys == null ? null : Try(() => doc.GetElement(sys.GetTypeId())?.Name);
        r["beschrijving"] = Try(() => c.Description);
        bool conn = Try(() => c.IsConnected);
        r["is_connected"] = conn;
        var owners = new List<long>();
        var details = new List<Dictionary<string, object?>>();
        if (conn)
        {
            try
            {
                foreach (Connector x in c.AllRefs)
                {
                    try
                    {
                        var ow = x.Owner;
                        if (ow == null || ow.Id == c.Owner.Id || ow is MEPSystem) continue;
                        if (ow is MEPCurve or FamilyInstance or FabricationPart)
                        {
                            if (!owners.Contains(ow.Id.Value)) { owners.Add(ow.Id.Value); details.Add(new() { ["id"] = ow.Id.Value, ["categorie"] = ow.Category?.Name, ["connector"] = x.Id }); }
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }
        r["verbonden_met"] = owners;
        r["verbonden_details"] = details;
        return r;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // cap_open_ends
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// cap_open_ends — open leidingeinden afdoppen (lasbodem, eindkap) met PlumbingUtils.PlaceCapOnOpenEnds en het
    /// Caps-onderdeel uit de routing preference van het leidingtype.
    /// params: target_document, dry_run (default TRUE), minstens één selectie:
    ///   element_ids?:[...] (leidingen; met include_fittings ook fittingen/appendages), system?: naam van een PipingSystemType
    ///   of MEP-systeem (alle leidingen daarvan), within_bbox?: {min_mm:[x,y,z], max_mm:[x,y,z]} (alleen open einden
    ///   binnen de box), cap_pipe_type?: naam van het PipeType waarvan de Caps-regel geldt (default het type van de
    ///   leiding zelf), include_fittings? (default false: PlaceCapOnOpenEnds op een fitting/appendage is niet getoetst).
    /// PlaceCapOnOpenEnds dopt ALLE open einden van een element af; valt maar een deel van de open einden van een leiding in
    /// within_bbox, dan wordt die leiding overgeslagen (status deels_buiten_box).
    /// Per element één TransactionGroup/transactie; read-back: de einden zijn daarna verbonden met een nieuwe fitting.
    /// Resultaat per element: {index, element_id, status: zou_afdoppen|afgedopt|geen_open_einden|deels_buiten_box|geweigerd|fout,
    /// open_einden:[{index, origin_mm, diameter_mm}], cap_type (Caps-regels), cap_ids, fouten}.
    /// </summary>
    public static CommandResponse CapOpenEnds(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool inclFit = HandlerUtil.Bool(p, "include_fittings", false);
        if (target == null) return Err("target_document is verplicht");
        var ids = HandlerUtil.Arr(p, "element_ids").Select(e => e.ValueKind == JsonValueKind.Number && e.TryGetInt64(out var v) ? v
                                                                : e.ValueKind == JsonValueKind.String && long.TryParse(e.GetString(), out var s) ? s : (long?)null).ToList();
        if (ids.Any(x => x == null)) return Err("element_ids bevat een waarde die geen id is");
        string? sysName = HandlerUtil.Str(p, "system");
        string? capTypeName = HandlerUtil.Str(p, "cap_pipe_type");
        XYZ? bmin = null, bmax = null;
        if (p != null && p.TryGetValue("within_bbox", out var bb) && bb.ValueKind == JsonValueKind.Object)
        {
            double[]? V(string k) => bb.TryGetProperty(k, out var a) && a.ValueKind == JsonValueKind.Array ? a.EnumerateArray().Select(NumEl).Where(x => x != null).Select(x => x!.Value).ToArray() : null;
            var mn = V("min_mm"); var mx = V("max_mm");
            if (mn?.Length != 3 || mx?.Length != 3) return Err("within_bbox:{min_mm:[x,y,z], max_mm:[x,y,z]}");
            bmin = new XYZ(Math.Min(mn[0], mx[0]) / MM, Math.Min(mn[1], mx[1]) / MM, Math.Min(mn[2], mx[2]) / MM);
            bmax = new XYZ(Math.Max(mn[0], mx[0]) / MM, Math.Max(mn[1], mx[1]) / MM, Math.Max(mn[2], mx[2]) / MM);
        }
        if (ids.Count == 0 && sysName == null && bmin == null) return Err("geef minstens element_ids, system of within_bbox (zonder selectie wordt niets afgedopt)");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "cap_open_ends" };
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var fouten0 = new List<string>();

                PipeType? capType = null;
                if (capTypeName != null) { capType = ByName(Collect<PipeType>(doc!), capTypeName, "PipeType", fouten0); if (capType == null) return (object)Fail(string.Join("; ", fouten0)); }

                // kandidaten
                var cand = new List<Element>();
                if (ids.Count > 0)
                    foreach (var id in ids)
                    {
                        var el = doc!.GetElement(new ElementId(id!.Value));
                        if (el == null) { results.Add(new() { ["index"] = results.Count, ["element_id"] = id, ["status"] = "fout", ["fouten"] = new List<string> { "niet gevonden" } }); continue; }
                        cand.Add(el);
                    }
                else
                {
                    cand.AddRange(Collect<Pipe>(doc!));
                    if (inclFit)
                        cand.AddRange(new FilteredElementCollector(doc!).WherePasses(new ElementMulticategoryFilter(new List<BuiltInCategory> { BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_PipeAccessory }))
                                          .WhereElementIsNotElementType().OfType<FamilyInstance>());
                }
                if (sysName != null)
                {
                    bool InSys(Element e)
                    {
                        if (e is Pipe pp) { var st = ParamId(pp, BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM); if (NameOf(doc!, st) == sysName) return true; try { if (pp.MEPSystem?.Name == sysName) return true; } catch { } return false; }
                        foreach (var c in AllConnectors(e))
                        {
                            try { var s = c.MEPSystem; if (s != null && (s.Name == sysName || doc!.GetElement(s.GetTypeId())?.Name == sysName)) return true; } catch { }
                        }
                        return false;
                    }
                    cand = cand.Where(InSys).ToList();
                }
                bool InBox(XYZ q) => bmin == null || (q.X >= bmin.X - Tol && q.Y >= bmin.Y - Tol && q.Z >= bmin.Z - Tol && q.X <= bmax!.X + Tol && q.Y <= bmax.Y + Tol && q.Z <= bmax.Z + Tol);

                foreach (var el in cand)
                {
                    var fouten = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = results.Count, ["element_id"] = el.Id.Value, ["categorie"] = el.Category?.Name, ["status"] = "fout", ["fouten"] = fouten };
                    var open = EndConnectors(el).Where(c => { try { return c.Domain == Domain.DomainPiping && !c.IsConnected; } catch { return false; } }).ToList();
                    if (open.Count == 0) { if (ids.Count > 0) { row["status"] = "geen_open_einden"; results.Add(row); } continue; }
                    var inBox = open.Where(c => InBox(c.Origin)).ToList();
                    if (inBox.Count == 0) continue;   // buiten de box: niet melden
                    results.Add(row);
                    row["open_einden"] = open.Select(c => new Dictionary<string, object?>
                    {
                        ["index"] = c.Id, ["origin_mm"] = Mm3(c.Origin), ["diameter_mm"] = SafeDiam(c), ["in_box"] = InBox(c.Origin),
                    }).ToList();
                    if (inBox.Count < open.Count) { row["status"] = "deels_buiten_box"; fouten.Add($"{open.Count - inBox.Count} van de {open.Count} open einden liggen buiten within_bbox; PlaceCapOnOpenEnds dopt alle einden af, dus overgeslagen"); continue; }
                    if (el is not Pipe && !inclFit) { row["status"] = "geweigerd"; fouten.Add("geen leiding; zet include_fittings: true om het op een fitting/appendage te proberen (niet getoetst)"); continue; }
                    // cap-type
                    PipeType? pt = capType ?? (el is Pipe pp0 ? doc!.GetElement(pp0.GetTypeId()) as PipeType : (NeighbourPipeType(doc!, el) is ElementId nid ? doc!.GetElement(nid) as PipeType : null));
                    if (pt == null) { row["status"] = "geweigerd"; fouten.Add("leidingtype voor de Caps-regel onbekend; geef cap_pipe_type"); continue; }
                    row["cap_pipe_type"] = pt.Name;
                    row["caps_regels"] = RuleParts(doc!, pt, RoutingPreferenceRuleGroupType.Caps);
                    if (RuleCount(pt, RoutingPreferenceRuleGroupType.Caps) == 0) { row["status"] = "geweigerd"; fouten.Add($"PipeType '{pt.Name}' heeft geen Caps-regel in de routing preferences"); continue; }
                    if (el is Pipe pp1 && pp1.IsPlaceholder) { row["status"] = "geweigerd"; fouten.Add("placeholder-leiding"); continue; }
                    if (dryRun) { row["status"] = "zou_afdoppen"; continue; }

                    swallow.Context = $"cap_open_ends {el.Id.Value}";
                    var openIdx = open.Select(c => c.Id).ToHashSet();
                    var groupNotes = new List<string>();
                    var capIds = new List<long>();
                    var elId = el.Id; var ptId = pt.Id;
                    bool kept = RunGroup(doc!, $"Afdoppen {elId.Value}", groupNotes, () =>
                    {
                        var (ok, n) = RunTx(doc!, $"Afdoppen {elId.Value}", () =>
                        {
                            if (!PlumbingUtils.HasOpenConnector(doc!, elId)) throw new InvalidOperationException("Revit ziet geen open connector (HasOpenConnector false)");
                            PlumbingUtils.PlaceCapOnOpenEnds(doc!, elId, ptId);
                        }, meldingen);
                        if (!ok) { fouten.Add($"afdoppen teruggerold: {n}"); return false; }
                        // read-back: de voorheen open einden zijn nu verbonden met een fitting
                        var back = doc!.GetElement(elId);
                        foreach (var c in EndConnectors(back).Where(c => openIdx.Contains(c.Id)))
                        {
                            var own = RefOwners(c).Where(o => doc.GetElement(new ElementId(o)) is FamilyInstance).ToList();
                            if (own.Count == 0) fouten.Add($"read-back: einde {c.Id} ({string.Join(", ", Mm3(c.Origin))}) is na commit niet afgedopt");
                            capIds.AddRange(own);
                        }
                        if (capIds.Count == 0) { fouten.Add("read-back: geen dop gevonden; teruggerold"); return false; }
                        return true;
                    });
                    foreach (var gn in groupNotes) fouten.Add(gn);
                    if (!kept) { row["status"] = "fout"; continue; }
                    row["cap_ids"] = capIds.Distinct().ToList();
                    row["cap_types"] = capIds.Distinct().Select(x => doc!.GetElement(new ElementId(x)) is FamilyInstance f ? $"{f.Symbol?.FamilyName} : {f.Symbol?.Name}" : null).Distinct().ToList();
                    row["status"] = fouten.Count == 0 ? "afgedopt" : "afgedopt_met_fouten";
                }
                if (dryRun) notes.Add("dry_run: niets gewijzigd; zou_afdoppen is het plan");
                notes.Add("PlaceCapOnOpenEnds dopt alle open leidingeinden van een element af, met het Caps-onderdeel van cap_pipe_type (default het eigen leidingtype)");
                var res = Envelope(doc!, dryRun, results.Count, results, meldingen, notes);
                res.Remove("element_ids");
                res["cap_ids"] = results.Where(r => r.ContainsKey("cap_ids")).SelectMany(r => (List<long>)r["cap_ids"]!).ToList();
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static double? SafeDiam(Connector c)
    {
        try { return c.Shape == ConnectorProfileType.Round ? R(c.Radius * 2 * MM) : null; } catch { return null; }
    }

    private static List<string> RuleParts(Document doc, MEPCurveType t, RoutingPreferenceRuleGroupType g)
    {
        var parts = new List<string>();
        var rpm = t.RoutingPreferenceManager;
        if (rpm == null) return parts;
        int n = RuleCount(t, g);
        for (int i = 0; i < n; i++)
        {
            try { var el = doc.GetElement(rpm.GetRule(g, i).MEPPartId); parts.Add(el is FamilySymbol fs ? $"{fs.Family.Name} : {fs.Name}" : el?.Name ?? "(leeg)"); }
            catch { parts.Add("(?)"); }
        }
        return parts;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // insert_pipe_accessory
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// insert_pipe_accessory — appendage (afsluiter, inregelafsluiter, ontluchter, aftapper) in een bestaande leiding.
    /// params: target_document, dry_run (default TRUE), min_fitting_distance_mm (default 100),
    ///   items:[{pipe_id, family?, type, point_mm:[x,y,z] (alias punt_mm; z absoluut; geprojecteerd op de hartlijn,
    ///           max_offset_mm default 50), reverse? (bool: stroomrichting omdraaien), at_end? ("start"|"end"|"open"),
    ///           params?{}, comments?}].
    /// at_end (aftapper/ontluchter op het laagste/hoogste punt): geen knip; de appendage (1 of 2 leidingconnectors) wordt
    /// met haar aansluitconnector op het open einde gezet, langs de leiding naar buiten gericht en verbonden; point_mm is
    /// dan optioneel (alleen nodig bij at_end open en twee open einden).
    /// Methode (knippen + aansluiten, zoals de UI het doet): transactie 1 PlumbingUtils.BreakCurve op het punt (commit;
    /// een directe pipe-op-pipe-koppeling wordt losgemaakt), transactie 2 de appendage plaatsen op het punt
    /// (NewFamilyInstance op het level van de leiding), de as van de twee leidingconnectors gelijkrichten met de leiding
    /// (draaien om z; bij een niet-horizontale leiding om de as loodrecht op beide), de maat van de connectors op de
    /// leidingdiameter zetten (Connector.Radius, waar de family dat toelaat), het midden tussen de connectors op het punt
    /// schuiven, beide leidinghelften inkorten tot de connectors en verbinden. Nooit een union of fitting in de
    /// knip-transactie. Faalt transactie 2, dan rolt de groep ook de knip terug.
    /// Geweigerd: geen Pipe of placeholder; punt verder dan max_offset_mm van de hartlijn; punt binnen
    /// min_fitting_distance_mm van een einde of fitting; family zonder twee leidingconnectors; categorie geen
    /// Pipe Accessory (waarschuwing, geen weigering).
    /// Idempotent: Comments gelijk → bestond; zonder Comments een appendage van hetzelfde type binnen 10 mm van het punt
    /// en verbonden met de leiding → bestond.
    /// Resultaat per item: {index, status, element_id, pipe_ids_na (beide helften), projectiepunt_mm, diameters, connectors
    /// (read-back), fouten, waarschuwingen}.
    /// </summary>
    public static CommandResponse InsertPipeAccessory(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var items = HandlerUtil.Arr(p, "items").Select(x => x.Clone()).ToList();
        if (items.Count == 0) return Err("items:[{pipe_id, family?, type, point_mm:[x,y,z], reverse?, params?, comments?}] is verplicht");
        double minFit = ((p != null && p.TryGetValue("min_fitting_distance_mm", out var mfe) ? NumEl(mfe) : null) ?? 100.0) / MM;

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "insert_pipe_accessory" };
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var allSyms = Collect<FamilySymbol>(doc!).ToList();

                for (int i = 0; i < items.Count; i++)
                {
                    var it = items[i];
                    var fouten = new List<string>();
                    var waarsch = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = i, ["status"] = "fout", ["element_id"] = null, ["fouten"] = fouten, ["waarschuwingen"] = waarsch };
                    results.Add(row);
                    swallow.Context = $"insert_pipe_accessory #{i}";
                    try
                    {
                        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("item is geen object"); continue; }
                        long? pid = LongProp(it, "pipe_id");
                        string? famName = HandlerUtil.Str(it, "family"), typeName = HandlerUtil.Str(it, "type");
                        bool reverse = HandlerUtil.Bool(it, "reverse") ?? false;
                        double maxOff = (Num(it, "max_offset_mm") ?? 50) / MM;
                        row["pipe_id"] = pid; row["family"] = famName; row["type"] = typeName;
                        if (pid == null) fouten.Add("pipe_id ontbreekt");
                        if (typeName == null) fouten.Add("type ontbreekt");
                        string? atEnd = HandlerUtil.Str(it, "at_end")?.Trim().ToLowerInvariant();
                        if (atEnd != null && atEnd is not ("start" or "end" or "open")) fouten.Add($"at_end '{atEnd}' onbekend (start|end|open)");
                        string ptKey = it.TryGetProperty("point_mm", out _) || !it.TryGetProperty("punt_mm", out _) ? "point_mm" : "punt_mm";
                        var pt = atEnd != null && !it.TryGetProperty(ptKey, out _) ? null : Xy(it, ptKey, fouten, zOptional: false);
                        var prms = ItemParams(it, fouten);
                        if (fouten.Count > 0) continue;
                        if (doc!.GetElement(new ElementId(pid!.Value)) is not Pipe pipe) { fouten.Add($"element {pid} is geen Pipe"); continue; }
                        if (pipe.IsPlaceholder) { fouten.Add("placeholder-leiding"); continue; }
                        if ((pipe.Location as LocationCurve)?.Curve is not Line pl) { fouten.Add("leiding is niet recht"); continue; }
                        var cands = allSyms.Where(s => s.Name == typeName && (famName == null || s.Family.Name == famName)).ToList();
                        if (cands.Count != 1)
                        {
                            fouten.Add(cands.Count == 0 ? $"type '{typeName}'{(famName != null ? $" van family '{famName}'" : "")} niet gevonden (niet geladen?)"
                                                        : $"type '{typeName}' bestaat in meerdere families ({string.Join(", ", cands.Select(c => c.Family.Name).Distinct().Take(10))}); geef family op");
                            continue;
                        }
                        var sym = cands[0];
                        row["family"] = sym.Family.Name; row["type_id"] = sym.Id.Value; row["category"] = sym.Category?.Name;
                        if (sym.Category?.Id.Value != (long)BuiltInCategory.OST_PipeAccessory) waarsch.Add($"categorie is {sym.Category?.Name}, geen Pipe Accessories");
                        var ptype = PlacementType(sym.Family);
                        if (ptype != FamilyPlacementType.OneLevelBased) { fouten.Add($"placement_type {ptype?.ToString() ?? "onbekend"}; alleen OneLevelBased appendages"); continue; }

                        if (atEnd != null)
                        {
                            OpEinde(doc, pipe, pl, sym, atEnd, pt, reverse, prms, dryRun, row, fouten, waarsch, meldingen);
                            continue;
                        }

                        // projectie op de hartlijn
                        var raw = new XYZ(pt![0] / MM, pt[1] / MM, pt[2] / MM);
                        var d = pl.Direction.Normalize(); var a0 = pl.GetEndPoint(0);
                        double t = (raw - a0).DotProduct(d);
                        var q = a0 + d * t;
                        row["projectiepunt_mm"] = Mm3(q);
                        row["afstand_tot_hartlijn_mm"] = R(q.DistanceTo(raw) * MM);
                        if (q.DistanceTo(raw) > maxOff) { fouten.Add($"punt ligt {R(q.DistanceTo(raw) * MM)} mm van de hartlijn (max {R(maxOff * MM)})"); continue; }
                        if (t < minFit || t > pl.Length - minFit) { fouten.Add($"punt ligt {R(Math.Min(t, pl.Length - t) * MM)} mm van een einde van de leiding (minimaal {R(minFit * MM)})"); continue; }
                        foreach (var (fid, tf) in FittingsOpHoofdleiding(doc, pipe, pl, OuterDiameter(pipe)))
                            if (Math.Abs(tf - t) < minFit) fouten.Add($"punt ligt {R(Math.Abs(tf - t) * MM)} mm van fitting/appendage {fid} (minimaal {R(minFit * MM)})");
                        if (fouten.Count > 0) continue;
                        row["diameter_leiding_mm"] = R(pipe.Diameter * MM);
                        var lvlId = pipe.ReferenceLevel?.Id ?? ElementId.InvalidElementId;
                        if (lvlId == ElementId.InvalidElementId) { fouten.Add("leiding heeft geen level"); continue; }

                        // idempotent
                        string? comments = CommentsWanted(prms);
                        List<FamilyInstance> bestaand;
                        if (comments != null) { bestaand = ByComments(doc, comments, exact: true, new ElementClassFilter(typeof(FamilyInstance))).Cast<FamilyInstance>().ToList(); row["herkend_op"] = "comments"; }
                        else
                        {
                            bestaand = new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>()
                                .Where(f => f.Symbol?.Id == sym.Id && f.Location is LocationPoint lp && lp.Point.DistanceTo(q) <= 10 / MM).ToList();
                            row["herkend_op"] = "geometrie";
                        }
                        if (bestaand.Count > 1) { fouten.Add($"{bestaand.Count} bestaande appendages passen ({string.Join(", ", bestaand.Select(f => f.Id.Value).Take(10))})"); continue; }
                        if (bestaand.Count == 1) { row["status"] = "bestond"; row["element_id"] = bestaand[0].Id.Value; row["connectors"] = AllConnectors(bestaand[0]).Select(c => ConnectorRow(doc, c)).ToList(); continue; }
                        row.Remove("herkend_op");
                        if (dryRun) { row["status"] = "zou_plaatsen"; continue; }

                        ElementId accId = ElementId.InvalidElementId, nieuwId = ElementId.InvalidElementId;
                        var pipeId = pipe.Id;
                        var paramRows = new Dictionary<string, object?>();
                        if (prms.Count > 0) row["params"] = paramRows;
                        var groupNotes = new List<string>();
                        bool kept = RunGroup(doc, $"Appendage {sym.Family.Name} in {pipeId.Value}", groupNotes, () =>
                        {
                            // 1: knippen
                            var (okC, nC) = RunTx(doc, $"Appendage: leiding {pipeId.Value} knippen", () =>
                            {
                                nieuwId = PlumbingUtils.BreakCurve(doc, pipeId, q);
                                if (nieuwId == ElementId.InvalidElementId) throw new InvalidOperationException("BreakCurve gaf geen nieuw element");
                            }, meldingen);
                            if (!okC) { fouten.Add($"knippen teruggerold: {nC}"); return false; }
                            if (doc.GetElement(nieuwId) is not Pipe || doc.GetElement(pipeId) is not Pipe) { fouten.Add("read-back: helften ontbreken na het knippen"); return false; }
                            // 2: plaatsen, richten, maat, aansluiten
                            var (okP, nP) = RunTx(doc, $"Appendage {sym.Family.Name} plaatsen", () =>
                            {
                                accId = PlaatsAppendage(doc, sym.Id, lvlId, q, d, reverse, pipeId, nieuwId, pipe.Diameter, waarsch);
                            }, meldingen);
                            if (!okP) { fouten.Add($"plaatsen/aansluiten teruggerold (knip ook): {nP}"); return false; }
                            if (doc.GetElement(accId) is not FamilyInstance acc) { fouten.Add("read-back: appendage niet gevonden na commit"); return false; }
                            var conns = EndConnectors(acc).Where(c => { try { return c.Domain == Domain.DomainPiping; } catch { return false; } }).ToList();
                            int verbonden = conns.Count(c => RefOwners(c).Any(o => o == pipeId.Value || o == nieuwId.Value));
                            if (verbonden < 2) { fouten.Add($"read-back: appendage met {verbonden} van 2 connectors aan de leiding verbonden; alles teruggerold"); return false; }
                            ZetParams(doc, accId, prms, paramRows, fouten, meldingen, "Appendage: parameters");
                            return true;
                        });
                        foreach (var gn in groupNotes) fouten.Add(gn);
                        if (!kept || doc.GetElement(accId) is not FamilyInstance placed) { row["status"] = "fout"; continue; }
                        row["element_id"] = accId.Value;
                        row["pipe_ids_na"] = new[] { pipeId.Value, nieuwId.Value };
                        row["connectors"] = AllConnectors(placed).Select(c => ConnectorRow(doc, c)).ToList();
                        if (placed.Location is LocationPoint lpp) row["locatie_mm"] = Mm3(lpp.Point);
                        row["status"] = fouten.Count == 0 ? "geplaatst" : "geplaatst_met_fouten";
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); }
                }
                if (dryRun) notes.Add("dry_run: niets gewijzigd; zou_plaatsen is het plan (projectiepunt, afstanden getoetst)");
                notes.Add("point_mm in mm, interne coördinaten, z absoluut; het punt wordt op de hartlijn van de leiding geprojecteerd");
                notes.Add("de leiding wordt geknipt: het tweede deel krijgt een nieuw id (pipe_ids_na); toets of Comments/markers van de leiding op beide delen staan");
                var res = Envelope(doc!, dryRun, items.Count, results, meldingen, notes);
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    /// <summary>In een open transactie: appendage plaatsen op q, richten langs d, maat zetten, centreren, beide helften
    /// inkorten en verbinden. Geeft het id van de appendage.</summary>
    private static ElementId PlaatsAppendage(Document doc, ElementId symId, ElementId lvlId, XYZ q, XYZ d, bool reverse,
                                             ElementId pipeA, ElementId pipeB, double diam, List<string> waarsch)
    {
        var s = (FamilySymbol)doc.GetElement(symId);
        if (!s.IsActive) { s.Activate(); doc.Regenerate(); }
        var lvl = (Level)doc.GetElement(lvlId);
        var fi = doc.Create.NewFamilyInstance(q, s, lvl, StructuralType.NonStructural) ?? throw new InvalidOperationException("NewFamilyInstance gaf null");
        var id = fi.Id;
        doc.Regenerate();
        List<Connector> Conns() => EndConnectors(doc.GetElement(id)).Where(c => { try { return c.Domain == Domain.DomainPiping; } catch { return false; } }).OrderBy(c => c.Id).ToList();
        var cs = Conns();
        if (cs.Count != 2) throw new InvalidOperationException($"family heeft {cs.Count} leidingconnectors; verwacht 2 (in en uit)");

        // richten: as van connector 0 naar connector 1 op d (reverse: tegen d in)
        var want = reverse ? -d : d;
        XYZ As() { var c2 = Conns(); return (c2[1].Origin - c2[0].Origin).Normalize(); }
        var a = As();
        if (a.IsZeroLength()) throw new InvalidOperationException("connectors van de appendage vallen samen");
        var mid = (cs[0].Origin + cs[1].Origin) / 2;
        if (Math.Abs(want.Z) < 1e-6 && Math.Abs(a.Z) < 1e-6)
        {
            double ang = Math.Atan2(a.X * want.Y - a.Y * want.X, a.X * want.X + a.Y * want.Y);
            if (Math.Abs(ang) > 1e-9) ElementTransformUtils.RotateElement(doc, id, Line.CreateBound(mid, mid + XYZ.BasisZ), ang);
        }
        else
        {
            var ax = a.CrossProduct(want);
            if (ax.GetLength() > 1e-9)
            {
                double ang = Math.Atan2(ax.GetLength(), a.DotProduct(want));
                try { ElementTransformUtils.RotateElement(doc, id, Line.CreateBound(mid, mid + ax.Normalize()), ang); }
                catch (Exception ex) { throw new InvalidOperationException($"appendage kan niet naar een niet-horizontale leiding gedraaid worden: {ex.Message}"); }
            }
            else if (a.DotProduct(want) < 0)
            {
                var perp = Math.Abs(a.Z) < 0.9 ? XYZ.BasisZ : XYZ.BasisX;
                ElementTransformUtils.RotateElement(doc, id, Line.CreateBound(mid, mid + perp), Math.PI);
            }
        }
        doc.Regenerate();
        if (As().DotProduct(want) < 1 - 1e-4) throw new InvalidOperationException($"richten mislukt: as [{string.Join(", ", Vec(As()))}], gewenst [{string.Join(", ", Vec(want))}]");

        // maat
        foreach (var c in Conns())
        {
            try { if (c.Shape == ConnectorProfileType.Round && Math.Abs(c.Radius - diam / 2) > 1e-6) c.Radius = diam / 2; }
            catch (Exception ex) { waarsch.Add($"connectormaat niet te zetten ({ex.Message}); de family-parameter bepaalt de maat"); break; }
        }
        doc.Regenerate();
        var dz = Conns().Select(c => SafeDiam(c)).ToList();
        if (dz.Any(x => x != null && Math.Abs(x.Value - R(diam * MM)) > 0.5)) waarsch.Add($"connectordiameter {string.Join("/", dz)} mm ≠ leiding {R(diam * MM)} mm");

        // centreren op q
        cs = Conns();
        var m2 = (cs[0].Origin + cs[1].Origin) / 2;
        if (m2.DistanceTo(q) > 1e-6) ElementTransformUtils.MoveElement(doc, id, q - m2);
        doc.Regenerate();
        cs = Conns();
        if (((cs[0].Origin + cs[1].Origin) / 2).DistanceTo(q) > Tol) throw new InvalidOperationException("centreren op het punt mislukt (verschuiving genegeerd?)");

        // helften inkorten en verbinden
        foreach (var pid in new[] { pipeA, pipeB })
        {
            var pp = (Pipe)doc.GetElement(pid);
            var cq = ConnectorAt(pp, q) ?? throw new InvalidOperationException($"connector van leiding {pid.Value} bij het knippunt niet gevonden");
            if (cq.IsConnected)
                foreach (Connector r in cq.AllRefs)
                    if (r.Owner is Pipe && (r.Owner.Id == pipeA || r.Owner.Id == pipeB)) { cq.DisconnectFrom(r); break; }
            var line = (Line)((LocationCurve)pp.Location).Curve;
            var far = line.GetEndPoint(0).DistanceTo(q) > line.GetEndPoint(1).DistanceTo(q) ? line.GetEndPoint(0) : line.GetEndPoint(1);
            var dir = (q - far).Normalize();
            // de connector van de appendage aan deze kant
            var ac = Conns().OrderBy(c => (c.Origin - q).DotProduct(dir)).First();   // meest richting 'far'
            if ((ac.Origin - q).DotProduct(dir) > -Tol / 2) throw new InvalidOperationException("appendage-connector ligt niet aan de kant van de leidinghelft");
            if (ac.Origin.DistanceTo(far) <= 5 * Tol) throw new InvalidOperationException($"leidinghelft {pid.Value} te kort voor de appendage");
            ZetEinde(doc, pid, q, ac.Origin);
            doc.Regenerate();
            var pc = ConnectorAt(doc.GetElement(pid), ac.Origin) ?? throw new InvalidOperationException("leidingconnector na inkorten niet gevonden");
            var acc = Conns().First(c => c.Id == ac.Id);
            pc.ConnectTo(acc);
        }
        doc.Regenerate();
        return id;
    }

    /// <summary>at_end: appendage op een open leidingeinde (aftapper, ontluchter, afsluiter aan het eind). Geen knip: de
    /// appendage wordt gericht (connector 0 naar de leiding, of bij één connector die connector naar de leiding), op het
    /// einde geschoven en verbonden. Zet zelf row["status"].</summary>
    private static void OpEinde(Document doc, Pipe pipe, Line pl, FamilySymbol sym, string atEnd, double[]? pt, bool reverse,
                                List<(string Name, JsonElement Value)> prms, bool dryRun, Dictionary<string, object?> row,
                                List<string> fouten, List<string> waarsch, List<string> meldingen)
    {
        var piping = EndConnectors(pipe).Where(c => { try { return c.Domain == Domain.DomainPiping; } catch { return false; } }).ToList();
        Connector? ec = null;
        if (atEnd is "start" or "end")
        {
            var ep = pl.GetEndPoint(atEnd == "start" ? 0 : 1);
            ec = piping.OrderBy(c => c.Origin.DistanceTo(ep)).FirstOrDefault();
        }
        else
        {
            var vrij = piping.Where(c => !c.IsConnected).ToList();
            if (vrij.Count == 1) ec = vrij[0];
            else if (vrij.Count == 2 && pt != null) { var raw = new XYZ(pt[0] / MM, pt[1] / MM, pt[2] / MM); ec = vrij.OrderBy(c => c.Origin.DistanceTo(raw)).First(); }
            else if (vrij.Count == 2) { fouten.Add("beide einden zijn open; geef at_end start|end of point_mm"); return; }
        }
        if (ec == null) { fouten.Add("leiding heeft geen open einde"); return; }
        row["einde_mm"] = Mm3(ec.Origin);
        row["methode"] = "op_einde";
        if (ec.IsConnected)
        {
            var buren = RefOwners(ec).ToList();
            var zelfde = buren.Where(b => doc.GetElement(new ElementId(b)) is FamilyInstance f && f.Symbol?.Id == sym.Id).ToList();
            if (zelfde.Count == 1) { row["status"] = "bestond"; row["element_id"] = zelfde[0]; return; }
            fouten.Add($"einde is al verbonden met {string.Join(", ", buren)}"); return;
        }
        var E = ec.Origin;
        var other = pl.GetEndPoint(0).DistanceTo(E) <= pl.GetEndPoint(1).DistanceTo(E) ? pl.GetEndPoint(1) : pl.GetEndPoint(0);
        var u = (E - other).Normalize();   // naar buiten
        row["richting_naar_buiten"] = Vec(u);
        row["diameter_leiding_mm"] = R(pipe.Diameter * MM);
        var lvlId = pipe.ReferenceLevel?.Id ?? ElementId.InvalidElementId;
        if (lvlId == ElementId.InvalidElementId) { fouten.Add("leiding heeft geen level"); return; }
        string? comments = CommentsWanted(prms);
        if (comments != null)
        {
            var hit = ByComments(doc, comments, exact: true, new ElementClassFilter(typeof(FamilyInstance))).ToList();
            if (hit.Count == 1) { row["status"] = "bestond"; row["element_id"] = hit[0].Id.Value; row["herkend_op"] = "comments"; return; }
            if (hit.Count > 1) { fouten.Add($"{hit.Count} appendages met deze Comments"); return; }
        }
        if (dryRun) { row["status"] = "zou_plaatsen"; return; }

        ElementId accId = ElementId.InvalidElementId;
        var pipeId = pipe.Id; int ecId = ec.Id; double diam = pipe.Diameter;
        var paramRows = new Dictionary<string, object?>();
        if (prms.Count > 0) row["params"] = paramRows;
        var groupNotes = new List<string>();
        bool kept = RunGroup(doc, $"Appendage {sym.Family.Name} op einde {pipeId.Value}", groupNotes, () =>
        {
            var (ok, n) = RunTx(doc, $"Appendage {sym.Family.Name} op einde", () =>
            {
                accId = PlaatsOpEinde(doc, sym.Id, pipe.ReferenceLevel.Id, E, u, reverse, diam, waarsch);
                var pc = EndConnectors(doc.GetElement(pipeId)).FirstOrDefault(c => c.Id == ecId) ?? throw new InvalidOperationException("leidingconnector niet meer te vinden");
                var ac = EndConnectors(doc.GetElement(accId)).Where(c => { try { return c.Domain == Domain.DomainPiping; } catch { return false; } })
                         .OrderBy(c => c.Origin.DistanceTo(E)).First();
                if (ac.Origin.DistanceTo(E) > Tol) throw new InvalidOperationException($"appendage-connector ligt {R(ac.Origin.DistanceTo(E) * MM)} mm van het leidingeinde");
                pc.ConnectTo(ac);
                doc.Regenerate();
            }, meldingen);
            if (!ok) { fouten.Add($"plaatsen teruggerold: {n}"); return false; }
            var back = EndConnectors(doc.GetElement(pipeId)).FirstOrDefault(c => c.Id == ecId);
            if (back == null || !RefOwners(back).Contains(accId.Value)) { fouten.Add("read-back: leidingeinde niet verbonden met de appendage; teruggerold"); return false; }
            ZetParams(doc, accId, prms, paramRows, fouten, meldingen, "Appendage: parameters");
            return true;
        });
        foreach (var gn in groupNotes) fouten.Add(gn);
        if (!kept || doc.GetElement(accId) is not FamilyInstance placed) { row["status"] = "fout"; return; }
        row["element_id"] = accId.Value;
        row["connectors"] = AllConnectors(placed).Select(c => ConnectorRow(doc, c)).ToList();
        row["status"] = fouten.Count == 0 ? "geplaatst" : "geplaatst_met_fouten";
    }

    /// <summary>In een open transactie: appendage zo plaatsen dat haar aansluitconnector op E ligt en het lichaam langs u
    /// (naar buiten) wijst. Twee connectors: as c0→c1 op u (reverse: c1 naar de leiding). Eén connector: −BasisZ op u.</summary>
    private static ElementId PlaatsOpEinde(Document doc, ElementId symId, ElementId lvlId, XYZ E, XYZ u, bool reverse, double diam, List<string> waarsch)
    {
        var s = (FamilySymbol)doc.GetElement(symId);
        if (!s.IsActive) { s.Activate(); doc.Regenerate(); }
        var fi = doc.Create.NewFamilyInstance(E, s, (Level)doc.GetElement(lvlId), StructuralType.NonStructural) ?? throw new InvalidOperationException("NewFamilyInstance gaf null");
        var id = fi.Id;
        doc.Regenerate();
        List<Connector> Conns() => EndConnectors(doc.GetElement(id)).Where(c => { try { return c.Domain == Domain.DomainPiping; } catch { return false; } }).OrderBy(c => c.Id).ToList();
        var cs = Conns();
        if (cs.Count is < 1 or > 2) throw new InvalidOperationException($"family heeft {cs.Count} leidingconnectors; verwacht 1 of 2");
        // aansluitconnector en as
        Connector Aansluit() { var c2 = Conns(); return c2.Count == 1 ? c2[0] : (reverse ? c2[1] : c2[0]); }
        XYZ As() { var c2 = Conns(); return c2.Count == 1 ? -c2[0].CoordinateSystem.BasisZ : (reverse ? (c2[0].Origin - c2[1].Origin) : (c2[1].Origin - c2[0].Origin)).Normalize(); }
        var a = As();
        var mid = Aansluit().Origin;
        var ax = a.CrossProduct(u);
        if (ax.GetLength() > 1e-9)
        {
            double ang = Math.Atan2(ax.GetLength(), a.DotProduct(u));
            try { ElementTransformUtils.RotateElement(doc, id, Line.CreateBound(mid, mid + ax.Normalize()), ang); }
            catch (Exception ex) { throw new InvalidOperationException($"appendage kan niet in de richting van de leiding gedraaid worden: {ex.Message}"); }
        }
        else if (a.DotProduct(u) < 0)
        {
            var perp = Math.Abs(a.Z) < 0.9 ? XYZ.BasisZ : XYZ.BasisX;
            ElementTransformUtils.RotateElement(doc, id, Line.CreateBound(mid, mid + perp), Math.PI);
        }
        doc.Regenerate();
        if (As().DotProduct(u) < 1 - 1e-4) throw new InvalidOperationException($"richten mislukt: as [{string.Join(", ", Vec(As()))}], gewenst [{string.Join(", ", Vec(u))}]");
        foreach (var c in Conns())
        {
            try { if (c.Shape == ConnectorProfileType.Round && Math.Abs(c.Radius - diam / 2) > 1e-6) c.Radius = diam / 2; }
            catch (Exception ex) { waarsch.Add($"connectormaat niet te zetten ({ex.Message}); de family-parameter bepaalt de maat"); break; }
        }
        doc.Regenerate();
        var m = Aansluit().Origin;
        if (m.DistanceTo(E) > 1e-6) ElementTransformUtils.MoveElement(doc, id, E - m);
        doc.Regenerate();
        if (Aansluit().Origin.DistanceTo(E) > Tol) throw new InvalidOperationException("verschuiven naar het leidingeinde mislukt (verschuiving genegeerd?)");
        var dz = SafeDiam(Aansluit());
        if (dz != null && Math.Abs(dz.Value - R(diam * MM)) > 0.5) waarsch.Add($"connectordiameter {dz} mm ≠ leiding {R(diam * MM)} mm");
        return id;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // duplicate_mep_type
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// duplicate_mep_type — PipeType of PipingSystemType dupliceren.
    /// params: target_document, dry_run (default TRUE), source_type (naam; alias bron), new_name (alias nieuwe_naam), kind? ("pipe_type" |
    ///   "piping_system_type"; default: gezocht in beide, moet uniek zijn), params?{typeparameter: waarde},
    ///   apply_params_if_exists? (default false).
    /// ElementType.Duplicate(new_name); bij een PipeType gaan de routing preferences mee (read-back: aantal regels per groep
    /// gelijk aan de bron; zo niet, dan worden de regels met hun criteria gekopieerd en opnieuw geteld). Typeparameters
    /// in een tweede transactie met read-back. Bestaat new_name al in dezelfde klasse: status bestond (niets gewijzigd,
    /// params alleen met apply_params_if_exists: true, want een typewijziging raakt alle elementen van dat type).
    /// Namen met \ : { } [ ] | ; &lt; &gt; ? ` ~ worden geweigerd.
    /// Resultaat: {status: zou_maken|gemaakt|gemaakt_met_fouten|bestond|fout, kind, bron_id, element_id, routing_regels
    /// {groep: [bron, nieuw]}, params, fouten}.
    /// </summary>
    public static CommandResponse DuplicateMepType(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool applyIfExists = HandlerUtil.Bool(p, "apply_params_if_exists", false);
        string? src = HandlerUtil.Str(p, "source_type") ?? HandlerUtil.Str(p, "bron"), nieuw = HandlerUtil.Str(p, "new_name") ?? HandlerUtil.Str(p, "nieuwe_naam"),
                kind = HandlerUtil.Str(p, "kind")?.ToLowerInvariant();
        if (target == null) return Err("target_document is verplicht");
        if (src == null || nieuw == null) return Err("source_type en new_name zijn verplicht");
        if (kind != null && kind is not ("pipe_type" or "piping_system_type")) return Err("kind is pipe_type of piping_system_type");
        if (SafeRevitName(nieuw) != nieuw.Trim()) return Err($"new_name '{nieuw}' bevat een teken dat Revit weigert (\\ : {{ }} [ ] | ; < > ? ` ~)");
        var prmsIn = new List<(string Name, JsonElement Value)>();
        if (p != null && p.TryGetValue("params", out var pe) && pe.ValueKind == JsonValueKind.Object)
            foreach (var pr in pe.EnumerateObject()) prmsIn.Add((pr.Name, pr.Value.Clone()));

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                var chk = DocCheck(doc, target, dryRun);
                if (chk != null) return (object)Fail(chk);
                using var swallow = new DialogSwallowScope(app) { Context = "duplicate_mep_type" };
                var fouten = new List<string>();
                var meldingen = new List<string>();
                var notes = new List<string>();
                var res = new Dictionary<string, object?> { ["document"] = doc!.Title, ["dry_run"] = dryRun, ["status"] = "fout", ["fouten"] = fouten, ["notes"] = notes };

                var pool = new List<ElementType>();
                if (kind is null or "pipe_type") pool.AddRange(Collect<PipeType>(doc));
                if (kind is null or "piping_system_type") pool.AddRange(Collect<PipingSystemType>(doc));
                var bron = pool.Where(t => t.Name == src).ToList();
                if (bron.Count != 1)
                {
                    fouten.Add(bron.Count == 0 ? $"bron '{src}' niet gevonden als {kind ?? "PipeType of PipingSystemType"}" : $"bron '{src}' bestaat als PipeType én PipingSystemType; geef kind");
                    res["beschikbaar"] = bron.Count == 0 ? pool.Select(t => $"{t.GetType().Name}: {t.Name}").OrderBy(x => x).Take(60).ToList() : null;
                    swallow.WriteTo(res);
                    return (object)res;
                }
                var b = bron[0];
                res["kind"] = b is PipeType ? "pipe_type" : "piping_system_type";
                res["bron_id"] = b.Id.Value;
                var zelfdeKlasse = (b is PipeType ? Collect<PipeType>(doc).Cast<ElementType>() : Collect<PipingSystemType>(doc).Cast<ElementType>()).ToList();
                var bestaat = zelfdeKlasse.FirstOrDefault(t => t.Name == nieuw);
                var paramRows = new Dictionary<string, object?>();
                if (prmsIn.Count > 0) res["params"] = paramRows;

                if (bestaat != null)
                {
                    res["status"] = "bestond";
                    res["element_id"] = bestaat.Id.Value;
                    if (b is PipeType bpt && bestaat is PipeType ept) res["routing_regels"] = RpCounts(bpt, ept);
                    if (prmsIn.Count > 0 && applyIfExists && !dryRun) ZetTypeParams(doc, bestaat.Id, prmsIn, paramRows, fouten, meldingen);
                    else if (prmsIn.Count > 0) notes.Add(applyIfExists ? "dry_run: params niet gezet" : "type bestond: params niet gezet (apply_params_if_exists: true om ze toch te zetten; raakt alle elementen van dit type)");
                    res["failure_meldingen"] = meldingen;
                    swallow.WriteTo(res);
                    return (object)res;
                }
                if (dryRun)
                {
                    res["status"] = "zou_maken";
                    if (b is PipeType bpt2) res["routing_regels_bron"] = RpCounts(bpt2, null);
                    notes.Add("dry_run: niets gewijzigd");
                    swallow.WriteTo(res);
                    return (object)res;
                }

                ElementId newId = ElementId.InvalidElementId;
                var groupNotes = new List<string>();
                bool kept = RunGroup(doc, $"Dupliceer {b.Name} → {nieuw}", groupNotes, () =>
                {
                    var (ok1, n1) = RunTx(doc, $"Dupliceer {b.Name}", () =>
                    {
                        var dup = ((ElementType)doc.GetElement(b.Id)).Duplicate(nieuw) ?? throw new InvalidOperationException("Duplicate gaf null");
                        newId = dup.Id;
                        if (b is PipeType sp && dup is PipeType dp)
                        {
                            var kopie = KopieerRp(sp, dp);
                            if (kopie != null) groupNotes.Add(kopie);
                        }
                    }, meldingen);
                    if (!ok1) { fouten.Add($"dupliceren teruggerold: {n1}"); return false; }
                    if (doc.GetElement(newId) is not ElementType nt || nt.Name != nieuw) { fouten.Add("read-back: nieuw type niet gevonden na commit"); return false; }
                    if (prmsIn.Count > 0) ZetTypeParams(doc, newId, prmsIn, paramRows, fouten, meldingen);
                    return true;
                });
                foreach (var gn in groupNotes) (gn.StartsWith("routing") ? notes : fouten).Add(gn);
                if (!kept) { res["status"] = "fout"; res["failure_meldingen"] = meldingen; swallow.WriteTo(res); return (object)res; }
                res["element_id"] = newId.Value;
                if (b is PipeType bp3 && doc.GetElement(newId) is PipeType np3)
                {
                    var rc = RpCounts(bp3, np3);
                    res["routing_regels"] = rc;
                    if (rc.Values.OfType<int[]>().Any(x => x[0] != x[1])) fouten.Add("read-back: aantal routing-regels wijkt af van de bron");
                    try { if (bp3.RoutingPreferenceManager.PreferredJunctionType != np3.RoutingPreferenceManager.PreferredJunctionType) fouten.Add("read-back: preferred junction type wijkt af"); } catch { }
                }
                res["status"] = fouten.Count == 0 ? "gemaakt" : "gemaakt_met_fouten";
                res["failure_meldingen"] = meldingen;
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static readonly RoutingPreferenceRuleGroupType[] RpGroups =
    {
        RoutingPreferenceRuleGroupType.Segments, RoutingPreferenceRuleGroupType.Elbows, RoutingPreferenceRuleGroupType.Junctions,
        RoutingPreferenceRuleGroupType.Crosses, RoutingPreferenceRuleGroupType.Transitions, RoutingPreferenceRuleGroupType.Unions,
        RoutingPreferenceRuleGroupType.MechanicalJoints, RoutingPreferenceRuleGroupType.TransitionsRectangularToRound,
        RoutingPreferenceRuleGroupType.TransitionsRectangularToOval, RoutingPreferenceRuleGroupType.TransitionsOvalToRound,
        RoutingPreferenceRuleGroupType.Caps,
    };

    private static Dictionary<string, object?> RpCounts(PipeType a, PipeType? b)
    {
        var d = new Dictionary<string, object?>();
        foreach (var g in RpGroups)
        {
            int na = RuleCount(a, g);
            if (b == null) { if (na > 0) d[g.ToString()] = na; continue; }
            int nb = RuleCount(b, g);
            if (na > 0 || nb > 0) d[g.ToString()] = new[] { na, nb };
        }
        return d;
    }

    /// <summary>Als Duplicate de routing preferences niet meenam: regels met criteria kopiëren. Geeft een note of null.</summary>
    private static string? KopieerRp(PipeType src, PipeType dst)
    {
        var sm = src.RoutingPreferenceManager; var dm = dst.RoutingPreferenceManager;
        if (sm == null || dm == null) return "routing preferences: manager ontbreekt";
        var gekopieerd = new List<string>();
        foreach (var g in RpGroups)
        {
            int ns = RuleCount(src, g), nd = RuleCount(dst, g);
            if (ns == nd) continue;
            for (int k = nd - 1; k >= 0; k--) dm.RemoveRule(g, k);
            for (int k = 0; k < ns; k++)
            {
                var r = sm.GetRule(g, k);
                var nr = new RoutingPreferenceRule(r.MEPPartId, r.Description);
                for (int c = 0; c < r.NumberOfCriteria; c++)
                {
                    if (r.GetCriterion(c) is PrimarySizeCriterion psc) nr.AddCriterion(new PrimarySizeCriterion(psc.MinimumSize, psc.MaximumSize));
                }
                dm.AddRule(g, nr);
            }
            gekopieerd.Add($"{g} ({ns})");
        }
        try { dm.PreferredJunctionType = sm.PreferredJunctionType; } catch { }
        return gekopieerd.Count == 0 ? null : "routing preferences handmatig gekopieerd: " + string.Join(", ", gekopieerd);
    }

    private static void ZetTypeParams(Document doc, ElementId typeId, List<(string Name, JsonElement Value)> prms, Dictionary<string, object?> paramRows,
                                      List<string> fouten, List<string> meldingen)
    {
        var desired = new Dictionary<string, (StorageType St, object Val)>();
        var (ok, n) = RunTx(doc, "Typeparameters", () =>
        {
            var el = doc.GetElement(typeId);
            foreach (var (pn, pv) in prms)
            {
                var pr = new Dictionary<string, object?> { ["gevraagd"] = Raw(pv), ["status"] = "fout" };
                paramRows[pn] = pr;
                var par = el.LookupParameter(pn) ?? (pn is "Assembly Code" ? el.LookupParameter("Assemblagecode") : null)
                          ?? (pn is "Description" or "Beschrijving" ? el.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION) : null)
                          ?? (pn is "Type Comments" ? el.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_COMMENTS) : null);
                if (par == null) { pr["reden"] = "parameter ontbreekt op het type"; fouten.Add($"param '{pn}': ontbreekt"); continue; }
                if (par.IsReadOnly) { pr["reden"] = "read-only"; fouten.Add($"param '{pn}': read-only"); continue; }
                var (val, setStr, err) = ConvertValue(doc, par, pv);
                if (err != null) { pr["reden"] = err; fouten.Add($"param '{pn}': {err}"); continue; }
                bool okSet;
                try { okSet = WriteValue(par, val!, setStr); }
                catch (Exception ex) { pr["reden"] = ex.Message; fouten.Add($"param '{pn}': {ex.Message}"); continue; }
                if (!okSet) { pr["reden"] = "Set gaf false"; fouten.Add($"param '{pn}': Set gaf false"); continue; }
                desired[pn] = (par.StorageType, val!);
                pr["status"] = "gezet_voor_commit";
            }
        }, meldingen);
        if (!ok) { fouten.Add($"typeparameters teruggerold: {n}"); return; }
        var back = doc.GetElement(typeId);
        foreach (var (pn, d) in desired)
        {
            var pr = (Dictionary<string, object?>)paramRows[pn]!;
            var par = back.LookupParameter(pn) ?? (pn is "Assembly Code" ? back.LookupParameter("Assemblagecode") : null)
                      ?? (pn is "Description" or "Beschrijving" ? back.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION) : null)
                      ?? (pn is "Type Comments" ? back.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_COMMENTS) : null);
            pr["gelezen"] = par == null ? null : DisplayValue(par);
            if (par != null && Equal(par, d.St, d.Val)) pr["status"] = "gezet";
            else { pr["status"] = "fout"; pr["reden"] = "read-back wijkt af"; fouten.Add($"param '{pn}': read-back wijkt af"); }
        }
    }
}
