using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_material_class — Material.MaterialClass (identity-tab "Klasse"/"Classe") lezen en zetten (bv. een NLRS-klasse
/// die in een vertaalde IFC blijft staan als IfcMaterial.Category). Geen parameter, dus niet via set_parameter_value.
/// params: target_document, edits:[{name|element_id, material_class}] (leeg edits = alleen lijst), dry_run (default true),
///         filter (optioneel: alleen materialen waarvan de naam dit bevat, voor de lijst).
/// </summary>
public static class MaterialClassHandlers
{
    public static CommandResponse SetMaterialClass(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? filter = GetString(p, "filter");
        bool dryRun = GetBool(p, "dry_run", true);
        var edits = new List<(string? name, long? id, string cls, string? cat)>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? n = it.TryGetProperty("name", out var ne) && ne.ValueKind == JsonValueKind.String ? ne.GetString() : null;
                long? id = it.TryGetProperty("element_id", out var ie) && ie.ValueKind == JsonValueKind.Number ? ie.GetInt64() : null;
                string? cls = it.TryGetProperty("material_class", out var ce) && ce.ValueKind == JsonValueKind.String ? ce.GetString() : null;
                string? cat = it.TryGetProperty("material_category", out var ca) && ca.ValueKind == JsonValueKind.String ? ca.GetString() : null;
                if ((n != null || id != null) && (cls != null || cat != null)) edits.Add((n, id, cls ?? "", cat));
            }
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                var mats = new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>().ToList();
                var list = mats.Where(m => filter == null || m.Name.Contains(filter, StringComparison.OrdinalIgnoreCase))
                               .Select(m => new Dictionary<string, object?> { ["element_id"] = m.Id.Value, ["name"] = m.Name, ["material_class"] = m.MaterialClass, ["material_category"] = m.MaterialCategory }).ToList();
                var results = new List<Dictionary<string, object?>>();
                if (edits.Count > 0)
                {
                    using var t = new Transaction(doc, "Revit Agent: set material class");
                    t.Start();
                    foreach (var (n, id, cls, cat) in edits)
                    {
                        var m = id != null ? doc.GetElement(new ElementId(id.Value)) as Material : mats.FirstOrDefault(x => string.Equals(x.Name, n, StringComparison.OrdinalIgnoreCase));
                        var row = new Dictionary<string, object?> { ["name"] = n ?? m?.Name, ["element_id"] = id ?? m?.Id.Value, ["material_class"] = cls, ["material_category"] = cat };
                        if (m == null) { row["status"] = "not_found"; results.Add(row); continue; }
                        row["current_class"] = m.MaterialClass; row["current_category"] = m.MaterialCategory;
                        bool chgCls = !string.IsNullOrEmpty(cls) && m.MaterialClass != cls, chgCat = cat != null && m.MaterialCategory != cat;
                        if (!chgCls && !chgCat) { row["status"] = "unchanged"; results.Add(row); continue; }
                        if (dryRun) { row["status"] = "would_set"; results.Add(row); continue; }
                        try { if (chgCls) m.MaterialClass = cls; if (chgCat) m.MaterialCategory = cat!; row["status"] = "set"; } catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                        results.Add(row);
                    }
                    if (dryRun) t.RollBack(); else t.Commit();
                }
                return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["dry_run"] = dryRun, ["materials"] = list, ["results"] = results };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el)) { if (el.ValueKind == JsonValueKind.True) return true; if (el.ValueKind == JsonValueKind.False) return false; }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) { var s = el.GetString(); return string.IsNullOrWhiteSpace(s) ? null : s; }
        return null;
    }
}
