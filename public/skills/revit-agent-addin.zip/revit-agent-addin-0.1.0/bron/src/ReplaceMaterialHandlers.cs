using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// replace_material — delete a material AND reassign the element-types that use it to a replacement
/// material ("vervang_door"). The natural follow-up to enum_material_usage:
/// instead of deleting and leaving types with no material, rebind first.
///
/// Per type, a material reference is reachable from the project doc via two paths, both reassigned here:
///   1. CompoundStructure layers (HostObjAttributes: Wall/Floor/Roof/Ceiling) — SetMaterialId + SetCompoundStructure.
///   2. ElementId-typed material parameters — Parameter.Set(targetId).
/// A third path — material baked into loadable-family GEOMETRY — is NOT reachable without editing the
/// family, so it is reported as 'unreachable'. SAFETY: the source material is deleted ONLY when no
/// unreachable references remain; otherwise it is kept and the residual is reported (no silent loss).
///
/// params:
///   target_document : scope by Title
///   replacements : [{source_id? , source_name, target_name, expected_name?}]
///   dry_run    : bool (default TRUE)
///   save_first : bool (default false)
/// </summary>
public static class ReplaceMaterialHandlers
{
    private record Repl(long? SourceId, string? SourceName, string TargetName, string? Expected);

    public static CommandResponse ReplaceMaterial(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);

        var repls = new List<Repl>();
        if (p != null && p.TryGetValue("replacements", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                long? sid = it.TryGetProperty("source_id", out var se) && se.ValueKind == JsonValueKind.Number ? se.GetInt64() : (long?)null;
                string? sn = GetProp(it, "source_name");
                string? tn = GetProp(it, "target_name");
                string? exp = GetProp(it, "expected_name");
                if (string.IsNullOrWhiteSpace(tn) || (sid == null && string.IsNullOrWhiteSpace(sn))) continue;
                repls.Add(new Repl(sid, sn, tn!.Trim(), exp));
            }
        }
        if (repls.Count == 0) return Err("replacements:[{source_id|source_name, target_name}] is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var mats = new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>().ToList();
                var byName = new Dictionary<string, Material>(StringComparer.OrdinalIgnoreCase);
                foreach (var m in mats) byName[m.Name] = m;

                // Resolve each replacement to (sourceId -> targetId); collect per-source result scaffolding.
                var map = new Dictionary<long, ElementId>();            // sourceId -> targetId
                var rowBySource = new Dictionary<long, Dictionary<string, object?>>();
                var results = new List<Dictionary<string, object?>>();
                foreach (var r in repls)
                {
                    var row = new Dictionary<string, object?> { ["source"] = (object?)r.SourceName ?? r.SourceId, ["target"] = r.TargetName };
                    Material? src = r.SourceId != null ? mats.FirstOrDefault(m => m.Id.Value == r.SourceId)
                                                       : (r.SourceName != null && byName.TryGetValue(r.SourceName, out var m1) ? m1 : null);
                    if (src == null) { row["status"] = "source_not_found"; results.Add(row); continue; }
                    if (r.Expected != null && !src.Name.Equals(r.Expected, StringComparison.Ordinal))
                    { row["status"] = "stale_skip"; row["reason"] = $"bron heet nu '{src.Name}' != verwacht '{r.Expected}'"; results.Add(row); continue; }
                    if (!byName.TryGetValue(r.TargetName, out var tgt))
                    { row["status"] = "target_not_found"; results.Add(row); continue; }
                    if (tgt.Id.Value == src.Id.Value)
                    { row["status"] = "noop_same"; results.Add(row); continue; }
                    map[src.Id.Value] = tgt.Id;
                    row["reassigned_compound"] = 0; row["reassigned_params"] = 0;
                    row["unreachable_types"] = 0; row["unreachable_names"] = new List<string>();
                    rowBySource[src.Id.Value] = row;
                    results.Add(row);
                }
                if (map.Count == 0)
                    return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["dry_run"] = dryRun, ["results"] = results };

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, aborted: {ex.Message}"); }
                }

                void Classify(Action<long, Element> tallyCompound, Action<long, Element> tallyParam, Action<long, Element> tallyGeom)
                {
                    foreach (Element el in new FilteredElementCollector(doc).WhereElementIsElementType())
                    {
                        if (el is not ElementType type) continue;
                        var viaCompound = new HashSet<long>();
                        var viaParam = new HashSet<long>();
                        try
                        {
                            var cs = (type as HostObjAttributes)?.GetCompoundStructure();
                            if (cs != null)
                                foreach (var layer in cs.GetLayers())
                                    if (layer.MaterialId != null && map.ContainsKey(layer.MaterialId.Value)) viaCompound.Add(layer.MaterialId.Value);
                        }
                        catch { }
                        try
                        {
                            foreach (Parameter par in type.Parameters)
                            {
                                if (par.StorageType != StorageType.ElementId) continue;
                                var vid = par.AsElementId();
                                if (vid != null && map.ContainsKey(vid.Value)) viaParam.Add(vid.Value);
                            }
                        }
                        catch { }
                        var geom = new HashSet<long>();
                        try { foreach (var mid in type.GetMaterialIds(false)) if (map.ContainsKey(mid.Value)) geom.Add(mid.Value); } catch { }
                        foreach (var s in viaCompound) tallyCompound(s, type);
                        foreach (var s in viaParam) tallyParam(s, type);
                        // geometry-only = reachable via GetMaterialIds but NOT via compound/param -> family-internal
                        foreach (var s in geom) if (!viaCompound.Contains(s) && !viaParam.Contains(s)) tallyGeom(s, type);
                    }
                }

                void AddName(long s, Element t)
                {
                    var row = rowBySource[s];
                    var names = (List<string>)row["unreachable_names"]!;
                    if (names.Count < 15)
                    {
                        string fam = ""; try { if (t is FamilySymbol fs) fam = fs.FamilyName + ": "; } catch { }
                        names.Add(fam + t.Name);
                    }
                    row["unreachable_types"] = (int)row["unreachable_types"]! + 1;
                }

                Action<Transaction?> mutate = (t) =>
                {
                    // reassign compound + params (mutating when a transaction is supplied)
                    foreach (Element el in new FilteredElementCollector(doc).WhereElementIsElementType())
                    {
                        if (el is not ElementType type) continue;
                        try
                        {
                            var cs = (type as HostObjAttributes)?.GetCompoundStructure();
                            if (cs != null)
                            {
                                bool changed = false;
                                var layers = cs.GetLayers();
                                for (int i = 0; i < layers.Count; i++)
                                {
                                    var mid = layers[i].MaterialId;
                                    if (mid != null && map.TryGetValue(mid.Value, out var tgt))
                                    {
                                        cs.SetMaterialId(layers[i].LayerId, tgt);
                                        rowBySource[mid.Value]["reassigned_compound"] = (int)rowBySource[mid.Value]["reassigned_compound"]! + 1;
                                        changed = true;
                                    }
                                }
                                if (changed && t != null) (type as HostObjAttributes)!.SetCompoundStructure(cs);
                            }
                        }
                        catch { }
                        try
                        {
                            foreach (Parameter par in type.Parameters)
                            {
                                if (par.StorageType != StorageType.ElementId || par.IsReadOnly) continue;
                                var vid = par.AsElementId();
                                if (vid != null && map.TryGetValue(vid.Value, out var tgt))
                                {
                                    if (t != null) par.Set(tgt);
                                    rowBySource[vid.Value]["reassigned_params"] = (int)rowBySource[vid.Value]["reassigned_params"]! + 1;
                                }
                            }
                        }
                        catch { }
                    }
                };

                // classify unreachable (family-internal) refs first — independent of mutation
                Classify((s, t) => { }, (s, t) => { }, AddName);

                var deleted = new List<long>();
                if (dryRun)
                {
                    // count would-reassign without mutating
                    mutate(null);
                    foreach (var kv in rowBySource)
                    {
                        bool canDelete = (int)kv.Value["unreachable_types"]! == 0;
                        kv.Value["status"] = canDelete ? "would_replace_and_delete" : "would_replace_keep_source";
                    }
                }
                else
                {
                    using var t = new Transaction(doc, "NLRS replace material");
                    t.Start();
                    mutate(t);
                    foreach (var kv in rowBySource)
                    {
                        bool canDelete = (int)kv.Value["unreachable_types"]! == 0;
                        if (canDelete)
                        {
                            try { doc.Delete(new ElementId(kv.Key)); deleted.Add(kv.Key); kv.Value["status"] = "replaced_and_deleted"; }
                            catch (Exception ex) { kv.Value["status"] = "replaced_delete_failed"; kv.Value["error"] = ex.Message; }
                        }
                        else kv.Value["status"] = "replaced_kept_source";
                    }
                    t.Commit();
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup,
                    ["replaced"] = rowBySource.Count, ["deleted"] = deleted.Count,
                    ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static string? GetProp(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
