using System.Globalization;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>Gedeelde hulpjes: parameters uit het JSON-verzoek lezen, documenten en elementen opzoeken, failures afvangen.</summary>
internal static class HandlerUtil
{
    // ── JSON param readers ──────────────────────────────────────────────────
    public static string? Str(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    public static bool Bool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    public static string? Str(JsonElement o, string key)
        => o.ValueKind == JsonValueKind.Object && o.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String
           && !string.IsNullOrWhiteSpace(el.GetString()) ? el.GetString() : null;

    public static bool? Bool(JsonElement o, string key)
    {
        if (o.ValueKind == JsonValueKind.Object && o.TryGetProperty(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return null;
    }

    public static int? Int(JsonElement o, string key)
        => o.ValueKind == JsonValueKind.Object && o.TryGetProperty(key, out var el)
           && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v) ? v : null;

    public static double? Dbl(JsonElement o, string key)
        => o.ValueKind == JsonValueKind.Object && o.TryGetProperty(key, out var el)
           && el.ValueKind == JsonValueKind.Number ? el.GetDouble() : null;

    public static List<JsonElement> Arr(Dictionary<string, JsonElement>? p, string key)
        => p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array
           ? el.EnumerateArray().ToList() : new List<JsonElement>();

    // ── colours ("RRGGBB" / "#RRGGBB") ──────────────────────────────────────
    public static Color? Colour(JsonElement o, string key)
    {
        var s = Str(o, key);
        if (s == null) return null;
        s = s.TrimStart('#');
        if (s.Length != 6 || !int.TryParse(s, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out _))
            return null;
        byte r = byte.Parse(s.Substring(0, 2), NumberStyles.HexNumber);
        byte g = byte.Parse(s.Substring(2, 2), NumberStyles.HexNumber);
        byte b = byte.Parse(s.Substring(4, 2), NumberStyles.HexNumber);
        return new Color(r, g, b);
    }

    // ── Revit lookups ───────────────────────────────────────────────────────
    public static Document? FindDoc(Autodesk.Revit.UI.UIApplication app, string title)
    {
        // 1. Exacte titel. Een open model gaat voor een geladen link met dezelfde titel; is er alleen een
        //    link met precies die titel, dan die (zo deed de oorspronkelijke opzoeking het ook).
        Document? link = null;
        foreach (Document d in app.Application.Documents)
            if (d.Title == title) { if (!d.IsLinked) return d; link ??= d; }
        if (link != null) return link;
        // 2. Titel zonder extensie, hoofdletterongevoelig (Windows toont .rvt soms wel, soms niet in de titel).
        //    Alleen open modellen, geen links, en alleen bij precies één kandidaat; anders een fout met de kandidaten.
        string Kaal(string s) => System.IO.Path.GetExtension(s).ToLowerInvariant() is ".rvt" or ".rfa" or ".rte" or ".rft"
            ? System.IO.Path.GetFileNameWithoutExtension(s) : s;
        var kandidaten = new List<Document>();
        foreach (Document d in app.Application.Documents)
            if (!d.IsLinked && string.Equals(Kaal(d.Title), Kaal(title), StringComparison.OrdinalIgnoreCase)) kandidaten.Add(d);
        if (kandidaten.Count == 1) return kandidaten[0];
        if (kandidaten.Count > 1)
            throw new InvalidOperationException($"'{title}' past op meer open modellen: "
                + string.Join(", ", kandidaten.Select(d => $"'{d.Title}'")) + ". Geef de exacte titel.");
        return null;
    }

    public static int? Int(Dictionary<string, JsonElement>? p, string key)
        => p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v) ? v : null;

    public static double? Dbl(Dictionary<string, JsonElement>? p, string key)
        => p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number ? el.GetDouble() : null;

    public static List<string> StrList(Dictionary<string, JsonElement>? p, string key)
        => Arr(p, key).Where(e => e.ValueKind == JsonValueKind.String).Select(e => e.GetString()!)
                      .Where(s => !string.IsNullOrWhiteSpace(s)).ToList();

    public static List<long> LongList(Dictionary<string, JsonElement>? p, string key)
        => Arr(p, key).Where(e => e.ValueKind == JsonValueKind.Number).Select(e => e.GetInt64()).ToList();

    /// <summary>Failures tijdens een transactie: waarschuwingen wegwerken en meenemen in het antwoord, fouten laten terugdraaien.</summary>
    public sealed class FailureVerzamelaar : IFailuresPreprocessor
    {
        public List<string> Meldingen { get; } = new();
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            bool fout = false;
            foreach (var f in fa.GetFailureMessages())
            {
                try { Meldingen.Add($"{f.GetSeverity()}: {f.GetDescriptionText()}"); } catch { }
                if (f.GetSeverity() == FailureSeverity.Warning) fa.DeleteWarning(f);
                else fout = true;
            }
            // Een fout zonder antwoord zou een dialoog in Revit openen die de bridge blokkeert: dan terugdraaien.
            return fout ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
        }
    }

    public static FailureVerzamelaar ZetFailureVerzamelaar(Transaction t)
    {
        var fv = new FailureVerzamelaar();
        var o = t.GetFailureHandlingOptions();
        o.SetFailuresPreprocessor(fv);
        o.SetClearAfterRollback(true);
        t.SetFailureHandlingOptions(o);
        return fv;
    }

    public static ElementId FillPatternIdByName(Document doc, string name)
    {
        foreach (var fp in new FilteredElementCollector(doc).OfClass(typeof(FillPatternElement)).Cast<FillPatternElement>())
            if (fp.Name == name) return fp.Id;
        return ElementId.InvalidElementId;
    }

    public static Material? MaterialByName(Document doc, string name)
        => new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>()
               .FirstOrDefault(m => m.Name == name);

    // A non-template view by element_id (Fid string) or by exact name.
    public static View? FindView(Document doc, string? idStr, string? name)
    {
        if (idStr != null && long.TryParse(idStr, out var v) && doc.GetElement(new ElementId(v)) is View byId && !byId.IsTemplate)
            return byId;
        if (name != null)
            return new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
                       .FirstOrDefault(vw => !vw.IsTemplate && vw.Name == name);
        return null;
    }
}
