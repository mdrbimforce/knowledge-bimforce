using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;

namespace RevitAgent.Addin;

/// <summary>
/// connect_to_pipe — een open leidingeinde (End-connector van een Pipe of fitting) aansluiten op een bestaande leiding
/// (de hoofdleiding) met een Tap (laszadel, NewTakeoffFitting) of een T-stuk (BreakCurve + NewTeeFitting).
/// Voor de NLRS Onderwijsmodellen: radiatoraftakkingen op de stalen CV-straat, stijgleiding op hoofdleiding,
/// HWA-standleidingen op grondleidingen.
///
/// params: target_document (verplicht), dry_run (default TRUE), min_fitting_distance_mm (default 150),
///         connections:[{branch_id, main_id, branch_end?: "open"|"start"|"end" (default open), mode?: "tap"|"tee"|"wye"|"auto"
///                       (default auto), extend?: bool (default true), main_flow?: "curve"|"reverse" (alleen wye)}].
///
/// Geometrie per verbinding. E = open einde, a = richting van de aftakking naar buiten, Q = loodrechte projectie op de
/// hartlijn van de hoofdleiding. Het laatste stuk komt altijd loodrecht op de hoofdleiding uit, met het einde op de hartlijn:
///   direct           — E ligt al op de hartlijn (alleen een Pipe als aftakking).
///   verlengen        — de aftakking wijst loodrecht op de hartlijn af: de leiding wordt verlengd tot Q (bij een fitting
///                      als aftakking: een nieuwe leiding vanaf de connector).
///   verlengen_en_val — de aftakking staat loodrecht op de hoofdleiding maar kruist hem op afstand (hoger/lager): verlengen
///                      tot P recht boven/naast Q, dan een stuk P→Q met een bocht in P.
///   val / haaks_stuk — een stuk E→Q (loodrecht op de hoofdleiding) met een bocht in E; val = bocht van 90°.
///                      Niet voor een fitting als aftakking (eerst een leiding maken).
///   Geweigerd: aftakking evenwijdig aan de hoofdleiding, of wijst ervan af (bocht &gt; 90° nodig).
/// Nieuwe stukken krijgen type, systeem, level en diameter van de aftakking; bochten volgen de routing preference.
///
/// Mode. tap: NewTakeoffFitting(connector van het laatste stuk, hoofdleiding). Eerst met het einde op de hartlijn; mislukt dat,
/// dan nog eens met het einde ingekort tot de buiswand. tee: BreakCurve op Q (commit), dan in een EIGEN transactie
/// NewTeeFitting(beide helften, aftakking); een directe pipe-op-pipe-koppeling van BreakCurve wordt eerst losgemaakt.
/// auto: tap als het leidingtype van de aftakking of van de hoofdleiding een Junctions-regel met een tap-onderdeel
/// (PartType Tap*/Spud*) heeft en de aftakking kleiner is dan de hoofdleiding; mislukt de tap, dan terugval op tee.
/// wye: Y-stuk. Het laatste stuk komt onder 45° stroomafwaarts op de hartlijn uit: Q = projectie van E plus
/// (afstand E tot de as) langs de stroomrichting (main_flow: "curve" = richting van de hoofdleidingcurve, default, of
/// "reverse"). Methode wye_verlengen (de aftakking wijst al onder 45° naar Q: verlengen) of wye_stuk (stuk E→Q met een bocht
/// in E, alleen een Pipe als aftakking; bocht &gt; 90° geweigerd). Daarna BreakCurve (eigen transactie) en NewTeeFitting in een
/// eigen transactie; Revit kiest het onderdeel uit de Junctions-regels. Is het geplaatste onderdeel geen PartType
/// Wye/LateralTee, dan rolt de verbinding terug met die reden. Vooraf geweigerd zonder Y-stuk in de Junctions-regels van een
/// van beide types; waarschuwing als een T-stuk-regel boven de Y-stuk-regel staat. Niet live getoetst.
/// Niet alleen het hoofdleidingtype telt: NewTakeoffFitting eist de
/// tap-regel op het PipeType van de aftakking, niet van de romp. Daarom worden beide gemeld en beide geaccepteerd; auto valt
/// terug op een T-stuk als Revit de tap weigert.
///
/// Weigeren (status geweigerd, met reden en ids): aftakking al verbonden of geen vrij leidingeinde; hoofdleiding geen Pipe of
/// een placeholder; projectiepunt buiten de hoofdleiding of minder dan min_fitting_distance_mm van een einde of van een
/// fitting/tap op de hoofdleiding; systeemtype van aftakking en hoofdleiding verschilt (aanvoer/retour); extend=false terwijl
/// verlengen nodig is; tap gevraagd zonder tap-regel of met een aftakking groter dan de hoofdleiding; bocht nodig zonder
/// Elbows-regel.
///
/// Transacties: per verbinding één TransactionGroup (één ongedaan-maakstap; een fout rolt alleen deze verbinding terug) met
/// gescheiden transacties: geometrie | tap | knip | T-stuk. Nooit een fitting in dezelfde transactie als BreakCurve.
/// Elke transactie heeft de stille failure-preprocessor (warnings weg, errors → rollback, geen modale dialoog).
/// Read-back na commit: de connector van de aftakking moet verbonden zijn met een fitting; anders gaat de hele groep terug.
/// Volgt een verbinding op een hoofdleiding die in dezelfde aanroep al geknipt is, dan zoekt hij het deelstuk waarop Q valt.
///
/// Resultaat per verbinding: {index, status: plan|verbonden|geweigerd|mislukt, branch_id, main_id_gevraagd, main_id, mode_gevraagd,
/// mode (gepland), mode_gebruikt, methode, open_einde_mm, projectiepunt_mm, afstand_mm (open einde → hartlijn),
/// afstand_buiswand_mm, verlenging_mm, val_mm, bochthoek_graden, diameters, types, systemen, tap_regels, fitting_id,
/// fitting_type, verlengstukken, bochten, hoofdleiding_na_knip, waarschuwingen, fouten, meldingen}. Totalen in tellers;
/// dialogs_dismissed/dialogs_notable van de DialogSwallowScope. Coördinaten in mm, interne coördinaten, z absoluut.
/// </summary>
public static partial class MepModelHandlers
{
    private const double LoodTol = 1e-3;        // |cos| tussen aftakking en hoofdleiding: loodrecht binnen ~0,06°
    private const double EvenwijdigTol = 1e-6;  // 1 - |cos|: evenwijdig

    private static readonly PartType[] TapParts =
        { PartType.TapPerpendicular, PartType.TapAdjustable, PartType.SpudPerpendicular, PartType.SpudAdjustable };

    public static CommandResponse ConnectToPipe(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var conIn = HandlerUtil.Arr(p, "connections").Select(r => r.Clone()).ToList();
        if (conIn.Count == 0) return Err("connections:[{branch_id, main_id, branch_end?, mode?, extend?}] is verplicht");
        double minFitMm = (p != null && p.TryGetValue("min_fitting_distance_mm", out var mfe) ? NumEl(mfe) : null) ?? 150.0;
        if (minFitMm < 0) return Err("min_fitting_distance_mm moet >= 0 zijn");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                if (!dryRun && doc.IsReadOnly) return (object)Fail("target_document is alleen-lezen");
                if (!dryRun && doc.IsModifiable) return (object)Fail("er staat al een transactie open in target_document");

                using var swallow = new DialogSwallowScope(app) { Context = "connect_to_pipe" };
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var familie = new Dictionary<long, HashSet<long>>();          // id → alle deelstukken van dezelfde hoofdleiding
                var gepland = new List<(HashSet<long> fam, XYZ q, int index)>(); // dry-run: geplande aansluitpunten
                int nTap = 0, nTee = 0, nWye = 0;

                for (int i = 0; i < conIn.Count; i++)
                {
                    var it = conIn[i];
                    var fouten = new List<string>();
                    var waarsch = new List<string>();
                    var rmeld = new List<string>();
                    var row = new Dictionary<string, object?>
                    {
                        ["index"] = i, ["status"] = "geweigerd", ["fouten"] = fouten, ["waarschuwingen"] = waarsch, ["meldingen"] = rmeld,
                    };
                    results.Add(row);
                    swallow.Context = $"connect_to_pipe #{i}";
                    try
                    {
                        var pl = PlanAftakking(doc, it, familie, minFitMm / MM, row, fouten, waarsch);
                        if (pl == null) { row["status"] = "geweigerd"; continue; }

                        // binnen deze aanroep: twee aansluitpunten te dicht bij elkaar op dezelfde hoofdleiding
                        var fam = Familie(familie, pl.MainId.Value);
                        foreach (var (f2, q2, k) in gepland)
                            if (ReferenceEquals(f2, fam) && Math.Abs((q2 - pl.Q).DotProduct(pl.D)) < minFitMm / MM && q2.DistanceTo(pl.Q) < 1.0)
                                waarsch.Add($"ligt {R(Math.Abs((q2 - pl.Q).DotProduct(pl.D)) * MM)} mm van het aansluitpunt van verbinding #{k} in deze aanroep" +
                                            (dryRun ? " (bij uitvoeren wordt deze geweigerd)" : ""));
                        gepland.Add((fam, pl.Q, i));

                        if (dryRun) { row["status"] = "plan"; continue; }

                        bool ok = ExecuteAftakking(doc, pl, i, row, fouten, rmeld, familie);
                        row["status"] = ok ? "verbonden" : "mislukt";
                        if (ok && (string?)row["mode_gebruikt"] == "tap") nTap++;
                        if (ok && (string?)row["mode_gebruikt"] == "tee") nTee++;
                        if (ok && (string?)row["mode_gebruikt"] == "wye") nWye++;
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); row["status"] = dryRun ? "geweigerd" : "mislukt"; }
                    finally { meldingen.AddRange(rmeld); }
                }

                if (dryRun) notes.Add("dry_run: niets gewijzigd; status plan = wat er zou gebeuren (methode, mode, projectiepunt, verlenging)");
                notes.Add("mm, interne coördinaten, z absoluut. afstand_mm = open einde tot de hartlijn van de hoofdleiding");
                notes.Add("auto: tap als een van beide leidingtypes een tap-regel heeft en de aftakking kleiner is; anders, of als Revit de tap weigert, een T-stuk");
                var res = new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["gevraagd"] = conIn.Count,
                    ["tellers"] = results.GroupBy(r => (string?)r["status"] ?? "?").ToDictionary(g => g.Key, g => g.Count()),
                    ["fittings"] = new Dictionary<string, int> { ["tap"] = nTap, ["tee"] = nTee, ["wye"] = nWye },
                    ["results"] = results,
                    ["failure_meldingen"] = meldingen.Take(100).ToList(),
                    ["notes"] = notes,
                };
                swallow.WriteTo(res);
                return (object)res;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private sealed class AftakPlan
    {
        public long BranchId, MainGevraagd;
        public bool BranchIsPipe;
        public int BranchConnId = -1;
        public XYZ E = null!, A = null!;         // open einde, richting naar buiten
        public XYZ Q = null!;                    // aansluitpunt op de hartlijn
        public XYZ? P;                           // knik bij verlengen_en_val
        public XYZ D = null!, M0 = null!;        // hartlijn hoofdleiding (deelstuk MainId)
        public ElementId MainId = ElementId.InvalidElementId;
        public string Method = "";               // direct | verlengen | verlengen_en_val | val | haaks_stuk
        public string Mode = "tee";              // tap | tee
        public bool TeeFallback;
        public double BranchDiam, MainOuter;
        public ElementId PipeTypeId = ElementId.InvalidElementId, SystemTypeId = ElementId.InvalidElementId, LevelId = ElementId.InvalidElementId;
    }

    private static HashSet<long> Familie(Dictionary<long, HashSet<long>> familie, long id)
    {
        if (!familie.TryGetValue(id, out var set)) { set = new HashSet<long> { id }; familie[id] = set; }
        return set;
    }

    /// <summary>Alle controles en het plan; null = geweigerd (reden in fouten). Geen transactie.</summary>
    private static AftakPlan? PlanAftakking(Document doc, JsonElement it, Dictionary<long, HashSet<long>> familie, double minFit,
                                            Dictionary<string, object?> row, List<string> fouten, List<string> waarsch)
    {
        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("verbinding is geen object"); return null; }
        long? bid = LongProp(it, "branch_id");
        long? mid = LongProp(it, "main_id");
        string end = (HandlerUtil.Str(it, "branch_end") ?? "open").Trim().ToLowerInvariant();
        string modeReq = (HandlerUtil.Str(it, "mode") ?? "auto").Trim().ToLowerInvariant();
        bool extend = HandlerUtil.Bool(it, "extend") ?? true;
        row["branch_id"] = bid; row["main_id_gevraagd"] = mid; row["branch_end"] = end; row["mode_gevraagd"] = modeReq; row["extend"] = extend;
        if (bid == null) fouten.Add("branch_id ontbreekt");
        if (mid == null) fouten.Add("main_id ontbreekt");
        if (end is not ("open" or "start" or "end")) fouten.Add($"branch_end '{end}' onbekend (open|start|end)");
        if (modeReq is not ("auto" or "tap" or "tee" or "wye")) fouten.Add($"mode '{modeReq}' onbekend (auto|tap|tee|wye)");
        string flow = (HandlerUtil.Str(it, "main_flow") ?? "curve").Trim().ToLowerInvariant();
        if (modeReq == "wye" && flow is not ("curve" or "reverse")) fouten.Add($"main_flow '{flow}' onbekend (curve|reverse)");
        if (fouten.Count > 0) return null;

        var pl = new AftakPlan { BranchId = bid!.Value, MainGevraagd = mid!.Value };
        var fam = Familie(familie, mid.Value);
        if (fam.Contains(bid.Value)) { fouten.Add("branch_id en main_id zijn (delen van) hetzelfde element"); return null; }

        // ── hoofdleiding (eerste controle; het deelstuk volgt na het open einde) ──
        var mainReq = doc.GetElement(new ElementId(mid.Value));
        var mainParts = fam.Select(x => doc.GetElement(new ElementId(x))).OfType<Pipe>().ToList();
        if (mainParts.Count == 0)
        {
            if (mainReq == null) fouten.Add($"hoofdleiding {mid} niet gevonden");
            else fouten.Add($"hoofdleiding {mid} is geen Pipe ({mainReq.Category?.Name ?? mainReq.GetType().Name})");
            return null;
        }
        if (mainParts.Any(m => m.IsPlaceholder)) { fouten.Add($"hoofdleiding {mid} is een placeholder"); return null; }

        // ── aftakking en open einde ──
        var bel = doc.GetElement(new ElementId(bid.Value));
        if (bel == null) { fouten.Add($"aftakking {bid} niet gevonden"); return null; }
        Line? bline = null;
        if (bel is Pipe bp)
        {
            if (bp.IsPlaceholder) { fouten.Add($"aftakking {bid} is een placeholder"); return null; }
            bline = (bp.Location as LocationCurve)?.Curve as Line;
            if (bline == null) { fouten.Add($"aftakking {bid} is geen rechte leiding"); return null; }
            pl.BranchIsPipe = true;
        }
        else if (bel is FamilyInstance fi && fi.MEPModel?.ConnectorManager != null) pl.BranchIsPipe = false;
        else { fouten.Add($"aftakking {bid} is geen Pipe of fitting ({bel.Category?.Name ?? bel.GetType().Name})"); return null; }

        var piping = EndConnectors(bel).Where(c => { try { return c.Domain == Domain.DomainPiping; } catch { return false; } }).ToList();
        if (piping.Count == 0) { fouten.Add($"aftakking {bid} heeft geen leidingconnectors"); return null; }

        var refMain = mainParts.First();
        var refLine = (refMain.Location as LocationCurve)?.Curve as Line;
        if (refLine == null) { fouten.Add($"hoofdleiding {refMain.Id.Value} is geen rechte leiding"); return null; }

        Connector bc;
        if (end == "open")
        {
            var free = piping.Where(c => !c.IsConnected).ToList();
            if (free.Count == 0)
            {
                fouten.Add($"aftakking {bid} heeft geen vrij leidingeinde (al verbonden met {string.Join(", ", piping.SelectMany(RefOwners).Distinct())})");
                return null;
            }
            bc = free.OrderBy(c => DistToSegment(c.Origin, refLine)).First();
        }
        else
        {
            if (bline == null) { fouten.Add("branch_end start/end kan alleen bij een Pipe; gebruik open voor een fitting"); return null; }
            var ep = bline.GetEndPoint(end == "start" ? 0 : 1);
            bc = piping.OrderBy(c => c.Origin.DistanceTo(ep)).First();
            if (bc.IsConnected) { fouten.Add($"aftakking {bid}: het {end}-einde is al verbonden met {string.Join(", ", RefOwners(bc))}"); return null; }
        }
        pl.BranchConnId = bc.Id;
        pl.E = bc.Origin;
        if (bline != null)
        {
            var e0 = bline.GetEndPoint(0); var e1 = bline.GetEndPoint(1);
            var other = e0.DistanceTo(pl.E) <= e1.DistanceTo(pl.E) ? e1 : e0;
            pl.A = (pl.E - other).Normalize();
        }
        else
        {
            try { pl.A = bc.CoordinateSystem.BasisZ.Normalize(); }
            catch { fouten.Add($"aftakking {bid}: richting van de connector onbekend"); return null; }
        }
        row["open_einde_mm"] = Mm3(pl.E);
        row["richting_aftakking"] = Vec(pl.A);

        // ── deelstuk van de hoofdleiding waarop de projectie valt ──
        Pipe? main = null; Line? mline = null; double bestDist = double.MaxValue;
        foreach (var m in mainParts)
        {
            if ((m.Location as LocationCurve)?.Curve is not Line ml) continue;
            var d0 = ml.Direction.Normalize(); var m0 = ml.GetEndPoint(0);
            double t = (pl.E - m0).DotProduct(d0);
            if (t < -Tol || t > ml.Length + Tol) continue;
            double dist = (pl.E - (m0 + d0 * t)).GetLength();
            if (dist < bestDist) { bestDist = dist; main = m; mline = ml; }
        }
        if (main == null || mline == null)
        {
            var d0 = refLine.Direction.Normalize();
            double t = (pl.E - refLine.GetEndPoint(0)).DotProduct(d0);
            fouten.Add($"projectiepunt ligt buiten de hoofdleiding {mid}" + (mainParts.Count > 1 ? $" en haar {mainParts.Count - 1} deelstukken" : "") +
                       $" ({R(t * MM)} mm langs de as, lengte {R(refLine.Length * MM)} mm)");
            return null;
        }
        pl.MainId = main.Id;
        pl.D = mline.Direction.Normalize();
        pl.M0 = mline.GetEndPoint(0);
        row["main_id"] = main.Id.Value;
        if (main.Id.Value != mid.Value) waarsch.Add($"hoofdleiding {mid} is in deze aanroep geknipt; aansluiting op deelstuk {main.Id.Value}");

        // ── methode ──
        XYZ Proj(XYZ x) => pl.M0 + pl.D * (x - pl.M0).DotProduct(pl.D);
        var q0 = Proj(pl.E);
        var r = pl.E - q0;
        double afstand = r.GetLength();
        pl.MainOuter = OuterDiameter(main);
        row["afstand_mm"] = R(afstand * MM);
        row["afstand_buiswand_mm"] = R((afstand - pl.MainOuter / 2) * MM);
        double ad = pl.A.DotProduct(pl.D);
        double verlenging = 0, val = 0, hoek = 0;
        if (modeReq == "wye")
        {
            // Y-stuk: het laatste stuk komt onder 45° stroomafwaarts op de hartlijn uit (afstand langs de as = afstand tot de as)
            if (afstand <= Tol) { fouten.Add("mode wye: open einde ligt al op de hartlijn; een Y-stuk vraagt een aanloop onder 45°"); return null; }
            if (!extend) { fouten.Add("mode wye vraagt een stuk naar de hartlijn en extend=false"); return null; }
            var stroom = flow == "reverse" ? -pl.D : pl.D;
            pl.Q = q0 + stroom * afstand;
            var w = (pl.Q - pl.E).Normalize();
            double aw = pl.A.DotProduct(w);
            row["main_flow"] = flow;
            if (aw > 1 - 1e-4)
            {
                pl.Method = "wye_verlengen"; verlenging = pl.E.DistanceTo(pl.Q);
            }
            else
            {
                if (!pl.BranchIsPipe) { fouten.Add($"aftakking {bid} is een fitting die niet onder 45° naar de hoofdleiding wijst; maak eerst een leiding vanaf de fitting"); return null; }
                if (aw < -1e-6) { fouten.Add($"mode wye: aftakking wijst van het aansluitpunt af; bocht van {R(Math.Acos(Math.Clamp(aw, -1, 1)) * 180 / Math.PI)}° nodig (> 90°); probeer main_flow {(flow == "curve" ? "reverse" : "curve")}"); return null; }
                pl.Method = "wye_stuk"; val = pl.E.DistanceTo(pl.Q); hoek = Math.Acos(Math.Clamp(aw, -1, 1)) * 180 / Math.PI;
            }
        }
        else if (afstand <= Tol)
        {
            if (!pl.BranchIsPipe) { fouten.Add("open einde van een fitting ligt al op de hartlijn; tap en T-stuk vragen een leidingconnector"); return null; }
            pl.Method = "direct"; pl.Q = q0;
        }
        else
        {
            if (!extend) { fouten.Add($"open einde ligt {R(afstand * MM)} mm van de hartlijn en extend=false"); return null; }
            if (Math.Abs(ad) > 1 - EvenwijdigTol) { fouten.Add("aftakking loopt evenwijdig aan de hoofdleiding"); return null; }
            var n = (q0 - pl.E).Normalize();
            if (Math.Abs(ad) < LoodTol)
            {
                double s = (q0 - pl.E).DotProduct(pl.A);
                var rperp = r - pl.A * r.DotProduct(pl.A);
                if (s < -Tol && rperp.GetLength() <= Tol) { fouten.Add($"aftakking wijst van de hoofdleiding af (hoofdleiding ligt {R(-s * MM)} mm achter het open einde)"); return null; }
                if (rperp.GetLength() <= Tol && s > Tol)
                {
                    pl.Method = "verlengen"; pl.Q = Proj(pl.E + pl.A * s); verlenging = s;
                }
                else if (s > Tol)
                {
                    pl.Method = "verlengen_en_val"; pl.P = pl.E + pl.A * s; pl.Q = Proj(pl.P);
                    verlenging = s; val = pl.P.DistanceTo(pl.Q); hoek = 90;
                }
                else if (s >= -Tol)
                {
                    pl.Method = "val"; pl.Q = q0; val = afstand; hoek = 90;
                }
                else { fouten.Add($"aftakking wijst van de hoofdleiding af ({R(-s * MM)} mm terug); bocht > 90° nodig"); return null; }
            }
            else
            {
                double cos = pl.A.DotProduct(n);
                if (cos < -1e-6) { fouten.Add($"aftakking wijst van de hoofdleiding af; haaks stuk vraagt een bocht van {R(Math.Acos(Math.Clamp(cos, -1, 1)) * 180 / Math.PI)}°"); return null; }
                pl.Method = "haaks_stuk"; pl.Q = q0; val = afstand; hoek = Math.Acos(Math.Clamp(cos, -1, 1)) * 180 / Math.PI;
                waarsch.Add($"aftakking staat niet loodrecht op de hoofdleiding (hoek met de as {R(Math.Acos(Math.Clamp(Math.Abs(ad), 0, 1)) * 180 / Math.PI)}°): haaks stuk met een bocht van {R(hoek)}°");
            }
            if (!pl.BranchIsPipe && pl.Method is "val" or "haaks_stuk")
            { fouten.Add($"aftakking {bid} is een fitting die niet naar de hoofdleiding wijst ({pl.Method}); maak eerst een leiding vanaf de fitting"); return null; }
        }
        row["methode"] = pl.Method;
        row["projectiepunt_mm"] = Mm3(pl.Q);
        row["knik_mm"] = pl.P == null ? null : Mm3(pl.P);
        row["verlenging_mm"] = R(verlenging * MM);
        row["val_mm"] = R(val * MM);
        row["bochthoek_graden"] = hoek > 0 ? R(hoek) : null;
        if (verlenging * MM > 1000) waarsch.Add($"verlenging van {R(verlenging * MM)} mm (loopt mogelijk door een wand)");

        // ── afstand tot einden en fittingen op de hoofdleiding ──
        double tq = (pl.Q - pl.M0).DotProduct(pl.D);
        double len = mline.Length;
        row["positie_langs_hoofdleiding_mm"] = R(tq * MM);
        foreach (var (tEnd, label) in new[] { (tq, "begin"), (len - tq, "eind") })
        {
            if (tEnd >= minFit) continue;
            var ec = ConnectorAt(main, label == "begin" ? mline.GetEndPoint(0) : mline.GetEndPoint(1));
            var buren = ec != null && ec.IsConnected ? RefOwners(ec).ToList() : new List<long>();
            fouten.Add($"aansluitpunt ligt {R(tEnd * MM)} mm van het {label} van hoofdleiding {main.Id.Value} (minimaal {R(minFit * MM)} mm)" +
                       (buren.Count > 0 ? $"; daar zit {string.Join(", ", buren)}" : ""));
        }
        foreach (var (fid, tf) in FittingsOpHoofdleiding(doc, main, mline, pl.MainOuter))
        {
            double dd = Math.Abs(tf - tq);
            if (dd < minFit) fouten.Add($"aansluitpunt ligt {R(dd * MM)} mm van fitting {fid} op de hoofdleiding (minimaal {R(minFit * MM)} mm)");
        }

        // ── systemen, types, diameters ──
        var mainSys = ParamId(main, BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM);
        ElementId branchSys = ElementId.InvalidElementId;
        if (bel is Pipe bpp) branchSys = ParamId(bpp, BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM);
        else { try { branchSys = bc.MEPSystem?.GetTypeId() ?? ElementId.InvalidElementId; } catch { } }
        row["systemen"] = new Dictionary<string, object?> { ["aftakking"] = NameOf(doc, branchSys), ["hoofdleiding"] = NameOf(doc, mainSys) };
        if (branchSys != ElementId.InvalidElementId && mainSys != ElementId.InvalidElementId && branchSys != mainSys)
            fouten.Add($"systeemtype verschilt: aftakking '{NameOf(doc, branchSys)}', hoofdleiding '{NameOf(doc, mainSys)}'");
        else if (branchSys == ElementId.InvalidElementId || mainSys == ElementId.InvalidElementId)
            waarsch.Add("systeemtype van aftakking of hoofdleiding onbekend; niet vergeleken");
        pl.SystemTypeId = branchSys != ElementId.InvalidElementId ? branchSys : mainSys;

        pl.PipeTypeId = bel is Pipe bpt ? bpt.GetTypeId() : NeighbourPipeType(doc, bel) ?? ElementId.InvalidElementId;
        if (pl.PipeTypeId == ElementId.InvalidElementId)
        {
            pl.PipeTypeId = main.GetTypeId();
            if (pl.Method != "direct") waarsch.Add($"leidingtype van de fitting-aftakking onbekend; nieuwe stukken krijgen het type van de hoofdleiding");
        }
        var branchType = doc.GetElement(pl.PipeTypeId) as PipeType;
        var mainType = doc.GetElement(main.GetTypeId()) as PipeType;
        row["types"] = new Dictionary<string, object?> { ["aftakking"] = branchType?.Name, ["hoofdleiding"] = mainType?.Name };
        if (pl.PipeTypeId != main.GetTypeId()) waarsch.Add($"verschillende leidingtypes: aftakking '{branchType?.Name}', hoofdleiding '{mainType?.Name}'");

        pl.LevelId = (bel as MEPCurve)?.ReferenceLevel?.Id ?? main.ReferenceLevel?.Id ?? ElementId.InvalidElementId;
        if (pl.LevelId == ElementId.InvalidElementId && pl.Method != "direct") { fouten.Add("geen level voor nieuwe stukken"); }

        double mainDiam = main.Diameter;
        try { pl.BranchDiam = bc.Radius * 2; } catch { pl.BranchDiam = (bel as MEPCurve)?.Diameter ?? 0; }
        row["diameters"] = new Dictionary<string, object?>
        {
            ["aftakking_mm"] = R(pl.BranchDiam * MM), ["hoofdleiding_mm"] = R(mainDiam * MM), ["hoofdleiding_buiten_mm"] = R(pl.MainOuter * MM),
        };
        if (pl.BranchDiam > mainDiam + Tol) waarsch.Add($"diameter aftakking ({R(pl.BranchDiam * MM)}) > hoofdleiding ({R(mainDiam * MM)})");
        if (val > 0 && val < 2 * pl.BranchDiam + pl.MainOuter / 2)
            waarsch.Add($"{(pl.Method == "verlengen_en_val" ? "val" : "haaks stuk")} van {R(val * MM)} mm is kort: bocht en fitting passen mogelijk niet");

        if (pl.Method is "verlengen_en_val" or "val" or "haaks_stuk" or "wye_stuk" && branchType != null && !HasElbowRule(branchType))
            fouten.Add($"PipeType '{branchType.Name}' heeft geen Elbows-regel; de {pl.Method} vraagt een bocht");

        // ── mode ──
        var jb = JunctionInfo(doc, branchType);
        var jm = JunctionInfo(doc, mainType);
        row["tap_regels"] = new Dictionary<string, object?>
        {
            ["aftakking"] = new Dictionary<string, object?> { ["voorkeur"] = jb.pref, ["tap"] = jb.taps, ["tee"] = jb.tees },
            ["hoofdleiding"] = new Dictionary<string, object?> { ["voorkeur"] = jm.pref, ["tap"] = jm.taps, ["tee"] = jm.tees },
        };
        bool tapRegel = jb.taps.Count > 0 || jm.taps.Count > 0;
        bool kleiner = pl.BranchDiam < mainDiam - Tol;
        switch (modeReq)
        {
            case "wye":
            {
                var wb = WyeParts(doc, branchType); var wm = WyeParts(doc, mainType);
                ((Dictionary<string, object?>)row["tap_regels"]!)["wye"] = new Dictionary<string, object?> { ["aftakking"] = wb, ["hoofdleiding"] = wm };
                if (wb.Count == 0 && wm.Count == 0) fouten.Add("mode wye: geen Y-stuk (PartType Wye/LateralTee) in de Junctions-regels van het aftakking- of hoofdleidingtype");
                else if ((jm.tees.Count > 0 && JunctionIndexOf(doc, mainType, PartType.Tee) < JunctionIndexOf(doc, mainType, PartType.Wye, PartType.LateralTee)))
                    waarsch.Add("mode wye: in de Junctions-regels van de hoofdleiding staat een T-stuk boven het Y-stuk; Revit kiest mogelijk het T-stuk (dan teruggerold)");
                pl.Mode = "wye";
                break;
            }
            case "tap":
                if (!tapRegel) fouten.Add("mode tap: geen tap-onderdeel in de Junctions-regels van het aftakking- of hoofdleidingtype");
                if (pl.BranchDiam > mainDiam + Tol) fouten.Add("mode tap: aftakking is groter dan de hoofdleiding");
                else if (!kleiner) waarsch.Add("mode tap: aftakking even groot als de hoofdleiding; Revit kan de tap weigeren");
                pl.Mode = "tap";
                break;
            case "tee":
                pl.Mode = "tee";
                break;
            default:
                if (tapRegel && kleiner) { pl.Mode = "tap"; pl.TeeFallback = true; }
                else
                {
                    pl.Mode = "tee";
                    waarsch.Add(!tapRegel ? "auto: geen tap-regel in de leidingtypes → T-stuk" : "auto: aftakking niet kleiner dan de hoofdleiding → T-stuk");
                }
                break;
        }
        if (pl.Mode == "tap" && jb.taps.Count == 0 && jm.taps.Count > 0)
            waarsch.Add("alleen het hoofdleidingtype heeft een tap-regel; NewTakeoffFitting eist die volgens les 17-8 op het aftakkingstype" +
                        (pl.TeeFallback ? " (weigert Revit, dan T-stuk)" : ""));
        if (pl.Mode == "tee" && jb.tees.Count == 0 && jm.tees.Count == 0)
            waarsch.Add("geen T-stuk in de Junctions-regels van beide leidingtypes; NewTeeFitting kan mislukken");
        row["mode"] = pl.Mode;
        row["terugval_tee"] = pl.TeeFallback;

        return fouten.Count > 0 ? null : pl;
    }

    /// <summary>Uitvoeren in een TransactionGroup; false = teruggerold (reden in fouten).</summary>
    private static bool ExecuteAftakking(Document doc, AftakPlan pl, int i, Dictionary<string, object?> row, List<string> fouten,
                                         List<string> meld, Dictionary<long, HashSet<long>> familie)
    {
        var nieuweSeg = new List<ElementId>();
        var nieuweFit = new List<ElementId>();
        var tapPogingen = new List<string>();
        ElementId finalSeg = ElementId.InvalidElementId, fitting = ElementId.InvalidElementId, knipNieuw = ElementId.InvalidElementId;
        string? modeGebruikt = null, tapEind = null;
        var buren = new List<long>();
        var groupNotes = new List<string>();

        bool kept = RunGroup(doc, $"connect_to_pipe #{i}", groupNotes, () =>
        {
            // A: geometrie (verlengen, val, bocht)
            if (pl.Method == "direct") finalSeg = new ElementId(pl.BranchId);
            else
            {
                var (okA, nA) = RunTx(doc, $"connect_to_pipe #{i}: {pl.Method}", () =>
                {
                    nieuweSeg.Clear(); nieuweFit.Clear();
                    finalSeg = BouwAftakGeometrie(doc, pl, nieuweSeg, nieuweFit);
                }, meld);
                if (!okA) { fouten.Add($"{pl.Method} teruggerold: {nA}"); return false; }
                if (doc.GetElement(finalSeg) is not Pipe || nieuweSeg.Any(x => doc.GetElement(x) == null) || nieuweFit.Any(x => doc.GetElement(x) == null))
                { fouten.Add("read-back: verlengstuk of bocht ontbreekt na commit"); return false; }
            }

            // B: tap (eerst einde op de hartlijn, dan ingekort tot de buiswand)
            if (pl.Mode == "tap")
            {
                foreach (var buiswand in new[] { false, true })
                {
                    string eind = buiswand ? "buiswand" : "hartlijn";
                    ElementId fid = ElementId.InvalidElementId;
                    var (okB, nB) = RunTx(doc, $"connect_to_pipe #{i}: tap ({eind})", () => { fid = MaakTap(doc, pl, finalSeg, buiswand); }, meld);
                    if (okB && fid != ElementId.InvalidElementId && doc.GetElement(fid) != null) { fitting = fid; modeGebruikt = "tap"; tapEind = eind; break; }
                    tapPogingen.Add($"tap ({eind}): {nB ?? "geen fitting na commit"}");
                }
                if (fitting == ElementId.InvalidElementId)
                {
                    if (!pl.TeeFallback) { fouten.AddRange(tapPogingen); return false; }
                }
            }

            // C + D: knippen, commit, dan T-stuk in een eigen transactie
            if (fitting == ElementId.InvalidElementId)
            {
                ElementId nieuw = ElementId.InvalidElementId;
                var (okC, nC) = RunTx(doc, $"connect_to_pipe #{i}: hoofdleiding knippen", () =>
                {
                    nieuw = PlumbingUtils.BreakCurve(doc, pl.MainId, pl.Q);
                    if (nieuw == ElementId.InvalidElementId) throw new InvalidOperationException("BreakCurve gaf geen nieuw element");
                }, meld);
                if (!okC) { fouten.Add($"knippen hoofdleiding teruggerold: {nC}"); return false; }
                if (doc.GetElement(nieuw) is not Pipe || doc.GetElement(pl.MainId) is not Pipe)
                { fouten.Add("read-back: deelstukken van de hoofdleiding ontbreken na het knippen"); return false; }
                knipNieuw = nieuw;
                ElementId fid = ElementId.InvalidElementId;
                string stuk = pl.Mode == "wye" ? "Y-stuk" : "T-stuk";
                var (okD, nD) = RunTx(doc, $"connect_to_pipe #{i}: {stuk}", () =>
                {
                    fid = MaakTee(doc, pl, nieuw, finalSeg);
                    if (pl.Mode == "wye" && doc.GetElement(fid) is FamilyInstance wf)
                    {
                        var wpt = wf.Symbol?.Family != null ? PartTypeOf(wf.Symbol.Family) : null;
                        if (wpt is not (PartType.Wye or PartType.LateralTee))
                            throw new InvalidOperationException($"Revit plaatste {wf.Symbol?.FamilyName} (PartType {wpt?.ToString() ?? "?"}) in plaats van een Y-stuk; de volgorde van de Junctions-regels bepaalt het onderdeel");
                    }
                }, meld);
                if (!okD || fid == ElementId.InvalidElementId || doc.GetElement(fid) == null) { fouten.Add($"{stuk} teruggerold: {nD ?? "geen fitting na commit"}"); return false; }
                fitting = fid; modeGebruikt = pl.Mode == "wye" ? "wye" : "tee";
            }

            // read-back: open einde nu verbonden met een fitting?
            var c = ConnectorAt(doc.GetElement(finalSeg), pl.Q);
            buren = c != null && c.IsConnected ? RefOwners(c).ToList() : new List<long>();
            bool aanFitting = buren.Any(b => doc.GetElement(new ElementId(b)) is FamilyInstance);
            if (!aanFitting)
            {
                fouten.Add($"read-back: aftakking {finalSeg.Value} is na commit niet verbonden met een fitting (buren: {string.Join(", ", buren)}); alles teruggerold");
                return false;
            }
            return true;
        });
        foreach (var gn in groupNotes) fouten.Add(gn);
        if (tapPogingen.Count > 0) row["tap_pogingen"] = tapPogingen;
        if (!kept) return false;

        row["mode_gebruikt"] = modeGebruikt;
        if (modeGebruikt == "tap" && pl.Mode == "tap") row["tap_eindpunt"] = tapEind;
        if (modeGebruikt == "tee" && pl.Mode == "tap") fouten.Add("tap mislukt, terugval op T-stuk (zie tap_pogingen)");
        row["fitting_id"] = fitting.Value;
        if (doc.GetElement(fitting) is FamilyInstance ff)
        {
            row["fitting_type"] = $"{ff.Symbol?.FamilyName} : {ff.Symbol?.Name}";
            row["fitting_part_type"] = ff.Symbol?.Family != null ? PartTypeOf(ff.Symbol.Family)?.ToString() : null;
            var fc = AllConnectors(ff).ToList();
            row["fitting_connectors"] = new Dictionary<string, int> { ["totaal"] = fc.Count, ["verbonden"] = fc.Count(x => x.IsConnected) };
        }
        row["aftakking_verbonden_met"] = buren;
        if (!buren.Contains(fitting.Value)) fouten.Add($"aftakking zit niet direct aan fitting {fitting.Value} maar aan {string.Join(", ", buren)} (verloop?)");
        row["laatste_stuk_id"] = finalSeg.Value;
        row["verlengstukken"] = nieuweSeg.Where(x => doc.GetElement(x) != null).Select(x => x.Value).ToList();
        row["bochten"] = nieuweFit.Where(x => doc.GetElement(x) != null).Select(x => x.Value).ToList();
        if (knipNieuw != ElementId.InvalidElementId)
        {
            row["hoofdleiding_na_knip"] = new[] { pl.MainId.Value, knipNieuw.Value };
            var fam = Familie(familie, pl.MainGevraagd);
            fam.Add(knipNieuw.Value); fam.Add(pl.MainId.Value);
            familie[knipNieuw.Value] = fam; familie[pl.MainId.Value] = fam;
        }
        if (pl.Method is "direct" or "verlengen" or "verlengen_en_val" or "wye_verlengen")
        {
            if (pl.BranchIsPipe && doc.GetElement(new ElementId(pl.BranchId)) is Pipe bp && (bp.Location as LocationCurve)?.Curve is Line bl)
                row["aftakking_lengte_mm"] = R(bl.Length * MM);
        }
        return true;
    }

    /// <summary>Binnen een open transactie: verlengen/val/bocht. Geeft het id van het laatste stuk (einde op Q).</summary>
    private static ElementId BouwAftakGeometrie(Document doc, AftakPlan pl, List<ElementId> nieuweSeg, List<ElementId> nieuweFit)
    {
        var bid = new ElementId(pl.BranchId);
        Connector FitConn() => EndConnectors(doc.GetElement(bid)).FirstOrDefault(c => c.Id == pl.BranchConnId)
                               ?? throw new InvalidOperationException("connector van de fitting-aftakking niet meer te vinden");
        Connector At(ElementId id, XYZ pt) => ConnectorAt(doc.GetElement(id), pt) ?? throw new InvalidOperationException($"connector van {id.Value} niet gevonden");
        FamilyInstance Elbow(Connector c1, Connector c2)
        {
            FamilyInstance? f;
            try { f = doc.Create.NewElbowFitting(c1, c2); }
            catch (Exception ex) { throw new InvalidOperationException($"bocht mislukt: {ex.Message}"); }
            return f ?? throw new InvalidOperationException("NewElbowFitting gaf null");
        }
        Pipe Seg(XYZ a, XYZ b, ElementId sys, double diam)
        {
            var pp = Pipe.Create(doc, sys, pl.PipeTypeId, pl.LevelId, a, b) ?? throw new InvalidOperationException("Pipe.Create gaf null");
            SetDouble(pp, BuiltInParameter.RBS_PIPE_DIAMETER_PARAM, diam, "diameter");
            return pp;
        }
        Pipe Stub(XYZ to)
        {
            Pipe? pp;
            try { pp = Pipe.Create(doc, pl.PipeTypeId, pl.LevelId, FitConn(), to); }
            catch (Exception ex) { throw new InvalidOperationException($"leiding vanaf de fitting-connector mislukt: {ex.Message}"); }
            return pp ?? throw new InvalidOperationException("Pipe.Create vanaf de connector gaf null");
        }

        switch (pl.Method)
        {
            case "verlengen":
            case "wye_verlengen":
                if (pl.BranchIsPipe) { ZetEinde(doc, bid, pl.E, pl.Q); return bid; }
                else { var st = Stub(pl.Q); nieuweSeg.Add(st.Id); return st.Id; }
            case "verlengen_en_val":
            {
                ElementId arm;
                if (pl.BranchIsPipe) { ZetEinde(doc, bid, pl.E, pl.P!); arm = bid; }
                else { var st = Stub(pl.P!); nieuweSeg.Add(st.Id); arm = st.Id; }
                doc.Regenerate();
                var armPipe = (Pipe)doc.GetElement(arm);
                var sys = pl.SystemTypeId != ElementId.InvalidElementId ? pl.SystemTypeId : ParamId(armPipe, BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM);
                var drop = Seg(pl.P!, pl.Q, sys, armPipe.Diameter);
                nieuweSeg.Add(drop.Id);
                doc.Regenerate();
                nieuweFit.Add(Elbow(At(arm, pl.P!), At(drop.Id, pl.P!)).Id);
                return drop.Id;
            }
            case "val":
            case "haaks_stuk":
            case "wye_stuk":
            {
                var bp = (Pipe)doc.GetElement(bid);
                var drop = Seg(pl.E, pl.Q, pl.SystemTypeId, bp.Diameter);
                nieuweSeg.Add(drop.Id);
                doc.Regenerate();
                nieuweFit.Add(Elbow(At(bid, pl.E), At(drop.Id, pl.E)).Id);
                return drop.Id;
            }
            default:
                throw new InvalidOperationException($"methode {pl.Method} onbekend");
        }
    }

    /// <summary>Verplaats het uiteinde van een leiding dat bij 'van' ligt naar 'naar'; richting van de curve blijft.</summary>
    private static void ZetEinde(Document doc, ElementId pipeId, XYZ van, XYZ naar)
    {
        var lc = doc.GetElement(pipeId).Location as LocationCurve ?? throw new InvalidOperationException($"leiding {pipeId.Value} heeft geen LocationCurve");
        var line = lc.Curve as Line ?? throw new InvalidOperationException($"leiding {pipeId.Value} is niet recht");
        var e0 = line.GetEndPoint(0); var e1 = line.GetEndPoint(1);
        lc.Curve = e0.DistanceTo(van) <= e1.DistanceTo(van) ? Line.CreateBound(naar, e1) : Line.CreateBound(e0, naar);
    }

    private static ElementId MaakTap(Document doc, AftakPlan pl, ElementId segId, bool buiswand)
    {
        if (buiswand)
        {
            var line = (doc.GetElement(segId).Location as LocationCurve)?.Curve as Line ?? throw new InvalidOperationException("laatste stuk is niet recht");
            var e0 = line.GetEndPoint(0); var e1 = line.GetEndPoint(1);
            var near = e0.DistanceTo(pl.Q) <= e1.DistanceTo(pl.Q) ? e0 : e1;
            var far = near == e0 ? e1 : e0;
            var u = (near - far).Normalize();
            var wand = pl.Q - u * (pl.MainOuter / 2);
            if (wand.DistanceTo(far) <= Tol * 5) throw new InvalidOperationException("laatste stuk te kort om tot de buiswand in te korten");
            ZetEinde(doc, segId, near, wand);
            doc.Regenerate();
        }
        var c = ConnectorAt(doc.GetElement(segId), pl.Q) ?? throw new InvalidOperationException("connector van het laatste stuk niet gevonden");
        if (c.IsConnected) throw new InvalidOperationException("connector van het laatste stuk is al verbonden");
        var main = doc.GetElement(pl.MainId) as MEPCurve ?? throw new InvalidOperationException("hoofdleiding niet meer te vinden");
        FamilyInstance? f;
        try { f = doc.Create.NewTakeoffFitting(c, main); }
        catch (Exception ex) { throw new InvalidOperationException($"NewTakeoffFitting: {ex.Message}"); }
        return (f ?? throw new InvalidOperationException("NewTakeoffFitting gaf null")).Id;
    }

    private static ElementId MaakTee(Document doc, AftakPlan pl, ElementId nieuwId, ElementId segId)
    {
        var h1 = ConnectorAt(doc.GetElement(pl.MainId), pl.Q);
        var h2 = ConnectorAt(doc.GetElement(nieuwId), pl.Q);
        if (h1 == null || h2 == null || h1.Origin.DistanceTo(pl.Q) > 5 * Tol || h2.Origin.DistanceTo(pl.Q) > 5 * Tol)
            throw new InvalidOperationException("open connectors van de hoofdleiding op het knippunt niet gevonden");
        // BreakCurve koppelt soms direct pipe-op-pipe: eerst los
        if (h1.IsConnected)
            foreach (Connector r in h1.AllRefs)
                if (r.Owner?.Id == nieuwId) { h1.DisconnectFrom(r); break; }
        var cb = ConnectorAt(doc.GetElement(segId), pl.Q) ?? throw new InvalidOperationException("connector van de aftakking niet gevonden");
        if (cb.IsConnected) throw new InvalidOperationException("connector van de aftakking is al verbonden");
        FamilyInstance? f;
        try { f = doc.Create.NewTeeFitting(h1, h2, cb); }
        catch (Exception ex) { throw new InvalidOperationException($"NewTeeFitting: {ex.Message}"); }
        return (f ?? throw new InvalidOperationException("NewTeeFitting gaf null")).Id;
    }

    // ── hulpjes ──

    /// <summary>Fittingen en appendages op/aan de hoofdleiding met hun positie langs de as (voet): verbonden met de leiding,
    /// of met hun plaatsingspunt binnen buitenstraal + 50 mm van de as (taps zitten op de buiswand, soms zonder connector).</summary>
    private static List<(long id, double t)> FittingsOpHoofdleiding(Document doc, Pipe main, Line ml, double outer)
    {
        var res = new Dictionary<long, double>();
        var d = ml.Direction.Normalize(); var m0 = ml.GetEndPoint(0);
        double T(XYZ x) => (x - m0).DotProduct(d);
        foreach (var c in AllConnectors(main))
        {
            if (!c.IsConnected) continue;
            foreach (Connector r in c.AllRefs)
            {
                try { if (r.Owner is FamilyInstance fi && fi.Id != main.Id) res[fi.Id.Value] = T(r.Origin); } catch { }
            }
        }
        var bb = main.get_BoundingBox(null);
        if (bb != null)
        {
            double marge = outer / 2 + 200 / MM;
            var ol = new Outline(bb.Min - new XYZ(marge, marge, marge), bb.Max + new XYZ(marge, marge, marge));
            var cats = new ElementMulticategoryFilter(new List<BuiltInCategory> { BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_PipeAccessory });
            foreach (var fi in new FilteredElementCollector(doc).WherePasses(cats).WherePasses(new BoundingBoxIntersectsFilter(ol))
                         .WhereElementIsNotElementType().OfType<FamilyInstance>())
            {
                if (res.ContainsKey(fi.Id.Value)) continue;
                if (fi.Location is not LocationPoint lp) continue;
                double t = T(lp.Point);
                if (t < -outer || t > ml.Length + outer) continue;
                double dist = (lp.Point - (m0 + d * t)).GetLength();
                bool raakt = dist <= outer / 2 + 50 / MM;
                if (!raakt)
                    foreach (var c in AllConnectors(fi))
                    {
                        try { if (c.IsConnected && c.AllRefs.Cast<Connector>().Any(r => r.Owner?.Id == main.Id)) { raakt = true; break; } } catch { }
                    }
                if (raakt) res[fi.Id.Value] = t;
            }
        }
        return res.Select(kv => (kv.Key, kv.Value)).ToList();
    }

    private static double DistToSegment(XYZ x, Line l)
    {
        var a = l.GetEndPoint(0); var d = l.Direction.Normalize();
        double t = Math.Clamp((x - a).DotProduct(d), 0, l.Length);
        return x.DistanceTo(a + d * t);
    }

    private static IEnumerable<long> RefOwners(Connector c)
    {
        var res = new List<long>();
        try
        {
            foreach (Connector r in c.AllRefs)
            {
                try { if (r.Owner is MEPCurve or FamilyInstance && r.Owner.Id != c.Owner.Id) res.Add(r.Owner.Id.Value); } catch { }
            }
        }
        catch { }
        return res;
    }

    private static double OuterDiameter(Pipe p)
    {
        try { var par = p.get_Parameter(BuiltInParameter.RBS_PIPE_OUTER_DIAMETER); if (par != null && par.HasValue && par.AsDouble() > 0) return par.AsDouble(); } catch { }
        return p.Diameter;
    }

    private static ElementId ParamId(Element e, BuiltInParameter bip)
    {
        try { var par = e.get_Parameter(bip); if (par != null && par.StorageType == StorageType.ElementId) return par.AsElementId(); } catch { }
        return ElementId.InvalidElementId;
    }

    private static string? NameOf(Document doc, ElementId id) => id == ElementId.InvalidElementId ? null : doc.GetElement(id)?.Name;

    /// <summary>Leidingtype van een leiding die aan de fitting vastzit.</summary>
    private static ElementId? NeighbourPipeType(Document doc, Element fitting)
    {
        foreach (var c in EndConnectors(fitting))
        {
            if (!c.IsConnected) continue;
            foreach (Connector r in c.AllRefs)
                if (r.Owner is Pipe pp) return pp.GetTypeId();
        }
        return null;
    }

    private static PartType? PartTypeOf(Family f)
    {
        try
        {
            var par = f.get_Parameter(BuiltInParameter.FAMILY_CONTENT_PART_TYPE);
            if (par != null && par.StorageType == StorageType.Integer) return (PartType)par.AsInteger();
        }
        catch { }
        return null;
    }

    /// <summary>Y-stukken (PartType Wye of LateralTee) in de Junctions-regels van een leidingtype ("familie : type").</summary>
    private static List<string> WyeParts(Document doc, PipeType? t)
    {
        var res = new List<string>();
        var rpm = t?.RoutingPreferenceManager;
        if (rpm == null) return res;
        int n = 0;
        try { n = rpm.GetNumberOfRules(RoutingPreferenceRuleGroupType.Junctions); } catch { }
        for (int k = 0; k < n; k++)
        {
            try
            {
                if (doc.GetElement(rpm.GetRule(RoutingPreferenceRuleGroupType.Junctions, k).MEPPartId) is not FamilySymbol sym) continue;
                var pt = PartTypeOf(sym.Family);
                if (pt is PartType.Wye or PartType.LateralTee) res.Add($"{sym.FamilyName} : {sym.Name}");
            }
            catch { }
        }
        return res;
    }

    /// <summary>Index van de eerste Junctions-regel met een van de PartTypes; int.MaxValue als er geen is.</summary>
    private static int JunctionIndexOf(Document doc, PipeType? t, params PartType[] parts)
    {
        var rpm = t?.RoutingPreferenceManager;
        if (rpm == null) return int.MaxValue;
        int n = 0;
        try { n = rpm.GetNumberOfRules(RoutingPreferenceRuleGroupType.Junctions); } catch { }
        for (int k = 0; k < n; k++)
        {
            try
            {
                if (doc.GetElement(rpm.GetRule(RoutingPreferenceRuleGroupType.Junctions, k).MEPPartId) is FamilySymbol sym
                    && PartTypeOf(sym.Family) is PartType pt && parts.Contains(pt)) return k;
            }
            catch { }
        }
        return int.MaxValue;
    }

    /// <summary>Junctions-regels van een leidingtype: voorkeur (Tee/Tap) en de tap- en T-onderdelen ("familie : type").</summary>
    private static (string? pref, List<string> taps, List<string> tees) JunctionInfo(Document doc, PipeType? t)
    {
        var taps = new List<string>(); var tees = new List<string>(); string? pref = null;
        var rpm = t?.RoutingPreferenceManager;
        if (rpm == null) return (pref, taps, tees);
        try { pref = rpm.PreferredJunctionType.ToString(); } catch { }
        int n = 0;
        try { n = rpm.GetNumberOfRules(RoutingPreferenceRuleGroupType.Junctions); } catch { }
        for (int k = 0; k < n; k++)
        {
            try
            {
                var rule = rpm.GetRule(RoutingPreferenceRuleGroupType.Junctions, k);
                if (doc.GetElement(rule.MEPPartId) is not FamilySymbol sym) continue;
                var pt = PartTypeOf(sym.Family);
                string naam = $"{sym.FamilyName} : {sym.Name}";
                if (pt != null && TapParts.Contains(pt.Value)) taps.Add(naam);
                else if (pt == PartType.Tee) tees.Add(naam);
            }
            catch { }
        }
        return (pref, taps, tees);
    }
}
