// Pattern B: FEC.OfClass collections. Reference: PhaseFilters.
// Validated with five working types.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public static class PatternB_Handlers
{
    private static string Owner(Document doc) => BasePatternHandlers.ResolveOwner(doc);

    // ── PhaseFilters ────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetPhaseFilters(Document doc)
        => BasePatternHandlers.Query<PhaseFilter>(doc, Owner(doc));

    public static Dictionary<string, object?> GetPhaseFilterDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<PhaseFilter>(doc, elementId, owner,
            pf =>
            {
                var phaseStatuses = new FilteredElementCollector(doc)
                    .OfClass(typeof(Phase)).Cast<Phase>()
                    .Where(p => p.IsValidObject)
                    .Select(p => new Dictionary<string, object?>
                    {
                        ["phase_id"] = RevitIdUtil.Fid(p.Id),
                        ["phase_name"] = p.Name,
                        ["phase_status"] = pf.GetPhaseStatus(p.Id).ToString()
                    }).ToList();
                return new Dictionary<string, object?>
                {
                    ["phase_statuses"] = phaseStatuses,
                    ["phase_status_count"] = phaseStatuses.Count
                };
            });
    }

    // ── LinePatterns ────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetLinePatterns(Document doc)
        => BasePatternHandlers.Query<LinePatternElement>(doc, Owner(doc));

    public static Dictionary<string, object?> GetLinePatternDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<LinePatternElement>(doc, elementId, owner,
            lp =>
            {
                var segments = new List<Dictionary<string, object?>>();
                try
                {
                    var pattern = lp.GetLinePattern();
                    if (pattern != null)
                        foreach (LinePatternSegment seg in pattern.GetSegments())
                            segments.Add(new() { ["type"] = seg.Type.ToString(), ["length"] = seg.Length });
                }
                catch { }
                return new Dictionary<string, object?>
                {
                    ["segment_count"] = segments.Count,
                    ["segments"] = segments
                };
            });
    }

    // ── FillPatterns ───────────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetFillPatterns(Document doc)
        => BasePatternHandlers.Query<FillPatternElement>(doc, Owner(doc));

    public static Dictionary<string, object?> GetFillPatternDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<FillPatternElement>(doc, elementId, owner,
            fp =>
            {
                var segments = new List<Dictionary<string, object?>>();
                bool? isSolidFill = null;
                try
                {
                    var pattern = fp.GetFillPattern();
                    if (pattern != null) isSolidFill = pattern.IsSolidFill;
                }
                catch { }
                return new Dictionary<string, object?>
                {
                    ["is_solid_fill"] = isSolidFill,
                    ["segment_count"] = segments.Count,
                    ["segments"] = segments
                };
            });
    }

    // ── TextNoteTypes ─────────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetTextNoteTypes(Document doc)
    {
        // Text Styles: dedicated (not the generic Query<T>) so the manage-review
        // columns land in the BULK export, not only the per-item detail call — mirrors GetDimensionTypes.
        // Fields via BuiltInParameter (font/size/width/bold/italic/underline/color) are the same reads the
        // detail method below already proves reliable; each is try/catch-guarded so a miss degrades to null,
        // never a misleading value.
        var owner = Owner(doc);
        var result = new List<Dictionary<string, object?>>();
        foreach (TextNoteType tnt in new FilteredElementCollector(doc).OfClass(typeof(TextNoteType)).Cast<TextNoteType>())
        {
            if (!tnt.IsValidObject) continue;
            var stub = BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(tnt.Id), "TextNoteType", null, tnt.Name, null, owner, "B",
                categoryName: BasePatternHandlers.SafeCategoryName(tnt), familyName: (tnt as ElementType)?.FamilyName,
                assemblyCode: BasePatternHandlers.SafeAssemblyCode(tnt), supplier: BasePatternHandlers.SafeSupplier(tnt),
                includeDescriptionModel: false);
            string? font = null; double? sizeFt = null, widthFactor = null;
            int? bold = null, italic = null, underline = null; string? colorRgb = null;
            try { font = tnt.get_Parameter(BuiltInParameter.TEXT_FONT)?.AsString(); } catch { }
            try { sizeFt = tnt.get_Parameter(BuiltInParameter.TEXT_SIZE)?.AsDouble(); } catch { }
            try { widthFactor = tnt.get_Parameter(BuiltInParameter.TEXT_WIDTH_SCALE)?.AsDouble(); } catch { }
            try { bold = tnt.get_Parameter(BuiltInParameter.TEXT_STYLE_BOLD)?.AsInteger(); } catch { }
            try { italic = tnt.get_Parameter(BuiltInParameter.TEXT_STYLE_ITALIC)?.AsInteger(); } catch { }
            try { underline = tnt.get_Parameter(BuiltInParameter.TEXT_STYLE_UNDERLINE)?.AsInteger(); } catch { }
            try
            {
                var cv = tnt.get_Parameter(BuiltInParameter.LINE_COLOR)?.AsInteger();
                if (cv.HasValue) colorRgb = $"{cv.Value & 0xFF},{(cv.Value >> 8) & 0xFF},{(cv.Value >> 16) & 0xFF}";
            }
            catch { }
            stub["font"] = font;
            stub["text_size_mm"] = sizeFt.HasValue ? Math.Round(sizeFt.Value * 304.8, 2) : null;
            stub["width_factor"] = widthFactor;
            stub["bold"] = bold;
            stub["italic"] = italic;
            stub["underline"] = underline;
            stub["color"] = colorRgb;
            result.Add(stub);
        }
        return result;
    }

    public static Dictionary<string, object?> GetTextNoteTypeDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<TextNoteType>(doc, elementId, owner,
            tnt =>
            {
                string? font = null;
                double? textSizeFt = null;
                double? widthFactor = null;
                int[]? colorRgb = null;
                try { font = tnt.get_Parameter(BuiltInParameter.TEXT_FONT)?.AsString(); } catch { }
                try { textSizeFt = tnt.get_Parameter(BuiltInParameter.TEXT_SIZE)?.AsDouble(); } catch { }
                try { widthFactor = tnt.get_Parameter(BuiltInParameter.TEXT_WIDTH_SCALE)?.AsDouble(); } catch { }
                try
                {
                    var cv = tnt.get_Parameter(BuiltInParameter.LINE_COLOR)?.AsInteger();
                    if (cv.HasValue) colorRgb = new[] { cv.Value & 0xFF, (cv.Value >> 8) & 0xFF, (cv.Value >> 16) & 0xFF };
                }
                catch { }

                double? textSizeMm = textSizeFt.HasValue ? Math.Round(textSizeFt.Value * 304.8, 2) : null;

                return new Dictionary<string, object?>
                {
                    ["font"] = font,
                    ["text_size_mm"] = textSizeMm,
                    ["width_factor"] = widthFactor,
                    ["color_rgb"] = colorRgb
                };
            });
    }

    // ── ViewFamilyTypes ───────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetViewFamilyTypes(Document doc)
        => BasePatternHandlers.Query<ViewFamilyType>(doc, Owner(doc));

    public static Dictionary<string, object?> GetViewFamilyTypeDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<ViewFamilyType>(doc, elementId, owner,
            vft =>
            {
                string? viewFamilyDisplay = null;
                string? discipline = null;
                try { viewFamilyDisplay = vft.get_Parameter(BuiltInParameter.VIEW_FAMILY)?.AsValueString(); } catch { }
                try { discipline = vft.get_Parameter(BuiltInParameter.VIEW_DISCIPLINE)?.AsValueString(); } catch { }
                return new Dictionary<string, object?>
                {
                    ["view_family"] = vft.ViewFamily.ToString(),
                    ["view_family_display"] = viewFamilyDisplay,
                    ["discipline"] = discipline
                };
            });
    }

    // ── ViewTemplates (View where IsTemplate) + ViewFilters (ParameterFilterElement) ──
    // Both were registered in TypeCatalog but had no Query case, so
    // query_elements fell through to the "Unknown Pattern-B type" default (count=0 + a per-doc error in
    // errors[]). Now first-class. View templates need a custom IsTemplate filter (the generic Query<View>
    // would also return every non-template view); view filters are a plain ParameterFilterElement FEC.

    public static List<Dictionary<string, object?>> GetViewTemplates(Document doc)
    {
        var owner = Owner(doc);
        return new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
            .Where(v => v.IsValidObject && v.IsTemplate)
            .Select(v => BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(v.Id), "View", null, v.Name, null, owner, "B",
                categoryName: v.ViewType.ToString(), familyName: null))
            .ToList();
    }

    public static Dictionary<string, object?> GetViewTemplateDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<View>(doc, elementId, owner,
            v =>
            {
                var fnames = new List<string?>();
                try { foreach (var fid in v.GetFilters()) fnames.Add(doc.GetElement(fid)?.Name); } catch { }
                return new Dictionary<string, object?>
                {
                    ["view_type"] = v.ViewType.ToString(),
                    ["is_template"] = v.IsTemplate,
                    ["applied_filter_count"] = fnames.Count(n => n != null),
                    ["applied_filters"] = fnames.Where(n => n != null).ToList()
                };
            });
    }

    public static List<Dictionary<string, object?>> GetViewFilters(Document doc)
        => BasePatternHandlers.Query<ParameterFilterElement>(doc, Owner(doc));

    public static Dictionary<string, object?> GetViewFilterDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<ParameterFilterElement>(doc, elementId, owner,
            pfe =>
            {
                var cats = new List<string?>();
                try
                {
                    foreach (var cid in pfe.GetCategories())
                        cats.Add(Category.GetCategory(doc, cid)?.Name ?? cid.ToString());
                }
                catch { }
                // Rule introspection lives in get_filter_rules; here we keep the detail light (categories).
                return new Dictionary<string, object?>
                {
                    ["category_count"] = cats.Count,
                    ["categories"] = cats
                };
            });
    }

    // ── Dimension Styles ──────────────────────────────────────────
    // DimensionType is the annotation "dimension style". Catalog-registered as dimension_types but the
    // Pattern-B dispatch never implemented it, so the sync/manage "Dimension Styles" tabs stayed shells.
    // FEC.OfClass(DimensionType) returns all concrete subtypes by name.
    public static List<Dictionary<string, object?>> GetDimensionTypes(Document doc)
    {
        // Dedicated (not the generic Query<T>) so the manage-review columns
        // asked for land in the bulk export, not just the per-item detail call. StyleType (Linear/Angular/
        // Radial/...) is a confirmed real property (already used in GetDimensionTypeDetail below — this
        // is exactly the "Radial vs Linear" distinction behind the confusing duplicate 1.8mm styles).
        // Tick Mark/Line Weight/Color/Text Size/Text Font/Snap Distance/Dimension String Type go through
        // SafeParamValue (LookupParameter-by-UI-name): a wrong guess degrades to null, never a misleading
        // wrong value — safer to attempt broadly than the V/G-overrides BuiltInParameter-enum approach.
        var owner = Owner(doc);
        var result = new List<Dictionary<string, object?>>();
        foreach (DimensionType dt in new FilteredElementCollector(doc).OfClass(typeof(DimensionType)).Cast<DimensionType>())
        {
            if (!dt.IsValidObject) continue;
            var stub = BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(dt.Id), "DimensionType", null, dt.Name, null, owner, "B",
                categoryName: BasePatternHandlers.SafeCategoryName(dt), familyName: (dt as ElementType)?.FamilyName,
                assemblyCode: BasePatternHandlers.SafeAssemblyCode(dt), supplier: BasePatternHandlers.SafeSupplier(dt),
                includeDescriptionModel: false);
            string? styleType = null;
            try { styleType = dt.StyleType.ToString(); } catch { }
            stub["style_type"] = styleType;
            stub["tick_mark"] = BasePatternHandlers.SafeParamValue(dt, "Tick Mark");
            stub["line_weight"] = BasePatternHandlers.SafeParamValue(dt, "Line Weight");
            stub["color"] = BasePatternHandlers.SafeParamValue(dt, "Color");
            stub["text_size"] = BasePatternHandlers.SafeParamValue(dt, "Text Size");
            stub["text_font"] = BasePatternHandlers.SafeParamValue(dt, "Text Font");
            stub["snap_distance"] = BasePatternHandlers.SafeParamValue(dt, "Snap Distance");
            stub["dimension_string_type"] = BasePatternHandlers.SafeParamValue(dt, "Dimension String Type");
            result.Add(stub);
        }
        return result;
    }

    public static Dictionary<string, object?> GetDimensionTypeDetail(Document doc, long elementId)
    {
        var owner = Owner(doc);
        return BasePatternHandlers.Detail<DimensionType>(doc, elementId, owner,
            dt =>
            {
                string? style = null;
                try { style = dt.StyleType.ToString(); } catch { }
                return new Dictionary<string, object?> { ["style_type"] = style };
            });
    }

    // ── Materials ─────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetMaterials(Document doc)
        => BasePatternHandlers.Query<Material>(doc, Owner(doc));

    public static Dictionary<string, object?> GetMaterialDetail(Document doc, long elementId)
    {
        var mat = BasePatternHandlers.GetElementOrThrow<Material>(doc, elementId);
        var owner = Owner(doc);

        int[]? colorRgb = null;
        try
        {
            var c = mat.Color;
            if (c != null && c.IsValid)
                colorRgb = new[] { (int)c.Red, (int)c.Green, (int)c.Blue };
        }
        catch { }

        int transparency = 0, shininess = 0, smoothness = 0;
        try { transparency = mat.Transparency; } catch { }
        try { shininess = mat.Shininess; } catch { }
        try { smoothness = mat.Smoothness; } catch { }

        string? materialClass = null, materialCategory = null;
        try { materialClass = mat.MaterialClass; } catch { }
        try { materialCategory = mat.MaterialCategory; } catch { }

        string? manufacturer = null, model = null;
        string? description = null, mark = null, url = null;
        double? cost = null;
        try { manufacturer = mat.get_Parameter(BuiltInParameter.ALL_MODEL_MANUFACTURER)?.AsString(); } catch { }
        try { model = mat.get_Parameter(BuiltInParameter.ALL_MODEL_MODEL)?.AsString(); } catch { }
        try { description = mat.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION)?.AsString(); } catch { }
        try { mark = mat.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString(); } catch { }
        try { cost = mat.get_Parameter(BuiltInParameter.ALL_MODEL_COST)?.AsDouble(); } catch { }
        try { url = mat.get_Parameter(BuiltInParameter.ALL_MODEL_URL)?.AsString(); } catch { }

        var rels = new List<Dictionary<string, object?>>();

        void AddFillPatternRel(string role, ElementId id)
        {
            rels.Add(new()
            {
                ["kind"] = "uses_fill_pattern",
                ["role"] = role,
                ["ref"] = id.Value > 0
                    ? new Dictionary<string, object?> { ["element_id"] = RevitIdUtil.Fid(id), ["revit_class"] = "FillPatternElement" }
                    : null
            });
        }

        AddFillPatternRel("surface_foreground", mat.SurfaceForegroundPatternId);
        AddFillPatternRel("surface_background", mat.SurfaceBackgroundPatternId);
        AddFillPatternRel("cut_foreground", mat.CutForegroundPatternId);
        AddFillPatternRel("cut_background", mat.CutBackgroundPatternId);

        return new Dictionary<string, object?>
        {
            ["stub"] = BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(mat.Id), "Material", null, mat.Name, null, owner, "B"),
            ["metadata"] = BasePatternHandlers.MetadataEnvelope(),
            ["properties"] = new Dictionary<string, object?>
            {
                ["color_rgb"] = colorRgb,
                ["transparency"] = transparency,
                ["shininess"] = shininess,
                ["smoothness"] = smoothness,
                ["material_class"] = materialClass,
                ["material_category"] = materialCategory,
                ["manufacturer"] = manufacturer,
                ["model"] = model,
                ["description"] = description,
                ["mark"] = mark,
                ["cost"] = cost,
                ["url"] = url
            },
            ["relationships"] = rels
        };
    }

    // ── Dispatch ──────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> Query(string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null) => typeId switch
    {
        "phase_filters" => GetPhaseFilters(doc),
        "line_patterns" => GetLinePatterns(doc),
        "fill_patterns" => GetFillPatterns(doc),
        "text_note_types" => GetTextNoteTypes(doc),
        "view_family_types" => GetViewFamilyTypes(doc),
        "view_templates" => GetViewTemplates(doc),
        "view_filters" => GetViewFilters(doc),
        "materials" => GetMaterials(doc),
        "dimension_types" => GetDimensionTypes(doc),
        _ => throw new ArgumentException($"Unknown Pattern-B type: {typeId}")
    };

    public static Dictionary<string, object?> Detail(string typeId, Document doc, long elementId) => typeId switch
    {
        "phase_filters" => GetPhaseFilterDetail(doc, elementId),
        "line_patterns" => GetLinePatternDetail(doc, elementId),
        "fill_patterns" => GetFillPatternDetail(doc, elementId),
        "text_note_types" => GetTextNoteTypeDetail(doc, elementId),
        "view_family_types" => GetViewFamilyTypeDetail(doc, elementId),
        "view_templates" => GetViewTemplateDetail(doc, elementId),
        "view_filters" => GetViewFilterDetail(doc, elementId),
        "materials" => GetMaterialDetail(doc, elementId),
        "dimension_types" => GetDimensionTypeDetail(doc, elementId),
        _ => throw new NotImplementedException($"Pattern B detail for {typeId} not yet implemented")
    };
}
