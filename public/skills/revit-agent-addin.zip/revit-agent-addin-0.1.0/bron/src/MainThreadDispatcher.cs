using System.Collections.Concurrent;
using System.IO;
using System.Reflection;
using Autodesk.Revit.UI;
using RevitDB = Autodesk.Revit.ApplicationServices;

namespace RevitAgent.Addin;

public static class MainThreadDispatcher
{
    private static UIApplication? _uiApp;
    private static bool _hasApp;
    private static readonly ConcurrentQueue<string> _log = new();
    private static int _cmdCounter;
    private static int _totalEnqueued;
    private static string _lastQueueStatus = "init";

    // Idling-based dispatch + ExternalEvent-fallback (Idling bleek dood
    // te vallen met een Rendering/Image-view actief; ExternalEvent.Raise wordt door
    // Revits event-loop óók buiten Idling om verwerkt en is de robuustere route).
    private static Action? _pendingDispatch;
    private static int _idlingCount;
    private static ExternalEvent? _externalEvent;

    private sealed class DispatchHandler : IExternalEventHandler
    {
        public void Execute(UIApplication app)
        {
            if (!_hasApp) { _uiApp = app; _hasApp = true; }
            var dispatch = Interlocked.Exchange(ref _pendingDispatch, null);
            if (dispatch == null) return;
            Log("ExternalEvent dispatch");
            try { dispatch(); }
            catch (Exception ex) { Log($"ExternalEvent action error: {ex.Message}"); }
        }
        public string GetName() => "RevitAgent MainThreadDispatcher";
    }

    /// <summary>
    /// Leeg project openen bij de opstart. Standaard uit: een gebruiker wil geen leeg project bij elke start.
    /// Zet REVIT_AGENT_OPEN_LEEG=1 om het aan te zetten (handig bij een onbeheerde start).
    /// </summary>
    public static bool OpenDefaultDocument { get; set; } =
        Environment.GetEnvironmentVariable("REVIT_AGENT_OPEN_LEEG") == "1";

    // Eén opdracht tegelijk op de hoofdthread: er is maar één wachtende dispatch-plek.
    private static readonly SemaphoreSlim _eenTegelijk = new(1, 1);

    public static void Initialize(UIControlledApplication app)
    {
        Log("Initialize start");

        TryGetApp(app);
        if (_uiApp != null && OpenDefaultDocument)
            TryOpenDefaultDocument();

        try { _externalEvent = ExternalEvent.Create(new DispatchHandler()); Log("ExternalEvent created"); }
        catch (Exception ex) { Log($"ExternalEvent create failed: {ex.Message}"); }

        app.Idling += (_, e) =>
        {
            _idlingCount++;
            TryGetApp(app);

            var dispatch = Interlocked.Exchange(ref _pendingDispatch, null);
            if (dispatch != null)
            {
                Log($"Idling dispatch at count={_idlingCount}");
                try { dispatch(); }
                catch (Exception ex) { Log($"Idling action error: {ex.Message}"); }
            }
        };

        Log($"Initialize done. hasApp={_hasApp}");
    }

    private static void TryOpenDefaultDocument()
    {
        try
        {
            if (_uiApp!.Application.Documents.Size > 0)
            {
                Log("Document already open");
                return;
            }
            var doc = _uiApp.Application.NewProjectDocument(Autodesk.Revit.DB.UnitSystem.Metric);
            if (doc != null)
            {
                Log($"Default document opened: {doc.Title}");
                ActivateDocument(doc);
            }
        }
        catch (Exception ex)
        {
            Log($"Open default doc failed: {ex.Message}");
        }
    }

    private static void ActivateDocument(Autodesk.Revit.DB.Document doc)
    {
        try
        {
            var uiDoc = new Autodesk.Revit.UI.UIDocument(doc);
            var prop = typeof(UIApplication).GetProperty("ActiveUIDocument",
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            var setter = prop?.GetSetMethod(true);
            if (setter != null)
            {
                setter.Invoke(_uiApp, new object[] { uiDoc });
                Log($"Document activated: {doc.Title}");
            }
            else
            {
                Log("ActiveUIDocument setter not found");
            }
        }
        catch (Exception ex)
        {
            Log($"Activate document error: {ex.Message}");
        }
    }

    private static void TryGetApp(UIControlledApplication app)
    {
        if (_hasApp) return;
        try
        {
            var field = typeof(RevitDB.ControlledApplication).GetField("m_application",
                BindingFlags.NonPublic | BindingFlags.Instance);
            var val = field?.GetValue(app.ControlledApplication);
            if (val is RevitDB.Application dbApp)
            {
                SetApp(dbApp);
                Log("Got App via reflection");
            }
        }
        catch (Exception ex) { Log($"TryGetApp error: {ex.Message}"); }
    }

    private static void SetApp(RevitDB.Application dbApp)
    {
        _uiApp = new UIApplication(dbApp);
        _hasApp = true;
        Log("Application set");
    }

    public static T? GetResult<T>(Func<UIApplication, T> func, int timeoutMs = 30000)
    {
        // Wacht op een vorige opdracht; die telt mee in de time-out van deze.
        var wachtStart = System.Diagnostics.Stopwatch.StartNew();
        if (!_eenTegelijk.Wait(timeoutMs))
        {
            _lastQueueStatus = "busy";
            throw new TimeoutException("Revit is nog bezig met een vorige opdracht");
        }
        bool laterVrijgeven = false;
        try
        {
            return GetResultCore(func, Math.Max(1000, timeoutMs - (int)wachtStart.ElapsedMilliseconds), ref laterVrijgeven);
        }
        finally { if (!laterVrijgeven) _eenTegelijk.Release(); }
    }

    private static T? GetResultCore<T>(Func<UIApplication, T> func, int timeoutMs, ref bool laterVrijgeven)
    {
        var cmdId = Interlocked.Increment(ref _cmdCounter);
        var done = new ManualResetEventSlim(false);
        T? result = default;
        Exception? exception = null;

        Interlocked.Increment(ref _totalEnqueued);

        Action? mijnDispatch = null;
        mijnDispatch = () =>
        {
            Log($"Executing cmd#{cmdId}...");
            try
            {
                if (_hasApp) result = func(_uiApp!);
                else exception = new InvalidOperationException("No UIApplication available");
            }
            catch (Exception ex) { exception = ex; }
            finally
            {
                try { done.Set(); }
                catch { }
                Log($"cmd#{cmdId} done, Set() called");
            }
        };

        _pendingDispatch = mijnDispatch;
        Log($"cmd#{cmdId} waiting (timeout={timeoutMs}ms)...");
        try { _externalEvent?.Raise(); } catch (Exception ex) { Log($"ExternalEvent raise failed: {ex.Message}"); }

        var sw = System.Diagnostics.Stopwatch.StartNew();
        while (!done.Wait(50))
        {
            if (sw.ElapsedMilliseconds > timeoutMs)
            {
                _lastQueueStatus = $"timeout:{sw.ElapsedMilliseconds}ms>{timeoutMs}ms";
                Log($"cmd#{cmdId} TIMEOUT after {sw.ElapsedMilliseconds}ms (limit={timeoutMs})");
                // Nog niet begonnen? Dan weghalen, zodat hij niet later alsnog draait.
                if (Interlocked.CompareExchange(ref _pendingDispatch, null, mijnDispatch) == mijnDispatch)
                {
                    Log($"cmd#{cmdId} ingetrokken: nooit gestart");
                    throw new TimeoutException("Revit begon niet aan de opdracht binnen de time-out (dialoogvenster open of Revit bezig?)");
                }
                // Al bezig op de hoofdthread: de volgende opdracht wacht tot deze klaar is.
                Log($"cmd#{cmdId} loopt al; de volgende opdracht wacht tot hij klaar is");
                laterVrijgeven = true;
                _ = Task.Run(() => { done.Wait(); _eenTegelijk.Release(); Log($"cmd#{cmdId} alsnog klaar"); });
                throw new TimeoutException("Revit is nog bezig met deze opdracht (time-out); hij loopt door in Revit");
            }
        }
        if (exception != null)
        {
            Log($"cmd#{cmdId} error: {exception.Message}");
            throw new Exception("Main thread error", exception);
        }
        Log($"cmd#{cmdId} OK after {sw.ElapsedMilliseconds}ms");
        return result;
    }

    public static string[] GetLog() => _log.ToArray();
    public static bool HasApp => _hasApp;
    public static string LastQueueStatus => _lastQueueStatus;
    public static int TotalEnqueued => _totalEnqueued;
    public static int TotalDequeued => 0;
    public static int QueueCount => 0; // No queue in Idling-dispatch mode
    public static string LastTimeoutMs => "";

    public static void ResetCounters()
    {
        _totalEnqueued = 0;
        _lastQueueStatus = "init";
        _log.Enqueue("[reset] counters cleared");
        while (_log.Count > 500) _log.TryDequeue(out _);
    }

    private static string _logFile = Path.Combine(
        Path.GetTempPath(), "revit-agent-debug.log");

    /// <summary>Ander logbestand.</summary>
    public static void SetLogFile(string path) => _logFile = path;

    /// <summary>Boven deze grootte begint een nieuw logbestand; het vorige blijft als .1 staan.</summary>
    private const long MaxLogBytes = 5L * 1024 * 1024;
    private static readonly object _logLock = new();

    public static void Log(string msg)
    {
        var entry = $"[{DateTime.Now:HH:mm:ss.fff}] {msg}";
        _log.Enqueue(entry);
        while (_log.Count > 500) _log.TryDequeue(out _);
        lock (_logLock)
        {
            try
            {
                var fi = new FileInfo(_logFile);
                if (fi.Exists && fi.Length > MaxLogBytes) File.Move(_logFile, _logFile + ".1", overwrite: true);
            }
            catch { }
            try { File.AppendAllText(_logFile, entry + Environment.NewLine); }
            catch { }
        }
    }
}
