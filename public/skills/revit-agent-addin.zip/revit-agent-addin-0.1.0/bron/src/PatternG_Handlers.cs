using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;

namespace RevitAgent.Addin;

/// <summary>
/// Pattern G — system-family sub-categories the class-based Pattern D/B switches don't reach yet.
/// The Revit "System Families" browser is organised by
/// CATEGORY, so each type_id maps to EITHER a concrete ElementType subclass (FEC.OfClass, when a clean
/// public class exists — verified against RevitAPI 2026 via reflection) OR a BuiltInCategory
/// (FEC.OfCategory + WhereElementIsElementType, for the genuinely class-less groups: Ramps, Roof Soffit,
/// Stairs Supports/Carriage/Stringer, Structural Foundation). One generic handler; each future coverage
/// item is a single line in _MAP. Stubs are identical in shape to Pattern D so the Python readers are
/// unaffected.
/// </summary>
public static class PatternG_Handlers
{
    // Exactly one of Cls / Cat is non-null. Cls -> FEC.OfClass; Cat -> FEC.OfCategory + type filter.
    private sealed record GSource(Type? Cls, BuiltInCategory? Cat);

    private static readonly Dictionary<string, GSource> _MAP = new()
    {
        // System Subs (subs convention)
        ["stairs_run_type"]            = new(typeof(StairsRunType), null),
        ["stairs_landing_type"]        = new(typeof(StairsLandingType), null),
        ["stairs_support_type"]        = new(null, BuiltInCategory.OST_StairsStringerCarriage), // Carriage/Stringer (no class; OST_StairsSupports is empty — live-verified)
        ["stairs_cut_mark_type"]       = new(typeof(CutMarkType), null),
        ["handrail_type"]              = new(typeof(HandRailType), null),
        ["toprail_type"]               = new(typeof(TopRailType), null),
        ["roof_soffit_type"]           = new(null, BuiltInCategory.OST_RoofSoffit),          // no class
        // Structural (system convention — folded into the System tab)
        ["beam_system_type"]           = new(typeof(BeamSystemType), null),
        ["structural_foundation_type"] = new(null, BuiltInCategory.OST_StructuralFoundation), // slab + wall foundation
        // Overig (overig convention)
        ["ramp_type"]                  = new(null, BuiltInCategory.OST_Ramps),               // no class
        ["toposolid_type"]             = new(typeof(ToposolidType), null),
        ["building_pad_type"]          = new(typeof(BuildingPadType), null),
        // MEP (mep convention) — the SYSTEM types, distinct from the duct/pipe curve types (Pattern D)
        ["duct_system_type"]           = new(typeof(MechanicalSystemType), null),
        ["piping_system_type"]         = new(typeof(PipingSystemType), null),
    };

    public static bool Handles(string typeId) => _MAP.ContainsKey(typeId);

    public static List<Dictionary<string, object?>> Query(
        string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        if (!_MAP.TryGetValue(typeId, out var src))
            throw new ArgumentException($"Unknown Pattern-G type: {typeId}");
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var col = new FilteredElementCollector(doc);
        IEnumerable<Element> elems = src.Cls != null
            ? col.OfClass(src.Cls).WhereElementIsElementType()
            : col.OfCategory(src.Cat!.Value).WhereElementIsElementType();
        return elems
            .Where(e => e.IsValidObject)
            .Select(e => BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(e.Id), e.GetType().Name, null, e.Name, null, owner, "G",
                categoryName: BasePatternHandlers.SafeCategoryName(e),
                familyName: (e as ElementType)?.FamilyName,
                assemblyCode: BasePatternHandlers.SafeAssemblyCode(e),
                supplier: BasePatternHandlers.SafeSupplier(e),
                includeDescriptionModel: false))
            .ToList();
    }

    public static Dictionary<string, object?> Detail(string typeId, Document doc, long elementId)
    {
        if (!_MAP.ContainsKey(typeId))
            throw new NotImplementedException($"Pattern G detail for {typeId} not yet implemented");
        var owner = BasePatternHandlers.ResolveOwner(doc);
        // Uniform param dump — curated per-type API access would be guesswork across this many classes.
        return BasePatternHandlers.Detail<ElementType>(doc, elementId, owner,
            BasePatternHandlers.DumpParameters, pattern: "G");
    }
}
