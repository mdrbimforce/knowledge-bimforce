using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// Startpunt van de addin. Start de bridge (TCP op 127.0.0.1) en zet een globale dialoog-afhandeling neer.
///
/// Wat de addin zelf wegklikt (buiten een opdracht):
///   alleen een korte lijst bekende, onschuldige meldingen (AlwaysDismissFragments).
/// Wat hij nooit wegklikt:
///   bewaar-dialogen (alles met "Save" in de id) en alle andere dialogen; die blijven voor de gebruiker.
/// Binnen een opdracht die families laadt of bewerkt, regelt een DialogSwallowScope de dialogen en meldt
/// hij ze in het antwoord.
///
/// Elke dialoog komt in het logbestand %TEMP%\revit-agent-debug.log ([dialoog]), zodat je de id van een
/// nieuwe terugkerende melding kunt aflezen.
/// </summary>
public class RevitAgentApp : IExternalApplication
{
    private RevitAgentCommandServer? _server;

    // Bekende onschuldige, terugkerende meldingen: mogen altijd weg. Substring op DialogId.
    private static readonly string[] AlwaysDismissFragments =
    {
        "Dialog_Communicator",                      // Autodesk-communicator/service-meldingen
        "Dialog_External_Service",                  // "Requested service not available"
        "TaskDialog_Missing_Third_Party_Updater",   // updater van een addin die hier niet staat
    };

    private static void OnGlobalDialog(object? sender, Autodesk.Revit.UI.Events.DialogBoxShowingEventArgs e)
    {
        string id;
        try { id = e.DialogId ?? "<leeg>"; } catch { id = "<onbekend>"; }
        if (DialogSwallowScope.IsActive)
        {
            MainThreadDispatcher.Log($"[dialoog] '{id}': opdracht loopt, de dialoogbewaker van de opdracht beslist");
            return;
        }
        if (id.IndexOf("Save", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            MainThreadDispatcher.Log($"[dialoog] bewaar-dialoog '{id}' bewust gelaten");
            return;
        }
        bool bekend = AlwaysDismissFragments.Any(k => id.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0);
        if (bekend)
        {
            MainThreadDispatcher.Log($"[dialoog] bekende melding '{id}' weggedrukt");
            try { e.OverrideResult(1); }
            catch (Exception ex) { MainThreadDispatcher.Log($"[dialoog] wegdrukken '{id}' mislukte: {ex.Message}"); }
        }
        else
            MainThreadDispatcher.Log($"[dialoog] gezien en gelaten: '{id}'");
    }

    public Result OnStartup(UIControlledApplication application)
    {
        RevitBridge.ControlledApp = application.ControlledApplication;
        MainThreadDispatcher.Initialize(application);

        try { application.DialogBoxShowing += OnGlobalDialog; } catch { }

        // Poort bezet door een andere Revit met de bridge: de server zoekt de volgende vrije (tot +5).
        // Lukt geen enkele, dan draait deze Revit gewoon zonder bridge.
        try
        {
            _server = RevitAgentCommandServer.StartOpVrijePoort();
        }
        catch (Exception ex)
        {
            MainThreadDispatcher.Log($"[start] bridge niet gestart: {ex.Message}");
            _server = null;
        }
        return Result.Succeeded;
    }

    public Result OnShutdown(UIControlledApplication application)
    {
        _server?.Dispose();
        return Result.Succeeded;
    }
}
