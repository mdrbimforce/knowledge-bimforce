using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_parameter_value — write parameter values from the remediation workbook.
/// Two targets:
///   - element value  (Material Parameters tab): edit {element_id, param_name, new_value}
///   - family default (Family/Builtin tabs):     edit {family, param_name, new_value}  (current-type default)
///
/// new_value is ALWAYS UI text. For ElementId-typed params (e.g. a material-valued param) the text is a
/// UI NAME resolved to the element; on a name mismatch the edit FAILS with a note (spec). Other
/// types go through Parameter.SetValueString (unit-aware) with a String fallback. dry_run (default) reports
/// current -> new without mutating; save_first writes a numbered backup before the first change.
///
/// params: target_document, edits:[{element_id?|family?, param_name, new_value, expected_current?}],
///          dry_run (default TRUE), save_first (default false).
/// </summary>
public static class SetValueHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }

    private record Edit(int? ElementId, string? Family, string ParamName, string NewValue, string? ExpectedCurrent);

    public static CommandResponse SetParameterValue(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        var edits = ParseEdits(p);
        if (edits.Count == 0) return Err("edits required: [{element_id|family, param_name, new_value}]");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");

                var elementEdits = edits.Where(e => e.ElementId != null).ToList();
                var familyEdits = edits.Where(e => e.ElementId == null && !string.IsNullOrWhiteSpace(e.Family)).ToList();
                var results = new List<Dictionary<string, object?>>();

                bool savedBackup = false;
                if (!dryRun && saveFirst && (elementEdits.Count > 0 || familyEdits.Count > 0))
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, set aborted: {ex.Message}"); }
                }

                // ── element values (materials etc.) ──
                if (elementEdits.Count > 0)
                {
                    if (dryRun)
                    {
                        foreach (var e in elementEdits) results.Add(InspectElement(doc, e));
                    }
                    else
                    {
                        using var t = new Transaction(doc, "NLRS set parameter values");
                        t.Start();
                        foreach (var e in elementEdits) results.Add(ApplyElement(doc, e));
                        t.Commit();
                    }
                }

                // ── family defaults (per family: EditFamily -> set on current type -> LoadFamily) ──
                foreach (var grp in familyEdits.GroupBy(e => e.Family!))
                {
                    var fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                        .FirstOrDefault(f => f.IsValidObject && f.IsEditable && f.Name.Equals(grp.Key, StringComparison.OrdinalIgnoreCase));
                    if (fam == null)
                    {
                        foreach (var e in grp) results.Add(Res(e, "not_found", $"family '{grp.Key}' niet (editable) gevonden"));
                        continue;
                    }
                    Document? fdoc = null;
                    try
                    {
                        fdoc = doc.EditFamily(fam);
                        var fm = fdoc.FamilyManager;
                        var ct = fm.CurrentType;
                        if (dryRun)
                        {
                            foreach (var e in grp) results.Add(InspectFamily(fm, ct, e));
                            fdoc.Close(false); continue;
                        }
                        bool any = false;
                        using (var t = new Transaction(fdoc, "NLRS set family default"))
                        {
                            t.Start();
                            if (ct != null) { try { fm.CurrentType = ct; } catch { } }
                            foreach (var e in grp)
                            {
                                var fp = FindFp(fm, e.ParamName);
                                if (fp == null) { results.Add(Res(e, "not_found", "family-param niet gevonden")); continue; }
                                if (fp.IsDeterminedByFormula || fp.Formula != null) { results.Add(Res(e, "failed", "param wordt door formule bepaald")); continue; }
                                try { fm.SetValueString(fp, e.NewValue); results.Add(Res(e, "set", null)); any = true; }
                                catch (Exception ex) { results.Add(Res(e, "failed", ex.Message)); }
                            }
                            if (any) t.Commit(); else t.RollBack();
                        }
                        if (any) fdoc.LoadFamily(doc, new FamLoadOpts());
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        foreach (var e in grp) results.Add(Res(e, "error", ex.Message));
                        try { fdoc?.Close(false); } catch { }
                    }
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["saved_backup"] = savedBackup,
                    ["set"] = results.Count(r => (string?)r.GetValueOrDefault("status") == "set"),
                    ["failed"] = results.Count(r => ((string?)r.GetValueOrDefault("status") ?? "").Contains("fail")
                                                    || (string?)r.GetValueOrDefault("status") == "error"),
                    ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── element helpers ──────────────────────────────────────────────────
    private static Dictionary<string, object?> InspectElement(Document doc, Edit e)
    {
        var elem = doc.GetElement(new ElementId((long)e.ElementId!.Value));
        if (elem == null || !elem.IsValidObject) return Res(e, "not_found", "element niet gevonden");
        var par = elem.LookupParameter(e.ParamName);
        if (par == null) return Res(e, "not_found", "param niet op element");
        var cur = ReadVal(doc, par);
        if (e.ExpectedCurrent != null && cur != e.ExpectedCurrent) return Res(e, "stale", $"huidig '{cur}' != verwacht '{e.ExpectedCurrent}'");
        if (par.IsReadOnly) return Res(e, "read_only", "param is read-only");
        return Res(e, "would_set", null, cur);
    }

    private static Dictionary<string, object?> ApplyElement(Document doc, Edit e)
    {
        var elem = doc.GetElement(new ElementId((long)e.ElementId!.Value));
        if (elem == null || !elem.IsValidObject) return Res(e, "not_found", "element niet gevonden");
        var par = elem.LookupParameter(e.ParamName);
        if (par == null) return Res(e, "not_found", "param niet op element");
        if (par.IsReadOnly) return Res(e, "read_only", "param is read-only");
        var cur = ReadVal(doc, par);
        if (e.ExpectedCurrent != null && cur != e.ExpectedCurrent) return Res(e, "stale", $"huidig '{cur}' != verwacht '{e.ExpectedCurrent}'");
        if (par.StorageType == StorageType.ElementId)
        {
            var id = ResolveByName(doc, e.NewValue);
            if (id == null) return Res(e, "failed", $"geen element met UI-naam '{e.NewValue}' (ElementId-mismatch)");
            return par.Set(id) ? Res(e, "set", null) : Res(e, "failed", "Set(ElementId) geweigerd");
        }
        try { if (par.SetValueString(e.NewValue)) return Res(e, "set", null); } catch { }
        if (par.StorageType == StorageType.String) return par.Set(e.NewValue) ? Res(e, "set", null) : Res(e, "failed", "Set(string) geweigerd");
        // Integer fallbacks (stijl-edits): SetValueString kent geen yes/no-checkboxes
        // (Bold/Italic/Underline) en geen kleur-pickers (Color slaat op als int, UI toont R,G,B). Beide
        // komen als UI-tekst uit het workbook binnen — hier expliciet geconverteerd i.p.v. generiek falen.
        if (par.StorageType == StorageType.Integer)
        {
            var v = e.NewValue.Trim().ToLowerInvariant();
            if (v is "1" or "yes" or "ja" or "true")
                return par.Set(1) ? Res(e, "set", null) : Res(e, "failed", "Set(1) geweigerd");
            if (v is "0" or "no" or "nee" or "false")
                return par.Set(0) ? Res(e, "set", null) : Res(e, "failed", "Set(0) geweigerd");
            var rgbParts = e.NewValue.Split(',');
            if (rgbParts.Length == 3
                && byte.TryParse(rgbParts[0].Trim(), out var rr)
                && byte.TryParse(rgbParts[1].Trim(), out var gg)
                && byte.TryParse(rgbParts[2].Trim(), out var bb))
            {
                int bgr = rr | (gg << 8) | (bb << 16);  // Revit kleur-int is BGR-gepakt (zie GetTextNoteTypes)
                return par.Set(bgr) ? Res(e, "set", null) : Res(e, "failed", "Set(kleur-int) geweigerd");
            }
            if (int.TryParse(e.NewValue.Trim(), out var iv))
                return par.Set(iv) ? Res(e, "set", null) : Res(e, "failed", "Set(int) geweigerd");
        }
        return Res(e, "failed", "kon UI-tekst niet naar waarde converteren");
    }

    private static string? ReadVal(Document doc, Parameter par)
    {
        try
        {
            if (par.StorageType == StorageType.ElementId)
            {
                var id = par.AsElementId();
                return (id != null && id != ElementId.InvalidElementId) ? doc.GetElement(id)?.Name : null;
            }
            return par.AsValueString() ?? par.AsString();
        }
        catch { return null; }
    }

    private static ElementId? ResolveByName(Document doc, string name)
    {
        var n = name.Trim();
        var mat = new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>()
            .FirstOrDefault(m => m.Name.Equals(n, StringComparison.OrdinalIgnoreCase));
        if (mat != null) return mat.Id;
        var el = new FilteredElementCollector(doc).WhereElementIsNotElementType()
            .FirstOrDefault(e => e.Name == n);
        if (el != null) return el.Id;
        // ElementTypes als laatste: een ElementId-param kan naar een TYPE wijzen —
        // concreet: Dimension Styles' Tick Mark is een arrowhead-ElementType. Types NA instances zodat
        // bestaand gedrag (materials, instances) voorrang houdt bij naam-collisies.
        var ty = new FilteredElementCollector(doc).WhereElementIsElementType()
            .FirstOrDefault(t => t.Name == n);
        return ty?.Id;
    }

    // ── family helpers ───────────────────────────────────────────────────
    private static FamilyParameter? FindFp(FamilyManager fm, string name)
    {
        foreach (FamilyParameter fp in fm.Parameters)
            if (fp?.Definition != null && fp.Definition.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return fp;
        return null;
    }

    private static Dictionary<string, object?> InspectFamily(FamilyManager fm, FamilyType? ct, Edit e)
    {
        var fp = FindFp(fm, e.ParamName);
        if (fp == null) return Res(e, "not_found", "family-param niet gevonden");
        if (fp.IsDeterminedByFormula || fp.Formula != null) return Res(e, "failed", "param wordt door formule bepaald");
        string? cur = null; try { cur = ct?.AsValueString(fp) ?? ct?.AsString(fp); } catch { }
        return Res(e, "would_set", null, cur);
    }

    // ── shared ───────────────────────────────────────────────────────────
    private static Dictionary<string, object?> Res(Edit e, string status, string? err, string? current = null) => new()
    {
        ["element_id"] = e.ElementId,
        ["family"] = e.Family,
        ["param"] = e.ParamName,
        ["new_value"] = e.NewValue,
        ["current"] = current,
        ["status"] = status,
        ["error"] = err ?? "",
    };

    private static List<Edit> ParseEdits(Dictionary<string, JsonElement>? p)
    {
        var outl = new List<Edit>();
        if (p == null || !p.TryGetValue("edits", out var arr) || arr.ValueKind != JsonValueKind.Array) return outl;
        foreach (var item in arr.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.Object) continue;
            int? eid = null;
            if (item.TryGetProperty("element_id", out var eel) && eel.ValueKind == JsonValueKind.Number) eid = eel.GetInt32();
            string? fam = item.TryGetProperty("family", out var fel) && fel.ValueKind == JsonValueKind.String ? fel.GetString() : null;
            string? pn = item.TryGetProperty("param_name", out var pel) && pel.ValueKind == JsonValueKind.String ? pel.GetString() : null;
            string? nv = item.TryGetProperty("new_value", out var nel) && nel.ValueKind == JsonValueKind.String ? nel.GetString() : null;
            string? ec = item.TryGetProperty("expected_current", out var cel) && cel.ValueKind == JsonValueKind.String ? cel.GetString() : null;
            if (string.IsNullOrWhiteSpace(pn) || nv == null) continue;
            outl.Add(new Edit(eid, fam, pn!, nv, ec));
        }
        return outl;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
