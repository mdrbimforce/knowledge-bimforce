using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// rename_nested_families_rfa — hernoem de (gedeelde) geneste families in een .rfa op schijf.
/// Reden: LoadFamily van een deur-rfa waarvan de geneste families nog de oude naam dragen (FR_32_GM_…) brengt
/// die onder de oude naam opnieuw het project in, naast de al hernoemde projectversie (FR_…). Door de nesting
/// in de rfa eerst te hernoemen en daarna te laden met shared_source=project, hangt de deur weer aan de
/// projectfamilies en kunnen de dubbelen worden verwijderd.
///
/// params: rfa_path (verplicht), renames:[{old_name,new_name}] en/of regex_from + regex_to (Regex.Replace op
/// elke geneste familienaam), dry_run (default true), dialog_ok (default true), list_only (default false).
/// </summary>
public static class NestedFamilyHandlers
{
    public static CommandResponse RenameNestedFamilies(CommandRequest request)
    {
        var p = request.Params;
        string? rfaPath = GetString(p, "rfa_path");
        bool dryRun = GetBool(p, "dry_run", true);
        bool dialogOk = GetBool(p, "dialog_ok", true);
        string? rxFrom = GetString(p, "regex_from"), rxTo = GetString(p, "regex_to");
        if (string.IsNullOrWhiteSpace(rfaPath) || !File.Exists(rfaPath)) return Err($"rfa_path ontbreekt of bestaat niet: {rfaPath}");

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (p != null && p.TryGetValue("renames", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? o = GetProp(it, "old_name"), n = GetProp(it, "new_name");
                if (o != null && n != null) map[o.Trim()] = n.Trim();
            }
        System.Text.RegularExpressions.Regex? rx = null;
        if (rxFrom != null) { try { rx = new System.Text.RegularExpressions.Regex(rxFrom); } catch (Exception ex) { return Err($"regex_from ongeldig: {ex.Message}"); } }

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var results = new List<Dictionary<string, object?>>();
                int renamed = 0, unchanged = 0, failed = 0;
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.Context = Path.GetFileNameWithoutExtension(rfaPath);
                Document? fdoc = null;
                try
                {
                    MainThreadDispatcher.Log($"rename_nested_families_rfa: opening '{rfaPath}'");
                    fdoc = app.Application.OpenDocumentFile(rfaPath);
                    if (!fdoc.IsFamilyDocument) return (object)Fail("rfa_path is geen family document");
                    var fams = new FilteredElementCollector(fdoc).OfClass(typeof(Family)).Cast<Family>().ToList();
                    var existing = new HashSet<string>(fams.Select(f => f.Name), StringComparer.OrdinalIgnoreCase);
                    var plan = new List<(Family fam, string oldName, string newName)>();
                    foreach (var f in fams)
                    {
                        string old = f.Name, nn = old;
                        if (map.TryGetValue(old, out var m)) nn = m;
                        else if (rx != null) nn = rx.Replace(old, rxTo ?? "");
                        bool shared = false; try { shared = f.get_Parameter(BuiltInParameter.FAMILY_SHARED)?.AsInteger() == 1; } catch { }
                        var row = new Dictionary<string, object?> { ["old_name"] = old, ["new_name"] = nn, ["shared"] = shared, ["category"] = f.FamilyCategory?.Name };
                        if (nn == old) { row["status"] = "unchanged"; unchanged++; results.Add(row); continue; }
                        if (existing.Contains(nn)) { row["status"] = "error"; row["error"] = "doelnaam bestaat al in de rfa"; failed++; results.Add(row); continue; }
                        row["status"] = dryRun ? "would_rename" : "pending"; results.Add(row); plan.Add((f, old, nn));
                    }
                    if (!dryRun && plan.Count > 0)
                    {
                        using (var t = new Transaction(fdoc, "Revit Agent: rename nested families"))
                        {
                            t.Start();
                            foreach (var (fam, old, nn) in plan)
                            {
                                var row = results.First(r => (string?)r["old_name"] == old);
                                try { fam.Name = nn; row["status"] = "renamed"; renamed++; }
                                catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; failed++; }
                            }
                            t.Commit();
                        }
                        fdoc.Save();
                    }
                    else if (dryRun) renamed = plan.Count;
                }
                finally
                {
                    try { fdoc?.Close(false); } catch { }
                }
                return (object)new Dictionary<string, object?>
                {
                    ["rfa_path"] = rfaPath, ["dry_run"] = dryRun, ["renamed"] = renamed, ["unchanged"] = unchanged, ["failed"] = failed,
                    ["results"] = results, ["notable_dialogs"] = swallow.NotableReport()
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static string? GetProp(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
