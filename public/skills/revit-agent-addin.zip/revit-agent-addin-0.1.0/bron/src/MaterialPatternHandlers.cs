using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_material_fill_pattern — set a material's surface/cut foreground+background fill
/// patterns (referenced BY NAME, resolved against the target doc so it consumes the FillPatterns name-map)
/// and their colours. Each property is set independently and reported; an unknown pattern is skipped.
///
/// params:
///   target_document : string (required)
///   edits : [{ material_name,
///       surface_fg_pattern, surface_bg_pattern, cut_fg_pattern, cut_bg_pattern,   // FillPatternElement names
///       surface_fg_color, surface_bg_color, cut_fg_color, cut_bg_color }]         // "RRGGBB"
///   dry_run : bool (default true) · save_first : bool (default false)
/// </summary>
public static class MaterialPatternHandlers
{
    public static CommandResponse SetMaterialFillPattern(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        bool saveFirst = HandlerUtil.Bool(p, "save_first", false);
        if (target == null)
            return new CommandResponse { Success = false, Error = "Parameter 'target_document' is required" };
        var edits = HandlerUtil.Arr(p, "edits");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target) ?? throw new Exception($"target_document '{target}' is not open");
                var results = new List<Dictionary<string, object?>>();
                int changed = 0;
                string? saved = null;

                void Apply(bool commit)
                {
                    foreach (var e in edits)
                    {
                        string? mn = HandlerUtil.Str(e, "material_name");
                        var mat = mn != null ? HandlerUtil.MaterialByName(doc, mn) : null;
                        if (mat == null) { results.Add(new() { ["material"] = mn, ["status"] = "skipped", ["reason"] = "materiaal niet gevonden" }); continue; }
                        var done = new List<string>(); var fail = new List<string>();

                        void Pat(string key, Action<ElementId> set)
                        {
                            var n = HandlerUtil.Str(e, key);
                            if (n == null) return;
                            var id = HandlerUtil.FillPatternIdByName(doc, n);
                            if (id == ElementId.InvalidElementId) { fail.Add($"{key}: patroon '{n}' niet gevonden"); return; }
                            try { if (commit) set(id); done.Add($"{key}={n}"); } catch (Exception ex) { fail.Add($"{key}: {ex.Message}"); }
                        }
                        void Col(string key, Action<Color> set)
                        {
                            if (HandlerUtil.Colour(e, key) is Color c) { try { if (commit) set(c); done.Add(key); } catch (Exception ex) { fail.Add($"{key}: {ex.Message}"); } }
                        }

                        Pat("surface_fg_pattern", id => mat.SurfaceForegroundPatternId = id);
                        Pat("surface_bg_pattern", id => mat.SurfaceBackgroundPatternId = id);
                        Pat("cut_fg_pattern", id => mat.CutForegroundPatternId = id);
                        Pat("cut_bg_pattern", id => mat.CutBackgroundPatternId = id);
                        Col("surface_fg_color", c => mat.SurfaceForegroundPatternColor = c);
                        Col("surface_bg_color", c => mat.SurfaceBackgroundPatternColor = c);
                        Col("cut_fg_color", c => mat.CutForegroundPatternColor = c);
                        Col("cut_bg_color", c => mat.CutBackgroundPatternColor = c);

                        if (commit && done.Count > 0) changed++;
                        results.Add(new()
                        {
                            ["material"] = mat.Name,
                            ["status"] = fail.Count > 0 && done.Count == 0 ? "error" : (dryRun ? "would_update" : "updated"),
                            ["applied"] = done, ["failed"] = fail
                        });
                    }
                }

                if (dryRun) Apply(false);
                else
                {
                    if (saveFirst) { try { doc.Save(); saved = doc.Title; } catch (Exception ex) { throw new Exception($"save_first failed: {ex.Message}"); } }
                    using var t = new Transaction(doc, "set material fill patterns");
                    t.Start(); Apply(true); t.Commit();
                }
                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun, ["target_document"] = doc.Title, ["saved_document"] = saved,
                    ["updated"] = changed, ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }
}
