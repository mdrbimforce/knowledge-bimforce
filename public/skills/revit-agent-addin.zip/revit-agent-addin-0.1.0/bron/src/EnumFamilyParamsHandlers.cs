using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// enum_family_parameters — read-only inventory of FamilyManager parameters across loadable families
/// Feeds two remediation tabs:
///   - Shared Family Parameters  : the IsShared subset  -> swap_family_parameter
///   - Builtin Family Parameters : the !IsShared subset (couplable spec, filtered Python-side) -> couple_builtin_parameter
///
/// Per family it opens an edit doc (doc.EditFamily), iterates fm.Parameters, and reports per parameter:
/// name, is_shared (+GUID), spec, is_instance, has_formula/formula, referenced_by_formulas (which other
/// params' formulas mention it), coupled_to (which SHARED params mirror it via formula — detects the
/// couple_builtin result), and default_value (current-type UI string, for the value-edit step). No
/// transaction, no LoadFamily — purely read; closes each edit doc with Close(false).
///
/// params: target_document (scope by Title), families [string] | scan_all (open every editable family — slow).
/// </summary>
public static class EnumFamilyParamsHandlers
{
    public static CommandResponse EnumFamilyParameters(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool scanAll = GetBool(p, "scan_all", false);
        bool dialogOk = GetBool(p, "dialog_ok", false);
        int dialogResult = GetInt(p, "dialog_result", 1);
        var famWhitelist = GetStringList(p, "families");
        if ((famWhitelist == null || famWhitelist.Count == 0) && !scanAll)
            return Err("provide 'families' (names) or set scan_all=true (opens every editable family — slow)");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");

                var fams = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable);
                if (famWhitelist != null && famWhitelist.Count > 0)
                {
                    var want = famWhitelist.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                    fams = fams.Where(f => want.Contains(f.Name.ToLowerInvariant()));
                }

                var outParams = new List<Dictionary<string, object?>>();
                int scanned = 0, failed = 0;

                // Auto-dismiss modal dialogs so a family whose definition pops a warning (open-warnings,
                // "Constraints are not satisfied", missing refs) on EditFamily can't block the main thread
                // and hang the bridge. Every dialog is recorded + attributed to its family; notable ones are
                // surfaced in the response. Without this guard
                // a single bad family hung the whole scan_all.
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.BlindResult = dialogResult;
                foreach (var fam in fams.ToList())
                {
                    swallow.Context = fam.Name;
                    Document? fdoc = null;
                    // Logged BEFORE EditFamily (not caught by the try/catch below): if this family's
                    // definition triggers a blocking Revit dialog (e.g. "Constraints are not satisfied"),
                    // EditFamily hangs the whole app and never returns/throws — the try/catch can't help.
                    // The debug log file is written synchronously, so it survives the hang and lets a
                    // human/agent identify the offending family via get_diagnostics or the raw log file
                    // instead of having to catch the dialog live on screen.
                    MainThreadDispatcher.Log($"enum_family_parameters: opening family '{fam.Name}' (category={fam.FamilyCategory?.Name})");
                    try
                    {
                        fdoc = doc.EditFamily(fam);
                        var fm = fdoc.FamilyManager;
                        string famName = fam.Name;
                        string catName = fam.FamilyCategory?.Name ?? "";
                        FamilyType? ct = null;
                        try { ct = fm.CurrentType; } catch { }

                        // Pre-read each param's name + formula once (for referenced_by / coupled_to cross-scan).
                        var all = new List<FamilyParameter>();
                        foreach (FamilyParameter fp in fm.Parameters)
                            if (fp?.Definition != null) all.Add(fp);

                        foreach (var fp in all)
                        {
                            string name = fp.Definition.Name;
                            string? formula = null; try { formula = fp.Formula; } catch { }
                            bool isShared = false; string? guid = null;
                            try { isShared = fp.IsShared; if (isShared) guid = fp.GUID.ToString(); } catch { }

                            // formulas that reference this param, split into shared (coupled_to) and other.
                            var refBy = new List<string>();
                            var coupledTo = new List<string>();
                            foreach (var other in all)
                            {
                                if (ReferenceEquals(other, fp)) continue;
                                string? of = null; try { of = other.Formula; } catch { }
                                if (string.IsNullOrEmpty(of) || !of!.Contains(name)) continue;
                                refBy.Add(other.Definition.Name);
                                bool oShared = false; try { oShared = other.IsShared; } catch { }
                                if (oShared) coupledTo.Add(other.Definition.Name);
                            }

                            string? defVal = null;
                            if (ct != null)
                                try { defVal = ct.AsValueString(fp) ?? ct.AsString(fp); } catch { }

                            outParams.Add(new Dictionary<string, object?>
                            {
                                ["family"] = famName,
                                ["category"] = catName,
                                ["name"] = name,
                                ["is_shared"] = isShared,
                                ["guid"] = guid,
                                ["spec"] = fp.Definition.GetDataType().TypeId,
                                ["is_instance"] = fp.IsInstance,
                                ["has_formula"] = !string.IsNullOrEmpty(formula),
                                ["formula"] = formula,
                                ["referenced_by_formulas"] = refBy,
                                ["coupled_to"] = coupledTo,
                                ["default_value"] = defVal,
                            });
                        }
                        scanned++;
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        failed++;
                        outParams.Add(new Dictionary<string, object?> { ["family"] = fam.Name, ["error"] = ex.Message });
                        try { fdoc?.Close(false); } catch { }
                    }
                }

                var outDict = new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["families_scanned"] = scanned,
                    ["families_failed"] = failed,
                    ["parameter_count"] = outParams.Count,
                    ["parameters"] = outParams,
                };
                swallow.WriteTo(outDict);
                return (object)outDict;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── helpers (self-contained) ─────────────────────────────────────────
    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                     .Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        return null;
    }
    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        return dflt;
    }
}
