using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// rename_family_parameter — hernoem FAMILY-parameters (niet-shared) in loadable families (vertaling,
/// bv. EL_sponningbreedte -> LargeurFeuillure etc.). Shared parameters hebben hun naam in het
/// SP-bestand/GUID en worden hier bewust NIET hernoemd (status shared_not_renamable) — daarvoor bestaat de
/// SP-bestand-route met GUID-behoud.
///
/// Per family: EditFamily -> FamilyManager.RenameParameter in een transactie -> LoadFamily terug -> Close(false).
/// Zelfde edit/load-cyclus en save-first-backup-gate als set_family_formula.
///
/// params:
///   target_document : scope op Title
///   edits : [{family, param_name, new_name, expected_current?}]   (expected_current = huidige naam, extra guard)
///   dry_run    : bool (default TRUE)
///   save_first : bool (default false) — genummerde backup vóór de eerste LoadFamily-overwrite
/// </summary>
public static class RenameFamilyParamHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Project; overwriteParameterValues = true; return true; }   // Project: FamilySource.Family bracht bij herladen de geneste kopieën als dubbel-typen " 1" binnen en verhing exemplaren
    }

    private record RenameEdit(string Family, string ParamName, string NewName, string? Expected);

    public static CommandResponse RenameFamilyParameter(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool dialogOk = GetBool(p, "dialog_ok", false);
        int dialogResult = GetInt(p, "dialog_result", 1);
        bool saveFirst = GetBool(p, "save_first", false);
        string? rfaPath = GetString(p, "rfa_path");   // optioneel: family-doc van schijf (Save) i.p.v. EditFamily/LoadFamily; edits.family = bestandsnaam zonder .rfa

        var edits = new List<RenameEdit>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? fam = GetProp(it, "family"), pn = GetProp(it, "param_name"), nn = GetProp(it, "new_name");
                if (string.IsNullOrWhiteSpace(fam) || string.IsNullOrWhiteSpace(pn) || string.IsNullOrWhiteSpace(nn)) continue;
                edits.Add(new RenameEdit(fam!.Trim(), pn!.Trim(), nn!.Trim(), GetProp(it, "expected_current")));
            }
        if (edits.Count == 0) return Err("edits:[{family, param_name, new_name}] is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, aborted: {ex.Message}"); }
                }

                var byFam = edits.GroupBy(e => e.Family.ToLowerInvariant()).ToDictionary(g => g.Key, g => g.ToList());
                var results = new List<Dictionary<string, object?>>();
                int applied = 0, failed = 0, notfound = 0;

                var fams = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable && byFam.ContainsKey(f.Name.ToLowerInvariant())).ToList();
                bool fromDisk = rfaPath != null;
                if (fromDisk && !System.IO.File.Exists(rfaPath)) return (object)Fail($"rfa_path bestaat niet: {rfaPath}");
                var famsIter = fromDisk ? new List<Family?> { null } : fams.Cast<Family?>().ToList();
                var seen = new HashSet<string>();

                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.BlindResult = dialogResult;
                foreach (var fam in famsIter)
                {
                    string famLabel; try { famLabel = fromDisk ? System.IO.Path.GetFileNameWithoutExtension(rfaPath!) : fam!.Name; } catch { results.Add(new Dictionary<string, object?> { ["family"] = "<ongeldig Family-element>", ["status"] = "error", ["error"] = "Family-element ongeldig (edit-doc open of herladen?)" }); failed++; continue; }
                    var key = famLabel.ToLowerInvariant();
                    if (fromDisk && !byFam.ContainsKey(key)) key = byFam.Keys.First();
                    seen.Add(key);
                    swallow.Context = famLabel;
                    Document? fdoc = null;
                    try
                    {
                        MainThreadDispatcher.Log($"rename_family_parameter: opening family '{famLabel}'");
                        fdoc = fromDisk ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                        var fm = fdoc.FamilyManager;
                        var pending = new List<Dictionary<string, object?>>();
                        bool anyOk = false;
                        using (var t = new Transaction(fdoc, "Revit Agent: rename family parameter"))
                        {
                            t.Start();
                            foreach (var ed in byFam[key])
                            {
                                var info = new Dictionary<string, object?> { ["family"] = famLabel, ["param"] = ed.ParamName, ["new_name"] = ed.NewName };
                                var fp = FindByName(fm, ed.ParamName);
                                if (fp == null) { info["status"] = "not_found"; notfound++; pending.Add(info); continue; }
                                if (fp.IsShared) { info["status"] = "shared_not_renamable"; info["reason"] = "shared parameter: naam volgt uit SP-bestand (GUID), gebruik de SP-route"; failed++; pending.Add(info); continue; }
                                if (ed.Expected != null && !fp.Definition.Name.Equals(ed.Expected, StringComparison.Ordinal))
                                { info["status"] = "stale_skip"; info["reason"] = $"huidige naam '{fp.Definition.Name}' != verwacht '{ed.Expected}'"; pending.Add(info); continue; }
                                if (FindByName(fm, ed.NewName) != null)
                                { info["status"] = "name_exists"; info["reason"] = $"parameter '{ed.NewName}' bestaat al in deze family"; failed++; pending.Add(info); continue; }
                                if (dryRun) { info["status"] = "would_rename"; pending.Add(info); continue; }
                                try { fm.RenameParameter(fp, ed.NewName); info["status"] = "renamed"; anyOk = true; applied++; }
                                catch (Exception ex) { info["status"] = "error"; info["error"] = ex.Message; failed++; }
                                pending.Add(info);
                            }
                            if (!dryRun && anyOk) t.Commit(); else t.RollBack();
                        }
                        if (!dryRun && anyOk) { if (fromDisk) fdoc.Save(); else fdoc.LoadFamily(doc, new FamLoadOpts()); }
                        results.AddRange(pending);
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        failed++;
                        results.Add(new Dictionary<string, object?> { ["family"] = famLabel, ["status"] = "error", ["error"] = ex.Message });
                        try { fdoc?.Close(false); } catch { }
                    }
                }
                foreach (var kv in byFam)
                    if (!seen.Contains(kv.Key))
                        foreach (var ed in kv.Value)
                        { results.Add(new Dictionary<string, object?> { ["family"] = ed.Family, ["param"] = ed.ParamName, ["status"] = "family_not_found" }); notfound++; }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup,
                    ["applied"] = applied, ["failed"] = failed, ["not_found"] = notfound,
                    ["notable_dialogs"] = swallow.NotableReport(), ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static FamilyParameter? FindByName(FamilyManager fm, string name)
    {
        foreach (FamilyParameter fp in fm.Parameters)
            if (fp?.Definition != null && fp.Definition.Name.Equals(name, StringComparison.Ordinal)) return fp;
        return null;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static string? GetProp(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String)
        { var s = el.GetString(); return string.IsNullOrWhiteSpace(s) ? null : s; }
        return null;
    }
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) return el.GetString();
        return null;
    }
    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        return dflt;
    }
}
