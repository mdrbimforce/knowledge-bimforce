using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// create_sheet: een sheet maken en optioneel views (of schedules) erop plaatsen.
/// params: target_document · sheet_number · sheet_name
///         · titleblock: "Familie : Type", of alleen de typenaam; leeg = het eerste titleblock in het model;
///           "geen" = een sheet zonder titleblock
///         · views: [{ "view": naam of element-id, "x_mm": .., "y_mm": .. }]  (midden van de viewport op de sheet;
///           zonder positie komen ze naast elkaar)
///         · dry_run (true): doet het in een transactie en draait die terug
/// Een view die al op een andere sheet staat, kan niet nog eens geplaatst worden (Revit-regel); dat staat in het antwoord.
/// </summary>
public static class SheetHandlers
{
    private const double MmPerFt = 304.8;

    public static CommandResponse CreateSheet(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        var nummer = HandlerUtil.Str(p, "sheet_number");
        var naam = HandlerUtil.Str(p, "sheet_name");
        if (target == null || nummer == null || naam == null) return Err("target_document, sheet_number en sheet_name zijn verplicht");
        var tbKeuze = HandlerUtil.Str(p, "titleblock");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        var viewSpecs = HandlerUtil.Arr(p, "views");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)DocumentHandlers.Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)DocumentHandlers.Fail("sheets bestaan alleen in een project");
                if (new FilteredElementCollector(doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().Any(s => s.SheetNumber == nummer))
                    return (object)DocumentHandlers.Fail($"sheetnummer '{nummer}' bestaat al");

                var tbs = new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_TitleBlocks)
                    .WhereElementIsElementType().Cast<FamilySymbol>().ToList();
                ElementId tbId = ElementId.InvalidElementId;
                string? tbNaam = null;
                if (!string.Equals(tbKeuze, "geen", StringComparison.OrdinalIgnoreCase))
                {
                    FamilySymbol? tb = null;
                    if (tbKeuze == null) tb = tbs.FirstOrDefault();
                    else
                    {
                        var delen = tbKeuze.Split(':').Select(s => s.Trim()).ToArray();
                        tb = delen.Length == 2
                            ? tbs.FirstOrDefault(s => s.FamilyName == delen[0] && s.Name == delen[1])
                            : tbs.FirstOrDefault(s => s.Name == tbKeuze) ?? tbs.FirstOrDefault(s => s.FamilyName == tbKeuze);
                        if (tb == null)
                            return (object)new Dictionary<string, object?>()
                            {
                                ["error"] = $"titleblock '{tbKeuze}' niet gevonden", ["ok"] = false,
                                ["beschikbaar"] = tbs.Select(s => $"{s.FamilyName} : {s.Name}").ToList(),
                            };
                    }
                    if (tb != null) { tbId = tb.Id; tbNaam = $"{tb.FamilyName} : {tb.Name}"; }
                }

                var plaatsingen = new List<Dictionary<string, object?>>();
                var res = new Dictionary<string, object?>();
                using (var t = new Transaction(doc, "Revit Agent: sheet maken"))
                {
                    t.Start();
                    var fv = HandlerUtil.ZetFailureVerzamelaar(t);
                    if (tbId != ElementId.InvalidElementId)
                    {
                        var sym = (FamilySymbol)doc.GetElement(tbId);
                        if (!sym.IsActive) sym.Activate();
                    }
                    var sheet = ViewSheet.Create(doc, tbId);
                    sheet.SheetNumber = nummer;
                    sheet.Name = naam;
                    doc.Regenerate();

                    double volgendeX = 150 / MmPerFt; // naast elkaar als er geen positie is
                    foreach (var spec in viewSpecs)
                    {
                        string? viewSleutel = spec.ValueKind == JsonValueKind.String ? spec.GetString()
                            : spec.ValueKind == JsonValueKind.Object && spec.TryGetProperty("view", out var ve)
                                ? (ve.ValueKind == JsonValueKind.Number ? ve.GetInt64().ToString() : ve.GetString()) : null;
                        var rij = new Dictionary<string, object?>() { ["view"] = viewSleutel };
                        plaatsingen.Add(rij);
                        if (viewSleutel == null) { rij["status"] = "geen view opgegeven"; continue; }
                        View? view = null;
                        if (long.TryParse(viewSleutel, out var vid)) view = doc.GetElement(new ElementId(vid)) as View;
                        view ??= new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
                            .FirstOrDefault(v => !v.IsTemplate && v.Name == viewSleutel);
                        if (view == null) { rij["status"] = "view niet gevonden"; continue; }
                        double? x = HandlerUtil.Dbl(spec, "x_mm"), y = HandlerUtil.Dbl(spec, "y_mm");
                        var punt = x != null && y != null ? new XYZ(x.Value / MmPerFt, y.Value / MmPerFt, 0) : new XYZ(volgendeX, 300 / MmPerFt, 0);
                        try
                        {
                            if (view is ViewSchedule vs)
                            {
                                var ssi = ScheduleSheetInstance.Create(doc, sheet.Id, vs.Id, punt);
                                rij["status"] = "geplaatst"; rij["element_id"] = ssi.Id.Value; rij["soort"] = "schedule";
                            }
                            else if (!Viewport.CanAddViewToSheet(doc, sheet.Id, view.Id))
                                rij["status"] = "kan niet: staat al op een sheet, of is een view die niet op een sheet kan";
                            else
                            {
                                var vp = Viewport.Create(doc, sheet.Id, view.Id, punt);
                                rij["status"] = "geplaatst"; rij["element_id"] = vp.Id.Value; rij["soort"] = "viewport";
                            }
                            rij["x_mm"] = Math.Round(punt.X * MmPerFt); rij["y_mm"] = Math.Round(punt.Y * MmPerFt);
                            volgendeX += 200 / MmPerFt;
                        }
                        catch (Exception ex) { rij["status"] = "fout"; rij["error"] = ex.Message; }
                    }

                    res["sheet_id"] = dryRun ? null : sheet.Id.Value;
                    res["meldingen"] = fv.Meldingen;
                    if (dryRun) t.RollBack();
                    else if (t.Commit() != TransactionStatus.Committed)
                        return (object)DocumentHandlers.Fail("transactie teruggedraaid: " + string.Join("; ", fv.Meldingen));
                }
                res["document"] = doc.Title;
                res["dry_run"] = dryRun;
                res["status"] = dryRun ? "zou maken" : "gemaakt";
                res["sheet_number"] = nummer;
                res["sheet_name"] = naam;
                res["titleblock"] = tbNaam;
                res["views"] = plaatsingen;
                return (object)res;
            }, timeoutMs: 120000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {ex.InnerException?.Message ?? ex.Message}"); }
    }

    private static CommandResponse Ok(object? data) => new() { Success = true, Data = data };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
}
