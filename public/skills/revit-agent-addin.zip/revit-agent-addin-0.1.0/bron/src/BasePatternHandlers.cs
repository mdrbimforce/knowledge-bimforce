using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public static class BasePatternHandlers
{
    public static string ResolveOwner(Document doc) =>
        doc.IsFamilyDocument ? "family:" + doc.Title : "main";

    public static Dictionary<string, object?> ToStub(
        long elementId, string revitClass, string? builtinCategory,
        string name, int? parentId, string owner, string pattern,
        string? categoryName = null, string? familyName = null, string? assemblyCode = null,
        string? description = null, string? model = null, string? supplier = null,
        // Description/Model are detail-only for callers that don't opt in (e.g. materials via Query<T>,
        // see test_pattern_b_materials::test_c_no_detail_fields_leak) — the KEY must be absent, not just
        // null, so this can't be a null-check on the value itself (many elements legitimately have no
        // description, and some do have one — either way the key must not leak at stub level).
        bool includeDescriptionModel = true)
    {
        var stub = new Dictionary<string, object?>
        {
            ["element_id"] = elementId,
            ["revit_class"] = revitClass,
            ["builtin_category"] = builtinCategory,
            // UI category name (e.g. "Walls" vs the OST_-enum) + family name (e.g. "Basic Wall" for a
            // system type) for human-readable remediation columns —  verzoek.
            ["category_name"] = categoryName,
            ["family_name"] = familyName,
            // Assembly Code (Uniformat) — NLRS templates carry the NL-SfB classification here, so the naming
            // layer can derive pos2 when it isn't already in the name.
            ["assembly_code"] = assemblyCode,
        };
        if (includeDescriptionModel)
        {
            // Description + Model type parameters — often hold the descriptive part of a poorly-named
            // family ('BI deur links'), so the naming layer can use them as an omschrijving source.
            stub["description"] = description;
            stub["model"] = model;
        }
        // Leverancier (pos6): Manufacturer, else the NLRS_C_leverancier/NLRS_C_fabrikant shared params —
        // so the naming layer can derive it instead of always defaulting to 'gen'.
        stub["supplier"] = supplier;
        stub["name"] = name;
        stub["parent_id"] = parentId;
        stub["document_owner"] = owner;
        stub["pattern"] = pattern;
        return stub;
    }

    public static Dictionary<string, object?> MetadataEnvelope() => new()
    {
        ["revit_version_introduced"] = null,
        ["revit_version_deprecated"] = null,
        ["is_system_family"] = true,
        ["is_in_place"] = false
    };

    public static List<Dictionary<string, object?>> EmptyRelationships() => new();

    public static T GetElementOrThrow<T>(Document doc, long elementId) where T : Element
    {
        var elem = doc.GetElement(new ElementId((long)elementId)) as T;
        if (elem == null)
            throw new ElementNotFoundException($"{typeof(T).Name} {elementId} not found");
        return elem;
    }

    public static List<Dictionary<string, object?>> Query<T>(
        Document doc, string owner, string pattern = "B") where T : Element
    {
        return new FilteredElementCollector(doc)
            .OfClass(typeof(T))
            .Cast<T>()
            .Where(e => e.IsValidObject)
            // description/model are intentionally NOT wired here (unlike the loadable_family stub in
            // PatternC_Handlers.cs): no consumer reads them for these types, and materials specifically
            // must not leak them at stub level (detail-only, see GetMaterialDetail) — test_pattern_b_materials.
            .Select(e => ToStub(
                RevitIdUtil.Fid(e.Id), typeof(T).Name, null, e.Name, null, owner, pattern,
                categoryName: SafeCategoryName(e), familyName: (e as ElementType)?.FamilyName,
                assemblyCode: SafeAssemblyCode(e),
                supplier: SafeSupplier(e),
                includeDescriptionModel: false))
            .ToList();
    }

    /// <summary>UI category name, guarded — some elements have no category.</summary>
    public static string? SafeCategoryName(Element e)
    {
        try { return e.Category?.Name; } catch { return null; }
    }

    /// <summary>A string builtin parameter value, guarded — null when absent/empty.</summary>
    public static string? SafeText(Element e, BuiltInParameter bip)
    {
        try
        {
            var s = e.get_Parameter(bip)?.AsString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        catch { return null; }
    }

    /// <summary>Assembly Code (Uniformat) of an element type, guarded — null when absent. NLRS templates
    /// store the NL-SfB classification here, feeding the naming layer's pos2 derivation. The BuiltInParameter
    /// enum member differs across Revit versions, so match it by runtime name (contains UNIFORMAT, or
    /// ASSEMBLY+CODE) rather than a compile-time constant.</summary>
    public static string? SafeAssemblyCode(Element e)
    {
        try
        {
            foreach (Parameter p in e.Parameters)
            {
                if (p?.Definition is not InternalDefinition id) continue;
                var bip = id.BuiltInParameter.ToString();
                if (bip.Contains("UNIFORMAT") || (bip.Contains("ASSEMBLY") && bip.Contains("CODE")))
                {
                    var s = p.AsString();
                    if (!string.IsNullOrWhiteSpace(s)) return s;
                }
            }
        }
        catch { }
        return null;
    }

    /// <summary>Leverancier/fabrikant, guarded — the standard Manufacturer
    /// parameter first, else the NLRS custom shared parameters (leverancier/fabrikant) by name; null when
    /// neither is set, so the naming layer's own 'gen' default applies.</summary>
    public static string? SafeSupplier(Element e)
    {
        var mfr = SafeText(e, BuiltInParameter.ALL_MODEL_MANUFACTURER);
        if (mfr != null) return mfr;
        try
        {
            foreach (Parameter p in e.Parameters)
            {
                var nm = p?.Definition?.Name;
                if (nm != null && (nm.Equals("NLRS_C_leverancier", StringComparison.OrdinalIgnoreCase)
                                 || nm.Equals("NLRS_C_fabrikant", StringComparison.OrdinalIgnoreCase)))
                {
                    var s = p.AsString();
                    if (!string.IsNullOrWhiteSpace(s)) return s;
                }
            }
        }
        catch { }
        return null;
    }

    /// <summary>Resolve a view/template parameter by its exact Revit UI name. Special-cases Phase/Phase
    /// Filter/Discipline via their BuiltInParameter (UI-localisation-proof, matches CreateViewHandlers.
    /// ResolveParam); everything else via LookupParameter (works for both builtins with a stable UI name
    /// and NLRS custom shared parameters). Shared by SafeParamValue (the value) and IsControlledByTemplate
    /// (whether the view's template locks it) so both agree on which Parameter they're looking at.</summary>
    public static Parameter? ResolveParam(Element e, string paramName) => paramName switch
    {
        "Phase" => e.get_Parameter(BuiltInParameter.VIEW_PHASE),
        "Phase Filter" => e.get_Parameter(BuiltInParameter.VIEW_PHASE_FILTER),
        "Discipline" => e.get_Parameter(BuiltInParameter.VIEW_DISCIPLINE),
        _ => e.LookupParameter(paramName)
    };

    /// <summary>A view/template parameter's readable value by its exact Revit UI name 
    /// (for view/template context columns: Phase, Title on Sheet, Scope Box, hoofd_map/sub_map, etc).
    /// Null when absent/no value/error — never fabricates, so a blank cell always means "genuinely not
    /// set" not "we guessed wrong".</summary>
    public static string? SafeParamValue(Element e, string paramName)
    {
        try
        {
            var p = ResolveParam(e, paramName);
            if (p == null || !p.HasValue) return null;
            var s = ParamDisplay(p);
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        catch { return null; }
    }

    /// <summary>Real PhaseFilter element name for a view/template's Phase Filter.
    /// AsValueString on VIEW_PHASE_FILTER (used by SafeParamValue) can render a descriptive
    /// label that diverges from the PhaseFilter element's actual .Name, which breaks round-tripping
    /// through set_view_property — FindPhaseFilterId in ViewPropertyHandlers.cs resolves phase filters by
    /// exact .Name, so a context column built from the value string isn't usable as a settarget. Resolve
    /// the ElementId directly instead of trusting the value string.</summary>
    public static string? PhaseFilterName(Element e)
    {
        try
        {
            var p = e.get_Parameter(BuiltInParameter.VIEW_PHASE_FILTER);
            if (p == null || !p.HasValue) return null;
            var id = p.AsElementId();
            if (id == null || id == ElementId.InvalidElementId) return null;
            return (e.Document.GetElement(id) as PhaseFilter)?.Name;
        }
        catch { return null; }
    }

    /// <summary>Is `paramName` on this view currently controlled by its assigned View Template? A view's
    /// own GetNonControlledTemplateParameterIds is the set it has EXCLUDED from template control (the
    /// "Include" checkboxes, unchecked); a parameter is controlled iff the view has a template assigned,
    /// has not excluded it, AND resolves to a real parameter on this view (so an inapplicable field —
    /// e.g. Scope Box on a Schedule — reads null, not a false "controlled"/"not controlled").
    /// Works for ANY resolvable parameter (builtin or custom), not just BuiltInParameter-backed ones, by
    /// comparing on the resolved Parameter's own Id rather than a hardcoded enum. First use of this Revit
    /// API in the addin ; verify against a live document before trusting
    /// the output.</summary>
    public static bool? IsControlledByTemplate(View v, string paramName)
    {
        try
        {
            if (v.ViewTemplateId == null || v.ViewTemplateId == ElementId.InvalidElementId) return null;
            var p = ResolveParam(v, paramName);
            if (p == null) return null;
            var nonControlled = v.GetNonControlledTemplateParameterIds();
            return !nonControlled.Contains(p.Id);
        }
        catch { return null; }
    }

    /// <summary>Does THIS template (v.IsTemplate) enforce `bip` on views that use it? Same underlying
    /// exclusion-set API as IsControlledByTemplate, but read directly off the template (no assigned-
    /// template check — a template doesn't have one of its own) and keyed on a BuiltInParameter directly
    /// (the V/G-overrides categories are control-flags, not user-facing value parameters with a UI name).</summary>
    public static bool? TemplateEnforces(View template, BuiltInParameter bip)
    {
        try
        {
            var nonControlled = template.GetNonControlledTemplateParameterIds();
            return !nonControlled.Contains(new ElementId(bip));
        }
        catch { return null; }
    }

    public static Dictionary<string, object?> Detail<T>(
        Document doc, long elementId, string owner,
        Func<T, Dictionary<string, object?>> extractProperties,
        string pattern = "B",
        List<Dictionary<string, object?>>? relationships = null,
        Dictionary<string, object?>? metadata = null) where T : Element
    {
        var elem = GetElementOrThrow<T>(doc, elementId);
        return new Dictionary<string, object?>
        {
            ["stub"] = ToStub(
                RevitIdUtil.Fid(elem.Id), typeof(T).Name, null, elem.Name, null, owner, pattern),
            ["metadata"] = metadata ?? MetadataEnvelope(),
            ["properties"] = extractProperties(elem),
            ["relationships"] = relationships ?? EmptyRelationships()
        };
    }

    // ── Generic helpers for high-fan-out patterns (D/E/F) ──────────────

    /// <summary>
    /// Honest, uniform property extractor: dumps all element parameters as
    /// {name, value, storage_type, is_read_only}. Used as the default detail
    /// body for Pattern-D system-family types where curated per-type API
    /// access would be guesswork (see pattern-b-template §6 API gotchas).
    /// </summary>
    public static Dictionary<string, object?> DumpParameters(Element elem)
    {
        var ps = new List<Dictionary<string, object?>>();
        foreach (Parameter p in elem.Parameters)
        {
            if (p?.Definition == null) continue;
            ps.Add(new Dictionary<string, object?>
            {
                ["name"] = p.Definition.Name,
                ["value"] = ParamDisplay(p),
                ["storage_type"] = p.StorageType.ToString(),
                ["is_read_only"] = p.IsReadOnly
            });
        }
        return new Dictionary<string, object?>
        {
            ["parameter_count"] = ps.Count,
            ["parameters"] = ps
        };
    }

    /// <summary>Best-effort human-readable parameter value (value-string first, then typed).</summary>
    public static string ParamDisplay(Parameter p)
    {
        if (p == null) return "";
        try
        {
            var vs = p.AsValueString();
            if (!string.IsNullOrEmpty(vs)) return vs;
            return p.StorageType switch
            {
                StorageType.String => p.AsString() ?? "",
                StorageType.Integer => p.AsInteger().ToString(),
                StorageType.Double => p.AsDouble().ToString("F3"),
                StorageType.ElementId => p.AsElementId().Value.ToString(),
                _ => ""
            };
        }
        catch { return ""; }
    }

    public static Dictionary<string, object?> MetadataEnvelope(bool isSystemFamily, bool isInPlace = false) => new()
    {
        ["revit_version_introduced"] = null,
        ["revit_version_deprecated"] = null,
        ["is_system_family"] = isSystemFamily,
        ["is_in_place"] = isInPlace
    };
}
