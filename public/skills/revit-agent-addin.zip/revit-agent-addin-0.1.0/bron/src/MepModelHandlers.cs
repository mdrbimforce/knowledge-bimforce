using System.Globalization;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB.Structure;

namespace RevitAgent.Addin;

/// <summary>
/// Installatiedelen modelleren in de NLRS Onderwijsmodellen (EL, HVAC, SAN) zonder handwerk in Revit
/// Drie commando's.
///
///   list_mep_types          — alleen lezen: leiding-/kanaaltypes, systeemtypes, kabelgoottypes, levels en per
///                             MEP-categorie de geladen families met types.
///   place_family_instances  — niet-gehoste (OneLevelBased) families plaatsen op level + x/y/z (mm), met rotatie
///                             en instance-parameters; met host:{height_mm, face_down} op een horizontaal
///                             referentievlak (vlak- en werkvlakgebonden families).
///   create_mep_runs         — leiding- en kanaalruns uit een puntenlijst, met bochten en optioneel een
///                             verbinding met de vrije connector van een bestaand element.
///   get_room_geometry       — alleen lezen: rooms met maat, bbox, buitenste boundary en deuren (From/ToRoom).
///   list_link_instances     — alleen lezen: RevitLinkInstances met gelinkt document, geladen, totale transformatie.
///   connect_to_pipe         — open leidingeinde met een Tap (laszadel) of T-stuk op een bestaande leiding aansluiten
///                             (MepConnectToPipe.cs).
///
/// Gemeenschappelijk: target_document (Title van een open document, verplicht). Schrijvende commando's hebben
/// dry_run (default TRUE). Coördinaten in MILLIMETERS in het interne coördinatenstelsel van het model; z is de
/// hoogte boven het opgegeven level. Elk item/elke run is een eigen TransactionGroup (één ongedaan-maakstap)
/// met transacties die een failure-preprocessor hebben die warnings wegdrukt en bij errors terugrolt: geen
/// modale dialogen. Resultaten tellen op read-back na commit, niet op returnwaarden; fouten per item.
/// </summary>
public static partial class MepModelHandlers
{
    private const double MM = 304.8;          // mm per voet (interne eenheid)
    private const double Tol = 1.0 / MM;      // 1 mm in voet
    private const double ParTol = 1e-5;       // 1 - |cos| voor evenwijdig (~0,26°)

    private static readonly (BuiltInCategory Bic, string Key)[] FamilyCats =
    {
        (BuiltInCategory.OST_MechanicalEquipment, "mechanical_equipment"),
        (BuiltInCategory.OST_PlumbingFixtures, "plumbing_fixtures"),
        (BuiltInCategory.OST_DuctTerminal, "air_terminals"),
        (BuiltInCategory.OST_LightingFixtures, "lighting_fixtures"),
        (BuiltInCategory.OST_ElectricalEquipment, "electrical_equipment"),
        (BuiltInCategory.OST_ElectricalFixtures, "electrical_fixtures"),
        (BuiltInCategory.OST_PipeAccessory, "pipe_accessories"),
        (BuiltInCategory.OST_DuctAccessory, "duct_accessories"),
        (BuiltInCategory.OST_Sprinklers, "sprinklers"),
    };

    // ═══════════════════════════════════════════════════════════════════════
    // 1. list_mep_types
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// list_mep_types — inventaris van wat create_mep_runs en place_family_instances kunnen gebruiken. Alleen lezen.
    /// params: target_document.
    /// Rapport: pipe_types, duct_types {rond, rechthoekig, ovaal}, piping_system_types, mechanical_system_types
    /// (met system_classification), cable_tray_types, levels {name, elevation_mm, project_elevation_mm} en
    /// families {categorie: [{family, placement_type, plaatsbaar, types:[{id, name, active}]}]}.
    /// Pipe- en DuctTypes tonen hun routing preferences per regelgroep (onderdelen), want bochten vereisen een
    /// Elbows-regel en leidingen een Segments-regel.
    /// </summary>
    public static CommandResponse ListMepTypes(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                var notes = new List<string>();

                var pipeTypes = Collect<PipeType>(doc).OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase)
                    .Select(t => CurveTypeRow(doc, t)).ToList();

                var ductRond = new List<Dictionary<string, object?>>();
                var ductRecht = new List<Dictionary<string, object?>>();
                var ductOvaal = new List<Dictionary<string, object?>>();
                foreach (var dt in Collect<DuctType>(doc).OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase))
                {
                    var row = CurveTypeRow(doc, dt);
                    switch (DuctShape(dt))
                    {
                        case ConnectorProfileType.Round: ductRond.Add(row); break;
                        case ConnectorProfileType.Rectangular: ductRecht.Add(row); break;
                        case ConnectorProfileType.Oval: ductOvaal.Add(row); break;
                        default: row["shape"] = "onbekend"; ductRecht.Add(row); notes.Add($"DuctType '{dt.Name}': vorm onbekend, bij rechthoekig gezet"); break;
                    }
                }

                var pipingSystems = Collect<PipingSystemType>(doc).OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase)
                    .Select(t => SystemTypeRow(t, t.SystemClassification)).ToList();
                var mechSystems = Collect<MechanicalSystemType>(doc).OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase)
                    .Select(t => SystemTypeRow(t, t.SystemClassification)).ToList();
                var trays = Collect<CableTrayType>(doc).OrderBy(t => t.Name, StringComparer.OrdinalIgnoreCase)
                    .Select(t => new Dictionary<string, object?> { ["id"] = t.Id.Value, ["name"] = t.Name, ["family_name"] = SafeFamilyName(t) })
                    .ToList();
                var levels = Collect<Level>(doc).OrderBy(l => l.Elevation)
                    .Select(l => new Dictionary<string, object?>
                    {
                        ["id"] = l.Id.Value, ["name"] = l.Name,
                        ["elevation_mm"] = R(l.Elevation * MM), ["project_elevation_mm"] = R(l.ProjectElevation * MM),
                    }).ToList();

                var families = new Dictionary<string, object?>();
                foreach (var (bic, key) in FamilyCats)
                {
                    var rows = new List<Dictionary<string, object?>>();
                    try
                    {
                        var syms = new FilteredElementCollector(doc).OfCategory(bic).OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>().ToList();
                        foreach (var grp in syms.GroupBy(s => s.Family.Id.Value).OrderBy(g => g.First().Family.Name, StringComparer.OrdinalIgnoreCase))
                        {
                            var fam = grp.First().Family;
                            var pt = PlacementType(fam);
                            rows.Add(new Dictionary<string, object?>
                            {
                                ["family"] = fam.Name,
                                ["family_id"] = fam.Id.Value,
                                ["placement_type"] = pt?.ToString(),
                                ["plaatsbaar"] = pt == FamilyPlacementType.OneLevelBased && !fam.IsInPlace,
                                ["plaatsbaar_met_host"] = fam.IsInPlace ? false
                                    : pt == FamilyPlacementType.WorkPlaneBased ? true
                                    : pt == FamilyPlacementType.OneLevelBased ? WorkPlaneFlag(fam) : false,
                                ["types"] = grp.OrderBy(s => s.Name, StringComparer.OrdinalIgnoreCase)
                                    .Select(s => new Dictionary<string, object?> { ["id"] = s.Id.Value, ["name"] = s.Name, ["active"] = s.IsActive })
                                    .ToList(),
                            });
                        }
                    }
                    catch (Exception ex) { notes.Add($"{key}: {ex.Message}"); }
                    families[key] = rows;
                }
                notes.Add("plaatsbaar = placement_type OneLevelBased (zonder host). plaatsbaar_met_host = WorkPlaneBased (vlakgebonden) of " +
                          "OneLevelBased met werkvlak-vlag (null = vlag niet leesbaar; de read-back toetst de host); te plaatsen met " +
                          "place_family_instances en host:{height_mm, face_down}. Wand- en plafondgebonden (OneLevelBasedHosted) en curve-families: niet");

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["pipe_types"] = pipeTypes,
                    ["duct_types"] = new Dictionary<string, object?> { ["rond"] = ductRond, ["rechthoekig"] = ductRecht, ["ovaal"] = ductOvaal },
                    ["piping_system_types"] = pipingSystems,
                    ["mechanical_system_types"] = mechSystems,
                    ["cable_tray_types"] = trays,
                    ["levels"] = levels,
                    ["families"] = families,
                    ["notes"] = notes,
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static IEnumerable<T> Collect<T>(Document doc) where T : Element
        => new FilteredElementCollector(doc).OfClass(typeof(T)).Cast<T>();

    private static string? SafeFamilyName(ElementType t) { try { return t.FamilyName; } catch { return null; } }

    private static FamilyPlacementType? PlacementType(Family fam) { try { return fam.FamilyPlacementType; } catch { return null; } }

    /// <summary>Werkvlak-vlag ("Work Plane-Based") van een family; null als de parameter in het project niet leesbaar is.</summary>
    private static bool? WorkPlaneFlag(Family fam)
    {
        try
        {
            var par = fam.get_Parameter(BuiltInParameter.FAMILY_WORK_PLANE_BASED);
            return par != null && par.HasValue && par.StorageType == StorageType.Integer ? par.AsInteger() == 1 : null;
        }
        catch { return null; }
    }

    private static ConnectorProfileType DuctShape(DuctType dt) { try { return dt.Shape; } catch { return ConnectorProfileType.Invalid; } }

    private static Dictionary<string, object?> SystemTypeRow(MEPSystemType t, MEPSystemClassification cls)
    {
        string? abbr = null;
        try { abbr = t.get_Parameter(BuiltInParameter.RBS_SYSTEM_ABBREVIATION_PARAM)?.AsString(); } catch { }
        return new Dictionary<string, object?>
        {
            ["id"] = t.Id.Value, ["name"] = t.Name, ["system_classification"] = cls.ToString(), ["abbreviation"] = abbr,
        };
    }

    private static Dictionary<string, object?> CurveTypeRow(Document doc, MEPCurveType t)
    {
        var routing = new Dictionary<string, object?>();
        try
        {
            var rpm = t.RoutingPreferenceManager;
            if (rpm != null)
            {
                foreach (RoutingPreferenceRuleGroupType g in Enum.GetValues(typeof(RoutingPreferenceRuleGroupType)))
                {
                    if (g == RoutingPreferenceRuleGroupType.Undefined) continue;
                    int n; try { n = rpm.GetNumberOfRules(g); } catch { continue; }
                    if (n == 0) continue;
                    var parts = new List<string>();
                    for (int i = 0; i < n; i++)
                    {
                        try
                        {
                            var el = doc.GetElement(rpm.GetRule(g, i).MEPPartId);
                            parts.Add(el is FamilySymbol fs ? $"{fs.Family.Name} : {fs.Name}" : el?.Name ?? "(leeg)");
                        }
                        catch { parts.Add("(?)"); }
                    }
                    routing[g.ToString()] = parts;
                }
                try { routing["preferred_junction_type"] = rpm.PreferredJunctionType.ToString(); } catch { }
            }
        }
        catch (Exception ex) { routing["fout"] = ex.Message; }
        var row = new Dictionary<string, object?>
        {
            ["id"] = t.Id.Value, ["name"] = t.Name, ["family_name"] = SafeFamilyName(t), ["routing_preferences"] = routing,
            ["bocht_mogelijk"] = HasElbowRule(t),
        };
        if (t is DuctType dt) row["shape"] = DuctShape(dt).ToString();
        return row;
    }

    /// <summary>Elbows-regel in de routing preferences; voor DuctTypes ook het oude type-veld "Elbow".</summary>
    private static bool HasElbowRule(MEPCurveType t)
    {
        try { if (t.RoutingPreferenceManager?.GetNumberOfRules(RoutingPreferenceRuleGroupType.Elbows) > 0) return true; } catch { }
        try
        {
            var par = t.get_Parameter(BuiltInParameter.RBS_CURVETYPE_DEFAULT_ELBOW_PARAM);
            if (par != null && par.StorageType == StorageType.ElementId && par.AsElementId() != ElementId.InvalidElementId) return true;
        }
        catch { }
        return false;
    }

    private static int RuleCount(MEPCurveType t, RoutingPreferenceRuleGroupType g)
    {
        try { return t.RoutingPreferenceManager?.GetNumberOfRules(g) ?? 0; } catch { return 0; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 2. place_family_instances
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// place_family_instances — plaats family-instanties.
    ///   Zonder host: niet-gehost (NewFamilyInstance met Level en StructuralType.NonStructural), alleen placement_type
    ///   OneLevelBased.
    ///   Met host:{height_mm, face_down (default true)}: op een horizontaal referentievlak op height_mm boven het level
    ///   (NewFamilyInstance(refplane.GetReference, punt, refDir, symbol)), voor WorkPlaneBased (vlakgebonden) en
    ///   werkvlakgebonden OneLevelBased families. face_down true = normaal −Z (onderkant van een plafond: de family
    ///   hangt omlaag, voor plafondelementen); false = normaal +Z (op de vloer). Eén vlak per (level, hoogte, richting)
    ///   met de vaste naam BF_host_&lt;level&gt;_&lt;hoogte mm&gt;_&lt;down|up&gt;; bestaat hij, dan wordt hij hergebruikt (mits normaal en
    ///   hoogte kloppen), anders aangemaakt in een eigen, gecommitte transactie in een plattegrond van het level (nooit
    ///   in de ActiveView), vóór de plaatsing. refDir = (cos rotation_deg, sin rotation_deg, 0); geen RotateElement.
    ///   z_mm mag dan ontbreken of moet gelijk zijn aan host.height_mm. Schedule Level wordt op het level gezet.
    ///   OneLevelBasedHosted (wand/plafond), CurveBased e.d. en in-place families worden per item geweigerd.
    ///
    /// params: target_document, dry_run (default TRUE),
    ///         items:[{family?, type, level, x_mm, y_mm, z_mm (hoogte boven het level, default 0), rotation_deg (default 0),
    ///                 host?:{height_mm, face_down?}, params:{naam: waarde}}].
    /// family is optioneel zolang de typenaam uniek is. Waarden: tekst; getal in projecteenheden (getal → de
    /// projecteenheid van die grootheid, tekst met eenheid → UnitFormatUtils.TryParse); ja/nee (true/false, ja/nee, 1/0).
    /// ElementId-parameters en type-parameters worden niet gezet (gemeld).
    /// Per item een TransactionGroup: transactie 1 plaatst (+ rotatie, hoogte), transactie 2 zet de parameters. Rolt
    /// transactie 2 terug, dan blijft het element staan en staan de parameters als fout in het resultaat.
    /// Resultaat per item: {index, status: zou_plaatsen|geplaatst|geplaatst_met_fouten|fout, element_id, locatie
    /// (read-back), params:{naam:{gevraagd, gelezen, status}}, fouten:[...]}.
    /// </summary>
    public static CommandResponse PlaceFamilyInstances(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var items = HandlerUtil.Arr(p, "items");
        if (items.Count == 0) return Err("items:[{family?, type, level, x_mm, y_mm, z_mm?, rotation_deg?, params?}] is verplicht");
        var specs = items.Select((it, i) => it.Clone()).ToList();

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                if (!dryRun && doc.IsReadOnly) return (object)Fail("target_document is alleen-lezen");
                if (!dryRun && doc.IsModifiable) return (object)Fail("er staat al een transactie open in target_document");

                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var allSyms = Collect<FamilySymbol>(doc).ToList();
                var levels = Collect<Level>(doc).ToList();
                var planeCache = new Dictionary<string, HostPlane>(StringComparer.Ordinal);

                for (int i = 0; i < specs.Count; i++)
                {
                    var it = specs[i];
                    var fouten = new List<string>();
                    var row = new Dictionary<string, object?> { ["index"] = i, ["status"] = "fout", ["element_id"] = null, ["fouten"] = fouten };
                    results.Add(row);
                    try
                    {
                        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("item is geen object"); continue; }
                        string? famName = HandlerUtil.Str(it, "family");
                        string? typeName = HandlerUtil.Str(it, "type");
                        string? levelName = HandlerUtil.Str(it, "level");
                        double? x = Num(it, "x_mm"), y = Num(it, "y_mm");
                        double z = Num(it, "z_mm") ?? 0, rot = Num(it, "rotation_deg") ?? 0;
                        row["family"] = famName; row["type"] = typeName; row["level"] = levelName;
                        if (typeName == null) fouten.Add("type ontbreekt");
                        if (levelName == null) fouten.Add("level ontbreekt");
                        if (x == null || y == null) fouten.Add("x_mm en y_mm zijn verplicht (getal)");
                        var prms = new List<(string Name, JsonElement Value)>();
                        if (it.TryGetProperty("params", out var pe))
                        {
                            if (pe.ValueKind == JsonValueKind.Object) foreach (var pr in pe.EnumerateObject()) prms.Add((pr.Name, pr.Value.Clone()));
                            else if (pe.ValueKind != JsonValueKind.Null) fouten.Add("params is geen object {naam: waarde}");
                        }
                        // ── host (optioneel): horizontaal referentievlak ──
                        double? hostH = null;
                        bool hostDown = true;
                        if (it.TryGetProperty("host", out var he) && he.ValueKind != JsonValueKind.Null)
                        {
                            if (he.ValueKind != JsonValueKind.Object) fouten.Add("host is geen object {height_mm, face_down?}");
                            else
                            {
                                hostH = Num(he, "height_mm");
                                if (hostH == null) fouten.Add("host.height_mm (getal, mm boven het level) is verplicht");
                                if (he.TryGetProperty("face_down", out var fd) && fd.ValueKind != JsonValueKind.Null)
                                {
                                    if (fd.ValueKind is JsonValueKind.True or JsonValueKind.False) hostDown = fd.ValueKind == JsonValueKind.True;
                                    else fouten.Add("host.face_down is geen true/false");
                                }
                                if (he.TryGetProperty("kind", out _)) fouten.Add("host.kind wordt niet ondersteund; alleen {height_mm, face_down}");
                                if (hostH != null)
                                {
                                    double afgerond = Math.Round(hostH.Value);
                                    if (Math.Abs(afgerond - hostH.Value) > 0.01) row["host_notitie"] = $"host.height_mm {hostH.Value} afgerond op {afgerond} mm";
                                    hostH = afgerond;
                                    if (it.TryGetProperty("z_mm", out _) && Math.Abs(z - hostH.Value) > 0.5)
                                        fouten.Add($"z_mm ({R(z)}) wijkt af van host.height_mm ({hostH.Value}); laat z_mm weg bij host");
                                    z = hostH.Value;
                                }
                            }
                        }
                        if (fouten.Count > 0) continue;

                        // ── type ──
                        var cands = allSyms.Where(s => s.Name == typeName && (famName == null || s.Family.Name == famName)).ToList();
                        if (cands.Count == 0)
                        {
                            var famTypes = famName == null ? null : allSyms.Where(s => s.Family.Name == famName).Select(s => s.Name).Distinct().Take(15).ToList();
                            fouten.Add(famTypes is { Count: > 0 }
                                ? $"type '{typeName}' niet gevonden in family '{famName}' (wel: {string.Join(", ", famTypes)})"
                                : $"type '{typeName}'{(famName != null ? $" van family '{famName}'" : "")} niet gevonden (niet geladen?)");
                            continue;
                        }
                        if (cands.Count > 1)
                        {
                            fouten.Add($"type '{typeName}' bestaat in meerdere families ({string.Join(", ", cands.Select(c => c.Family.Name).Distinct().Take(10))}); geef family op");
                            continue;
                        }
                        var sym = cands[0];
                        var fam = sym.Family;
                        row["family"] = fam.Name;
                        row["type_id"] = sym.Id.Value;
                        row["category"] = sym.Category?.Name;
                        var pt = PlacementType(fam);
                        row["placement_type"] = pt?.ToString();
                        if (fam.IsInPlace) { fouten.Add("geweigerd: in-place family"); continue; }
                        if (hostH == null && pt != FamilyPlacementType.OneLevelBased)
                        {
                            fouten.Add(pt == FamilyPlacementType.WorkPlaneBased
                                ? "geweigerd: placement_type WorkPlaneBased (vlakgebonden) zonder host; geef host:{height_mm, face_down}"
                                : $"geweigerd: placement_type {pt?.ToString() ?? "onbekend"}; dit commando plaatst alleen OneLevelBased (zonder host) en WorkPlaneBased/werkvlakgebonden (met host)");
                            continue;
                        }
                        if (hostH != null && pt != FamilyPlacementType.WorkPlaneBased && pt != FamilyPlacementType.OneLevelBased)
                        {
                            fouten.Add($"geweigerd met host: placement_type {pt?.ToString() ?? "onbekend"}; een referentievlak host alleen WorkPlaneBased (vlakgebonden) en werkvlakgebonden OneLevelBased families");
                            continue;
                        }
                        if (hostH != null && pt == FamilyPlacementType.OneLevelBased)
                        {
                            var wpf = WorkPlaneFlag(fam);
                            row["werkvlak_vlag"] = wpf;
                            if (wpf == false) { fouten.Add("geweigerd met host: OneLevelBased family zonder werkvlak-vlag (Work Plane-Based uit); plaats zonder host"); continue; }
                        }

                        // ── level ──
                        var level = FindLevel(levels, levelName!, out var lvlErr);
                        if (level == null) { fouten.Add(lvlErr!); continue; }
                        row["level"] = level.Name;
                        var ptXyz = new XYZ(x!.Value / MM, y!.Value / MM, level.Elevation + z / MM);
                        var gepland = new Dictionary<string, object?> { ["x_mm"] = R(x.Value), ["y_mm"] = R(y.Value), ["z_mm"] = R(z), ["rotation_deg"] = R(rot) };
                        row["gepland"] = gepland;

                        // ── referentievlak (host): eigen transactie, vóór de plaatsing ──
                        ElementId? hostId = null;
                        if (hostH != null)
                        {
                            var hp = EnsureHostPlane(doc, level, hostH.Value, hostDown, ptXyz, dryRun, planeCache, meldingen);
                            row["host"] = new Dictionary<string, object?>
                            {
                                ["refplane"] = hp.Name, ["refplane_id"] = hp.Id?.Value, ["refplane_status"] = hp.Status,
                                ["height_mm"] = hostH.Value, ["face_down"] = hostDown, ["normaal"] = hostDown ? "-Z" : "+Z",
                                ["aangemaakt_in_view"] = hp.View,
                            };
                            if (hp.Note != null && !notes.Contains(hp.Note)) notes.Add(hp.Note);
                            if (hp.Err != null) { fouten.Add(hp.Err); continue; }
                            hostId = hp.Id;
                        }

                        // ── params vooraf: type-parameters herkennen ──
                        var paramRows = new Dictionary<string, object?>();
                        row["params"] = paramRows;
                        var instParams = new List<(string Name, JsonElement Value)>();
                        foreach (var (pn, pv) in prms)
                        {
                            var tp = sym.LookupParameter(pn);
                            if (tp != null)
                            {
                                paramRows[pn] = new Dictionary<string, object?> { ["gevraagd"] = Raw(pv), ["status"] = "fout", ["reden"] = "type-parameter; niet gezet (gebruik set_parameter_values_bulk met target \"type\")" };
                                fouten.Add($"param '{pn}': type-parameter, niet gezet");
                                continue;
                            }
                            instParams.Add((pn, pv));
                            if (dryRun) paramRows[pn] = new Dictionary<string, object?> { ["gevraagd"] = Raw(pv), ["status"] = "pas_na_plaatsing_te_toetsen" };
                        }

                        if (dryRun) { row["status"] = "zou_plaatsen"; continue; }

                        // ── plaatsen ──
                        ElementId newId = ElementId.InvalidElementId;
                        var groupNotes = new List<string>();
                        bool kept = RunGroup(doc, $"Plaats {fam.Name} : {sym.Name}", groupNotes, () =>
                        {
                            var (ok1, n1) = RunTx(doc, $"Plaats {fam.Name} : {sym.Name}", () =>
                            {
                                var s = (FamilySymbol)doc.GetElement(sym.Id);
                                if (!s.IsActive) { s.Activate(); doc.Regenerate(); }
                                if (hostId != null)
                                {
                                    // refplane komt uit een eerdere, gecommitte transactie (anders host weg bij de eerste Regenerate)
                                    var rp = doc.GetElement(hostId) as ReferencePlane
                                             ?? throw new InvalidOperationException($"referentievlak {hostId.Value} niet gevonden");
                                    double th = rot * Math.PI / 180.0;
                                    var refDir = new XYZ(Math.Cos(th), Math.Sin(th), 0);
                                    var fi = doc.Create.NewFamilyInstance(rp.GetReference(), ptXyz, refDir, s)
                                             ?? throw new InvalidOperationException("NewFamilyInstance (referentievlak) gaf null");
                                    newId = fi.Id;
                                    doc.Regenerate();
                                    var h = (doc.GetElement(newId) as FamilyInstance)?.Host;
                                    if (h == null || h.Id.Value != hostId.Value)
                                        throw new InvalidOperationException($"host na Regenerate {(h == null ? "verloren" : $"is {h.Id.Value}, niet het referentievlak")}");
                                    var sl = doc.GetElement(newId).get_Parameter(BuiltInParameter.INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM);
                                    if (sl != null && !sl.IsReadOnly && sl.AsElementId().Value != level.Id.Value)
                                    {
                                        try { if (!sl.Set(level.Id)) groupNotes.Add("Schedule Level zetten gaf false"); }
                                        catch (Exception ex) { groupNotes.Add($"Schedule Level niet gezet: {ex.Message}"); }
                                    }
                                }
                                else
                                {
                                    var fi = doc.Create.NewFamilyInstance(ptXyz, s, level, StructuralType.NonStructural)
                                             ?? throw new InvalidOperationException("NewFamilyInstance gaf null");
                                    newId = fi.Id;
                                    if (Math.Abs(rot) > 1e-9)
                                        ElementTransformUtils.RotateElement(doc, newId, Line.CreateBound(ptXyz, ptXyz + XYZ.BasisZ), rot * Math.PI / 180.0);
                                    var elev = ElevationParam(doc.GetElement(newId));
                                    if (elev != null && !elev.IsReadOnly && Math.Abs(elev.AsDouble() - z / MM) > 1e-6 && !elev.Set(z / MM))
                                        throw new InvalidOperationException($"hoogte boven level zetten mislukt ({elev.Definition?.Name})");
                                }
                            }, meldingen);
                            if (!ok1) { fouten.Add($"plaatsen teruggerold: {n1}"); return false; }
                            if (doc.GetElement(newId) is not FamilyInstance) { fouten.Add("read-back: element niet gevonden na commit"); return false; }
                            if (n1 != null) groupNotes.Add(n1);

                            if (instParams.Count > 0)
                            {
                                var desired = new Dictionary<string, (string Key, StorageType St, object Val, string? SetStr)>();
                                var (ok2, n2) = RunTx(doc, "Parameters na plaatsing", () =>
                                {
                                    var el = doc.GetElement(newId);
                                    foreach (var (pn, pv) in instParams)
                                    {
                                        var pr = new Dictionary<string, object?> { ["gevraagd"] = Raw(pv), ["status"] = "fout" };
                                        paramRows[pn] = pr;
                                        var par = el.LookupParameter(pn);
                                        if (par == null) { pr["reden"] = "parameter ontbreekt op de instantie"; fouten.Add($"param '{pn}': ontbreekt"); continue; }
                                        if (par.IsReadOnly) { pr["reden"] = "read-only"; fouten.Add($"param '{pn}': read-only"); continue; }
                                        var (val, setStr, err) = ConvertValue(doc, par, pv);
                                        if (err != null) { pr["reden"] = err; fouten.Add($"param '{pn}': {err}"); continue; }
                                        bool ok;
                                        try { ok = WriteValue(par, val!, setStr); }
                                        catch (Exception ex) { pr["reden"] = $"exception bij Set: {ex.Message}"; fouten.Add($"param '{pn}': {ex.Message}"); continue; }
                                        if (!ok) { pr["reden"] = "Set gaf false"; fouten.Add($"param '{pn}': Set gaf false"); continue; }
                                        desired[pn] = (pn, par.StorageType, val!, setStr);
                                        pr["status"] = "gezet_voor_commit";
                                    }
                                }, meldingen);
                                if (!ok2)
                                {
                                    fouten.Add($"parameters teruggerold: {n2}");
                                    foreach (var kv in paramRows)
                                        if (kv.Value is Dictionary<string, object?> pr && (string?)pr["status"] == "gezet_voor_commit")
                                        { pr["status"] = "fout"; pr["reden"] = "transactie teruggerold"; }
                                }
                                else
                                {
                                    // read-back
                                    var el = doc.GetElement(newId);
                                    foreach (var (pn, d) in desired)
                                    {
                                        var pr = (Dictionary<string, object?>)paramRows[pn]!;
                                        var par = el?.LookupParameter(pn);
                                        pr["gelezen"] = par == null ? null : DisplayValue(par);
                                        if (par != null && Equal(par, d.St, d.Val)) pr["status"] = "gezet";
                                        else { pr["status"] = "fout"; pr["reden"] = "read-back wijkt af"; fouten.Add($"param '{pn}': read-back wijkt af"); }
                                    }
                                }
                            }
                            return true;
                        });
                        foreach (var gn in groupNotes) fouten.Add(gn);
                        if (!kept || doc.GetElement(newId) is not FamilyInstance placed) { row["status"] = "fout"; continue; }

                        row["element_id"] = newId.Value;
                        row["locatie"] = ReadLocation(doc, placed, hostId != null ? level : null);
                        if (hostId != null)
                        {
                            long? hidRead = null;
                            try { hidRead = placed.Host?.Id.Value; } catch { }
                            if (row["host"] is Dictionary<string, object?> hrow) hrow["host_id_gelezen"] = hidRead;
                            if (hidRead != hostId.Value) fouten.Add($"read-back: host is {(hidRead?.ToString() ?? "leeg")}, niet referentievlak {hostId.Value}");
                        }
                        // hoogte en rotatie toetsen
                        if (placed.Location is LocationPoint lp)
                        {
                            var lvl = hostId != null ? level : doc.GetElement(placed.LevelId) as Level ?? level;
                            double dx = (lp.Point.X - ptXyz.X) * MM, dy = (lp.Point.Y - ptXyz.Y) * MM, dz = (lp.Point.Z - lvl.Elevation) * MM - z;
                            if (Math.Abs(dx) > 1 || Math.Abs(dy) > 1) fouten.Add($"read-back: locatie wijkt af (dx {R(dx)} mm, dy {R(dy)} mm)");
                            if (Math.Abs(dz) > 1) fouten.Add($"read-back: hoogte boven level wijkt {R(dz)} mm af");
                        }
                        row["status"] = fouten.Count == 0 ? "geplaatst" : "geplaatst_met_fouten";
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); }
                }

                if (dryRun) notes.Add("dry_run: niets gewijzigd; status zou_plaatsen is het plan. Instance-parameters worden pas na plaatsing getoetst; referentievlakken met refplane_status zou_aanmaken worden pas bij dry_run=false gemaakt");
                notes.Add("x_mm/y_mm in interne coördinaten van het model; z_mm boven het level");
                if (planeCache.Count > 0)
                    notes.Add("met host: family-X volgt refDir (rotation_deg), family-Z volgt de vlaknormaal (face_down: omlaag). " +
                              "rotation_deg in de read-back is bij gehoste instanties niet betrouwbaar; toets hand_orientation/facing_orientation. " +
                              "Een referentievlak dat eenmaal is aangemaakt blijft staan, ook als de plaatsing daarna mislukt");
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["gevraagd"] = specs.Count,
                    ["tellers"] = results.GroupBy(r => (string?)r["status"] ?? "?").ToDictionary(g => g.Key, g => g.Count()),
                    ["element_ids"] = results.Where(r => r["element_id"] != null).Select(r => r["element_id"]).ToList(),
                    ["results"] = results,
                    ["failure_meldingen"] = meldingen.Take(100).ToList(),
                    ["notes"] = notes,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Level? FindLevel(List<Level> levels, string name, out string? err)
    {
        err = null;
        var exact = levels.FirstOrDefault(l => l.Name == name);
        if (exact != null) return exact;
        var ci = levels.Where(l => l.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
        if (ci.Count == 1) return ci[0];
        err = $"level '{name}' niet gevonden (wel: {string.Join(", ", levels.OrderBy(l => l.Elevation).Select(l => l.Name).Take(20))})";
        return null;
    }

    private static Parameter? ElevationParam(Element el)
    {
        var a = el.get_Parameter(BuiltInParameter.INSTANCE_ELEVATION_PARAM);
        if (a != null && !a.IsReadOnly) return a;
        var b = el.get_Parameter(BuiltInParameter.INSTANCE_FREE_HOST_OFFSET_PARAM);
        if (b != null && !b.IsReadOnly) return b;
        return a ?? b;
    }

    /// <summary>Locatie na commit. refLevel: het gevraagde level (bij gehoste instanties, waar LevelId leeg of een
    /// ander level kan zijn); z_mm is dan t.o.v. refLevel.</summary>
    private static Dictionary<string, object?> ReadLocation(Document doc, FamilyInstance fi, Level? refLevel = null)
    {
        var d = new Dictionary<string, object?>();
        var lvl = refLevel ?? doc.GetElement(fi.LevelId) as Level;
        d["level"] = lvl?.Name;
        if (refLevel != null)
        {
            try { d["level_id_element"] = (doc.GetElement(fi.LevelId) as Level)?.Name; } catch { }
            try
            {
                var sl = fi.get_Parameter(BuiltInParameter.INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM);
                if (sl != null) d["schedule_level"] = (doc.GetElement(sl.AsElementId()) as Level)?.Name;
            }
            catch { }
            try { d["host_id"] = fi.Host?.Id.Value; d["host_naam"] = fi.Host?.Name; } catch { }
        }
        if (fi.Location is LocationPoint lp)
        {
            d["x_mm"] = R(lp.Point.X * MM);
            d["y_mm"] = R(lp.Point.Y * MM);
            d["z_mm"] = lvl != null ? R((lp.Point.Z - lvl.Elevation) * MM) : null;
            d["z_absoluut_mm"] = R(lp.Point.Z * MM);
            try { d["rotation_deg"] = R(lp.Rotation * 180.0 / Math.PI); } catch { }
        }
        try { d["hand_orientation"] = Vec(fi.HandOrientation); } catch { }
        try { d["facing_orientation"] = Vec(fi.FacingOrientation); } catch { }
        var elev = ElevationParam(fi);
        if (elev != null) { d["hoogte_param"] = elev.Definition?.Name; d["hoogte_param_mm"] = R(elev.AsDouble() * MM); }
        return d;
    }

    private static double[] Vec(XYZ v) => new[] { Math.Round(v.X, 4), Math.Round(v.Y, 4), Math.Round(v.Z, 4) };

    // ── referentievlak als host ──

    private sealed class HostPlane
    {
        public string Name = "";
        public ElementId? Id;
        public string Status = "fout";   // bestond | aangemaakt | zou_aanmaken | fout
        public string? Err, View, Note;
    }

    /// <summary>Tekens die Revit in namen weigert (en ~/| uit een eerdere les) vervangen door '-'.</summary>
    private static string SafeRevitName(string s)
    {
        var sb = new System.Text.StringBuilder(s.Length);
        foreach (var ch in s) sb.Append("\\:{}[]|;<>?`~".IndexOf(ch) >= 0 ? '-' : ch);
        return sb.ToString().Trim();
    }

    private static string HostPlaneName(Level level, double hMm, bool down)
        => $"BF_host_{SafeRevitName(level.Name)}_{((long)Math.Round(hMm)).ToString(CultureInfo.InvariantCulture)}_{(down ? "down" : "up")}";

    /// <summary>Plattegrond om een referentievlak in aan te maken: nooit de ActiveView (3D/sheet geeft onbruikbare
    /// vlakken). Eerst een niet-template FloorPlan/CeilingPlan/EngineeringPlan van het level (laagste id), anders
    /// dezelfde soort van een ander level (met note).</summary>
    private static ViewPlan? PlanViewFor(Document doc, Level level, out string? note)
    {
        note = null;
        static int Rank(ViewPlan v) => v.ViewType switch
        {
            ViewType.FloorPlan => 0, ViewType.CeilingPlan => 1, ViewType.EngineeringPlan => 2, _ => 9,
        };
        var plans = Collect<ViewPlan>(doc).Where(v => !v.IsTemplate && Rank(v) < 9).ToList();
        long? GenLvl(ViewPlan v) { try { return v.GenLevel?.Id.Value; } catch { return null; } }
        var own = plans.Where(v => GenLvl(v) == level.Id.Value).OrderBy(Rank).ThenBy(v => v.Id.Value).FirstOrDefault();
        if (own != null) return own;
        var any = plans.OrderBy(Rank).ThenBy(v => v.Id.Value).FirstOrDefault();
        if (any != null) note = $"geen plattegrond van level '{level.Name}'; referentievlak aangemaakt in '{any.Name}' (de hoogte komt uit de punten, niet uit de view)";
        return any;
    }

    /// <summary>Zoekt of maakt het horizontale referentievlak BF_host_&lt;level&gt;_&lt;hoogte&gt;_&lt;down|up&gt;. Bestaand:
    /// hergebruiken als normaal en hoogte kloppen (opnieuw aanmaken met dezelfde naam rolt de transactie terug).
    /// Nieuw: eigen transactie (commit vóór de plaatsing), lijn langs +X vanaf het eerste plaatsingspunt, cutVec +Y (gemeten: −Y gaf normaal +Z)
    /// (normaal −Z, face_down) of +Y (normaal +Z); normaal na Regenerate getoetst. Resultaat per naam gecachet.</summary>
    private static HostPlane EnsureHostPlane(Document doc, Level level, double hMm, bool down, XYZ anchor, bool dryRun,
                                             Dictionary<string, HostPlane> cache, List<string> meldingen)
    {
        string name = HostPlaneName(level, hMm, down);
        if (cache.TryGetValue(name, out var hit)) return hit;
        var hp = new HostPlane { Name = name };
        cache[name] = hp;
        double zAbs = level.Elevation + hMm / MM;
        var wantN = down ? -XYZ.BasisZ : XYZ.BasisZ;

        var bestaand = Collect<ReferencePlane>(doc).Where(r => { try { return r.Name == name; } catch { return false; } }).ToList();
        if (bestaand.Count > 0)
        {
            var rp = bestaand[0];
            hp.Id = rp.Id;
            XYZ n; double zb, zf;
            try { n = rp.Normal; zb = rp.BubbleEnd.Z; zf = rp.FreeEnd.Z; }
            catch (Exception ex) { hp.Err = $"referentievlak '{name}' ({rp.Id.Value}) niet leesbaar: {ex.Message}"; return hp; }
            if (n.DotProduct(wantN) < 1 - ParTol || Math.Abs(zb - zAbs) > Tol || Math.Abs(zf - zAbs) > Tol)
            {
                hp.Err = $"referentievlak '{name}' ({rp.Id.Value}) bestaat maar ligt anders (normaal [{string.Join(", ", Vec(n))}], " +
                         $"z {R((zb - level.Elevation) * MM)} mm boven het level); niet hergebruikt, niet overschreven";
                return hp;
            }
            hp.Status = "bestond";
            if (bestaand.Count > 1) hp.Note = $"referentievlak '{name}' bestaat {bestaand.Count}×; eerste ({rp.Id.Value}) gebruikt";
            return hp;
        }

        var view = PlanViewFor(doc, level, out var vnote);
        hp.Note = vnote;
        if (view == null) { hp.Err = "geen plattegrond (FloorPlan/CeilingPlan/EngineeringPlan, geen template) om het referentievlak in aan te maken"; return hp; }
        hp.View = view.Name;
        if (dryRun) { hp.Status = "zou_aanmaken"; return hp; }

        ElementId newId = ElementId.InvalidElementId;
        var (ok, note) = RunTx(doc, $"Referentievlak {name}", () =>
        {
            var a = new XYZ(anchor.X, anchor.Y, zAbs);
            var b = new XYZ(anchor.X + 1000.0 / MM, anchor.Y, zAbs);
            var rp = doc.Create.NewReferencePlane(a, b, down ? XYZ.BasisY : -XYZ.BasisY, view)
                     ?? throw new InvalidOperationException("NewReferencePlane gaf null");
            rp.Name = name;   // niet cosmetisch: hergebruik leunt op de naam
            doc.Regenerate();
            if (rp.Normal.DotProduct(wantN) < 1 - ParTol)
                throw new InvalidOperationException($"normaal van het nieuwe vlak is [{string.Join(", ", Vec(rp.Normal))}], verwacht [{string.Join(", ", Vec(wantN))}]");
            newId = rp.Id;
        }, meldingen);
        if (!ok) { hp.Err = $"referentievlak '{name}' aanmaken teruggerold: {note}"; return hp; }
        if (doc.GetElement(newId) is not ReferencePlane back || back.Name != name)
        { hp.Err = $"read-back: referentievlak '{name}' niet gevonden na commit"; return hp; }
        hp.Id = newId;
        hp.Status = "aangemaakt";
        return hp;
    }

    /// <summary>JSON-waarde → opgeslagen waarde. Getallen bij Double: in de projecteenheid van de grootheid;
    /// tekst met eenheid via UnitFormatUtils.TryParse (setStr != null: schrijven via SetValueString).</summary>
    private static (object? val, string? setStr, string? err) ConvertValue(Document doc, Parameter par, JsonElement v)
    {
        switch (par.StorageType)
        {
            case StorageType.String:
                return v.ValueKind switch
                {
                    JsonValueKind.String => (v.GetString() ?? "", null, null),
                    JsonValueKind.Number => (v.GetRawText(), null, null),
                    JsonValueKind.True => ("true", null, null),
                    JsonValueKind.False => ("false", null, null),
                    _ => (null, null, "waarde niet bruikbaar voor tekstparameter"),
                };
            case StorageType.Integer:
            {
                bool yesNo = false;
                try { yesNo = par.Definition?.GetDataType()?.TypeId == SpecTypeId.Boolean.YesNo.TypeId; } catch { }
                if (yesNo)
                {
                    int? yn = v.ValueKind switch
                    {
                        JsonValueKind.True => 1,
                        JsonValueKind.False => 0,
                        JsonValueKind.Number => v.TryGetInt32(out var n) && (n == 0 || n == 1) ? n : null,
                        JsonValueKind.String => (v.GetString() ?? "").Trim().ToLowerInvariant() switch
                        {
                            "ja" or "yes" or "true" or "1" or "waar" => 1,
                            "nee" or "no" or "false" or "0" or "onwaar" => 0,
                            _ => null,
                        },
                        _ => null,
                    };
                    return yn == null ? (null, null, $"'{Raw(v)}' is geen ja/nee-waarde") : (yn.Value, null, null);
                }
                if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var iv)) return (iv, null, null);
                if (v.ValueKind == JsonValueKind.String && int.TryParse((v.GetString() ?? "").Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var sv)) return (sv, null, null);
                if (v.ValueKind == JsonValueKind.True) return (1, null, null);
                if (v.ValueKind == JsonValueKind.False) return (0, null, null);
                return (null, null, $"'{Raw(v)}' is geen geheel getal");
            }
            case StorageType.Double:
            {
                ForgeTypeId? spec = null;
                try { spec = par.Definition?.GetDataType(); } catch { }
                bool measurable = false;
                try { measurable = spec != null && UnitUtils.IsMeasurableSpec(spec); } catch { }
                if (v.ValueKind == JsonValueKind.Number)
                {
                    double d = v.GetDouble();
                    if (!measurable) return (d, null, null);
                    try
                    {
                        ForgeTypeId unit;
                        try { unit = doc.GetUnits().GetFormatOptions(spec!).GetUnitTypeId(); }
                        catch { unit = par.GetUnitTypeId(); }
                        return (UnitUtils.ConvertToInternalUnits(d, unit), null, null);
                    }
                    catch (Exception ex) { return (null, null, $"eenheidsconversie mislukt: {ex.Message}"); }
                }
                if (v.ValueKind == JsonValueKind.String)
                {
                    var s = (v.GetString() ?? "").Trim();
                    if (s.Length == 0) return (null, null, "lege waarde voor een getalparameter");
                    if (spec != null)
                    {
                        try { if (UnitFormatUtils.TryParse(doc.GetUnits(), spec, s, out double parsed)) return (parsed, s, null); }
                        catch { }
                    }
                    return (null, null, $"'{s}' niet te parsen als waarde in projecteenheden");
                }
                return (null, null, $"'{Raw(v)}' is geen getal");
            }
            case StorageType.ElementId:
                return (null, null, "ElementId-parameter: niet ondersteund");
            default:
                return (null, null, $"StorageType {par.StorageType} niet ondersteund");
        }
    }

    private static bool WriteValue(Parameter par, object val, string? setStr)
    {
        switch (par.StorageType)
        {
            case StorageType.String: return par.Set((string)val);
            case StorageType.Integer: return par.Set((int)val);
            case StorageType.Double:
                if (setStr != null) { try { if (par.SetValueString(setStr)) return true; } catch { } }
                return par.Set((double)val);
            default: return false;
        }
    }

    private static bool Equal(Parameter par, StorageType st, object desired)
    {
        try
        {
            return st switch
            {
                StorageType.String => string.Equals(par.AsString() ?? "", (string)desired, StringComparison.Ordinal),
                StorageType.Integer => par.HasValue && par.AsInteger() == (int)desired,
                StorageType.Double => par.HasValue && Math.Abs(par.AsDouble() - (double)desired) <= 1e-6 * Math.Max(1.0, Math.Abs((double)desired)),
                _ => false,
            };
        }
        catch { return false; }
    }

    private static string? DisplayValue(Parameter par)
    {
        try { return par.AsValueString() ?? par.AsString(); } catch { return null; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 3. create_mep_runs
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// create_mep_runs — leiding- en kanaalruns uit punten. Per run: segmenten tussen opeenvolgende punten
    /// (Pipe.Create / Duct.Create), bochten met NewElbowFitting. Rechte doorloop (collineair tussenpunt): het punt
    /// vervalt en de segmenten worden samengevoegd (geen union). Terugkerende richting: fout.
    ///
    /// params: target_document, dry_run (default TRUE),
    ///         runs:[{kind: "pipe"|"duct", system_type (PipingSystemType / MechanicalSystemType), segment_type (PipeType- of
    ///                DuctType-naam), level, diameter_mm (pipe, rond kanaal) | width_mm + height_mm (rechthoekig/ovaal kanaal),
    ///                points_mm:[[x,y,z],...] (z boven het level), connect_start_to?: element_id, connect_end_to?: element_id,
    ///                segment_diameters_mm?: [d0, d1, ...] (alleen pipe; één diameter per segment points_mm[k] → points_mm[k+1];
    ///                vervangt diameter_mm)}].
    ///
    /// Verloop (gekozen boven een los insert_transition): met segment_diameters_mm krijgt elk segment zijn eigen
    /// diameter. Een collineair tussenpunt met een diameterwissel blijft staan en krijgt NewTransitionFitting (het
    /// Transitions-onderdeel uit de routing preference; zonder Transitions-regel: run geweigerd); een diameterwissel in een
    /// bocht wordt geweigerd (zet een tussenpunt op het rechte stuk). Zo plaatst Revit het verloop zelf, in dezelfde
    /// transactie als segmenten en bochten (alles of niets), en hoeven er geen bestaande leidingen geknipt te worden.
    /// Een verbinding (connect_start_to/connect_end_to) krijgt de diameter van het eindsegment aan die kant.
    /// Resultaat extra: segment_diameters_mm, segment_diameters_gelezen_mm, verloop_ids, verlopen_gepland (dry-run).
    ///
    /// Verbinden met een element: de dichtstbijzijnde vrije End-connector van het juiste domein (piping/HVAC). Methoden:
    ///   direct          — connector valt samen met het run-uiteinde (≤ 1 mm): ConnectTo.
    ///   verlengen       — connector ligt in het verlengde van het eindsegment en kijkt ertegenin: segment verlengen + ConnectTo.
    ///   stub            — korte verbinding: stuk langs de connectoras tot het run-uiteinde (of het verlengde ervan), met
    ///                     één bocht, of met een tussenstuk en twee bochten.
    ///   Kijkt de connector van de run af of snijdt de as het segment: niet verbonden, gemeld, niet geforceerd.
    /// Per run een TransactionGroup: transactie 1 maakt segmenten en bochten (alles of niets), transactie 2 en 3
    /// maken de begin- en eindverbinding; een mislukte verbinding rolt alleen zichzelf terug.
    /// Vooraf: pipe-type zonder Segments-regel of bochten nodig zonder Elbows-regel in de routing preferences →
    /// run niet gemaakt, fout gemeld.
    /// Resultaat per run: {index, status, segment_ids, fitting_ids, lengte_totaal_mm, maat (read-back), verbindingen
    /// {start, end: {element_id, methode, gelukt, reden}}, fouten, notes}.
    /// </summary>
    public static CommandResponse CreateMepRuns(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        if (target == null) return Err("target_document is verplicht");
        var runsIn = HandlerUtil.Arr(p, "runs").Select(r => r.Clone()).ToList();
        if (runsIn.Count == 0) return Err("runs:[{kind, system_type, segment_type, level, diameter_mm|width_mm+height_mm, points_mm, connect_start_to?, connect_end_to?}] is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                if (!dryRun && doc.IsReadOnly) return (object)Fail("target_document is alleen-lezen");
                if (!dryRun && doc.IsModifiable) return (object)Fail("er staat al een transactie open in target_document");

                double shortTol = app.Application.ShortCurveTolerance;
                var notes = new List<string>();
                var meldingen = new List<string>();
                var results = new List<Dictionary<string, object?>>();
                var levels = Collect<Level>(doc).ToList();

                for (int i = 0; i < runsIn.Count; i++)
                {
                    var it = runsIn[i];
                    var fouten = new List<string>();
                    var rnotes = new List<string>();
                    var row = new Dictionary<string, object?>
                    {
                        ["index"] = i, ["status"] = "fout", ["segment_ids"] = new List<long>(), ["fitting_ids"] = new List<long>(),
                        ["fouten"] = fouten, ["notes"] = rnotes,
                    };
                    results.Add(row);
                    try
                    {
                        var spec = ResolveRun(doc, it, levels, shortTol, fouten, rnotes);
                        if (spec == null) continue;
                        row["kind"] = spec.Kind;
                        row["segment_type"] = spec.CurveType.Name;
                        row["system_type"] = spec.SystemType.Name;
                        row["level"] = spec.Level.Name;
                        row["punten_na_samenvoegen"] = spec.Points.Select(q => new[] { R(q.X * MM), R(q.Y * MM), R((q.Z - spec.Level.Elevation) * MM) }).ToList();
                        int nSeg = spec.Points.Count - 1;
                        double planLen = 0;
                        for (int k = 0; k < nSeg; k++) planLen += spec.Points[k].DistanceTo(spec.Points[k + 1]);

                        // ── verbindingen plannen ──
                        var conns = new Dictionary<string, object?>();
                        row["verbindingen"] = conns;
                        bool hasElbow = HasElbowRule(spec.CurveType);
                        foreach (var (key, tid, isStart) in new[] { ("start", spec.ConnectStart, true), ("end", spec.ConnectEnd, false) })
                        {
                            if (tid == null) continue;
                            var terminal = isStart ? spec.Points[0] : spec.Points[^1];
                            var inner = isStart ? spec.Points[1] : spec.Points[^2];
                            var plan = PlanConnect(doc, terminal, (terminal - inner).Normalize(), new ElementId(tid.Value), spec.Domain, hasElbow);
                            conns[key] = plan.ToRow(tid.Value);
                            if (plan.Method == null) fouten.Add($"verbinding {key} niet mogelijk: {plan.Reason}");
                        }

                        // knikpunt k+1: bocht, of verloop (recht doorgaand met andere diameter)
                        var verloopBij = new HashSet<int>();
                        for (int k = 0; k < nSeg - 1; k++)
                            if ((spec.Points[k + 1] - spec.Points[k]).Normalize().DotProduct((spec.Points[k + 2] - spec.Points[k + 1]).Normalize()) > 1 - ParTol)
                                verloopBij.Add(k);
                        if (spec.SegDiam.Count > 0) row["segment_diameters_mm"] = spec.SegDiam.Select(x => R(x * MM)).ToList();

                        if (dryRun)
                        {
                            row["status"] = "zou_maken";
                            row["segmenten_gepland"] = nSeg;
                            row["bochten_gepland"] = nSeg - 1 - verloopBij.Count;
                            row["verlopen_gepland"] = verloopBij.Count;
                            row["lengte_gepland_mm"] = R(planLen * MM);
                            continue;
                        }

                        // ── uitvoeren ──
                        var segIds = new List<ElementId>();
                        var fitIds = new List<ElementId>();
                        var groupNotes = new List<string>();
                        bool kept = RunGroup(doc, $"MEP-run {i} ({spec.Kind})", groupNotes, () =>
                        {
                            var (ok1, n1) = RunTx(doc, $"MEP-run {i}: segmenten en bochten", () =>
                            {
                                segIds.Clear(); fitIds.Clear();
                                for (int k = 0; k < nSeg; k++)
                                    segIds.Add(CreateSegment(doc, spec, spec.Points[k], spec.Points[k + 1], spec.SegDiam.Count > 0 ? spec.SegDiam[k] : null).Id);
                                doc.Regenerate();
                                for (int k = 0; k < nSeg - 1; k++)
                                {
                                    var joint = spec.Points[k + 1];
                                    var c1 = ConnectorAt(doc.GetElement(segIds[k]), joint) ?? throw new InvalidOperationException($"geen connector op segment {k} bij knik {k + 1}");
                                    var c2 = ConnectorAt(doc.GetElement(segIds[k + 1]), joint) ?? throw new InvalidOperationException($"geen connector op segment {k + 1} bij knik {k + 1}");
                                    bool verloop = verloopBij.Contains(k);
                                    string wat = verloop ? "verloop" : "bocht";
                                    FamilyInstance? f;
                                    try { f = verloop ? doc.Create.NewTransitionFitting(c1, c2) : doc.Create.NewElbowFitting(c1, c2); }
                                    catch (Exception ex) { throw new InvalidOperationException($"{wat} bij punt {k + 1} mislukt: {ex.Message}"); }
                                    if (f == null) throw new InvalidOperationException($"{wat} bij punt {k + 1}: {(verloop ? "NewTransitionFitting" : "NewElbowFitting")} gaf null");
                                    fitIds.Add(f.Id);
                                }
                            }, meldingen);
                            if (!ok1) { fouten.Add($"run teruggerold: {n1}"); return false; }
                            if (n1 != null) rnotes.Add(n1);
                            if (segIds.Any(id => doc.GetElement(id) is not MEPCurve) || fitIds.Any(id => doc.GetElement(id) == null))
                            { fouten.Add("read-back: segmenten of bochten ontbreken na commit"); return false; }

                            foreach (var (key, tid, isStart) in new[] { ("start", spec.ConnectStart, true), ("end", spec.ConnectEnd, false) })
                            {
                                if (tid == null) continue;
                                var crow = (Dictionary<string, object?>)conns[key]!;
                                crow["gelukt"] = false;
                                if (crow["methode"] == null) continue;   // plan was al onmogelijk; staat in fouten
                                var extraSeg = new List<ElementId>();
                                var extraFit = new List<ElementId>();
                                string? methode = null, reden = null;
                                var segId = isStart ? segIds[0] : segIds[^1];
                                var refPt = isStart ? spec.Points[0] : spec.Points[^1];
                                var (okc, nc) = RunTx(doc, $"MEP-run {i}: verbinding {key}", () =>
                                {
                                    var (m, rsn) = ExecuteConnect(doc, spec, segId, refPt, new ElementId(tid.Value), hasElbow, extraSeg, extraFit);
                                    methode = m; reden = rsn;
                                    if (m == null) throw new InvalidOperationException(rsn ?? "verbinden niet mogelijk");
                                }, meldingen);
                                crow["methode"] = methode;
                                if (!okc)
                                {
                                    crow["reden"] = reden ?? nc;
                                    fouten.Add($"verbinding {key} niet gemaakt: {reden ?? nc}");
                                    continue;
                                }
                                // read-back: is de doelconnector nu met een element van deze run verbonden?
                                var ours = new HashSet<long>(segIds.Concat(extraSeg).Select(x => x.Value));
                                bool verbonden = TargetConnectedTo(doc, new ElementId(tid.Value), ours);
                                crow["gelukt"] = verbonden;
                                if (!verbonden) { crow["reden"] = "read-back: doelconnector niet verbonden met de run"; fouten.Add($"verbinding {key}: read-back niet verbonden"); }
                                segIds.AddRange(extraSeg.Where(x => doc.GetElement(x) != null));
                                fitIds.AddRange(extraFit.Where(x => doc.GetElement(x) != null));
                            }
                            return true;
                        });
                        foreach (var gn in groupNotes) fouten.Add(gn);
                        if (!kept) { row["status"] = "fout"; continue; }

                        // ── read-back ──
                        var segs = segIds.Select(id => doc.GetElement(id) as MEPCurve).Where(m => m != null).Cast<MEPCurve>().ToList();
                        var fits = fitIds.Where(id => doc.GetElement(id) != null).ToList();
                        ((List<long>)row["segment_ids"]!).AddRange(segs.Select(s => s.Id.Value));
                        ((List<long>)row["fitting_ids"]!).AddRange(fits.Select(f => f.Value));
                        double len = segs.Sum(s => (s.Location as LocationCurve)?.Curve?.Length ?? 0);
                        row["lengte_totaal_mm"] = R(len * MM);
                        if (segs.Count > 0) row["maat"] = ReadSize(segs[0], spec);
                        if (spec.SegDiam.Count > 0)
                        {
                            var gelezen = segIds.Take(nSeg).Select(id => doc.GetElement(id) is Pipe pp ? (double?)R(pp.Diameter * MM) : null).ToList();
                            row["segment_diameters_gelezen_mm"] = gelezen;
                            for (int k = 0; k < gelezen.Count; k++)
                                if (gelezen[k] == null || Math.Abs(gelezen[k]!.Value - R(spec.SegDiam[k] * MM)) > 0.5)
                                    fouten.Add($"read-back: segment {k} heeft diameter {gelezen[k]?.ToString() ?? "?"} mm, gevraagd {R(spec.SegDiam[k] * MM)}");
                            row["verloop_ids"] = verloopBij.OrderBy(k => k).Select(k => k < fitIds.Count ? fitIds[k].Value : (long?)null).ToList();
                        }
                        if (segs.Count != segIds.Count || fits.Count != fitIds.Count) fouten.Add("read-back: niet alle elementen zijn er na commit");
                        row["verbonden_segmentuiteinden"] = CountConnectedEnds(segs);
                        row["status"] = fouten.Count == 0 ? "gemaakt" : "gemaakt_met_fouten";
                    }
                    catch (Exception ex) { fouten.Add(ex.Message); }
                }

                if (dryRun) notes.Add("dry_run: niets gewijzigd; zou_maken is het plan (verbindingen: methode en afstand)");
                notes.Add("punten in mm, interne coördinaten; z boven het level. Lengte = som van de segmentlengtes, zonder fittings");
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["gevraagd"] = runsIn.Count,
                    ["tellers"] = results.GroupBy(r => (string?)r["status"] ?? "?").ToDictionary(g => g.Key, g => g.Count()),
                    ["results"] = results,
                    ["failure_meldingen"] = meldingen.Take(100).ToList(),
                    ["notes"] = notes,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private sealed class RunSpec
    {
        public string Kind = "pipe";
        public MEPCurveType CurveType = null!;
        public MEPSystemType SystemType = null!;
        public Level Level = null!;
        public ConnectorProfileType Shape = ConnectorProfileType.Round;
        public double? Diameter, Width, Height;   // voet
        public List<XYZ> Points = new();
        public List<double> SegDiam = new();      // voet, per segment na samenvoegen (alleen met segment_diameters_mm)
        public long? ConnectStart, ConnectEnd;
        public Domain Domain = Domain.DomainPiping;
    }

    /// <summary>Valideert een run en lost namen op. Null bij fouten (in fouten gezet).</summary>
    private static RunSpec? ResolveRun(Document doc, JsonElement it, List<Level> levels, double shortTol, List<string> fouten, List<string> notes)
    {
        if (it.ValueKind != JsonValueKind.Object) { fouten.Add("run is geen object"); return null; }
        var s = new RunSpec();
        string kind = (HandlerUtil.Str(it, "kind") ?? "").Trim().ToLowerInvariant();
        string? sysName = HandlerUtil.Str(it, "system_type");
        string? typeName = HandlerUtil.Str(it, "segment_type");
        string? levelName = HandlerUtil.Str(it, "level");
        if (kind is not ("pipe" or "duct")) fouten.Add($"kind '{kind}' onbekend (pipe|duct)");
        if (sysName == null) fouten.Add("system_type ontbreekt");
        if (typeName == null) fouten.Add("segment_type ontbreekt");
        if (levelName == null) fouten.Add("level ontbreekt");
        var raw = new List<double[]>();
        if (it.TryGetProperty("points_mm", out var pe) && pe.ValueKind == JsonValueKind.Array)
        {
            int k = 0;
            foreach (var q in pe.EnumerateArray())
            {
                var xyz = q.ValueKind == JsonValueKind.Array ? q.EnumerateArray().Select(NumEl).ToList() : new List<double?>();
                if (xyz.Count != 3 || xyz.Any(v => v == null)) { fouten.Add($"points_mm[{k}] is geen [x,y,z]"); }
                else raw.Add(new[] { xyz[0]!.Value, xyz[1]!.Value, xyz[2]!.Value });
                k++;
            }
        }
        if (raw.Count < 2) fouten.Add("points_mm heeft minstens twee punten [x,y,z] nodig");
        // verloop: diameter per segment (segment k = points_mm[k] → points_mm[k+1])
        List<double>? segDiamRaw = null;
        if (it.TryGetProperty("segment_diameters_mm", out var sde) && sde.ValueKind != JsonValueKind.Null)
        {
            var v = sde.ValueKind == JsonValueKind.Array ? sde.EnumerateArray().Select(NumEl).ToList() : new List<double?>();
            if (kind != "pipe") fouten.Add("segment_diameters_mm kan alleen bij kind pipe");
            else if (v.Count == 0 || v.Any(x => x == null || x <= 0)) fouten.Add("segment_diameters_mm is geen lijst met diameters (> 0)");
            else if (raw.Count >= 2 && v.Count != raw.Count - 1) fouten.Add($"segment_diameters_mm heeft {v.Count} waarden; verwacht {raw.Count - 1} (één per segment tussen opeenvolgende punten)");
            else segDiamRaw = v.Select(x => x!.Value / MM).ToList();
        }
        s.ConnectStart = LongProp(it, "connect_start_to");
        s.ConnectEnd = LongProp(it, "connect_end_to");
        if (fouten.Count > 0) return null;
        s.Kind = kind;
        s.Domain = kind == "pipe" ? Domain.DomainPiping : Domain.DomainHvac;

        var lvl = FindLevel(levels, levelName!, out var lvlErr);
        if (lvl == null) { fouten.Add(lvlErr!); return null; }
        s.Level = lvl;

        if (kind == "pipe")
        {
            var pt = ByName(Collect<PipeType>(doc), typeName!, "PipeType", fouten);
            var st = ByName(Collect<PipingSystemType>(doc), sysName!, "PipingSystemType", fouten);
            if (pt == null || st == null) return null;
            s.CurveType = pt; s.SystemType = st;
            var d = Num(it, "diameter_mm");
            if (segDiamRaw != null)
            {
                if (d != null && Math.Abs(d.Value / MM - segDiamRaw[0]) > 1e-9) notes.Add("diameter_mm wijkt af van segment_diameters_mm[0]; segment_diameters_mm geldt");
                d = segDiamRaw[0] * MM;
            }
            if (d == null || d <= 0) { fouten.Add("diameter_mm (> 0) of segment_diameters_mm is verplicht voor een pipe"); return null; }
            s.Diameter = d / MM;
            if (RuleCount(pt, RoutingPreferenceRuleGroupType.Segments) == 0)
            { fouten.Add($"PipeType '{pt.Name}' heeft geen Segments-regel in de routing preferences; leidingen niet te maken"); return null; }
            if (segDiamRaw != null && segDiamRaw.Distinct().Count() > 1 && RuleCount(pt, RoutingPreferenceRuleGroupType.Transitions) == 0)
            { fouten.Add($"PipeType '{pt.Name}' heeft geen Transitions-regel in de routing preferences; verloop niet te maken"); return null; }
        }
        else
        {
            var dt = ByName(Collect<DuctType>(doc), typeName!, "DuctType", fouten);
            var st = ByName(Collect<MechanicalSystemType>(doc), sysName!, "MechanicalSystemType", fouten);
            if (dt == null || st == null) return null;
            s.CurveType = dt; s.SystemType = st;
            s.Shape = DuctShape(dt);
            if (s.Shape == ConnectorProfileType.Round)
            {
                var d = Num(it, "diameter_mm");
                if (d == null || d <= 0) { fouten.Add($"DuctType '{dt.Name}' is rond: diameter_mm (> 0) is verplicht"); return null; }
                s.Diameter = d / MM;
            }
            else if (s.Shape is ConnectorProfileType.Rectangular or ConnectorProfileType.Oval)
            {
                var w = Num(it, "width_mm"); var h = Num(it, "height_mm");
                if (w == null || h == null || w <= 0 || h <= 0) { fouten.Add($"DuctType '{dt.Name}' is {s.Shape}: width_mm en height_mm (> 0) zijn verplicht"); return null; }
                s.Width = w / MM; s.Height = h / MM;
            }
            else { fouten.Add($"DuctType '{dt.Name}': vorm onbekend"); return null; }
        }

        // punten → absolute XYZ; dubbele en collineaire tussenpunten samenvoegen
        var pts = raw.Select(r => new XYZ(r[0] / MM, r[1] / MM, lvl.Elevation + r[2] / MM)).ToList();
        // Met segment_diameters_mm: een collineair tussenpunt met een andere diameter blijft staan (daar komt het verloop).
        var clean = new List<XYZ> { pts[0] };
        var cdiam = new List<double>();
        int dubbel = 0, samengevoegd = 0;
        for (int j = 1; j < pts.Count; j++)
        {
            var q = pts[j];
            double dj = segDiamRaw != null ? segDiamRaw[j - 1] : 0;
            if (q.DistanceTo(clean[^1]) <= Tol) { dubbel++; continue; }
            if (clean.Count >= 2)
            {
                var d1 = (clean[^1] - clean[^2]).Normalize();
                var d2 = (q - clean[^1]).Normalize();
                double dot = d1.DotProduct(d2);
                if (dot > 1 - ParTol && Math.Abs(cdiam[^1] - dj) < 1e-9) { clean[^1] = q; samengevoegd++; continue; }
                if (dot < -1 + ParTol) { fouten.Add($"richting keert om bij punt ({R(clean[^1].X * MM)}, {R(clean[^1].Y * MM)}); dat kan niet met een bocht"); return null; }
            }
            clean.Add(q);
            cdiam.Add(dj);
        }
        if (clean.Count < 2) { fouten.Add("na samenvoegen van dubbele punten blijft er geen segment over"); return null; }
        if (dubbel > 0) notes.Add($"{dubbel} dubbel punt/punten overgeslagen");
        if (samengevoegd > 0) notes.Add($"{samengevoegd} collineair tussenpunt/-punten samengevoegd (rechte doorloop als één segment)");
        if (segDiamRaw != null)
        {
            s.SegDiam = cdiam;
            s.Diameter = cdiam[0];
            for (int k = 0; k < clean.Count - 2; k++)
            {
                if (Math.Abs(cdiam[k] - cdiam[k + 1]) < 1e-9) continue;
                double dot = (clean[k + 1] - clean[k]).Normalize().DotProduct((clean[k + 2] - clean[k + 1]).Normalize());
                if (dot <= 1 - ParTol)
                { fouten.Add($"diameter wisselt ({R(cdiam[k] * MM)} → {R(cdiam[k + 1] * MM)}) in een bocht bij punt {k + 1}; een verloop kan alleen op een recht doorgaand punt (zet een tussenpunt op het rechte stuk)"); return null; }
            }
        }
        double size = s.Diameter ?? Math.Max(s.Width ?? 0, s.Height ?? 0);
        for (int k = 0; k < clean.Count - 1; k++)
        {
            double len = clean[k].DistanceTo(clean[k + 1]);
            double sk = s.SegDiam.Count > 0 ? s.SegDiam[k] : size;
            if (len <= shortTol) { fouten.Add($"segment {k} is korter dan de korte-lijntolerantie van Revit"); return null; }
            if (len < 2 * sk) notes.Add($"segment {k} ({R(len * MM)} mm) is korter dan 2× de maat: bochten of verlopen passen mogelijk niet");
        }
        s.Points = clean;
        int bochten = 0;
        for (int k = 0; k < clean.Count - 2; k++)
            if ((clean[k + 1] - clean[k]).Normalize().DotProduct((clean[k + 2] - clean[k + 1]).Normalize()) <= 1 - ParTol) bochten++;
        if (bochten > 0 && !HasElbowRule(s.CurveType))
        { fouten.Add($"{(kind == "pipe" ? "PipeType" : "DuctType")} '{s.CurveType.Name}' heeft geen Elbows-regel in de routing preferences; {bochten} bocht(en) nodig. Run niet gemaakt"); return null; }

        // systeemtype past bij kind (al afgedwongen door de klasse); classificatie melden
        try { notes.Add($"systeemclassificatie: {(s.SystemType is PipingSystemType ps ? ps.SystemClassification : ((MechanicalSystemType)s.SystemType).SystemClassification)}"); } catch { }
        return s;
    }

    private static T? ByName<T>(IEnumerable<T> all, string name, string label, List<string> fouten) where T : Element
    {
        var list = all.ToList();
        var exact = list.Where(e => e.Name == name).ToList();
        if (exact.Count == 1) return exact[0];
        var ci = list.Where(e => e.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
        if (exact.Count == 0 && ci.Count == 1) return ci[0];
        if (exact.Count > 1 || ci.Count > 1) { fouten.Add($"{label} '{name}' is niet uniek"); return null; }
        fouten.Add($"{label} '{name}' niet gevonden (wel: {string.Join(", ", list.Select(e => e.Name).OrderBy(n => n).Take(20))})");
        return null;
    }

    /// <summary>diam (voet, alleen pipe): diameter van dit segment; default s.Diameter.</summary>
    private static MEPCurve CreateSegment(Document doc, RunSpec s, XYZ a, XYZ b, double? diam = null)
    {
        MEPCurve mc = s.Kind == "pipe"
            ? Pipe.Create(doc, s.SystemType.Id, s.CurveType.Id, s.Level.Id, a, b)
            : Duct.Create(doc, s.SystemType.Id, s.CurveType.Id, s.Level.Id, a, b);
        if (mc == null) throw new InvalidOperationException($"{s.Kind}.Create gaf null");
        if (s.Kind == "pipe") SetDouble(mc, BuiltInParameter.RBS_PIPE_DIAMETER_PARAM, diam ?? s.Diameter!.Value, "diameter");
        else if (s.Diameter != null) SetDouble(mc, BuiltInParameter.RBS_CURVE_DIAMETER_PARAM, s.Diameter.Value, "diameter");
        else
        {
            SetDouble(mc, BuiltInParameter.RBS_CURVE_WIDTH_PARAM, s.Width!.Value, "breedte");
            SetDouble(mc, BuiltInParameter.RBS_CURVE_HEIGHT_PARAM, s.Height!.Value, "hoogte");
        }
        return mc;
    }

    private static void SetDouble(Element el, BuiltInParameter bip, double v, string label)
    {
        var par = el.get_Parameter(bip) ?? throw new InvalidOperationException($"{label}-parameter ontbreekt");
        if (par.IsReadOnly) throw new InvalidOperationException($"{label}-parameter is read-only");
        if (!par.Set(v)) throw new InvalidOperationException($"{label} zetten gaf false");
    }

    private static Dictionary<string, object?> ReadSize(MEPCurve mc, RunSpec s)
    {
        double? Get(BuiltInParameter b) { try { var par = mc.get_Parameter(b); return par != null && par.HasValue ? R(par.AsDouble() * MM) : null; } catch { return null; } }
        var d = new Dictionary<string, object?>();
        if (s.Kind == "pipe")
        {
            d["diameter_mm"] = Get(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM);
            d["gevraagd_mm"] = R(s.Diameter!.Value * MM);
        }
        else if (s.Diameter != null) { d["diameter_mm"] = Get(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM); d["gevraagd_mm"] = R(s.Diameter.Value * MM); }
        else
        {
            d["width_mm"] = Get(BuiltInParameter.RBS_CURVE_WIDTH_PARAM); d["height_mm"] = Get(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM);
            d["gevraagd_mm"] = new[] { R(s.Width!.Value * MM), R(s.Height!.Value * MM) };
        }
        return d;
    }

    private static int CountConnectedEnds(List<MEPCurve> segs)
    {
        int n = 0;
        foreach (var s in segs)
            foreach (var c in EndConnectors(s))
                if (c.IsConnected) n++;
        return n;
    }

    // ── connectors ──

    private static IEnumerable<Connector> AllConnectors(Element? el)
    {
        ConnectorManager? cm = el switch
        {
            MEPCurve mc => mc.ConnectorManager,
            FamilyInstance fi => fi.MEPModel?.ConnectorManager,
            _ => null,
        };
        if (cm == null) yield break;
        foreach (Connector c in cm.Connectors) yield return c;
    }

    private static IEnumerable<Connector> EndConnectors(Element? el)
    {
        foreach (var c in AllConnectors(el))
        {
            bool end; try { end = c.ConnectorType == ConnectorType.End; } catch { end = false; }
            if (end) yield return c;
        }
    }

    private static Connector? ConnectorAt(Element? el, XYZ pt)
        => EndConnectors(el).OrderBy(c => c.Origin.DistanceTo(pt)).FirstOrDefault();

    private static bool TargetConnectedTo(Document doc, ElementId targetId, HashSet<long> ours)
    {
        foreach (var c in EndConnectors(doc.GetElement(targetId)))
        {
            if (!c.IsConnected) continue;
            foreach (Connector r in c.AllRefs)
            {
                try { if (r.Owner != null && ours.Contains(r.Owner.Id.Value)) return true; } catch { }
            }
        }
        return false;
    }

    private sealed class ConnectPlan
    {
        public string? Method;           // direct | verlengen | stub | stub_verlengen | stub_tussenstuk | null
        public string? Reason;
        public int ConnectorId = -1;
        public XYZ? Origin, Axis, P;     // P = voet van de loodlijn van het run-uiteinde op de connectoras
        public double Distance;

        public Dictionary<string, object?> ToRow(long target) => new()
        {
            ["element_id"] = target,
            ["methode"] = Method,
            ["reden"] = Reason,
            ["afstand_mm"] = Origin != null ? R(Distance * MM) : null,
            ["connector"] = Origin == null ? null : new Dictionary<string, object?>
            {
                ["id"] = ConnectorId,
                ["origin_mm"] = new[] { R(Origin.X * MM), R(Origin.Y * MM), R(Origin.Z * MM) },
                ["richting"] = Axis == null ? null : new[] { Math.Round(Axis.X, 3), Math.Round(Axis.Y, 3), Math.Round(Axis.Z, 3) },
            },
        };
    }

    /// <summary>Kies de dichtstbijzijnde vrije End-connector van het juiste domein en bepaal de methode.
    /// terminal = run-uiteinde, u = richting van de run naar buiten bij dat uiteinde.</summary>
    private static ConnectPlan PlanConnect(Document doc, XYZ terminal, XYZ u, ElementId targetId, Domain domain, bool hasElbow)
    {
        var plan = new ConnectPlan();
        var el = doc.GetElement(targetId);
        if (el == null) { plan.Reason = $"element {targetId.Value} niet gevonden"; return plan; }
        var free = new List<Connector>();
        int total = 0;
        foreach (var c in EndConnectors(el))
        {
            total++;
            try { if (c.Domain == domain && !c.IsConnected) free.Add(c); } catch { }
        }
        if (free.Count == 0)
        {
            plan.Reason = total == 0 ? $"element {targetId.Value} heeft geen connectors" : $"element {targetId.Value} heeft geen vrije {domain}-connector ({total} connector(s))";
            return plan;
        }
        var tc = free.OrderBy(c => c.Origin.DistanceTo(terminal)).First();
        plan.ConnectorId = tc.Id;
        plan.Origin = tc.Origin;
        plan.Distance = tc.Origin.DistanceTo(terminal);
        XYZ? a = null;
        try { a = tc.CoordinateSystem.BasisZ.Normalize(); } catch { }
        plan.Axis = a;

        if (plan.Distance <= Tol) { plan.Method = "direct"; return plan; }
        if (a == null) { plan.Reason = "richting van de connector onbekend"; return plan; }

        var v = tc.Origin - terminal;
        var vn = v.Normalize();
        // verlengen: connector in het verlengde van de run en kijkt de run aan
        if (vn.DotProduct(u) > 1 - ParTol && a.DotProduct(u) < -1 + ParTol) { plan.Method = "verlengen"; return plan; }

        // korte verbinding langs de connectoras
        var w = terminal - tc.Origin;
        double t = w.DotProduct(a);
        if (t <= Tol) { plan.Reason = "connector kijkt van het run-uiteinde af; korte verbinding zou terug moeten lopen"; return plan; }
        if (!hasElbow) { plan.Reason = "korte verbinding vraagt een bocht; geen Elbows-regel op het type"; return plan; }
        var P = tc.Origin + a * t;
        plan.P = P;
        var r = terminal - P;                       // loodrecht op a
        if (r.GetLength() <= Tol)
        {
            if (a.DotProduct(u) < -1 + ParTol) { plan.Method = "verlengen"; return plan; }
            if (Math.Abs(a.DotProduct(u)) > 1 - ParTol) { plan.Reason = "connectoras valt samen met de run maar kijkt dezelfde kant op"; return plan; }
            plan.Method = "stub"; return plan;
        }
        var back = (P - terminal).Normalize();      // van het uiteinde naar P
        double dbu = back.DotProduct(u);
        if (dbu > 1 - ParTol) { plan.Method = "stub_verlengen"; return plan; }
        if (dbu < -1 + ParTol) { plan.Reason = "connectoras kruist het run-segment; een T-stuk ondersteunt dit commando niet"; return plan; }
        plan.Method = "stub_tussenstuk";
        return plan;
    }

    /// <summary>Voert de verbinding uit binnen een open transactie. Geeft (methode, reden) terug; methode null = mislukt
    /// (de aanroeper rolt dan terug).</summary>
    private static (string? method, string? reason) ExecuteConnect(Document doc, RunSpec s, ElementId segId, XYZ refPt, ElementId targetId,
                                                                   bool hasElbow, List<ElementId> extraSeg, List<ElementId> extraFit)
    {
        if (doc.GetElement(segId) is not MEPCurve seg || seg.Location is not LocationCurve lc || lc.Curve is not Line line)
            return (null, "eindsegment niet gevonden of niet recht");
        var e0 = line.GetEndPoint(0); var e1 = line.GetEndPoint(1);
        bool atStart = e0.DistanceTo(refPt) <= e1.DistanceTo(refPt);
        var terminal = atStart ? e0 : e1;
        var other = atStart ? e1 : e0;
        var u = (terminal - other).Normalize();
        var plan = PlanConnect(doc, terminal, u, targetId, s.Domain, hasElbow);
        if (plan.Method == null) return (null, plan.Reason);
        double? segDiam = s.Kind == "pipe" && seg is Pipe segPipe ? segPipe.Diameter : null;   // verloop: stub in de maat van het eindsegment
        Connector Tc() => EndConnectors(doc.GetElement(targetId)).FirstOrDefault(c => c.Id == plan.ConnectorId)
                          ?? throw new InvalidOperationException("doelconnector niet meer te vinden");
        Connector SegAt(ElementId id, XYZ pt) => ConnectorAt(doc.GetElement(id), pt) ?? throw new InvalidOperationException("segmentconnector niet gevonden");
        void Extend(XYZ to)
        {
            var c = (LocationCurve)doc.GetElement(segId).Location;
            c.Curve = atStart ? Line.CreateBound(to, other) : Line.CreateBound(other, to);
        }
        FamilyInstance Elbow(Connector c1, Connector c2, string waar)
        {
            FamilyInstance? f;
            try { f = doc.Create.NewElbowFitting(c1, c2); }
            catch (Exception ex) { throw new InvalidOperationException($"bocht {waar} mislukt: {ex.Message}"); }
            return f ?? throw new InvalidOperationException($"bocht {waar}: NewElbowFitting gaf null");
        }

        switch (plan.Method)
        {
            case "direct":
                SegAt(segId, terminal).ConnectTo(Tc());
                break;
            case "verlengen":
                Extend(plan.Origin!);
                doc.Regenerate();
                SegAt(segId, plan.Origin!).ConnectTo(Tc());
                break;
            case "stub":
            {
                var stub = CreateSegment(doc, s, plan.Origin!, terminal, segDiam);
                extraSeg.Add(stub.Id);
                doc.Regenerate();
                SegAt(stub.Id, plan.Origin!).ConnectTo(Tc());
                extraFit.Add(Elbow(SegAt(stub.Id, terminal), SegAt(segId, terminal), "stub-run").Id);
                break;
            }
            case "stub_verlengen":
            {
                Extend(plan.P!);
                var stub = CreateSegment(doc, s, plan.Origin!, plan.P!, segDiam);
                extraSeg.Add(stub.Id);
                doc.Regenerate();
                SegAt(stub.Id, plan.Origin!).ConnectTo(Tc());
                extraFit.Add(Elbow(SegAt(stub.Id, plan.P!), SegAt(segId, plan.P!), "stub-run").Id);
                break;
            }
            case "stub_tussenstuk":
            {
                var stub = CreateSegment(doc, s, plan.Origin!, plan.P!, segDiam);
                var bridge = CreateSegment(doc, s, plan.P!, terminal, segDiam);
                extraSeg.Add(stub.Id); extraSeg.Add(bridge.Id);
                doc.Regenerate();
                SegAt(stub.Id, plan.Origin!).ConnectTo(Tc());
                extraFit.Add(Elbow(SegAt(stub.Id, plan.P!), SegAt(bridge.Id, plan.P!), "stub-tussenstuk").Id);
                extraFit.Add(Elbow(SegAt(bridge.Id, terminal), SegAt(segId, terminal), "tussenstuk-run").Id);
                break;
            }
            default:
                return (null, $"methode {plan.Method} onbekend");
        }
        return (plan.Method, null);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 4. get_room_geometry
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// get_room_geometry — rooms met geometrie, alleen lezen. Werkt ook op een gelinkt model dat geladen is: geef dan
    /// de Title van het gelinkte document als target_document (list_link_instances noemt die); coördinaten zijn dan
    /// in het interne stelsel van dat model (omrekenen met de totale transformatie van de link).
    ///
    /// params: target_document, levels?: [levelnaam, ...] (filter; onbekende namen in notes).
    /// Per room: id, unique_id, name, number, level, phase, area_m2, geplaatst, omsloten, location_point_mm [x,y,z],
    /// bbox_mm {min, max} ([x,y,z]), boundary_mm (buitenste lus, [[x,y], ...], bogen getesselleerd, laatste punt ≠
    /// eerste), boundary_z_mm, lussen (aantal boundary-lussen, incl. de buitenste), deuren [{element_id, mark, family,
    /// type, from_room_number, to_room_number}] (deuren in hetzelfde document met deze room als FromRoom of ToRoom).
    /// Boundary: SpatialElementBoundaryOptions met SpatialElementBoundaryLocation.Finish; buitenste lus = de lus met
    /// het grootste oppervlak in XY. FromRoom/ToRoom gelden voor de laatste fase van het project.
    /// </summary>
    public static CommandResponse GetRoomGeometry(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");
        var levelFilter = HandlerUtil.Arr(p, "levels").Where(e => e.ValueKind == JsonValueKind.String)
            .Select(e => e.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open (een gelinkt model moet geladen zijn)");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                var notes = new List<string>();

                HashSet<long>? lvlIds = null;
                if (levelFilter.Count > 0)
                {
                    var levels = Collect<Level>(doc).ToList();
                    lvlIds = new HashSet<long>();
                    foreach (var ln in levelFilter)
                    {
                        var l = FindLevel(levels, ln, out var lerr);
                        if (l == null) notes.Add(lerr!); else lvlIds.Add(l.Id.Value);
                    }
                }

                // deuren per room
                var doorsByRoom = new Dictionary<long, List<Dictionary<string, object?>>>();
                int nDoors = 0;
                foreach (var d in new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Doors)
                             .WhereElementIsNotElementType().OfType<FamilyInstance>())
                {
                    Autodesk.Revit.DB.Architecture.Room? from = null, to = null;
                    try { from = d.FromRoom; } catch { }
                    try { to = d.ToRoom; } catch { }
                    if (from == null && to == null) continue;
                    nDoors++;
                    string? mark = null;
                    try { mark = d.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString(); } catch { }
                    var row = new Dictionary<string, object?>
                    {
                        ["element_id"] = d.Id.Value, ["mark"] = mark,
                        ["family"] = d.Symbol?.Family?.Name, ["type"] = d.Symbol?.Name,
                        ["from_room_number"] = from?.Number, ["to_room_number"] = to?.Number,
                    };
                    foreach (var r in new[] { from, to }.Where(r => r != null).Select(r => r!.Id.Value).Distinct())
                    {
                        if (!doorsByRoom.TryGetValue(r, out var lst)) doorsByRoom[r] = lst = new List<Dictionary<string, object?>>();
                        lst.Add(row);
                    }
                }

                var opts = new SpatialElementBoundaryOptions { SpatialElementBoundaryLocation = SpatialElementBoundaryLocation.Finish };
                var rooms = new List<Dictionary<string, object?>>();
                int nGeplaatst = 0, nOmsloten = 0;
                foreach (var room in new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms)
                             .WhereElementIsNotElementType().OfType<Autodesk.Revit.DB.Architecture.Room>()
                             .OrderBy(r => r.Number ?? "", StringComparer.OrdinalIgnoreCase))
                {
                    if (lvlIds != null && !lvlIds.Contains(room.LevelId.Value)) continue;
                    var row = new Dictionary<string, object?>
                    {
                        ["id"] = room.Id.Value,
                        ["unique_id"] = room.UniqueId,
                        ["name"] = SafeStr(() => room.get_Parameter(BuiltInParameter.ROOM_NAME)?.AsString()),
                        ["number"] = room.Number,
                        ["level"] = SafeStr(() => room.Level?.Name),
                        ["phase"] = SafeStr(() => (doc.GetElement(room.get_Parameter(BuiltInParameter.ROOM_PHASE)?.AsElementId() ?? ElementId.InvalidElementId))?.Name),
                    };
                    double area = 0;
                    try { area = room.Area; } catch { }
                    bool placed = room.Location is LocationPoint;
                    bool enclosed = placed && area > 1e-9;
                    if (placed) nGeplaatst++;
                    if (enclosed) nOmsloten++;
                    row["area_m2"] = Math.Round(area * 0.09290304, 2);
                    row["geplaatst"] = placed;
                    row["omsloten"] = enclosed;
                    row["location_point_mm"] = room.Location is LocationPoint lp ? Mm3(lp.Point) : null;
                    try
                    {
                        var bb = room.get_BoundingBox(null);
                        row["bbox_mm"] = bb == null ? null : new Dictionary<string, object?> { ["min"] = Mm3(bb.Min), ["max"] = Mm3(bb.Max) };
                    }
                    catch { row["bbox_mm"] = null; }

                    row["boundary_mm"] = null;
                    row["boundary_z_mm"] = null;
                    row["lussen"] = 0;
                    if (enclosed)
                    {
                        try
                        {
                            var loops = room.GetBoundarySegments(opts);
                            if (loops != null && loops.Count > 0)
                            {
                                row["lussen"] = loops.Count;
                                List<XYZ>? best = null; double bestA = -1;
                                foreach (var loop in loops)
                                {
                                    var pts = LoopPoints(loop);
                                    double a = Math.Abs(SignedArea(pts));
                                    if (a > bestA) { bestA = a; best = pts; }
                                }
                                if (best != null && best.Count > 0)
                                {
                                    row["boundary_mm"] = best.Select(q => new[] { R(q.X * MM), R(q.Y * MM) }).ToList();
                                    row["boundary_z_mm"] = R(best[0].Z * MM);
                                }
                            }
                        }
                        catch (Exception ex) { row["boundary_fout"] = ex.Message; }
                    }
                    row["deuren"] = doorsByRoom.TryGetValue(room.Id.Value, out var dl) ? dl : new List<Dictionary<string, object?>>();
                    rooms.Add(row);
                }

                notes.Add("coördinaten in mm in het interne stelsel van dit document; bij een gelinkt model omrekenen met de totale transformatie uit list_link_instances");
                notes.Add("boundary: Finish-afwerking, buitenste lus (grootste oppervlak), [x,y] in volgorde, gesloten (laatste punt verbindt met het eerste)");
                notes.Add("deuren: FromRoom/ToRoom in de laatste projectfase, alleen deuren in hetzelfde document");
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["is_link"] = doc.IsLinked,
                    ["tellers"] = new Dictionary<string, object?>
                    {
                        ["rooms"] = rooms.Count, ["geplaatst"] = nGeplaatst, ["omsloten"] = nOmsloten,
                        ["niet_geplaatst"] = rooms.Count - nGeplaatst, ["niet_omsloten"] = nGeplaatst - nOmsloten,
                        ["deuren_met_room"] = nDoors,
                    },
                    ["rooms"] = rooms,
                    ["notes"] = notes,
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static string? SafeStr(Func<string?> f) { try { return f(); } catch { return null; } }

    private static double[] Mm3(XYZ q) => new[] { R(q.X * MM), R(q.Y * MM), R(q.Z * MM) };

    /// <summary>Punten van een boundary-lus: per segment het beginpunt; bogen e.d. getesselleerd (zonder eindpunt).</summary>
    private static List<XYZ> LoopPoints(IList<BoundarySegment> loop)
    {
        var pts = new List<XYZ>();
        foreach (var seg in loop)
        {
            Curve? c = null;
            try { c = seg.GetCurve(); } catch { }
            if (c == null) continue;
            if (c is Line) { pts.Add(c.GetEndPoint(0)); continue; }
            IList<XYZ> tess;
            try { tess = c.Tessellate(); } catch { tess = new List<XYZ> { c.GetEndPoint(0) }; }
            for (int k = 0; k < tess.Count - 1; k++) pts.Add(tess[k]);
            if (tess.Count == 1) pts.Add(tess[0]);
        }
        // dubbele opeenvolgende punten weg
        var clean = new List<XYZ>();
        foreach (var q in pts) if (clean.Count == 0 || clean[^1].DistanceTo(q) > Tol) clean.Add(q);
        if (clean.Count > 1 && clean[0].DistanceTo(clean[^1]) <= Tol) clean.RemoveAt(clean.Count - 1);
        return clean;
    }

    private static double SignedArea(List<XYZ> pts)
    {
        double a = 0;
        for (int k = 0; k < pts.Count; k++)
        {
            var q1 = pts[k]; var q2 = pts[(k + 1) % pts.Count];
            a += q1.X * q2.Y - q2.X * q1.Y;
        }
        return a / 2;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 5. list_link_instances
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// list_link_instances — RevitLinkInstances in target_document, alleen lezen.
    /// params: target_document.
    /// Per instantie: element_id, name, type_name, type_id, linked_document (Title van het geladen gelinkte document =
    /// target_document voor get_room_geometry, null als niet geladen), geladen, status (LinkedFileStatus), pad,
    /// attachment, genest, pinned, transform {origin_mm, basis_x, basis_y, basis_z, rotatie_xy_deg}
    /// (GetTotalTransform: van gelinkte interne coördinaten naar die van target_document), origin_op_origin (origin
    /// ≤ 1 mm en basis = identiteit).
    /// </summary>
    public static CommandResponse ListLinkInstances(CommandRequest request)
    {
        var p = request.Params;
        string? target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("target_document is verplicht");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (doc.IsFamilyDocument) return (object)Fail("target_document is een familiedocument");
                var notes = new List<string>();
                var rows = new List<Dictionary<string, object?>>();
                foreach (var li in Collect<RevitLinkInstance>(doc).OrderBy(l => l.Id.Value))
                {
                    var row = new Dictionary<string, object?> { ["element_id"] = li.Id.Value, ["name"] = SafeStr(() => li.Name) };
                    rows.Add(row);
                    try
                    {
                        var lt = doc.GetElement(li.GetTypeId()) as RevitLinkType;
                        row["type_name"] = lt?.Name;
                        row["type_id"] = lt?.Id.Value;
                        bool? loaded = null;
                        try { if (lt != null) loaded = RevitLinkType.IsLoaded(doc, lt.Id); } catch { }
                        row["geladen"] = loaded;
                        try { row["status"] = lt?.GetLinkedFileStatus().ToString(); } catch { row["status"] = null; }
                        try { row["attachment"] = lt?.AttachmentType.ToString(); } catch { }
                        try { row["genest"] = lt?.IsNestedLink; } catch { }
                        try
                        {
                            var efr = lt?.GetExternalFileReference();
                            row["pad"] = efr == null ? null : ModelPathUtils.ConvertModelPathToUserVisiblePath(efr.GetAbsolutePath());
                        }
                        catch { row["pad"] = null; }
                        try { row["pinned"] = li.Pinned; } catch { }
                        Document? ld = null;
                        try { ld = li.GetLinkDocument(); } catch { }
                        row["linked_document"] = ld?.Title;

                        var t = li.GetTotalTransform();
                        bool ident = t.Origin.GetLength() <= Tol
                                     && t.BasisX.IsAlmostEqualTo(XYZ.BasisX) && t.BasisY.IsAlmostEqualTo(XYZ.BasisY) && t.BasisZ.IsAlmostEqualTo(XYZ.BasisZ);
                        row["transform"] = new Dictionary<string, object?>
                        {
                            ["origin_mm"] = Mm3(t.Origin),
                            ["basis_x"] = Vec(t.BasisX), ["basis_y"] = Vec(t.BasisY), ["basis_z"] = Vec(t.BasisZ),
                            ["rotatie_xy_deg"] = Math.Round(Math.Atan2(t.BasisX.Y, t.BasisX.X) * 180.0 / Math.PI, 4),
                            ["gespiegeld"] = t.HasReflection,
                        };
                        row["origin_op_origin"] = ident;
                    }
                    catch (Exception ex) { row["fout"] = ex.Message; }
                }
                notes.Add("transform = GetTotalTransform: punt_hier = transform.OfPoint(punt_in_link); origin in mm, basisvectoren eenheidsloos");
                notes.Add("origin_op_origin: origin ≤ 1 mm en basisvectoren gelijk aan de eenheidsassen (geen rotatie, geen spiegeling)");
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["aantal"] = rows.Count,
                    ["links"] = rows,
                    ["notes"] = notes,
                };
            }, timeoutMs: 60000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Transacties en failures
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>Warnings weg (DeleteWarning), errors → terugrollen; nooit een modale dialoog.</summary>
    private sealed class StilleFailures : IFailuresPreprocessor
    {
        public readonly List<string> Meldingen = new();
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            bool error = false;
            foreach (var f in fa.GetFailureMessages())
            {
                string desc; try { desc = f.GetDescriptionText(); } catch { desc = "?"; }
                string ids = "";
                try { var fe = f.GetFailingElementIds(); if (fe.Count > 0) ids = " [ids " + string.Join(",", fe.Take(20).Select(x => x.Value)) + "]"; } catch { }
                FailureSeverity sev; try { sev = f.GetSeverity(); } catch { sev = FailureSeverity.Error; }
                if (sev == FailureSeverity.Warning) { Meldingen.Add("warning: " + desc + ids); try { fa.DeleteWarning(f); } catch { } }
                else { Meldingen.Add("error: " + desc + ids); error = true; }
            }
            return error ? FailureProcessingResult.ProceedWithRollBack : FailureProcessingResult.Continue;
        }
    }

    /// <summary>Eén transactie met StilleFailures; RollBack in finally als niet gecommit. Geeft (gecommit, note).</summary>
    private static (bool committed, string? note) RunTx(Document doc, string name, Action body, List<string>? meldingenOut = null)
    {
        var pp = new StilleFailures();
        using var t = new Transaction(doc, name);
        string? note = null;
        bool committed = false;
        try
        {
            var fho = t.GetFailureHandlingOptions();
            fho.SetFailuresPreprocessor(pp);
            fho.SetClearAfterRollback(true);
            fho.SetForcedModalHandling(false);
            t.SetFailureHandlingOptions(fho);
            if (t.Start() != TransactionStatus.Started) return (false, "transactie kon niet starten");
            body();
            var st = t.Commit();
            committed = st == TransactionStatus.Committed;
            if (!committed) note = $"commit-status {st}";
        }
        catch (Exception ex) { note = ex.Message; }
        finally
        {
            try { if (t.HasStarted() && !t.HasEnded()) t.RollBack(); } catch { }
        }
        if (pp.Meldingen.Count > 0)
        {
            meldingenOut?.AddRange(pp.Meldingen);
            if (!committed) note = (note ?? "teruggerold") + "; " + string.Join(" | ", pp.Meldingen.Take(5));
        }
        return (committed, note);
    }

    /// <summary>TransactionGroup om de transacties van één item/run: Assimilate als body true geeft, anders RollBack
    /// (ook in finally). Eén ongedaan-maakstap per item.</summary>
    private static bool RunGroup(Document doc, string name, List<string> notes, Func<bool> body)
    {
        using var g = new TransactionGroup(doc, name);
        bool kept = false;
        try
        {
            if (g.Start() != TransactionStatus.Started) { notes.Add("transactiegroep kon niet starten"); return false; }
            if (body())
            {
                var st = g.Assimilate();
                kept = st == TransactionStatus.Committed;
                if (!kept) notes.Add($"transactiegroep-status {st}");
            }
        }
        catch (Exception ex) { notes.Add(ex.Message); kept = false; }
        finally
        {
            try { if (g.HasStarted() && !g.HasEnded()) g.RollBack(); } catch { }
        }
        return kept;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JSON-helpers
    // ═══════════════════════════════════════════════════════════════════════

    private static double? NumEl(JsonElement el)
    {
        if (el.ValueKind == JsonValueKind.Number) return el.GetDouble();
        if (el.ValueKind == JsonValueKind.String && double.TryParse(el.GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) return d;
        return null;
    }

    private static double? Num(JsonElement o, string key)
        => o.ValueKind == JsonValueKind.Object && o.TryGetProperty(key, out var el) ? NumEl(el) : null;

    private static long? LongProp(JsonElement o, string key)
    {
        if (o.ValueKind != JsonValueKind.Object || !o.TryGetProperty(key, out var el)) return null;
        if (el.ValueKind == JsonValueKind.Number && el.TryGetInt64(out var v)) return v;
        if (el.ValueKind == JsonValueKind.String && long.TryParse(el.GetString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var s)) return s;
        return null;
    }

    private static string Raw(JsonElement v) => v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : v.GetRawText();

    private static double R(double v) => Math.Round(v, 1);

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
}
