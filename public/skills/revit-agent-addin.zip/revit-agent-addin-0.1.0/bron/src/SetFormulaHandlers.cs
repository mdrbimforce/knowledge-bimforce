using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_family_formula — edit / add / clear a formula on a FAMILY parameter.
/// Formulas live only on FamilyManager parameters, so this opens each loadable family (EditFamily),
/// runs SetFormula(param, expr) — or SetFormula(param, null) to clear — in a transaction, then loads the
/// family back. Mirrors couple_builtin_parameter's edit/load cycle (incl. save-first backup gate).
///
/// A formula expression references other parameters by their bare name; Revit validates on SetFormula,
/// so an invalid expression is reported per-edit (status=error) without aborting the batch.
///
/// params:
///   target_document : scope by Title
///   edits : [{family, param_name | guid, formula (null/"" = clear), expected_current?}]
///   dry_run    : bool (default TRUE)
///   save_first : bool (default false) — numbered backup before any LoadFamily overwrite
/// </summary>
public static class SetFormulaHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Project; overwriteParameterValues = true; return true; }   // Project: FamilySource.Family bracht bij herladen de geneste kopieën als dubbel-typen " 1" binnen en verhing exemplaren
    }

    private record FormulaEdit(string Family, string? ParamName, string? Guid, string? Formula, bool Clear, string? Expected);

    public static CommandResponse SetFamilyFormula(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        string? rfaPath = GetString(p, "rfa_path");   // optioneel: family-doc van schijf (Save) i.p.v. EditFamily/LoadFamily; edits.family = bestandsnaam zonder .rfa
        bool dialogOk = GetBool(p, "dialog_ok", false);
        int dialogResult = GetInt(p, "dialog_result", 1);

        var edits = new List<FormulaEdit>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? fam = GetProp(it, "family");
                string? pn = GetProp(it, "param_name");
                string? guid = GetProp(it, "guid");
                string? exp = GetProp(it, "expected_current");
                bool hasFormula = it.TryGetProperty("formula", out var fEl);
                bool clear = hasFormula && (fEl.ValueKind == JsonValueKind.Null
                              || (fEl.ValueKind == JsonValueKind.String && string.IsNullOrWhiteSpace(fEl.GetString())));
                string? formula = (hasFormula && fEl.ValueKind == JsonValueKind.String) ? fEl.GetString() : null;
                if (string.IsNullOrWhiteSpace(fam) || (string.IsNullOrWhiteSpace(pn) && string.IsNullOrWhiteSpace(guid))) continue;
                edits.Add(new FormulaEdit(fam!.Trim(), pn, guid, clear ? null : formula, clear, exp));
            }
        }
        if (edits.Count == 0) return Err("edits:[{family, param_name|guid, formula}] is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, aborted: {ex.Message}"); }
                }

                var byFam = edits.GroupBy(e => e.Family.ToLowerInvariant()).ToDictionary(g => g.Key, g => g.ToList());
                var results = new List<Dictionary<string, object?>>();
                int applied = 0, failed = 0, notfound = 0;

                var fams = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable
                                && byFam.ContainsKey(f.Name.ToLowerInvariant())).ToList();
                bool fromDisk = rfaPath != null;
                if (fromDisk && !System.IO.File.Exists(rfaPath)) return (object)Fail($"rfa_path bestaat niet: {rfaPath}");
                var famsIter = fromDisk ? new List<Family?> { null } : fams.Cast<Family?>().ToList();
                var seen = new HashSet<string>();

                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.BlindResult = dialogResult;
                foreach (var fam in famsIter)
                {
                    string famLabel; try { famLabel = fromDisk ? System.IO.Path.GetFileNameWithoutExtension(rfaPath!) : fam!.Name; } catch { results.Add(new Dictionary<string, object?> { ["family"] = "<ongeldig Family-element>", ["status"] = "error", ["error"] = "Family-element ongeldig (edit-doc open of herladen?)" }); failed++; continue; }
                    var key = famLabel.ToLowerInvariant();
                    if (fromDisk && !byFam.ContainsKey(key)) key = byFam.Keys.First();
                    seen.Add(key);
                    swallow.Context = famLabel;
                    Document? fdoc = null;
                    try
                    {
                        fdoc = fromDisk ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                        var fm = fdoc.FamilyManager;
                        var pending = new List<Dictionary<string, object?>>();
                        bool anyOk = false;
                        using (var t = new Transaction(fdoc, "NLRS set formula"))
                        {
                            t.Start();
                            foreach (var ed in byFam[key])
                            {
                                var info = new Dictionary<string, object?> { ["family"] = famLabel, ["param"] = ed.ParamName ?? ed.Guid };
                                var fp = FindFamilyParam(fm, ed.Guid, ed.ParamName);
                                if (fp == null) { info["status"] = "not_found"; notfound++; pending.Add(info); continue; }
                                string? cur = null; try { cur = fp.Formula; } catch { }
                                info["current_formula"] = cur;
                                info["new_formula"] = ed.Clear ? null : ed.Formula;
                                if (ed.Expected != null && (cur ?? "") != ed.Expected)
                                { info["status"] = "stale_skip"; info["reason"] = $"huidige formule '{cur}' != verwacht '{ed.Expected}'"; pending.Add(info); continue; }
                                if (!fp.CanAssignFormula)
                                { info["status"] = "no_formula_allowed"; info["reason"] = "parameter accepteert geen formule (read-only/bepaald)"; failed++; pending.Add(info); continue; }
                                if (dryRun) { info["status"] = ed.Clear ? "would_clear" : "would_set"; pending.Add(info); continue; }
                                try
                                {
                                    fm.SetFormula(fp, ed.Clear ? null : ed.Formula);
                                    info["status"] = ed.Clear ? "cleared" : "set";
                                    anyOk = true; applied++;
                                }
                                catch (Exception ex) { info["status"] = "error"; info["error"] = ex.Message; failed++; }
                                pending.Add(info);
                            }
                            if (!dryRun && anyOk) t.Commit(); else t.RollBack();
                        }
                        if (!dryRun && anyOk) { if (fromDisk) fdoc.Save(); else fdoc.LoadFamily(doc, new FamLoadOpts()); }
                        results.AddRange(pending);
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        failed++;
                        results.Add(new Dictionary<string, object?> { ["family"] = famLabel, ["status"] = "error", ["error"] = ex.Message });
                        try { fdoc?.Close(false); } catch { }
                    }
                }
                foreach (var kv in byFam)
                    if (!seen.Contains(kv.Key))
                        foreach (var ed in kv.Value)
                        { results.Add(new Dictionary<string, object?> { ["family"] = ed.Family, ["param"] = ed.ParamName ?? ed.Guid, ["status"] = "family_not_found" }); notfound++; }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup,
                    ["applied"] = applied, ["failed"] = failed, ["not_found"] = notfound,
                    ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static FamilyParameter? FindFamilyParam(FamilyManager fm, string? guid, string? name)
    {
        var g = guid?.Trim().ToLowerInvariant();
        foreach (FamilyParameter fp in fm.Parameters)
        {
            if (fp?.Definition == null) continue;
            if (g != null)
            {
                try { if (fp.IsShared && fp.GUID.ToString().ToLowerInvariant() == g) return fp; } catch { }
            }
            else if (name != null && fp.Definition.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return fp;
        }
        return null;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static string? GetProp(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out var v)) return v;
        return dflt;
    }
}
