// Pattern A: Document.Settings collections — global to document, fixed set, no instances.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public static class PatternA_Handlers
{
    public static string ResolveDocumentOwner(Document doc)
    {
        if (doc.IsFamilyDocument)
            return "family:" + doc.Title;
        return "main";
    }

    private static Dictionary<string, object?> ToStub(
        long elementId, string revitClass, string? builtinCategory,
        string name, int? parentId, string owner,
        int? lineWeight = null, string? lineColor = null, string? linePattern = null)
    {
        return new Dictionary<string, object?>
        {
            ["element_id"] = elementId,
            ["revit_class"] = revitClass,
            ["builtin_category"] = builtinCategory,
            ["name"] = name,
            ["parent_id"] = parentId,
            ["document_owner"] = owner,
            ["pattern"] = "A",
            // Line Weight/Color/Pattern: only meaningful for line-style categories,
            // null elsewhere. Projection graphics (the visible line in a normal view), not cut.
            ["line_weight"] = lineWeight,
            ["line_color"] = lineColor,
            ["line_pattern"] = linePattern
        };
    }

    /// <summary>A Category's Projection line weight/colour/pattern, guarded — meaningful only for a
    /// line-style subcategory (OST_Lines); null (not error) for categories that don't carry these.</summary>
    private static (int? weight, string? color, string? pattern) LineStyleGraphics(Document doc, Category cat)
    {
        int? weight = null; string? color = null; string? pattern = null;
        try { weight = cat.GetLineWeight(GraphicsStyleType.Projection); } catch { }
        try
        {
            var c = cat.LineColor;
            if (c != null && c.IsValid) color = $"{c.Red},{c.Green},{c.Blue}";
        }
        catch { }
        try
        {
            var pid = cat.GetLinePatternId(GraphicsStyleType.Projection);
            if (pid != null && pid != ElementId.InvalidElementId)
                pattern = doc.GetElement(pid)?.Name;
            else if (pid == ElementId.InvalidElementId)
                pattern = "Solid";  // Revit's own sentinel for the built-in solid pattern
        }
        catch { }
        return (weight, color, pattern);
    }

    public static List<Dictionary<string, object?>> GetObjectStyles(Document doc, string? parentCategoryFilter = null)
    {
        var owner = ResolveDocumentOwner(doc);
        var result = new List<Dictionary<string, object?>>();

        if (parentCategoryFilter != null)
        {
            var bic = (BuiltInCategory)System.Enum.Parse(typeof(BuiltInCategory), parentCategoryFilter);
            var parent = doc.Settings.Categories.get_Item(bic);
            if (parent == null) return result;
            foreach (Category sub in parent.SubCategories)
            {
                var (w, c, p) = LineStyleGraphics(doc, sub);
                result.Add(ToStub(RevitIdUtil.Fid(sub.Id), "Category", ((BuiltInCategory)sub.Id.Value).ToString(),
                    sub.Name, RevitIdUtil.Fid(parent.Id), owner, w, c, p));
            }
            return result;
        }

        foreach (Category cat in doc.Settings.Categories)
            result.Add(ToStub(RevitIdUtil.Fid(cat.Id), "Category", ((BuiltInCategory)cat.Id.Value).ToString(), cat.Name, cat.Parent != null ? RevitIdUtil.Fid(cat.Parent.Id) : (int?)null, owner));
        return result;
    }

    public static List<Dictionary<string, object?>> GetLineStyles(Document doc)
    {
        return GetObjectStyles(doc, "OST_Lines");
    }

    public static List<Dictionary<string, object?>> GetPhases(Document doc)
    {
        var owner = ResolveDocumentOwner(doc);
        return doc.Phases.Cast<Phase>().Select(phase =>
            ToStub(RevitIdUtil.Fid(phase.Id), "Phase", null, phase.Name, null, owner)).ToList();
    }

    public static List<Dictionary<string, object?>> GetWorksets(Document doc)
    {
        var owner = ResolveDocumentOwner(doc);
        var collector = new FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset);
        return collector.Select(ws =>
            ToStub(ws.Id.IntegerValue, "Workset", null, ws.Name, null, owner)).ToList();
    }

    public static List<Dictionary<string, object?>> GetProjectBasePoint(Document doc)
    {
        var owner = ResolveDocumentOwner(doc);
        return new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_ProjectBasePoint)
            .WhereElementIsNotElementType()
            .Select(e => e as BasePoint)
            .Where(bp => bp != null)
            .Select(bp => ToStub(RevitIdUtil.Fid(bp!.Id), "BasePoint",
                BuiltInCategory.OST_ProjectBasePoint.ToString(), bp!.Name, null, owner))
            .ToList();
    }

    public static List<Dictionary<string, object?>> GetSurveyPoint(Document doc)
    {
        var owner = ResolveDocumentOwner(doc);
        return new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_SharedBasePoint)
            .WhereElementIsNotElementType()
            .Select(e => e as BasePoint)
            .Where(bp => bp != null)
            .Select(bp => ToStub(RevitIdUtil.Fid(bp!.Id), "BasePoint",
                BuiltInCategory.OST_SharedBasePoint.ToString(), bp!.Name, null, owner))
            .ToList();
    }

    public static Dictionary<string, object?> GetObjectStyleDetail(Document doc, long elementId)
    {
        var owner = ResolveDocumentOwner(doc);
        var targetId = new ElementId((long)elementId);
        Category? cat = null;
        foreach (Category c in doc.Settings.Categories)
        {
            if (c.Id.Value == targetId.Value)
            { cat = c; break; }
        }
        if (cat == null)
            throw new ElementNotFoundException($"Category {elementId} not found");

        var subCats = cat.SubCategories;
        var subCount = 0;
        foreach (Category _ in subCats) subCount++;

        int[]? rgb = null;
        try
        {
            var c = cat.LineColor;
            if (c != null && c.IsValid)
                rgb = new[] { (int)c.Red, (int)c.Green, (int)c.Blue };
        }
        catch { }

        int? linePatternId = null;
        try
        {
            var lp = cat.GetLinePatternId(GraphicsStyleType.Projection);
            if (lp != null && lp.Value > 0)
                linePatternId = RevitIdUtil.Fid(lp);
        }
        catch { }

        int? matId = null;
        try { matId = cat.Material != null ? RevitIdUtil.Fid(cat.Material.Id) : (int?)null; } catch { }

        int? lineWeightProj = null, lineWeightCut = null;
        try { lineWeightProj = cat.GetLineWeight(GraphicsStyleType.Projection); } catch { }
        try { lineWeightCut = cat.GetLineWeight(GraphicsStyleType.Cut); } catch { }

        return new Dictionary<string, object?>
        {
            ["stub"] = ToStub(RevitIdUtil.Fid(cat.Id), "Category", ((BuiltInCategory)cat.Id.Value).ToString(), cat.Name,
                cat.Parent != null ? RevitIdUtil.Fid(cat.Parent.Id) : (int?)null, owner),
            ["metadata"] = new Dictionary<string, object?>
            {
                ["revit_version_introduced"] = null,
                ["revit_version_deprecated"] = null,
                ["is_system_family"] = true,
                ["is_in_place"] = false
            },
            ["properties"] = new Dictionary<string, object?>
            {
                ["category_type"] = cat.CategoryType.ToString(),
                ["is_subcategory"] = cat.Parent != null,
                ["line_weight_projection"] = lineWeightProj,
                ["line_weight_cut"] = lineWeightCut,
                ["line_color_rgb"] = rgb,
                ["line_pattern_id"] = linePatternId,
                ["line_pattern_label"] = linePatternId == null ? "<Solid>" : null,
                ["material_id"] = matId,
                ["allows_subcategories"] = subCount > 0,
                ["subcategory_count"] = subCount
            },
            ["relationships"] = new List<Dictionary<string, object?>>
            {
                new() { ["kind"] = "parent",
                        ["role"] = null,
                        ["ref"] = cat.Parent != null
                            ? new Dictionary<string, object?> { ["element_id"] = RevitIdUtil.Fid(cat.Parent.Id), ["revit_class"] = "Category" }
                            : null },
                new() { ["kind"] = "uses_line_pattern",
                        ["role"] = null,
                        ["ref"] = linePatternId != null
                            ? new Dictionary<string, object?> { ["element_id"] = linePatternId, ["revit_class"] = "LinePatternElement" }
                            : null },
                new() { ["kind"] = "uses_material",
                        ["role"] = null,
                        ["ref"] = matId != null
                            ? new Dictionary<string, object?> { ["element_id"] = matId, ["revit_class"] = "Material" }
                            : null }
            }
        };
    }

    public static List<Dictionary<string, object?>> Query(string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        if (typeId == "object_styles")
        {
            var filter = extraParams?.TryGetValue("parent_category_filter", out var pf) == true
                ? pf.GetString() : null;
            return GetObjectStyles(doc, filter);
        }
        return typeId switch
        {
            "line_styles" => GetLineStyles(doc),
            "phases" => GetPhases(doc),
            "worksets" => GetWorksets(doc),
            "project_base_point" => GetProjectBasePoint(doc),
            "survey_point" => GetSurveyPoint(doc),
            _ => throw new System.ArgumentException($"Unknown Pattern-A type: {typeId}")
        };
    }

    public static Dictionary<string, object?> Detail(string typeId, Document doc, long elementId) => typeId switch
    {
        "object_styles" => GetObjectStyleDetail(doc, elementId),
        "line_styles" => GetObjectStyleDetail(doc, elementId),
        "project_base_point" => GetBasePointDetail(doc, elementId),
        "survey_point" => GetBasePointDetail(doc, elementId),
        _ => throw new System.NotImplementedException($"Pattern A detail for {typeId} not yet implemented")
    };

    // ── Detail helpers ─────────────────────────────────────────

    private static int? BpFid(ElementId? id) => id != null && id.Value != 0 ? RevitIdUtil.Fid(id) : null;

    private static Dictionary<string, object?> GetBasePointDetail(Document doc, long elementId)
    {
        var bp = doc.GetElement(new ElementId((long)elementId)) as BasePoint;
        if (bp == null)
            throw new ElementNotFoundException($"BasePoint {elementId} not found");

        var owner = ResolveDocumentOwner(doc);
        var bic = bp.Category?.Id.Value != null
            ? ((BuiltInCategory)RevitIdUtil.Fid(bp.Category.Id)).ToString() : null;

        double FtToMm(double ft) => Math.Round(ft * 304.8, 1);
        double RadToDeg(double rad) => Math.Round(rad * 180.0 / Math.PI, 4);

        return new Dictionary<string, object?>
        {
            ["stub"] = ToStub(RevitIdUtil.Fid(bp.Id), "BasePoint", bic, bp.Name, null, owner),
            ["metadata"] = new Dictionary<string, object?>
            {
                ["revit_version_introduced"] = null,
                ["revit_version_deprecated"] = null,
                ["is_system_family"] = true,
                ["is_in_place"] = false
            },
            ["properties"] = new Dictionary<string, object?>
            {
                ["is_shared"] = bp.IsShared,
                ["elevation_mm"] = FtToMm(GetBpParam(bp, BuiltInParameter.BASEPOINT_ELEVATION_PARAM)),
                ["position_x_mm"] = FtToMm(bp.Position.X),
                ["position_y_mm"] = FtToMm(bp.Position.Y),
                ["position_z_mm"] = FtToMm(bp.Position.Z),
                ["east_west_mm"] = FtToMm(GetBpParam(bp, BuiltInParameter.BASEPOINT_EASTWEST_PARAM)),
                ["north_south_mm"] = FtToMm(GetBpParam(bp, BuiltInParameter.BASEPOINT_NORTHSOUTH_PARAM)),
                ["angle_to_north_deg"] = RadToDeg(GetBpParam(bp, BuiltInParameter.BASEPOINT_ANGLETON_PARAM))
            },
            ["relationships"] = new List<Dictionary<string, object?>>
            {
                new() { ["kind"] = "parent",
                        ["role"] = null,
                        ["ref"] = bp.Category != null
                            ? new Dictionary<string, object?> { ["element_id"] = RevitIdUtil.Fid(bp.Category.Id), ["revit_class"] = "Category" }
                            : null }
            }
        };
    }

    private static double GetBpParam(BasePoint bp, BuiltInParameter bip)
    {
        try { return bp.get_Parameter(bip)?.AsDouble() ?? 0; }
        catch { return 0; }
    }
}
