using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_line_style_graphics — write line-style graphics. A line style is a
/// SUBCATEGORY of OST_Lines: the manage-workbook's element_id is the CATEGORY id, not an Element id,
/// so set_parameter_value can't reach it. This command goes through the Category API instead:
/// SetLineWeight(Projection), LineColor, SetLinePatternId(Projection).
///
/// Value formats mirror the manage-workbook read columns (PatternA LineStyleGraphics):
///   line_weight  1-16 (int)
///   line_color   "R,G,B" (bv "0,0,0")
///   line_pattern LinePatternElement name; "Solid" = Revit's built-in sentinel (InvalidElementId)
///
/// expected_name is the stale-id guard (same convention as rename_element): the live subcategory name
/// must still match the sheet's column A or the edit is skipped as stale instead of hitting the wrong
/// style. dry_run (default) reports current -> new without mutating; save_first writes a backup first.
///
/// params: target_document, edits:[{category_id, expected_name?, line_weight?, line_color?, line_pattern?}],
///         dry_run (default TRUE), save_first (default false).
/// </summary>
public static class SetLineStyleHandlers
{
    private record Edit(long CategoryId, string? ExpectedName, int? LineWeight, string? LineColor, string? LinePattern);

    public static CommandResponse SetLineStyleGraphics(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        var edits = ParseEdits(p);
        if (edits.Count == 0)
            return new CommandResponse { Success = false, Error = "edits required: [{category_id, line_weight|line_color|line_pattern}]" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)new Dictionary<string, object?> { ["error"] = "no matching open document", ["ok"] = false };

                // OST_Lines subcategories indexed by category id (the workbook key).
                var byId = new Dictionary<long, Category>();
                var lines = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines);
                if (lines != null)
                    foreach (Category sub in lines.SubCategories)
                        byId[sub.Id.Value] = sub;

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)new Dictionary<string, object?> { ["error"] = $"save-first backup failed, set aborted: {ex.Message}", ["ok"] = false }; }
                }

                var results = new List<Dictionary<string, object?>>();
                Transaction? t = null;
                if (!dryRun) { t = new Transaction(doc, "NLRS set line style graphics"); t.Start(); }
                try
                {
                    foreach (var e in edits)
                        results.Add(ApplyOne(doc, byId, e, dryRun));
                    t?.Commit();
                }
                catch
                {
                    try { t?.RollBack(); } catch { }
                    throw;
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["saved_backup"] = savedBackup,
                    ["set"] = results.Count(r => (string?)r.GetValueOrDefault("status") == "set"),
                    ["failed"] = results.Count(r => ((string?)r.GetValueOrDefault("status") ?? "").Contains("fail")
                                                    || (string?)r.GetValueOrDefault("status") == "error"),
                    ["results"] = results,
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> ApplyOne(Document doc, Dictionary<long, Category> byId, Edit e, bool dryRun)
    {
        if (!byId.TryGetValue(e.CategoryId, out var cat))
            return Res(e, null, "not_found", "geen OST_Lines-subcategorie met dit category_id");
        if (!string.IsNullOrWhiteSpace(e.ExpectedName) && !string.Equals(cat.Name, e.ExpectedName, StringComparison.Ordinal))
            return Res(e, cat.Name, "stale", $"live naam '{cat.Name}' != verwacht '{e.ExpectedName}'");

        var planned = new Dictionary<string, object?>();
        var errors = new List<string>();

        // line_weight
        if (e.LineWeight.HasValue)
        {
            int? cur = null; try { cur = cat.GetLineWeight(GraphicsStyleType.Projection); } catch { }
            planned["line_weight"] = new Dictionary<string, object?> { ["current"] = cur, ["new"] = e.LineWeight.Value };
            if (!dryRun)
            {
                try { cat.SetLineWeight(e.LineWeight.Value, GraphicsStyleType.Projection); }
                catch (Exception ex) { errors.Add($"line_weight: {ex.Message}"); }
            }
        }

        // line_color "R,G,B"
        if (!string.IsNullOrWhiteSpace(e.LineColor))
        {
            var rgb = ParseRgb(e.LineColor!);
            string? cur = null;
            try { var c = cat.LineColor; if (c != null && c.IsValid) cur = $"{c.Red},{c.Green},{c.Blue}"; } catch { }
            planned["line_color"] = new Dictionary<string, object?> { ["current"] = cur, ["new"] = e.LineColor };
            if (rgb == null)
                errors.Add($"line_color: '{e.LineColor}' is geen 'R,G,B' (bv 0,0,0)");
            else if (!dryRun)
            {
                try { cat.LineColor = new Color(rgb[0], rgb[1], rgb[2]); }
                catch (Exception ex) { errors.Add($"line_color: {ex.Message}"); }
            }
        }

        // line_pattern by name ("Solid" = built-in sentinel)
        if (!string.IsNullOrWhiteSpace(e.LinePattern))
        {
            string? cur = null;
            try
            {
                var pid = cat.GetLinePatternId(GraphicsStyleType.Projection);
                cur = pid == ElementId.InvalidElementId ? "Solid" : doc.GetElement(pid)?.Name;
            }
            catch { }
            planned["line_pattern"] = new Dictionary<string, object?> { ["current"] = cur, ["new"] = e.LinePattern };
            ElementId? patId = null;
            if (string.Equals(e.LinePattern!.Trim(), "Solid", StringComparison.OrdinalIgnoreCase))
                patId = LinePatternElement.GetSolidPatternId();
            else
                patId = new FilteredElementCollector(doc).OfClass(typeof(LinePatternElement)).Cast<LinePatternElement>()
                    .FirstOrDefault(lp => lp.Name.Equals(e.LinePattern!.Trim(), StringComparison.OrdinalIgnoreCase))?.Id;
            if (patId == null)
                errors.Add($"line_pattern: geen LinePatternElement met naam '{e.LinePattern}'");
            else if (!dryRun)
            {
                try { cat.SetLinePatternId(patId, GraphicsStyleType.Projection); }
                catch (Exception ex) { errors.Add($"line_pattern: {ex.Message}"); }
            }
        }

        string status = errors.Count > 0 ? "failed" : (dryRun ? "would_set" : "set");
        return Res(e, cat.Name, status, errors.Count > 0 ? string.Join("; ", errors) : null, planned);
    }

    private static byte[]? ParseRgb(string s)
    {
        var parts = s.Split(',');
        if (parts.Length != 3) return null;
        var outv = new byte[3];
        for (int i = 0; i < 3; i++)
        {
            if (!byte.TryParse(parts[i].Trim(), out outv[i])) return null;
        }
        return outv;
    }

    private static Dictionary<string, object?> Res(Edit e, string? name, string status, string? err,
                                                   Dictionary<string, object?>? planned = null) => new()
    {
        ["category_id"] = e.CategoryId,
        ["name"] = name,
        ["status"] = status,
        ["error"] = err ?? "",
        ["planned"] = planned,
    };

    private static List<Edit> ParseEdits(Dictionary<string, JsonElement>? p)
    {
        var outl = new List<Edit>();
        if (p == null || !p.TryGetValue("edits", out var arr) || arr.ValueKind != JsonValueKind.Array) return outl;
        foreach (var item in arr.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.Object) continue;
            long? cid = null;
            if (item.TryGetProperty("category_id", out var cel))
            {
                if (cel.ValueKind == JsonValueKind.Number) cid = cel.GetInt64();
                else if (cel.ValueKind == JsonValueKind.String && long.TryParse(cel.GetString(), out var cparsed)) cid = cparsed;
            }
            if (cid == null) continue;
            string? expected = item.TryGetProperty("expected_name", out var eel) && eel.ValueKind == JsonValueKind.String ? eel.GetString() : null;
            int? lw = null;
            if (item.TryGetProperty("line_weight", out var wel))
            {
                if (wel.ValueKind == JsonValueKind.Number) lw = wel.GetInt32();
                else if (wel.ValueKind == JsonValueKind.String && int.TryParse(wel.GetString(), out var wparsed)) lw = wparsed;
            }
            string? lc = item.TryGetProperty("line_color", out var lel) && lel.ValueKind == JsonValueKind.String ? lel.GetString() : null;
            string? lp = item.TryGetProperty("line_pattern", out var pel) && pel.ValueKind == JsonValueKind.String ? pel.GetString() : null;
            if (lw == null && string.IsNullOrWhiteSpace(lc) && string.IsNullOrWhiteSpace(lp)) continue;
            outl.Add(new Edit(cid.Value, expected, lw, lc, lp));
        }
        return outl;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
