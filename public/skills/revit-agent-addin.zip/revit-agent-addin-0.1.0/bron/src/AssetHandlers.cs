using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// asset_rename + asset_swap — manage material ASSETS from the Material Assets tab.
/// Appearance assets are AppearanceAssetElement; thermal/physical assets are PropertySetElement (told
/// apart by GetThermalAsset/GetStructuralAsset). An asset is shared across materials, so a rename is
/// global (deduped per kind+name). A swap repoints ONE material's slot (Appearance/Thermal/Structural)
/// to a different existing asset, found by name. Both dry-run by default with a save-first backup gate.
/// </summary>
public static class AssetHandlers
{
    private record RenameEdit(string Kind, string Current, string New, string? Expected);
    private record SwapEdit(long? MaterialId, string? MaterialName, string Kind, string TargetAsset);

    // ── asset_rename: edits:[{kind, current_name, new_name}] ──
    public static CommandResponse AssetRename(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);

        var edits = new List<RenameEdit>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? kind = GetProp(it, "kind"); string? cur = GetProp(it, "current_name"); string? nw = GetProp(it, "new_name");
                if (string.IsNullOrWhiteSpace(kind) || string.IsNullOrWhiteSpace(cur) || string.IsNullOrWhiteSpace(nw)) continue;
                edits.Add(new RenameEdit(kind!.Trim(), cur!.Trim(), nw!.Trim(), GetProp(it, "expected")));
            }
        if (edits.Count == 0) return Err("edits:[{kind, current_name, new_name}] is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = ResolveDoc(app, target);
                if (doc == null) return (object)Fail("no matching open document");
                bool savedBackup = false;
                if (!dryRun && saveFirst)
                { try { doc.Save(); savedBackup = true; } catch (Exception ex) { return (object)Fail($"save-first failed, aborted: {ex.Message}"); } }

                var results = new List<Dictionary<string, object?>>();
                var seen = new HashSet<string>();
                Transaction? t = null;
                if (!dryRun) { t = new Transaction(doc, "NLRS asset rename"); t.Start(); }
                foreach (var e in edits)
                {
                    if (!seen.Add((e.Kind + "|" + e.Current).ToLowerInvariant())) continue;  // asset is gedeeld -> dedup
                    var row = new Dictionary<string, object?> { ["kind"] = e.Kind, ["current"] = e.Current, ["new"] = e.New };
                    var asset = FindAsset(doc, e.Kind, e.Current);
                    if (asset == null) { row["status"] = "not_found"; results.Add(row); continue; }
                    if (dryRun) { row["status"] = "would_rename"; results.Add(row); continue; }
                    try { asset.Name = e.New; row["status"] = "renamed"; }
                    catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                    results.Add(row);
                }
                t?.Commit();
                return (object)new Dictionary<string, object?>
                { ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup, ["results"] = results };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    // ── asset_swap: edits:[{material_id|material_name, kind, target_asset}] ──
    public static CommandResponse AssetSwap(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);

        var edits = new List<SwapEdit>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                long? mid = it.TryGetProperty("material_id", out var me) && me.ValueKind == JsonValueKind.Number ? me.GetInt64() : (long?)null;
                string? mn = GetProp(it, "material_name"); string? kind = GetProp(it, "kind"); string? tgt = GetProp(it, "target_asset");
                if (string.IsNullOrWhiteSpace(kind) || string.IsNullOrWhiteSpace(tgt) || (mid == null && string.IsNullOrWhiteSpace(mn))) continue;
                edits.Add(new SwapEdit(mid, mn, kind!.Trim(), tgt!.Trim()));
            }
        if (edits.Count == 0) return Err("edits:[{material_id|material_name, kind, target_asset}] is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = ResolveDoc(app, target);
                if (doc == null) return (object)Fail("no matching open document");
                var mats = new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>().ToList();
                bool savedBackup = false;
                if (!dryRun && saveFirst)
                { try { doc.Save(); savedBackup = true; } catch (Exception ex) { return (object)Fail($"save-first failed, aborted: {ex.Message}"); } }

                var results = new List<Dictionary<string, object?>>();
                Transaction? t = null;
                if (!dryRun) { t = new Transaction(doc, "NLRS asset swap"); t.Start(); }
                foreach (var e in edits)
                {
                    var row = new Dictionary<string, object?> { ["material"] = (object?)e.MaterialName ?? e.MaterialId, ["kind"] = e.Kind, ["target"] = e.TargetAsset };
                    Material? mat = e.MaterialId != null ? mats.FirstOrDefault(m => m.Id.Value == e.MaterialId)
                                                         : mats.FirstOrDefault(m => m.Name.Equals(e.MaterialName, StringComparison.OrdinalIgnoreCase));
                    if (mat == null) { row["status"] = "material_not_found"; results.Add(row); continue; }
                    var asset = FindAsset(doc, e.Kind, e.TargetAsset);
                    if (asset == null) { row["status"] = "target_asset_not_found"; results.Add(row); continue; }
                    if (dryRun) { row["status"] = "would_swap"; results.Add(row); continue; }
                    try
                    {
                        var k = e.Kind.ToLowerInvariant();
                        if (k.StartsWith("app")) mat.AppearanceAssetId = asset.Id;
                        else if (k.StartsWith("therm")) mat.ThermalAssetId = asset.Id;
                        else mat.StructuralAssetId = asset.Id;
                        row["status"] = "swapped";
                    }
                    catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                    results.Add(row);
                }
                t?.Commit();
                return (object)new Dictionary<string, object?>
                { ["document"] = doc.Title, ["dry_run"] = dryRun, ["saved_backup"] = savedBackup, ["results"] = results };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Element? FindAsset(Document doc, string kind, string name)
    {
        var k = kind.ToLowerInvariant();
        if (k.StartsWith("app"))
        {
            foreach (var a in new FilteredElementCollector(doc).OfClass(typeof(AppearanceAssetElement)).Cast<AppearanceAssetElement>())
                if (a.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return a;
            return null;
        }
        bool wantThermal = k.StartsWith("therm");
        foreach (var a in new FilteredElementCollector(doc).OfClass(typeof(PropertySetElement)).Cast<PropertySetElement>())
        {
            if (!a.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) continue;
            try { if (wantThermal ? a.GetThermalAsset() != null : a.GetStructuralAsset() != null) return a; }
            catch { return a; }  // sommige sets gooien -> accepteer op naam
        }
        return null;
    }

    private static Document? ResolveDoc(Autodesk.Revit.UI.UIApplication app, string? target)
    {
        foreach (Document d in app.Application.Documents)
        { if (target != null && d.Title != target) continue; return d; }
        return null;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static string? GetProp(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
