using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// couple_builtin_parameter — the last open swap variant. Built-in parameters
/// have no GUID, are not in the NLRS list and CANNOT be deleted, so the add->copy->delete swap does
/// not fit. Instead, inside a loadable family we ADD an NLRS shared parameter and SET its formula to
/// reference the built-in (e.g. formula "Width"), so the NLRS param LIVE-MIRRORS the built-in value
/// without touching it. Formulas exist only on FAMILY parameters (FamilyManager) — hence this is a
/// family-level path. Project-level / system-family built-ins have no live formula coupling; for those
/// the one-time value-copy via swap_parameter (--source-builtin + categories) is the strategy.
///
/// Core primitive (in a famDoc transaction): fm.AddParameter(externalDefinition, group, isInstance);
/// fm.SetFormula(newParam, sourceParamName). The new param mirrors the source's instance/type-ness so
/// the formula reference is valid (a type-param formula may not reference an instance-param).
///
/// Workflow per family: projectDoc.EditFamily -> famDoc; AddParameter + SetFormula in a transaction;
/// LoadFamily back (overwrite); close. SharedParametersFilename is repointed to the NLRS .txt for the
/// ExternalDefinition and restored afterwards. Dry-run (default) reports per family: built-in found,
/// instance/type, source/target spec + compatibility, name collision, and the formula it would set.
///
/// params:
///   source_name   : the built-in (or any) family-parameter to mirror, by name (built-ins have no GUID)
///   source_guid   : optional — mirror a shared family parameter instead (by GUID)
///   target_guid   : canonical NLRS shared parameter (GUID) to add + formula-couple
///   shared_param_file : NLRS .txt (required — source of the target ExternalDefinition)
///   families      : [string] family names to process (else needs scan_all)
///   scan_all      : bool — process ALL editable loadable families (expensive: opens each)
///   target_document : scope by doc Title
///   dry_run       : bool (default TRUE)
///   save_first    : bool (default false) — numbered backup before any LoadFamily overwrite
/// </summary>
public static class CoupleBuiltinHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }

    public static CommandResponse CoupleBuiltinParameter(CommandRequest request)
    {
        var p = request.Params;
        string? sourceName = GetString(p, "source_name");
        string? sourceGuid = GetString(p, "source_guid");
        string? targetGuid = GetString(p, "target_guid");
        string? sharedParamFile = GetString(p, "shared_param_file");
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool scanAll = GetBool(p, "scan_all", false);
        var famWhitelist = GetStringList(p, "families");

        if (string.IsNullOrWhiteSpace(targetGuid))
            return Err("target_guid is required");
        if (string.IsNullOrWhiteSpace(sourceName) && string.IsNullOrWhiteSpace(sourceGuid))
            return Err("provide source_name (built-in/family param) or source_guid (shared)");
        if (string.IsNullOrWhiteSpace(sharedParamFile))
            return Err("shared_param_file is required (the NLRS .txt holding the target ExternalDefinition)");
        if ((famWhitelist == null || famWhitelist.Count == 0) && !scanAll)
            return Err("provide 'families' (names) or set scan_all=true (opens every editable family — slow)");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");
                if (!System.IO.File.Exists(sharedParamFile)) return (object)Fail($"shared_param_file not found: {sharedParamFile}");

                string? prevSpf = app.Application.SharedParametersFilename;
                try
                {
                    app.Application.SharedParametersFilename = sharedParamFile;
                    var extDef = FindExternalDefinition(app.Application, targetGuid!);
                    if (extDef == null) return (object)Fail($"target GUID {targetGuid} not in shared_param_file");
                    string targetSpec = extDef.GetDataType().TypeId;

                    // save-first backup gate (mirrors the other mutating handlers): one numbered backup
                    // of the pre-couple project before any LoadFamily overwrite, so it's recoverable.
                    bool savedBackup = false;
                    if (!dryRun && GetBool(p, "save_first", false))
                    {
                        try { doc.Save(); savedBackup = true; }
                        catch (Exception ex) { return (object)Fail($"save-first backup failed, couple aborted: {ex.Message}"); }
                    }

                    var fams = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                        .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable);
                    if (famWhitelist != null && famWhitelist.Count > 0)
                    {
                        var want = famWhitelist.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                        fams = fams.Where(f => want.Contains(f.Name.ToLowerInvariant()));
                    }

                    var perFamily = new List<Dictionary<string, object?>>();
                    int processed = 0, coupled = 0, notfound = 0, skipped = 0, failed = 0;

                    foreach (var fam in fams.ToList())
                    {
                        processed++;
                        Document? fdoc = null;
                        try
                        {
                            fdoc = doc.EditFamily(fam);
                            var fm = fdoc.FamilyManager;
                            FamilyParameter? src = FindFamilyParam(fm, sourceGuid, sourceName);
                            var info = new Dictionary<string, object?> { ["family"] = fam.Name };

                            if (src == null) { info["action"] = "not_found"; notfound++; perFamily.Add(info); fdoc.Close(false); continue; }

                            string srcName = src.Definition.Name;
                            string srcSpec = src.Definition.GetDataType().TypeId;
                            bool srcShared = false; try { srcShared = src.IsShared; } catch { }
                            bool specCompatible = srcSpec == targetSpec;
                            bool nameCollision = false;
                            foreach (FamilyParameter fp in fm.Parameters)
                                if (fp?.Definition != null && fp.Definition.Name == extDef.Name) { nameCollision = true; break; }
                            // Revit formulas reference a parameter by its bare name (no brackets).
                            string formula = srcName;

                            info["source_param"] = srcName;
                            info["source_is_shared"] = srcShared;
                            info["is_instance"] = src.IsInstance;
                            info["source_spec"] = srcSpec;
                            info["target_spec"] = targetSpec;
                            info["spec_compatible"] = specCompatible;
                            info["name_collision"] = nameCollision;
                            info["formula_to_set"] = formula;

                            if (nameCollision) { info["action"] = "already_present"; skipped++; perFamily.Add(info); fdoc.Close(false); continue; }
                            if (!specCompatible) { info["action"] = "spec_mismatch"; failed++; perFamily.Add(info); fdoc.Close(false); continue; }

                            if (dryRun) { info["action"] = "would_couple"; perFamily.Add(info); fdoc.Close(false); continue; }

                            // EXECUTE: AddParameter (group mirrors the source) + SetFormula, then load back.
                            bool ok;
                            using (var t = new Transaction(fdoc, "NLRS couple built-in"))
                            {
                                t.Start();
                                try
                                {
                                    var grp = src.Definition.GetGroupTypeId();
                                    var np = fm.AddParameter(extDef, grp, src.IsInstance);
                                    fm.SetFormula(np, formula);
                                    ok = true;
                                }
                                catch (Exception ex) { info["error"] = ex.Message; ok = false; }
                                if (ok) t.Commit(); else t.RollBack();
                            }
                            if (ok)
                            {
                                fdoc.LoadFamily(doc, new FamLoadOpts());
                                coupled++;
                                info["action"] = "coupled";
                            }
                            else { failed++; info["action"] = "failed"; }
                            perFamily.Add(info);
                            fdoc.Close(false);
                        }
                        catch (Exception ex)
                        {
                            failed++;
                            perFamily.Add(new Dictionary<string, object?> { ["family"] = fam.Name, ["action"] = "error", ["error"] = ex.Message });
                            try { fdoc?.Close(false); } catch { }
                        }
                    }

                    return (object)new Dictionary<string, object?>
                    {
                        ["document"] = doc.Title,
                        ["dry_run"] = dryRun,
                        ["saved_backup"] = savedBackup,
                        ["target"] = new Dictionary<string, object?> { ["guid"] = targetGuid, ["name"] = extDef.Name, ["spec"] = targetSpec },
                        ["families_scanned"] = processed,
                        ["coupled"] = coupled, ["not_found"] = notfound, ["skipped_collision"] = skipped, ["failed"] = failed,
                        ["results"] = perFamily,
                    };
                }
                finally { try { app.Application.SharedParametersFilename = prevSpf; } catch { } }
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── helpers (self-contained, mirroring SwapFamilyHandlers) ───────────

    private static FamilyParameter? FindFamilyParam(FamilyManager fm, string? guid, string? name)
    {
        var g = guid?.Trim().ToLowerInvariant();
        foreach (FamilyParameter fp in fm.Parameters)
        {
            if (fp?.Definition == null) continue;
            if (g != null)
            {
                try { if (fp.IsShared && fp.GUID.ToString().ToLowerInvariant() == g) return fp; } catch { }
            }
            else if (name != null && fp.Definition.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return fp;
        }
        return null;
    }

    private static ExternalDefinition? FindExternalDefinition(Autodesk.Revit.ApplicationServices.Application app, string guid)
    {
        var g = guid.Trim().ToLowerInvariant();
        DefinitionFile? df;
        try { df = app.OpenSharedParameterFile(); } catch { return null; }
        if (df == null) return null;
        foreach (DefinitionGroup grp in df.Groups)
            foreach (Definition d in grp.Definitions)
                if (d is ExternalDefinition ed)
                {
                    try { if (ed.GUID.ToString().ToLowerInvariant() == g) return ed; } catch { }
                }
        return null;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                     .Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        return null;
    }
}
