using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;

namespace RevitAgent.Addin;

/// <summary>
/// Dialoogbewaker voor één bridge-opdracht (EditFamily, LoadFamily, bouwen, links herladen).
///
/// Binnen de scope drukt hij elke TaskDialog en MessageBox weg met OK en onthoudt hij wat hij zag.
/// Een dialoog zonder tekst (een gewone Revit-dialoog) drukt hij alleen weg als BlindOkForTextless
/// aan staat, met BlindResult als antwoord. Bewaar-dialogen ("Save") laat hij altijd staan: die zijn
/// van de gebruiker. Het verslag komt in het antwoord van de opdracht (WriteTo / NotableReport),
/// zodat de assistent kan melden wat er is weggeklikt.
///
/// Gebruik:  using var bewaker = new DialogSwallowScope(app) { Context = "load_family" };
///           ... werk ...
///           bewaker.WriteTo(resultaat);
/// </summary>
public sealed class DialogSwallowScope : IDisposable
{
    private static int _actief;
    /// <summary>True zolang er ergens een scope open is; de globale handler laat de dialoog dan aan de scope.</summary>
    public static bool IsActive => Volatile.Read(ref _actief) > 0;

    /// <summary>
    /// Dialogen met keuzeknoppen (command links) waar OK niet het goede antwoord is.
    /// 1001 = eerste keuze, 1002 = tweede keuze (TaskDialogResult.CommandLink1/2).
    /// </summary>
    private static readonly Dictionary<string, int> BekendeAntwoorden = new(StringComparer.OrdinalIgnoreCase)
    {
        ["TaskDialog_Unresolved_References"] = 1002,          // "Ignore and continue opening the project"
        ["TaskDialog_Missing_Third_Party_Updaters"] = 1001,   // "Continue working with the file"
    };

    private readonly UIApplication _app;
    private readonly List<Dictionary<string, object?>> _weggedrukt = new();
    private readonly List<Dictionary<string, object?>> _laten = new();
    private bool _klaar;

    /// <summary>Waar de assistent mee bezig was (familienaam, opdracht met volgnummer); komt in het verslag.</summary>
    public string? Context { get; set; }
    /// <summary>Ook dialogen zonder tekst wegdrukken (standaard uit).</summary>
    public bool BlindOkForTextless { get; set; }
    /// <summary>Antwoordcode voor een dialoog zonder tekst (1 = OK).</summary>
    public int BlindResult { get; set; } = 1;

    public DialogSwallowScope(UIApplication app)
    {
        _app = app;
        Interlocked.Increment(ref _actief);
        try { _app.DialogBoxShowing += OnDialog; } catch { }
    }

    private void OnDialog(object? sender, DialogBoxShowingEventArgs e)
    {
        string id;
        try { id = e.DialogId ?? ""; } catch { id = ""; }
        string? tekst = null;
        if (e is TaskDialogShowingEventArgs td) { try { tekst = td.Message; } catch { } }
        else if (e is MessageBoxShowingEventArgs mb) { try { tekst = mb.Message; } catch { } }

        var rij = new Dictionary<string, object?>()
        {
            ["context"] = Context,
            ["dialog_id"] = id,
            ["message"] = tekst,
        };

        if (id.IndexOf("Save", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            rij["actie"] = "gelaten (bewaren is aan de gebruiker)";
            _laten.Add(rij);
            MainThreadDispatcher.Log($"[dialoogbewaker] bewaar-dialoog '{id}' bewust gelaten");
            return;
        }

        int? antwoord = null;
        foreach (var kv in BekendeAntwoorden)
            if (id.IndexOf(kv.Key, StringComparison.OrdinalIgnoreCase) >= 0) { antwoord = kv.Value; break; }
        if (antwoord == null && tekst != null) antwoord = 1; // OK
        else if (BlindOkForTextless) antwoord = BlindResult;

        if (antwoord == null)
        {
            rij["actie"] = "gelaten (geen tekst, dialog_ok staat uit)";
            _laten.Add(rij);
            MainThreadDispatcher.Log($"[dialoogbewaker] '{id}' gelaten");
            return;
        }
        try
        {
            e.OverrideResult(antwoord.Value);
            rij["actie"] = "weggedrukt";
            rij["result"] = antwoord.Value;
            _weggedrukt.Add(rij);
            MainThreadDispatcher.Log($"[dialoogbewaker] '{id}' weggedrukt met {antwoord.Value} ({Context})");
        }
        catch (Exception ex)
        {
            rij["actie"] = "wegdrukken mislukte: " + ex.Message;
            _laten.Add(rij);
        }
    }

    /// <summary>Dialogen die de gebruiker moet weten: alles met tekst en alles wat bleef staan.</summary>
    public List<Dictionary<string, object?>> NotableReport()
        => _weggedrukt.Where(r => r["message"] != null).Concat(_laten).ToList();

    /// <summary>Zet het verslag in het antwoord: dialogs_dismissed (aantal) en dialogs_notable (lijst).</summary>
    public void WriteTo(IDictionary<string, object?> uit)
    {
        uit["dialogs_dismissed"] = _weggedrukt.Count;
        uit["dialogs_notable"] = NotableReport();
    }

    public void Dispose()
    {
        if (_klaar) return;
        _klaar = true;
        try { _app.DialogBoxShowing -= OnDialog; } catch { }
        Interlocked.Decrement(ref _actief);
    }
}
