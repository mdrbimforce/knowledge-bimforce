// Pattern E: pure element instances (groups, assemblies, parts, MEP systems) +
// the GroupType definition. Unlike Pattern D these are instances, so metadata
// is_system_family = false. Query is FEC.OfClass<T>; model/detail groups share
// the Group class and are split by BuiltInCategory. Detail = generic param dump.
//
// Bulk fan-out, with the same contract as the other patterns.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB.Electrical;

namespace RevitAgent.Addin;

public static class PatternE_Handlers
{
    private static string Owner(Document doc) => BasePatternHandlers.ResolveOwner(doc);

    /// <summary>Pattern-E detail: generic param dump, instance metadata (is_system_family=false).</summary>
    private static Dictionary<string, object?> GenericDetail<T>(Document doc, long elementId, string owner)
        where T : Element
        => BasePatternHandlers.Detail<T>(
            doc, elementId, owner,
            BasePatternHandlers.DumpParameters,
            pattern: "E",
            relationships: null,
            metadata: BasePatternHandlers.MetadataEnvelope(isSystemFamily: false));

    /// <summary>Group instances filtered by BuiltInCategory (model vs detail groups share the Group class).</summary>
    private static List<Dictionary<string, object?>> QueryGroups(Document doc, string owner, BuiltInCategory bic, string builtinCatName)
    {
        return new FilteredElementCollector(doc)
            .OfClass(typeof(Group))
            .WhereElementIsNotElementType()
            .Cast<Group>()
            .Where(g => g.IsValidObject && g.Category != null && g.Category.Id.Value == (long)bic)
            .Select(g => BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(g.Id), "Group", builtinCatName, g.Name, null, owner, "E"))
            .ToList();
    }

    // ── Query dispatch ────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> Query(string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        var owner = Owner(doc);
        return typeId switch
        {
            "group_type"             => BasePatternHandlers.Query<GroupType>(doc, owner, "E"),
            "model_group"            => QueryGroups(doc, owner, BuiltInCategory.OST_IOSModelGroups, "OST_IOSModelGroups"),
            "detail_group"           => QueryGroups(doc, owner, BuiltInCategory.OST_IOSDetailGroups, "OST_IOSDetailGroups"),
            "assembly_instance"      => BasePatternHandlers.Query<AssemblyInstance>(doc, owner, "E"),
            "part"                   => BasePatternHandlers.Query<Part>(doc, owner, "E"),
            "mep_mechanical_system"  => BasePatternHandlers.Query<MechanicalSystem>(doc, owner, "E"),
            "mep_piping_system"      => BasePatternHandlers.Query<PipingSystem>(doc, owner, "E"),
            "mep_electrical_system"  => BasePatternHandlers.Query<ElectricalSystem>(doc, owner, "E"),
            _ => throw new ArgumentException($"Unknown Pattern-E type: {typeId}")
        };
    }

    // ── Detail dispatch ───────────────────────────────────────────────

    public static Dictionary<string, object?> Detail(string typeId, Document doc, long elementId)
    {
        var owner = Owner(doc);
        return typeId switch
        {
            "group_type"             => GenericDetail<GroupType>(doc, elementId, owner),
            "model_group"            => GenericDetail<Group>(doc, elementId, owner),
            "detail_group"           => GenericDetail<Group>(doc, elementId, owner),
            "assembly_instance"      => GenericDetail<AssemblyInstance>(doc, elementId, owner),
            "part"                   => GenericDetail<Part>(doc, elementId, owner),
            "mep_mechanical_system"  => GenericDetail<MechanicalSystem>(doc, elementId, owner),
            "mep_piping_system"      => GenericDetail<PipingSystem>(doc, elementId, owner),
            "mep_electrical_system"  => GenericDetail<ElectricalSystem>(doc, elementId, owner),
            _ => throw new NotImplementedException($"Pattern E detail for {typeId} not yet implemented")
        };
    }
}
