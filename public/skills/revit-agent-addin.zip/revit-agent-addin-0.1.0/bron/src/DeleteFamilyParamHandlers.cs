using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// delete_family_parameter — remove a shared/family parameter FROM a loadable family
/// (FamilyManager.RemoveParameter), so the "Shared Family Parameters" remediation tab can support
/// status=delete. Distinct from delete_element, which deletes
/// the project-level SharedParameterElement; this removes the parameter definition inside the family
/// and reloads it. Mirrors the swap_family EditFamily -> transaction -> LoadFamily skeleton.
///
/// Per family: EditFamily -> find the param (by GUID if shared, else by name) -> RemoveParameter in a
/// transaction -> LoadFamily back. An expected_name guard skips a stale id/name mismatch. RemoveParameter
/// throws if the param drives a formula/label — caught and reported as failed (not silently swallowed).
///
/// params: target_document, deletes:[{family, guid?|param_name, expected_name?}], dry_run (default TRUE),
///          save_first (default false).
/// </summary>
public static class DeleteFamilyParamHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        { overwriteParameterValues = true; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Family; overwriteParameterValues = true; return true; }
    }

    private record Del(string Family, string? Guid, string? ParamName, string? ExpectedName);

    public static CommandResponse DeleteFamilyParameter(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        var dels = ParseDeletes(p);
        if (dels.Count == 0) return Err("deletes required: [{family, guid|param_name [,expected_name]}]");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");

                bool savedBackup = false;
                if (!dryRun && saveFirst)
                {
                    try { doc.Save(); savedBackup = true; }
                    catch (Exception ex) { return (object)Fail($"save-first backup failed, delete aborted: {ex.Message}"); }
                }

                var results = new List<Dictionary<string, object?>>();
                int removed = 0, notfound = 0, failed = 0;

                foreach (var grp in dels.GroupBy(d => d.Family))
                {
                    var fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                        .FirstOrDefault(f => f.IsValidObject && f.IsEditable && f.Name.Equals(grp.Key, StringComparison.OrdinalIgnoreCase));
                    if (fam == null)
                    {
                        foreach (var d in grp) { results.Add(Res(d, "not_found", $"family '{grp.Key}' niet (editable) gevonden")); notfound++; }
                        continue;
                    }
                    Document? fdoc = null;
                    try
                    {
                        fdoc = doc.EditFamily(fam);
                        var fm = fdoc.FamilyManager;
                        if (dryRun)
                        {
                            foreach (var d in grp)
                            {
                                var fp = Find(fm, d.Guid, d.ParamName);
                                if (fp == null) { results.Add(Res(d, "not_found", "family-param niet gevonden")); notfound++; }
                                else if (d.ExpectedName != null && fp.Definition.Name != d.ExpectedName)
                                    results.Add(Res(d, "stale", $"huidig '{fp.Definition.Name}' != verwacht '{d.ExpectedName}'"));
                                else results.Add(Res(d, "would_delete", null));
                            }
                            fdoc.Close(false); continue;
                        }
                        bool any = false;
                        using (var t = new Transaction(fdoc, "NLRS delete family parameter"))
                        {
                            t.Start();
                            foreach (var d in grp)
                            {
                                var fp = Find(fm, d.Guid, d.ParamName);
                                if (fp == null) { results.Add(Res(d, "not_found", "family-param niet gevonden")); notfound++; continue; }
                                if (d.ExpectedName != null && fp.Definition.Name != d.ExpectedName)
                                { results.Add(Res(d, "stale", $"huidig '{fp.Definition.Name}' != verwacht '{d.ExpectedName}'")); continue; }
                                try { fm.RemoveParameter(fp); results.Add(Res(d, "removed", null)); removed++; any = true; }
                                catch (Exception ex) { results.Add(Res(d, "failed", ex.Message)); failed++; }
                            }
                            if (any) t.Commit(); else t.RollBack();
                        }
                        if (any) fdoc.LoadFamily(doc, new FamLoadOpts());
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        foreach (var d in grp) { results.Add(Res(d, "error", ex.Message)); failed++; }
                        try { fdoc?.Close(false); } catch { }
                    }
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["dry_run"] = dryRun,
                    ["saved_backup"] = savedBackup,
                    ["removed"] = removed, ["not_found"] = notfound, ["failed"] = failed,
                    ["results"] = results,
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static FamilyParameter? Find(FamilyManager fm, string? guid, string? name)
    {
        var g = guid?.Trim().ToLowerInvariant();
        foreach (FamilyParameter fp in fm.Parameters)
        {
            if (fp?.Definition == null) continue;
            if (!string.IsNullOrEmpty(g))
            {
                try { if (fp.IsShared && fp.GUID.ToString().ToLowerInvariant() == g) return fp; } catch { }
            }
            else if (name != null && fp.Definition.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return fp;
        }
        return null;
    }

    private static Dictionary<string, object?> Res(Del d, string status, string? err) => new()
    {
        ["family"] = d.Family, ["guid"] = d.Guid, ["param"] = d.ParamName,
        ["status"] = status, ["error"] = err ?? "",
    };

    private static List<Del> ParseDeletes(Dictionary<string, JsonElement>? p)
    {
        var outl = new List<Del>();
        if (p == null || !p.TryGetValue("deletes", out var arr) || arr.ValueKind != JsonValueKind.Array) return outl;
        foreach (var item in arr.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.Object) continue;
            string? fam = item.TryGetProperty("family", out var f) && f.ValueKind == JsonValueKind.String ? f.GetString() : null;
            string? guid = item.TryGetProperty("guid", out var g) && g.ValueKind == JsonValueKind.String ? g.GetString() : null;
            string? pn = item.TryGetProperty("param_name", out var n) && n.ValueKind == JsonValueKind.String ? n.GetString() : null;
            string? ex = item.TryGetProperty("expected_name", out var e) && e.ValueKind == JsonValueKind.String ? e.GetString() : null;
            if (string.IsNullOrWhiteSpace(fam) || (string.IsNullOrWhiteSpace(guid) && string.IsNullOrWhiteSpace(pn))) continue;
            outl.Add(new Del(fam!, guid, pn, ex));
        }
        return outl;
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
