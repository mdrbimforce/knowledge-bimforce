// Pattern D: System Family types (Type+Instance, no Family layer) via per-class FEC.
// Query is uniform (BasePatternHandlers.Query<T>). Detail defaults to an honest
// generic parameter dump (BasePatternHandlers.DumpParameters); compound-structure
// types (Wall/Floor/Ceiling/Roof) additionally emit uses_material layer relationships.
//
// Bulk fan-out, with the same contract as the other patterns
// (stub shape, RevitIdUtil.Fid, IsValidObject guard, always-emit rels).

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB.Electrical;

namespace RevitAgent.Addin;

public static class PatternD_Handlers
{
    private static string Owner(Document doc) => BasePatternHandlers.ResolveOwner(doc);

    // ── Detail builders ───────────────────────────────────────────────

    /// <summary>Default Pattern-D detail: honest generic parameter dump, no relationships.</summary>
    private static Dictionary<string, object?> GenericDetail<T>(Document doc, long elementId, string owner)
        where T : Element
        => BasePatternHandlers.Detail<T>(
            doc, elementId, owner,
            BasePatternHandlers.DumpParameters,
            pattern: "D");

    /// <summary>Compound-structure detail: generic param dump + uses_material layer relationships.</summary>
    private static Dictionary<string, object?> CompoundDetail<T>(Document doc, long elementId, string owner)
        where T : HostObjAttributes
    {
        var elem = BasePatternHandlers.GetElementOrThrow<T>(doc, elementId);
        return BasePatternHandlers.Detail<T>(
            doc, elementId, owner,
            BasePatternHandlers.DumpParameters,
            pattern: "D",
            relationships: CompoundMaterialRels(elem));
    }

    /// <summary>
    /// One uses_material relationship per compound-structure layer (role = layer function).
    /// Always-emits a single null-ref uses_material entry when the type has no usable
    /// compound structure, so the kind is never silently absent.
    /// </summary>
    private static List<Dictionary<string, object?>> CompoundMaterialRels(HostObjAttributes hoa)
    {
        var rels = new List<Dictionary<string, object?>>();
        CompoundStructure? cs = null;
        try { cs = hoa.GetCompoundStructure(); } catch { }

        if (cs != null)
        {
            try
            {
                foreach (var layer in cs.GetLayers())
                {
                    var mid = layer.MaterialId;
                    rels.Add(new Dictionary<string, object?>
                    {
                        ["kind"] = "uses_material",
                        ["role"] = layer.Function.ToString(),
                        ["ref"] = (mid != null && mid.Value > 0)
                            ? new Dictionary<string, object?>
                              {
                                  ["element_id"] = RevitIdUtil.Fid(mid),
                                  ["revit_class"] = "Material"
                              }
                            : null
                    });
                }
            }
            catch { }
        }

        if (rels.Count == 0)
            rels.Add(new Dictionary<string, object?> { ["kind"] = "uses_material", ["role"] = null, ["ref"] = null });

        return rels;
    }

    // ── Query dispatch (22 types, uniform FEC.OfClass<T>) ─────────────

    public static List<Dictionary<string, object?>> Query(string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        var owner = Owner(doc);
        return typeId switch
        {
            // architectural
            "wall_type"                   => BasePatternHandlers.Query<WallType>(doc, owner, "D"),
            "floor_type"                  => BasePatternHandlers.Query<FloorType>(doc, owner, "D"),
            "ceiling_type"                => BasePatternHandlers.Query<CeilingType>(doc, owner, "D"),
            "roof_type"                   => BasePatternHandlers.Query<RoofType>(doc, owner, "D"),
            "stairs_type"                 => BasePatternHandlers.Query<StairsType>(doc, owner, "D"),
            "railing_type"                => BasePatternHandlers.Query<RailingType>(doc, owner, "D"),
            "curtain_system_type"         => BasePatternHandlers.Query<CurtainSystemType>(doc, owner, "D"),
            "mullion_type"                => BasePatternHandlers.Query<MullionType>(doc, owner, "D"),
            "slab_edge_type"              => BasePatternHandlers.Query<SlabEdgeType>(doc, owner, "D"),
            "fascia_type"                 => BasePatternHandlers.Query<FasciaType>(doc, owner, "D"),
            "gutter_type"                 => BasePatternHandlers.Query<GutterType>(doc, owner, "D"),
            // structural
            "structural_connection_type"  => BasePatternHandlers.Query<StructuralConnectionType>(doc, owner, "D"),
            // mep
            "duct_type"                   => BasePatternHandlers.Query<DuctType>(doc, owner, "D"),
            "pipe_type"                   => BasePatternHandlers.Query<PipeType>(doc, owner, "D"),
            "conduit_type"                => BasePatternHandlers.Query<ConduitType>(doc, owner, "D"),
            "cable_tray_type"             => BasePatternHandlers.Query<CableTrayType>(doc, owner, "D"),
            "duct_insulation_type"        => BasePatternHandlers.Query<DuctInsulationType>(doc, owner, "D"),
            "pipe_insulation_type"        => BasePatternHandlers.Query<PipeInsulationType>(doc, owner, "D"),
            "duct_lining_type"            => BasePatternHandlers.Query<DuctLiningType>(doc, owner, "D"),
            "flex_duct_type"              => BasePatternHandlers.Query<FlexDuctType>(doc, owner, "D"),
            "flex_pipe_type"              => BasePatternHandlers.Query<FlexPipeType>(doc, owner, "D"),
            "wire_type"                   => BasePatternHandlers.Query<WireType>(doc, owner, "D"),
            _ => throw new ArgumentException($"Unknown Pattern-D type: {typeId}")
        };
    }

    // ── Detail dispatch ───────────────────────────────────────────────

    public static Dictionary<string, object?> Detail(string typeId, Document doc, long elementId)
    {
        var owner = Owner(doc);
        return typeId switch
        {
            // compound-structure types → uses_material layer relationships
            "wall_type"                   => CompoundDetail<WallType>(doc, elementId, owner),
            "floor_type"                  => CompoundDetail<FloorType>(doc, elementId, owner),
            "ceiling_type"                => CompoundDetail<CeilingType>(doc, elementId, owner),
            "roof_type"                   => CompoundDetail<RoofType>(doc, elementId, owner),
            // architectural (generic param dump)
            "stairs_type"                 => GenericDetail<StairsType>(doc, elementId, owner),
            "railing_type"                => GenericDetail<RailingType>(doc, elementId, owner),
            "curtain_system_type"         => GenericDetail<CurtainSystemType>(doc, elementId, owner),
            "mullion_type"                => GenericDetail<MullionType>(doc, elementId, owner),
            "slab_edge_type"              => GenericDetail<SlabEdgeType>(doc, elementId, owner),
            "fascia_type"                 => GenericDetail<FasciaType>(doc, elementId, owner),
            "gutter_type"                 => GenericDetail<GutterType>(doc, elementId, owner),
            // structural
            "structural_connection_type"  => GenericDetail<StructuralConnectionType>(doc, elementId, owner),
            // mep
            "duct_type"                   => GenericDetail<DuctType>(doc, elementId, owner),
            "pipe_type"                   => GenericDetail<PipeType>(doc, elementId, owner),
            "conduit_type"                => GenericDetail<ConduitType>(doc, elementId, owner),
            "cable_tray_type"             => GenericDetail<CableTrayType>(doc, elementId, owner),
            "duct_insulation_type"        => GenericDetail<DuctInsulationType>(doc, elementId, owner),
            "pipe_insulation_type"        => GenericDetail<PipeInsulationType>(doc, elementId, owner),
            "duct_lining_type"            => GenericDetail<DuctLiningType>(doc, elementId, owner),
            "flex_duct_type"              => GenericDetail<FlexDuctType>(doc, elementId, owner),
            "flex_pipe_type"              => GenericDetail<FlexPipeType>(doc, elementId, owner),
            "wire_type"                   => GenericDetail<WireType>(doc, elementId, owner),
            _ => throw new NotImplementedException($"Pattern D detail for {typeId} not yet implemented")
        };
    }
}
