using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// enum_material_parameters — read-only inventory of materials, their three asset NAMES
/// (Appearance / Thermal / Structural) and all of their parameters.
/// Feeds the "Material Parameters" remediation tab (row per material x parameter).
///
/// Per Material (FEC.OfClass(Material)): name + asset names resolved via AppearanceAssetId /
/// ThermalAssetId / StructuralAssetId, plus mat.GetOrderedParameters each reported as
/// {name, is_shared, guid?, spec, storage_type, value (UI text), is_elementid}. ElementId-typed
/// params resolve to the referenced element's name (so the value-edit step can round-trip on UI-name).
///
/// params: target_document (scope by Title).
/// </summary>
public static class MaterialParamsHandlers
{
    public static CommandResponse EnumMaterialParameters(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");

                string? AssetName(ElementId id)
                {
                    if (id == null || id == ElementId.InvalidElementId) return null;
                    try { return doc.GetElement(id)?.Name; } catch { return null; }
                }

                var mats = new List<Dictionary<string, object?>>();
                foreach (Material mat in new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>())
                {
                    var paramList = new List<Dictionary<string, object?>>();
                    try
                    {
                        foreach (Parameter par in mat.GetOrderedParameters())
                        {
                            if (par?.Definition == null) continue;
                            bool isShared = false; string? guid = null;
                            try { isShared = par.IsShared; if (isShared) guid = par.GUID.ToString(); } catch { }
                            bool isEid = par.StorageType == StorageType.ElementId;
                            string? value = null;
                            try
                            {
                                if (isEid)
                                {
                                    var vid = par.AsElementId();
                                    value = (vid != null && vid != ElementId.InvalidElementId) ? doc.GetElement(vid)?.Name : null;
                                }
                                else
                                {
                                    value = par.AsValueString() ?? par.AsString();
                                    if (value == null && par.StorageType == StorageType.Integer) value = par.AsInteger().ToString();
                                }
                            }
                            catch { }
                            paramList.Add(new Dictionary<string, object?>
                            {
                                ["name"] = par.Definition.Name,
                                ["is_shared"] = isShared,
                                ["guid"] = guid,
                                ["spec"] = SafeSpec(par),
                                ["storage_type"] = par.StorageType.ToString(),
                                ["is_elementid"] = isEid,
                                ["value"] = value,
                            });
                        }
                    }
                    catch { }

                    mats.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(mat.Id),
                        ["name"] = mat.Name,
                        ["material_class"] = SafeClass(mat),
                        ["appearance_asset"] = AssetName(mat.AppearanceAssetId),
                        ["thermal_asset"] = AssetName(mat.ThermalAssetId),
                        ["structural_asset"] = AssetName(mat.StructuralAssetId),
                        ["params"] = paramList,
                    });
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["material_count"] = mats.Count,
                    ["materials"] = mats,
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    /// <summary>
    /// enum_material_usage — per material, count the DISTINCT element-types that reference it
    /// ("aan hoeveel element-types is dit materiaal toegekend"). Drives the
    /// is_toegepast column on the Materials tab so a delete decision shows its blast-radius, and is the
    /// precursor to the delete+replace workflow (replace_material). Type-level (not instance) on purpose.
    ///
    /// Three reference paths are unioned per type: (1) Element.GetMaterialIds(false) — geometry/assigned
    /// materials; (2) CompoundStructure layer materials for HostObjAttributes types (Wall/Floor/Roof/
    /// Ceiling); (3) ElementId-typed parameters whose value resolves to a Material (the NLRS family
    /// material-parameter pattern). A capped name list is returned for context.
    ///
    /// params: target_document (scope by Title).
    /// </summary>
    public static CommandResponse EnumMaterialUsage(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                {
                    if (target != null && d.Title != target) continue;
                    doc = d; break;
                }
                if (doc == null) return (object)Fail("no matching open document");

                var typeIds = new Dictionary<long, HashSet<long>>();  // matId -> set of element-type ids
                var names = new Dictionary<long, List<string>>();       // matId -> capped type-name list

                void Tally(ElementId matId, Element type)
                {
                    if (matId == null || matId == ElementId.InvalidElementId) return;
                    long mk = matId.Value;
                    if (!typeIds.TryGetValue(mk, out var set)) { set = new HashSet<long>(); typeIds[mk] = set; names[mk] = new List<string>(); }
                    if (set.Add(type.Id.Value) && names[mk].Count < 15)
                    {
                        string fam = "";
                        try { if (type is FamilySymbol fs) fam = fs.FamilyName + ": "; } catch { }
                        names[mk].Add(fam + type.Name);
                    }
                }

                foreach (Element el in new FilteredElementCollector(doc).WhereElementIsElementType())
                {
                    if (el is not ElementType type) continue;
                    try { foreach (var mid in type.GetMaterialIds(false)) Tally(mid, type); } catch { }
                    try
                    {
                        var cs = (type as HostObjAttributes)?.GetCompoundStructure();
                        if (cs != null) foreach (var layer in cs.GetLayers()) Tally(layer.MaterialId, type);
                    }
                    catch { }
                    try
                    {
                        foreach (Parameter par in type.Parameters)
                        {
                            if (par.StorageType != StorageType.ElementId) continue;
                            var vid = par.AsElementId();
                            if (vid != null && vid != ElementId.InvalidElementId && doc.GetElement(vid) is Material)
                                Tally(vid, type);
                        }
                    }
                    catch { }
                }

                var mats = new List<Dictionary<string, object?>>();
                foreach (Material mat in new FilteredElementCollector(doc).OfClass(typeof(Material)).Cast<Material>())
                {
                    long mk = mat.Id.Value;
                    int cnt = typeIds.TryGetValue(mk, out var set) ? set.Count : 0;
                    mats.Add(new Dictionary<string, object?>
                    {
                        ["element_id"] = RevitIdUtil.Fid(mat.Id),
                        ["name"] = mat.Name,
                        ["type_count"] = cnt,
                        ["type_names"] = names.TryGetValue(mk, out var nl) ? nl : new List<string>(),
                    });
                }

                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["material_count"] = mats.Count,
                    ["materials"] = mats,
                };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static string? SafeSpec(Parameter par)
    {
        try { return par.Definition.GetDataType().TypeId; } catch { return null; }
    }

    private static string? SafeClass(Material mat)
    {
        try { return string.IsNullOrEmpty(mat.MaterialClass) ? mat.MaterialCategory : mat.MaterialClass; }
        catch { return null; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
