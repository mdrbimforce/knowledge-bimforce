using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// set_family_param_kind — family-parameters wisselen tussen instance en type (FamilyManager.MakeInstance / MakeType).
/// Bijvoorbeeld voor IfcName[Type]/IfcDescription[Type] die als instance-parameter in een family staan.
/// params: target_document, family (projectfamily via EditFamily + LoadFamily) óf rfa_path (family-doc van schijf, Save),
///         edits:[{param_name, is_instance}], dry_run (default true), dialog_ok (default true), overwrite_values (default false bij LoadFamily).
/// </summary>
public static class FamilyParamKindHandlers
{
    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool Overwrite = false;
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues) { overwriteParameterValues = Overwrite; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = FamilySource.Project; overwriteParameterValues = Overwrite; return true; }
    }

    public static CommandResponse SetFamilyParamKind(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? family = GetString(p, "family");
        string? rfaPath = GetString(p, "rfa_path");
        bool dryRun = GetBool(p, "dry_run", true);
        bool dialogOk = GetBool(p, "dialog_ok", true);
        bool overwrite = GetBool(p, "overwrite_values", false);
        var edits = new List<(string name, bool inst)>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? n = GetProp(it, "param_name");
                bool inst = it.TryGetProperty("is_instance", out var ie) && ie.ValueKind == JsonValueKind.True;
                if (n != null) edits.Add((n, inst));
            }
        if (edits.Count == 0) return Err("edits:[{param_name, is_instance}] is required");
        bool fromDisk = !string.IsNullOrWhiteSpace(rfaPath);
        if (fromDisk && !File.Exists(rfaPath)) return Err($"rfa_path bestaat niet: {rfaPath}");
        if (!fromDisk && string.IsNullOrWhiteSpace(family)) return Err("family of rfa_path is required");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                Family? fam = null;
                if (!fromDisk)
                {
                    fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>().FirstOrDefault(f => string.Equals(f.Name, family, StringComparison.OrdinalIgnoreCase));
                    if (fam == null) return (object)Fail($"family '{family}' niet gevonden in '{doc.Title}'");
                }
                var results = new List<Dictionary<string, object?>>();
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.Context = fromDisk ? Path.GetFileNameWithoutExtension(rfaPath!) : family!;
                Document? fdoc = null; bool anyOk = false;
                try
                {
                    fdoc = fromDisk ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                    var fm = fdoc.FamilyManager;
                    using (var t = new Transaction(fdoc, "Revit Agent: family param kind"))
                    {
                        t.Start();
                        foreach (var (name, inst) in edits)
                        {
                            var row = new Dictionary<string, object?> { ["param"] = name, ["is_instance"] = inst };
                            var fp = fm.get_Parameter(name);
                            if (fp == null) { row["status"] = "not_found"; results.Add(row); continue; }
                            row["was_instance"] = fp.IsInstance;
                            if (fp.IsInstance == inst) { row["status"] = "unchanged"; results.Add(row); continue; }
                            if (dryRun) { row["status"] = "would_change"; results.Add(row); continue; }
                            try
                            {
                                if (inst) fm.MakeInstance(fp); else fm.MakeType(fp);
                                row["status"] = "changed"; anyOk = true;
                            }
                            catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                            results.Add(row);
                        }
                        if (dryRun || !anyOk) t.RollBack(); else t.Commit();
                    }
                    if (!dryRun && anyOk)
                    {
                        if (fromDisk) { fdoc.Save(); results.Add(new Dictionary<string, object?> { ["status"] = "saved_rfa" }); }
                        else { fdoc.LoadFamily(doc, new FamLoadOpts { Overwrite = overwrite }); results.Add(new Dictionary<string, object?> { ["status"] = "reloaded" }); }
                    }
                }
                finally { try { fdoc?.Close(false); } catch { } }
                return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["family"] = fromDisk ? Path.GetFileNameWithoutExtension(rfaPath!) : family, ["dry_run"] = dryRun, ["results"] = results, ["notable_dialogs"] = swallow.NotableReport() };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    /// <summary>delete_family_types — family-types van de ROOT-family in een family-doc verwijderen (FamilyManager.DeleteCurrentType).
    /// params: target_document, family (projectfamily) óf rfa_path; types:[...] te verwijderen óf keep_types:[...] (alle andere weg);
    /// dry_run (default true), dialog_ok (default true).</summary>
    public static CommandResponse DeleteFamilyTypes(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? family = GetString(p, "family");
        string? rfaPath = GetString(p, "rfa_path");
        bool dryRun = GetBool(p, "dry_run", true);
        bool dialogOk = GetBool(p, "dialog_ok", true);
        var del = new HashSet<string>(StringComparer.OrdinalIgnoreCase); var keep = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (p != null && p.TryGetValue("types", out var a1) && a1.ValueKind == JsonValueKind.Array) foreach (var it in a1.EnumerateArray()) if (it.ValueKind == JsonValueKind.String) del.Add(it.GetString()!);
        if (p != null && p.TryGetValue("keep_types", out var a2) && a2.ValueKind == JsonValueKind.Array) foreach (var it in a2.EnumerateArray()) if (it.ValueKind == JsonValueKind.String) keep.Add(it.GetString()!);
        if (del.Count == 0 && keep.Count == 0) return Err("types:[...] of keep_types:[...] is required");
        bool fromDisk = !string.IsNullOrWhiteSpace(rfaPath);
        if (fromDisk && !File.Exists(rfaPath)) return Err($"rfa_path bestaat niet: {rfaPath}");
        if (!fromDisk && string.IsNullOrWhiteSpace(family)) return Err("family of rfa_path is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                Family? fam = null;
                if (!fromDisk)
                {
                    fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>().FirstOrDefault(f => string.Equals(f.Name, family, StringComparison.OrdinalIgnoreCase));
                    if (fam == null) return (object)Fail($"family '{family}' niet gevonden in '{doc.Title}'");
                }
                var results = new List<Dictionary<string, object?>>();
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.Context = fromDisk ? Path.GetFileNameWithoutExtension(rfaPath!) : family!;
                Document? fdoc = null; bool anyOk = false;
                try
                {
                    fdoc = fromDisk ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                    var fm = fdoc.FamilyManager;
                    var names = fm.Types.Cast<FamilyType>().Select(t => t.Name).ToList();
                    var targets = names.Where(n => del.Contains(n) || (keep.Count > 0 && !keep.Contains(n))).ToList();
                    if (targets.Count >= names.Count) return (object)Fail("zou alle typen verwijderen; minstens één type moet blijven");
                    using (var t = new Transaction(fdoc, "Revit Agent: delete family types"))
                    {
                        t.Start();
                        foreach (var n in targets)
                        {
                            var row = new Dictionary<string, object?> { ["type"] = n };
                            if (dryRun) { row["status"] = "would_delete"; results.Add(row); continue; }
                            try
                            {
                                var ft = fm.Types.Cast<FamilyType>().First(x => x.Name == n);
                                fm.CurrentType = ft; fm.DeleteCurrentType();
                                row["status"] = "deleted"; anyOk = true;
                            }
                            catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                            results.Add(row);
                        }
                        if (dryRun || !anyOk) t.RollBack(); else t.Commit();
                    }
                    if (!dryRun && anyOk)
                    {
                        if (fromDisk) { fdoc.Save(); results.Add(new Dictionary<string, object?> { ["status"] = "saved_rfa" }); }
                        else { fdoc.LoadFamily(doc, new FamLoadOpts { Overwrite = false }); results.Add(new Dictionary<string, object?> { ["status"] = "reloaded" }); }
                    }
                }
                finally { try { fdoc?.Close(false); } catch { } }
                return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["family"] = fromDisk ? Path.GetFileNameWithoutExtension(rfaPath!) : family, ["dry_run"] = dryRun, ["results"] = results, ["notable_dialogs"] = swallow.NotableReport() };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    /// <summary>copy_family_type — een family-type dupliceren onder een nieuwe naam (FamilyManager.NewType kopieert de waarden van het
    /// huidige type) en optioneel het brontype verwijderen. Workaround voor RenameCurrentType dat op sommige typen stil niet doorkomt.
    /// params: target_document, family óf rfa_path, edits:[{source_type, new_name}], delete_source (default false),
    /// dry_run (default true), dialog_ok (default true).</summary>
    public static CommandResponse CopyFamilyType(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? family = GetString(p, "family");
        string? rfaPath = GetString(p, "rfa_path");
        bool dryRun = GetBool(p, "dry_run", true);
        bool dialogOk = GetBool(p, "dialog_ok", true);
        bool deleteSource = GetBool(p, "delete_source", false);
        var edits = new List<(string src, string nn)>();
        if (p != null && p.TryGetValue("edits", out var arr) && arr.ValueKind == JsonValueKind.Array)
            foreach (var it in arr.EnumerateArray())
            {
                if (it.ValueKind != JsonValueKind.Object) continue;
                string? a = GetProp(it, "source_type"), b = GetProp(it, "new_name");
                if (a != null && b != null) edits.Add((a, b));
            }
        if (edits.Count == 0) return Err("edits:[{source_type, new_name}] is required");
        bool fromDisk = !string.IsNullOrWhiteSpace(rfaPath);
        if (fromDisk && !File.Exists(rfaPath)) return Err($"rfa_path bestaat niet: {rfaPath}");
        if (!fromDisk && string.IsNullOrWhiteSpace(family)) return Err("family of rfa_path is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                Family? fam = null;
                if (!fromDisk)
                {
                    fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>().FirstOrDefault(f => string.Equals(f.Name, family, StringComparison.OrdinalIgnoreCase));
                    if (fam == null) return (object)Fail($"family '{family}' niet gevonden in '{doc.Title}'");
                }
                var results = new List<Dictionary<string, object?>>();
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = dialogOk; swallow.Context = fromDisk ? Path.GetFileNameWithoutExtension(rfaPath!) : family!;
                Document? fdoc = null; bool anyOk = false;
                try
                {
                    fdoc = fromDisk ? app.Application.OpenDocumentFile(rfaPath) : doc.EditFamily(fam!);
                    var fm = fdoc.FamilyManager;
                    var pre = new MiscDocHandlers.LoadFailurePreprocessor();
                    using (var t = new Transaction(fdoc, "Revit Agent: copy family type"))
                    {
                        t.Start();
                        try { t.SetFailureHandlingOptions(t.GetFailureHandlingOptions().SetFailuresPreprocessor(pre).SetClearAfterRollback(true)); } catch { }
                        foreach (var (src, nn) in edits)
                        {
                            var row = new Dictionary<string, object?> { ["source_type"] = src, ["new_name"] = nn };
                            var names = fm.Types.Cast<FamilyType>().Select(x => x.Name).ToList();
                            if (!names.Contains(src)) { row["status"] = "source_not_found"; results.Add(row); continue; }
                            if (names.Contains(nn)) { row["status"] = "name_exists"; results.Add(row); continue; }
                            if (dryRun) { row["status"] = "would_copy"; results.Add(row); continue; }
                            try
                            {
                                fm.CurrentType = fm.Types.Cast<FamilyType>().First(x => x.Name == src);
                                var nt = fm.NewType(nn);
                                row["status"] = "copied"; anyOk = true;
                                if (deleteSource)
                                {
                                    fm.CurrentType = fm.Types.Cast<FamilyType>().First(x => x.Name == src);
                                    fm.DeleteCurrentType(); row["source_deleted"] = true;
                                }
                            }
                            catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                            results.Add(row);
                        }
                        if (dryRun || !anyOk) t.RollBack(); else { var st = t.Commit(); if (st != TransactionStatus.Committed) { anyOk = false; results.Add(new Dictionary<string, object?> { ["status"] = "rolled_back", ["failures"] = pre.Messages }); } else if (pre.Messages.Count > 0) results.Add(new Dictionary<string, object?> { ["status"] = "failures_resolved", ["failures"] = pre.Messages }); }
                    }
                    if (!dryRun && anyOk)
                    {
                        if (fromDisk) { fdoc.Save(); results.Add(new Dictionary<string, object?> { ["status"] = "saved_rfa" }); }
                        else { fdoc.LoadFamily(doc, new FamLoadOpts { Overwrite = false }); results.Add(new Dictionary<string, object?> { ["status"] = "reloaded" }); }
                    }
                }
                finally { try { fdoc?.Close(false); } catch { } }
                return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["dry_run"] = dryRun, ["results"] = results, ["notable_dialogs"] = swallow.NotableReport() };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static string? GetProp(JsonElement obj, string key)
    {
        if (obj.TryGetProperty(key, out var el) && el.ValueKind == JsonValueKind.String) { var s = el.GetString(); return string.IsNullOrWhiteSpace(s) ? null : s; }
        return null;
    }
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el)) { if (el.ValueKind == JsonValueKind.True) return true; if (el.ValueKind == JsonValueKind.False) return false; }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) { var s = el.GetString(); return string.IsNullOrWhiteSpace(s) ? null : s; }
        return null;
    }
}
