using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// Documenten openen en bewaren, links laden, een type wisselen, een sheet lezen en views als beeld exporteren.
/// Coördinaten in het antwoord zijn millimeters.
/// </summary>
public static class DocumentHandlers
{
    private const double MmPerFt = 304.8;

    // ── open_document ───────────────────────────────────────────────────────
    /// <summary>
    /// open_document: een .rvt/.rfa openen op de achtergrond (geen venster, wel volledig bruikbaar via de bridge).
    /// params: path · worksets ("alle" standaard | "geen" | "laatste") · detach ("nee" standaard | "behoud" | "weggooien")
    ///         · audit (false)
    /// Ontbrekende links: de melding "Unresolved References" wordt beantwoord met "doorgaan met openen";
    /// het antwoord noemt welke links niet geladen zijn (links_niet_geladen).
    /// </summary>
    public static CommandResponse OpenDocument(CommandRequest request) => Open(request, metVenster: false);

    /// <summary>open_document_ui: als open_document, maar het model wordt getoond en actief in Revit.</summary>
    public static CommandResponse OpenDocumentUi(CommandRequest request) => Open(request, metVenster: true);

    private static CommandResponse Open(CommandRequest request, bool metVenster)
    {
        var p = request.Params;
        var path = HandlerUtil.Str(p, "path");
        if (path == null) return Err("Parameter 'path' is required");
        if (!File.Exists(path)) return Err($"Bestand niet gevonden: {path}");
        var worksets = (HandlerUtil.Str(p, "worksets") ?? "alle").ToLowerInvariant();
        var detach = (HandlerUtil.Str(p, "detach") ?? "nee").ToLowerInvariant();
        bool audit = HandlerUtil.Bool(p, "audit", false);
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                using var bewaker = new DialogSwallowScope(app) { Context = (metVenster ? "open_document_ui " : "open_document ") + Path.GetFileName(path) };
                var mp = ModelPathUtils.ConvertUserVisiblePathToModelPath(path);
                var opts = new OpenOptions() { Audit = audit };
                bool ws = false;
                try { ws = BasicFileInfo.Extract(path).IsWorkshared; } catch { }
                if (ws)
                {
                    var cfg = worksets switch
                    {
                        "geen" => WorksetConfigurationOption.CloseAllWorksets,
                        "laatste" => WorksetConfigurationOption.OpenLastViewed,
                        _ => WorksetConfigurationOption.OpenAllWorksets,
                    };
                    opts.SetOpenWorksetsConfiguration(new WorksetConfiguration(cfg));
                    if (detach == "behoud") opts.DetachFromCentralOption = DetachFromCentralOption.DetachAndPreserveWorksets;
                    else if (detach == "weggooien") opts.DetachFromCentralOption = DetachFromCentralOption.DetachAndDiscardWorksets;
                }

                Document doc;
                bool getoond = false;
                if (metVenster)
                {
                    try { doc = app.OpenAndActivateDocument(mp, opts, false).Document; getoond = true; }
                    catch (Exception exA) when (exA.Message.Contains("Switching active documents"))
                    {
                        // In deze context mag Revit niet van actief document wisselen: dan op de achtergrond.
                        doc = app.Application.OpenDocumentFile(mp, opts);
                    }
                }
                else doc = app.Application.OpenDocumentFile(mp, opts);

                var res = new Dictionary<string, object?>()
                {
                    ["title"] = doc.Title,
                    ["path"] = doc.PathName,
                    ["is_family"] = doc.IsFamilyDocument,
                    ["is_workshared"] = doc.IsWorkshared,
                    ["getoond"] = getoond,
                    ["links_niet_geladen"] = LinksNietGeladen(doc),
                };
                if (doc.IsWorkshared)
                {
                    try { res["worksets_dicht"] = new FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset).Count(w => !w.IsOpen); } catch { }
                }
                bewaker.WriteTo(res);
                return (object)res;
            }, timeoutMs: 1200000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed to open: {Unwrap(ex)}"); }
    }

    private static List<string> LinksNietGeladen(Document doc)
    {
        var uit = new List<string>();
        try
        {
            foreach (var lt in new FilteredElementCollector(doc).OfClass(typeof(RevitLinkType)).Cast<RevitLinkType>())
            {
                try { if (!RevitLinkType.IsLoaded(doc, lt.Id)) uit.Add(lt.Name); } catch { }
            }
        }
        catch { }
        return uit;
    }

    // ── save_document ───────────────────────────────────────────────────────
    /// <summary>save_document: een open model bewaren. params: target_document. Alleen op verzoek van de gebruiker.</summary>
    public static CommandResponse SaveDocument(CommandRequest request)
    {
        var target = HandlerUtil.Str(request.Params, "target_document");
        if (target == null) return Err("Parameter 'target_document' is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                if (string.IsNullOrEmpty(doc.PathName))
                    return (object)Fail("dit model is nog nooit bewaard; gebruik save_document_as met een pad");
                if (doc.IsLinked) return (object)Fail("dit is een geladen link; open het model zelf om het te bewaren");
                doc.Save();
                return (object)new Dictionary<string, object?>() { ["saved"] = true, ["document"] = doc.Title, ["path"] = doc.PathName };
            }, timeoutMs: 600000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    // ── load_links ──────────────────────────────────────────────────────────
    /// <summary>
    /// load_links: Revit-links toevoegen.
    /// params: target_document · paths [..] of folder (alle *.rvt, optioneel name_contains)
    ///         · placement ("origin" standaard | "shared") · dry_run (true)
    /// Een link waarvan de bestandsnaam al als link in het model staat, wordt overgeslagen.
    /// </summary>
    public static CommandResponse LoadLinks(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("Parameter 'target_document' is required");
        var paths = HandlerUtil.StrList(p, "paths");
        var folder = HandlerUtil.Str(p, "folder");
        var nameContains = HandlerUtil.Str(p, "name_contains");
        if (paths.Count == 0 && folder != null && Directory.Exists(folder))
            paths = Directory.GetFiles(folder, "*.rvt")
                .Where(f => nameContains == null || Path.GetFileName(f).IndexOf(nameContains, StringComparison.OrdinalIgnoreCase) >= 0)
                .OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToList();
        if (paths.Count == 0) return Err("Geef 'paths' (lijst) of een bestaande 'folder' met .rvt-bestanden");
        var placement = (HandlerUtil.Str(p, "placement") ?? "origin").ToLowerInvariant();
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                var bestaand = new FilteredElementCollector(doc).OfClass(typeof(RevitLinkType)).Cast<RevitLinkType>()
                    .Select(lt => Path.GetFileNameWithoutExtension(lt.Name.Split(':')[0].Trim())).ToHashSet(StringComparer.OrdinalIgnoreCase);
                var rows = new List<Dictionary<string, object?>>();
                using var bewaker = new DialogSwallowScope(app) { Context = "load_links" };
                foreach (var pad in paths)
                {
                    var row = new Dictionary<string, object?>() { ["path"] = pad };
                    rows.Add(row);
                    var naam = Path.GetFileNameWithoutExtension(pad);
                    if (!File.Exists(pad)) { row["status"] = "bestand ontbreekt"; continue; }
                    if (bestaand.Contains(naam)) { row["status"] = "al gelinkt"; continue; }
                    if (dryRun) { row["status"] = "zou linken"; continue; }
                    using var t = new Transaction(doc, "Revit Agent: link laden");
                    t.Start();
                    var fv = HandlerUtil.ZetFailureVerzamelaar(t);
                    try
                    {
                        var mp = ModelPathUtils.ConvertUserVisiblePathToModelPath(pad);
                        var lr = RevitLinkType.Create(doc, mp, new RevitLinkOptions(false));
                        var inst = RevitLinkInstance.Create(doc, lr.ElementId,
                            placement == "shared" ? ImportPlacement.Shared : ImportPlacement.Origin);
                        if (t.Commit() == TransactionStatus.Committed)
                        {
                            row["status"] = "gelinkt"; row["link_type_id"] = lr.ElementId.Value; row["instance_id"] = inst.Id.Value;
                            row["load_result"] = lr.LoadResult.ToString();
                            bestaand.Add(naam);
                        }
                        else row["status"] = "teruggedraaid";
                    }
                    catch (Exception ex)
                    {
                        if (t.HasStarted() && !t.HasEnded()) t.RollBack();
                        row["status"] = "fout"; row["error"] = ex.Message;
                    }
                    if (fv.Meldingen.Count > 0) row["meldingen"] = fv.Meldingen;
                }
                var res = new Dictionary<string, object?>()
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["placement"] = placement, ["results"] = rows,
                };
                bewaker.WriteTo(res);
                return (object)res;
            }, timeoutMs: 3600000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    // ── change_element_type ─────────────────────────────────────────────────
    /// <summary>
    /// change_element_type: elementen een ander type geven.
    /// params: target_document · element_ids [..] · new_type_id of new_type_name (+ optioneel family_name) · dry_run (true)
    /// </summary>
    public static CommandResponse ChangeElementType(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        if (target == null) return Err("Parameter 'target_document' is required");
        var ids = HandlerUtil.LongList(p, "element_ids");
        if (ids.Count == 0) return Err("Parameter 'element_ids' (lijst van getallen) is required");
        long newTypeId = 0;
        if (p != null && p.TryGetValue("new_type_id", out var nt) && nt.ValueKind == JsonValueKind.Number) newTypeId = nt.GetInt64();
        var newTypeName = HandlerUtil.Str(p, "new_type_name");
        var famName = HandlerUtil.Str(p, "family_name");
        if (newTypeId == 0 && newTypeName == null) return Err("Geef 'new_type_id' of 'new_type_name'");
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                ElementType? nieuw = newTypeId != 0 ? doc.GetElement(new ElementId(newTypeId)) as ElementType
                    : new FilteredElementCollector(doc).WhereElementIsElementType().Cast<ElementType>()
                        .FirstOrDefault(t => t.Name == newTypeName && (famName == null || t.FamilyName == famName));
                if (nieuw == null) return (object)Fail($"type niet gevonden ({newTypeId} / {newTypeName})");

                var rows = new List<Dictionary<string, object?>>();
                var fv = new HandlerUtil.FailureVerzamelaar();
                using (var t = new Transaction(doc, "Revit Agent: type wisselen"))
                {
                    t.Start();
                    fv = HandlerUtil.ZetFailureVerzamelaar(t);
                    foreach (var id in ids)
                    {
                        var row = new Dictionary<string, object?>() { ["element_id"] = id };
                        rows.Add(row);
                        var el = doc.GetElement(new ElementId(id));
                        if (el == null) { row["status"] = "niet gevonden"; continue; }
                        row["oud_type"] = doc.GetElement(el.GetTypeId())?.Name;
                        if (el.GetTypeId() == nieuw.Id) { row["status"] = "al dit type"; continue; }
                        if (!el.IsValidType(nieuw.Id)) { row["status"] = "type past niet bij dit element"; continue; }
                        try { el.ChangeTypeId(nieuw.Id); row["status"] = dryRun ? "zou wisselen" : "gewisseld"; }
                        catch (Exception ex) { row["status"] = "fout"; row["error"] = ex.Message; }
                    }
                    if (dryRun) t.RollBack();
                    else if (t.Commit() != TransactionStatus.Committed)
                        foreach (var r in rows.Where(r => (string?)r["status"] == "gewisseld")) r["status"] = "teruggedraaid";
                }
                return (object)new Dictionary<string, object?>()
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["nieuw_type"] = nieuw.Name, ["nieuw_type_id"] = nieuw.Id.Value,
                    ["results"] = rows, ["meldingen"] = fv.Meldingen,
                };
            }, timeoutMs: 300000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    // ── get_sheet_detail ────────────────────────────────────────────────────
    /// <summary>
    /// get_sheet_detail: één sheet lezen. params: target_document · sheet_name (deel van nummer of naam).
    /// Antwoord: sheet_number, sheet_name, viewports [{view_name, view_type, scale, view_template, viewport_type,
    /// center_mm, filters}], schedules [{name, point_mm}], titleblocks [{family, type, parameters}].
    /// </summary>
    public static CommandResponse GetSheetDetail(CommandRequest request)
    {
        var target = HandlerUtil.Str(request.Params, "target_document");
        var name = HandlerUtil.Str(request.Params, "sheet_name");
        if (target == null || name == null) return Err("Parameters 'target_document' en 'sheet_name' zijn vereist");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                var sheets = new FilteredElementCollector(doc).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().ToList();
                var sheet = sheets.FirstOrDefault(s => s.SheetNumber == name || s.Name == name)
                         ?? sheets.FirstOrDefault(s => s.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0
                                                    || s.SheetNumber.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0);
                if (sheet == null) return (object)Fail($"sheet '{name}' niet gevonden");

                var vps = new List<Dictionary<string, object?>>();
                foreach (var vpId in sheet.GetAllViewports())
                {
                    if (doc.GetElement(vpId) is not Viewport vp) continue;
                    if (doc.GetElement(vp.ViewId) is not View view) continue;
                    var filters = new List<Dictionary<string, object?>>();
                    try
                    {
                        foreach (var fid in view.GetFilters())
                            filters.Add(new Dictionary<string, object?>()
                            { ["name"] = doc.GetElement(fid)?.Name, ["visible"] = view.GetFilterVisibility(fid) });
                    }
                    catch { }
                    var c = vp.GetBoxCenter();
                    vps.Add(new Dictionary<string, object?>()
                    {
                        ["viewport_id"] = vp.Id.Value,
                        ["view_id"] = view.Id.Value,
                        ["view_name"] = view.Name,
                        ["view_type"] = view.ViewType.ToString(),
                        ["scale"] = view.Scale,
                        ["detail_level"] = view.DetailLevel.ToString(),
                        ["view_template"] = (doc.GetElement(view.ViewTemplateId) as View)?.Name,
                        ["viewport_type"] = (doc.GetElement(vp.GetTypeId()) as ElementType)?.Name,
                        ["center_mm"] = new[] { Math.Round(c.X * MmPerFt), Math.Round(c.Y * MmPerFt) },
                        ["filters"] = filters,
                    });
                }

                var scheds = new List<Dictionary<string, object?>>();
                foreach (var ssi in new FilteredElementCollector(doc, sheet.Id).OfClass(typeof(ScheduleSheetInstance)).Cast<ScheduleSheetInstance>())
                {
                    if (ssi.IsTitleblockRevisionSchedule) continue;
                    scheds.Add(new Dictionary<string, object?>()
                    {
                        ["name"] = (doc.GetElement(ssi.ScheduleId) as View)?.Name,
                        ["point_mm"] = new[] { Math.Round(ssi.Point.X * MmPerFt), Math.Round(ssi.Point.Y * MmPerFt) },
                    });
                }

                var tbs = new List<Dictionary<string, object?>>();
                foreach (var tb in new FilteredElementCollector(doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks)
                             .OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>())
                {
                    var prm = new Dictionary<string, object?>();
                    foreach (Parameter par in tb.Parameters)
                    {
                        try
                        {
                            var v = RevitAgentCommandServer.GetParamDisplayValue(par);
                            if (par.Definition != null && !string.IsNullOrEmpty(v)) prm[par.Definition.Name] = v;
                        }
                        catch { }
                    }
                    tbs.Add(new Dictionary<string, object?>()
                    { ["element_id"] = tb.Id.Value, ["family"] = tb.Symbol?.FamilyName, ["type"] = tb.Symbol?.Name, ["parameters"] = prm });
                }

                return (object)new Dictionary<string, object?>()
                {
                    ["document"] = doc.Title,
                    ["sheet_id"] = sheet.Id.Value,
                    ["sheet_number"] = sheet.SheetNumber,
                    ["sheet_name"] = sheet.Name,
                    ["viewports"] = vps,
                    ["schedules"] = scheds,
                    ["titleblocks"] = tbs,
                };
            }, timeoutMs: 120000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    // ── export_views_image ──────────────────────────────────────────────────
    /// <summary>
    /// export_views_image: views als PNG naar een map. Wijzigt het model niet.
    /// params: target_document · output_dir · view_names [..] of view_types (standaard ["DraftingView","FloorPlan"])
    ///         · name_contains · pixel_size (2048)
    /// </summary>
    public static CommandResponse ExportViewsImage(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        var outDir = HandlerUtil.Str(p, "output_dir");
        if (target == null || outDir == null) return Err("Parameters 'target_document' en 'output_dir' zijn vereist");
        var viewNames = HandlerUtil.StrList(p, "view_names").ToHashSet(StringComparer.OrdinalIgnoreCase);
        var typeNames = HandlerUtil.StrList(p, "view_types").ToHashSet();
        if (typeNames.Count == 0) typeNames = new HashSet<string>() { "DraftingView", "FloorPlan" };
        var nameContains = HandlerUtil.Str(p, "name_contains");
        int pixelSize = HandlerUtil.Int(p, "pixel_size") ?? 2048;
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)Fail($"target_document '{target}' is niet open");
                Directory.CreateDirectory(outDir);
                var views = new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>()
                    .Where(v => !v.IsTemplate && v.CanBePrinted)
                    .Where(v => viewNames.Count > 0 ? viewNames.Contains(v.Name) : typeNames.Contains(v.ViewType.ToString()))
                    .Where(v => nameContains == null || v.Name.IndexOf(nameContains, StringComparison.OrdinalIgnoreCase) >= 0)
                    .OrderBy(v => v.Name).ToList();
                if (views.Count == 0) return (object)Fail("geen views gevonden met deze keuze");

                var rows = new List<Dictionary<string, object?>>();
                foreach (var v in views)
                {
                    var row = new Dictionary<string, object?>() { ["view"] = v.Name, ["type"] = v.ViewType.ToString() };
                    try
                    {
                        var safe = string.Join("_", v.Name.Split(Path.GetInvalidFileNameChars()));
                        var before = Directory.GetFiles(outDir, "*.png").ToHashSet();
                        var opts = new ImageExportOptions()
                        {
                            ExportRange = ExportRange.SetOfViews,
                            FilePath = Path.Combine(outDir, safe),
                            HLRandWFViewsFileType = ImageFileType.PNG,
                            ShadowViewsFileType = ImageFileType.PNG,
                            ImageResolution = ImageResolution.DPI_150,
                            ZoomType = ZoomFitType.FitToPage,
                            PixelSize = pixelSize,
                        };
                        opts.SetViewsAndSheets(new List<ElementId>() { v.Id });
                        doc.ExportImage(opts);
                        var created = Directory.GetFiles(outDir, "*.png").Where(f => !before.Contains(f)).ToList();
                        row["files"] = created.Select(Path.GetFileName).ToList();
                        row["ok"] = created.Count > 0;
                    }
                    catch (Exception ex) { row["error"] = ex.Message; }
                    rows.Add(row);
                }
                return (object)new Dictionary<string, object?>()
                { ["document"] = doc.Title, ["output_dir"] = outDir, ["exported"] = rows.Count(r => r.ContainsKey("ok")), ["views"] = rows };
            }, timeoutMs: 1800000);
            return Ok(result);
        }
        catch (Exception ex) { return Err($"Failed: {Unwrap(ex)}"); }
    }

    internal static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Ok(object? data) => new() { Success = true, Data = data };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static string Unwrap(Exception ex) => ex.InnerException?.Message ?? ex.Message;
}
