using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// enum_nested_families — recursive inventory of the families NESTED inside loadable families
/// (e.g. which sub-families live inside a stair family).
/// Read-only: no transaction, no LoadFamily.
///
/// Per family it opens an edit doc (doc.EditFamily), collects the Family elements inside it
/// (FEC.OfClass(Family) = the nested/loaded families), records each (parent -> nested) edge, and recurses
/// into each nested family. A visited-set (by family name) walks a shared nested family's SUBTREE only
/// once (shared families recur across many parents — without this the walk explodes / never ends on a
/// cycle), but EVERY occurrence edge is still recorded so the tree stays complete. A depth cap bounds the
/// walk. EditFamily is logged BEFORE the call (a family whose definition triggers a blocking dialog hangs
/// the app and never throws — the log survives the hang for diagnosis, same as enum_family_parameters).
/// Each edit doc is closed with Close(false).
///
/// params: target_document; families:[names] | family_ids:[ints] | scan_all; max_depth (default 5).
/// </summary>
public static class EnumNestedFamiliesHandlers
{
    public static CommandResponse EnumNestedFamilies(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool scanAll = GetBool(p, "scan_all", false);
        var famWhitelist = GetStringList(p, "families");
        var famIds = GetIntList(p, "family_ids");
        int maxDepth = GetInt(p, "max_depth", 5);
        if ((famWhitelist == null || famWhitelist.Count == 0)
            && (famIds == null || famIds.Count == 0) && !scanAll)
            return Err("provide 'families' (names), 'family_ids', or set scan_all=true");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var roots = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>()
                    .Where(f => f.IsValidObject && !f.IsInPlace && f.IsEditable);
                if (famWhitelist != null && famWhitelist.Count > 0)
                {
                    var want = famWhitelist.Select(n => n.Trim().ToLowerInvariant()).ToHashSet();
                    roots = roots.Where(f => want.Contains(f.Name.ToLowerInvariant()));
                }
                else if (famIds != null && famIds.Count > 0)
                {
                    var wantIds = famIds.ToHashSet();
                    roots = roots.Where(f => wantIds.Contains(RevitIdUtil.Fid(f.Id)));
                }

                var relations = new List<Dictionary<string, object?>>();
                var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                int opened = 0, failed = 0;

                // Auto-dismiss modal dialogs so a family whose definition pops a warning (open-warnings,
                // "Constraints are not satisfied", missing refs) on EditFamily can't block the main thread
                // and hang the bridge. Each dialog is attributed to its family; notable ones surface in the
                // response so a swallow never hides a real problem.
                using var swallow = new DialogSwallowScope(app);

                void Walk(Document parentDoc, Family fam, int depth)
                {
                    if (depth > maxDepth) return;
                    MainThreadDispatcher.Log($"enum_nested_families: editing '{fam.Name}' (depth={depth})");
                    swallow.Context = fam.Name;
                    Document? fdoc = null;
                    try
                    {
                        fdoc = parentDoc.EditFamily(fam);
                        opened++;
                        // FEC.OfClass(Family) inside the edit doc also yields the family being edited itself
                        // (empty/placeholder name) — filter it and any nameless entry so the tree is only the
                        // genuine nested families (live-verified against trap dubbelkwart).
                        var nested = new FilteredElementCollector(fdoc).OfClass(typeof(Family)).Cast<Family>()
                            .Where(f => f.IsValidObject && !string.IsNullOrWhiteSpace(f.Name)
                                        && !f.Name.Equals(fam.Name, StringComparison.OrdinalIgnoreCase))
                            .ToList();
                        foreach (var nf in nested)
                        {
                            bool editable = nf.IsEditable && !nf.IsInPlace;
                            relations.Add(new Dictionary<string, object?>
                            {
                                ["parent"] = fam.Name,
                                ["parent_category"] = fam.FamilyCategory?.Name ?? "",
                                ["depth"] = depth + 1,
                                ["nested"] = nf.Name,
                                ["nested_category"] = nf.FamilyCategory?.Name ?? "",
                                ["nested_id_in_parent"] = RevitIdUtil.Fid(nf.Id),
                                ["editable"] = editable,
                            });
                            // Recurse a given nested-family name's subtree only ONCE (shared families reused
                            // across parents); the edge above is still recorded for every occurrence.
                            if (editable && visited.Add(nf.Name))
                                Walk(fdoc, nf, depth + 1);
                        }
                        fdoc.Close(false);
                    }
                    catch (Exception ex)
                    {
                        failed++;
                        relations.Add(new Dictionary<string, object?>
                        { ["family"] = fam.Name, ["depth"] = depth, ["error"] = ex.Message });
                        try { fdoc?.Close(false); } catch { }
                    }
                }

                foreach (var root in roots.ToList())
                {
                    visited.Add(root.Name);
                    Walk(doc, root, 0);
                }

                var outDict = new Dictionary<string, object?>
                {
                    ["document"] = doc.Title,
                    ["families_opened"] = opened,
                    ["families_failed"] = failed,
                    ["max_depth"] = maxDepth,
                    ["relation_count"] = relations.Count,
                    ["relations"] = relations,
                };
                swallow.WriteTo(outDict);
                return (object)outDict;
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    // ── helpers (self-contained) ─────────────────────────────────────────
    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static int GetInt(Dictionary<string, JsonElement>? p, string key, int dflt)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Number
            && el.TryGetInt32(out var v)) return v;
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }

    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String)
                     .Select(x => x.GetString()!).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
        return null;
    }

    private static List<int>? GetIntList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.Number && x.TryGetInt32(out _))
                     .Select(x => x.GetInt32()).ToList();
        return null;
    }
}
