using System.Text.Json;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitAgent.Addin;

/// <summary>
/// Write-back handlers — the bridge's first mutating capability.
/// Read-only patterns A-F stay untouched; renames live here, gated by an always-save-first backup.
///
/// rename_element params:
///   renames    : [{ "element_id": int, "new_name": string }]   (batch; preferred)
///   element_id + new_name                                       (single; convenience)
///   dry_run    : bool (default true) — validate + report, geen save/transaction
///   save_first : bool (default false) — doc.Save vóór rename; Revit maakt automatisch een
///                genummerde backup (.NNNN.rvt). Mislukt de save -> renames worden NIET toegepast
///                (geen mutatie zonder backup). Een doc zonder save-pad faalt hier bewust.
/// </summary>
public static class WriteHandlers
{
    public record RenameSpec(int ElementId, string NewName, string? ExpectedName = null);

    public static CommandResponse RenameElements(CommandRequest request)
    {
        var p = request.Params;
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        string? target = GetString(p, "target_document");  // scope to one doc by Title (id-collision guard)

        var specs = new List<RenameSpec>();
        if (p != null && p.TryGetValue("renames", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in arr.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object) continue;
                if (!item.TryGetProperty("element_id", out var idEl)) continue;
                if (!item.TryGetProperty("new_name", out var nmEl)) continue;
                var nm = nmEl.GetString();
                if (string.IsNullOrWhiteSpace(nm)) continue;
                string? exp = item.TryGetProperty("expected_name", out var exEl) ? exEl.GetString() : null;
                specs.Add(new RenameSpec(idEl.GetInt32(), nm, exp));
            }
        }
        else if (p != null && p.TryGetValue("element_id", out var sidEl) && p.TryGetValue("new_name", out var snmEl))
        {
            var nm = snmEl.GetString();
            string? exp = p.TryGetValue("expected_name", out var exEl2) ? exEl2.GetString() : null;
            if (!string.IsNullOrWhiteSpace(nm))
                specs.Add(new RenameSpec(sidEl.GetInt32(), nm, exp));
        }

        if (specs.Count == 0)
            return new CommandResponse
            {
                Success = false,
                Error = "No valid renames (need 'renames':[{element_id,new_name[,expected_name]}] or element_id+new_name)"
            };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var results = new List<Dictionary<string, object?>>();
                var savedDocs = new List<string>();
                var handled = new HashSet<int>();

                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;  // doc-scope guard

                    var inDoc = new List<(RenameSpec spec, Element elem)>();
                    foreach (var s in specs)
                    {
                        if (handled.Contains(s.ElementId)) continue;
                        var elem = doc.GetElement(new ElementId((long)s.ElementId));
                        if (elem != null && elem.IsValidObject)
                            inDoc.Add((s, elem));
                    }
                    if (inDoc.Count == 0) continue;

                    // Classify before touching the model. stale = current name != expected_name (the
                    // id resolved to a different element than the caller intended — never rename it).
                    bool IsStale((RenameSpec spec, Element elem) x) =>
                        x.spec.ExpectedName != null && x.elem.Name != x.spec.ExpectedName;
                    bool WillChange((RenameSpec spec, Element elem) x) =>
                        !IsStale(x) && x.elem.Name != x.spec.NewName;
                    bool actionable = inDoc.Any(WillChange);

                    if (dryRun)
                    {
                        foreach (var x in inDoc)
                        {
                            handled.Add(x.spec.ElementId);
                            var status = IsStale(x) ? "stale_id" : (x.elem.Name == x.spec.NewName ? "unchanged" : "would_rename");
                            var err = IsStale(x) ? $"current '{x.elem.Name}' != expected '{x.spec.ExpectedName}'" : null;
                            results.Add(Row(x.spec, x.elem.Name, status, err, doc.Title));
                        }
                        continue;
                    }

                    // Backup gate: save first (Revit writes a numbered backup). Only when something
                    // will actually change — no needless backup churn for an all-stale/unchanged doc.
                    if (saveFirst && actionable)
                    {
                        try
                        {
                            doc.Save();
                            savedDocs.Add(doc.Title);
                        }
                        catch (Exception ex)
                        {
                            foreach (var x in inDoc)
                            {
                                handled.Add(x.spec.ElementId);
                                results.Add(Row(x.spec, x.elem.Name, "save_failed", ex.Message, doc.Title));
                            }
                            continue;
                        }
                    }

                    Transaction? t = actionable ? new Transaction(doc, "NLRS rename") : null;
                    t?.Start();
                    foreach (var x in inDoc)
                    {
                        handled.Add(x.spec.ElementId);
                        var oldName = x.elem.Name;
                        if (IsStale(x))
                        {
                            results.Add(Row(x.spec, oldName, "stale_id",
                                            $"current '{oldName}' != expected '{x.spec.ExpectedName}'", doc.Title));
                            continue;
                        }
                        if (oldName == x.spec.NewName)
                        {
                            results.Add(Row(x.spec, oldName, "unchanged", null, doc.Title));
                            continue;
                        }
                        try
                        {
                            // AssemblyInstance draagt zijn naam op het TYPE ("This element does not
                            // support assignment of a user-specified name"):
                            // hernoem dan het AssemblyType-element in plaats van de instantie.
                            if (x.elem is AssemblyInstance asmX
                                && doc.GetElement(asmX.GetTypeId()) is { } asmType)
                                asmType.Name = x.spec.NewName;
                            else
                                x.elem.Name = x.spec.NewName;
                            // Revit silently no-ops a case-only rename (names are case-insensitive): the
                            // setter neither changes the name nor throws. Verify the change actually took
                            // instead of trusting the absence of an exception (no false "renamed").
                            var after = x.elem.Name;
                            if (after == x.spec.NewName)
                                results.Add(Row(x.spec, oldName, "renamed", null, doc.Title));
                            else
                                results.Add(Row(x.spec, oldName, "noop",
                                    $"naam onveranderd na rename (Revit weigerde stil — bv case-only): nog '{after}'", doc.Title));
                        }
                        catch (Exception ex)
                        {
                            // collision, read-only name, invalid chars, … — surface per element, keep going.
                            results.Add(Row(x.spec, oldName, "error", ex.Message, doc.Title));
                        }
                    }
                    t?.Commit();
                }

                foreach (var s in specs)
                    if (!handled.Contains(s.ElementId))
                        results.Add(Row(s, null, "not_found", null, null));

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["save_first"] = saveFirst,
                    ["target_document"] = target,
                    ["saved_documents"] = savedDocs,
                    ["count"] = results.Count,
                    ["renamed"] = results.Count(r => (string?)r["status"] == "renamed"),
                    ["stale"] = results.Count(r => (string?)r["status"] == "stale_id"),
                    ["errors"] = results.Count(r => (string?)r["status"] is "error" or "save_failed"),
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Row(RenameSpec s, string? oldName, string status, string? error, string? doc) => new()
    {
        ["element_id"] = s.ElementId,
        ["old_name"] = oldName,
        ["new_name"] = s.NewName,
        ["status"] = status,
        ["error"] = error,
        ["document"] = doc
    };

    public record DeleteSpec(int ElementId, string? ExpectedName = null);

    /// <summary>
    /// delete_element — remove elements from the model (NLRS remediation status="delete").
    /// Same backup-gate as rename: doc.Save first (numbered backup) before any mutation. doc.Delete
    /// also removes dependent elements — the returned count reflects everything Revit removed.
    /// Safety: pass expected_name per element so a stale/colliding id (resolving
    /// to a different element than intended) is SKIPPED as stale_id instead of deleting the wrong thing;
    /// target_document scopes to one open doc by Title.
    ///   deletes    : [{element_id[, expected_name]}]  |  element_ids:[int]  |  element_id:int
    ///   dry_run/save_first : bool                      |  target_document : string
    /// </summary>
    public static CommandResponse DeleteElements(CommandRequest request)
    {
        var p = request.Params;
        bool dryRun = GetBool(p, "dry_run", true);
        bool saveFirst = GetBool(p, "save_first", false);
        string? target = GetString(p, "target_document");

        var specs = new List<DeleteSpec>();
        if (p != null && p.TryGetValue("deletes", out var darr) && darr.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in darr.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object) continue;
                if (!item.TryGetProperty("element_id", out var idEl) || idEl.ValueKind != JsonValueKind.Number) continue;
                string? exp = item.TryGetProperty("expected_name", out var exEl) ? exEl.GetString() : null;
                specs.Add(new DeleteSpec(idEl.GetInt32(), exp));
            }
        }
        else if (p != null && p.TryGetValue("element_ids", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in arr.EnumerateArray())
                if (item.ValueKind == JsonValueKind.Number) specs.Add(new DeleteSpec(item.GetInt32()));
        }
        else if (p != null && p.TryGetValue("element_id", out var sid) && sid.ValueKind == JsonValueKind.Number)
        {
            specs.Add(new DeleteSpec(sid.GetInt32()));
        }

        if (specs.Count == 0)
            return new CommandResponse
            {
                Success = false,
                Error = "No valid deletes (need 'deletes':[{element_id[,expected_name]}], 'element_ids':[int], or element_id)"
            };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                var results = new List<Dictionary<string, object?>>();
                var savedDocs = new List<string>();
                var handled = new HashSet<int>();

                foreach (Document doc in app.Application.Documents)
                {
                    if (target != null && doc.Title != target) continue;  // doc-scope guard

                    var inDoc = new List<(DeleteSpec spec, Element elem)>();
                    foreach (var s in specs)
                    {
                        if (handled.Contains(s.ElementId)) continue;
                        var elem = doc.GetElement(new ElementId((long)s.ElementId));
                        if (elem != null && elem.IsValidObject)
                            inDoc.Add((s, elem));
                    }
                    if (inDoc.Count == 0) continue;

                    bool IsStale((DeleteSpec spec, Element elem) x) =>
                        x.spec.ExpectedName != null && x.elem.Name != x.spec.ExpectedName;
                    bool actionable = inDoc.Any(x => !IsStale(x));

                    if (dryRun)
                    {
                        foreach (var x in inDoc)
                        {
                            handled.Add(x.spec.ElementId);
                            var status = IsStale(x) ? "stale_id" : "would_delete";
                            var err = IsStale(x) ? $"current '{x.elem.Name}' != expected '{x.spec.ExpectedName}'" : null;
                            results.Add(DRow(x.spec.ElementId, x.elem.Name, status, err, doc.Title));
                        }
                        continue;
                    }

                    if (saveFirst && actionable)
                    {
                        try
                        {
                            doc.Save();
                            savedDocs.Add(doc.Title);
                        }
                        catch (Exception ex)
                        {
                            foreach (var x in inDoc)
                            {
                                handled.Add(x.spec.ElementId);
                                results.Add(DRow(x.spec.ElementId, x.elem.Name, "save_failed", ex.Message, doc.Title));
                            }
                            continue;
                        }
                    }

                    Transaction? t = actionable ? new Transaction(doc, "NLRS delete") : null;
                    t?.Start();
                    foreach (var x in inDoc)
                    {
                        handled.Add(x.spec.ElementId);
                        var nm = x.elem.Name;
                        if (IsStale(x))
                        {
                            results.Add(DRow(x.spec.ElementId, nm, "stale_id",
                                             $"current '{nm}' != expected '{x.spec.ExpectedName}'", doc.Title));
                            continue;
                        }
                        try
                        {
                            var deleted = doc.Delete(new ElementId((long)x.spec.ElementId));
                            var n = deleted?.Count ?? 0;
                            // Surface the cascade instead of discarding it: n counts
                            // every element Revit removed (the target + its dependents). dependent_ids are
                            // the collateral ids beyond the requested element — the invisible cascade made
                            // visible so view-integrity is auditable without a backup-diff.
                            var depIds = deleted == null
                                ? new List<int>()
                                : deleted.Where(id => id.Value != x.spec.ElementId)
                                         .Select(id => RevitIdUtil.Fid(id)).ToList();
                            var drow = DRow(x.spec.ElementId, nm, n > 0 ? "deleted" : "not_deleted",
                                            n > 0 ? null : "Revit removed 0 elements", doc.Title);
                            drow["cascade_count"] = n;
                            drow["dependent_count"] = depIds.Count;
                            drow["dependent_ids"] = depIds;
                            results.Add(drow);
                        }
                        catch (Exception ex)
                        {
                            // pinned / read-only / dependency-locked — surface per element, keep going.
                            results.Add(DRow(x.spec.ElementId, nm, "error", ex.Message, doc.Title));
                        }
                    }
                    t?.Commit();
                }

                foreach (var s in specs)
                    if (!handled.Contains(s.ElementId))
                        results.Add(DRow(s.ElementId, null, "not_found", null, null));

                return (object)new Dictionary<string, object?>
                {
                    ["dry_run"] = dryRun,
                    ["save_first"] = saveFirst,
                    ["target_document"] = target,
                    ["saved_documents"] = savedDocs,
                    ["count"] = results.Count,
                    ["deleted"] = results.Count(r => (string?)r["status"] == "deleted"),
                    ["stale"] = results.Count(r => (string?)r["status"] == "stale_id"),
                    ["errors"] = results.Count(r => (string?)r["status"] is "error" or "save_failed"),
                    ["total_cascade"] = results.Where(r => r.ContainsKey("cascade_count"))
                                               .Sum(r => (int)(r["cascade_count"] ?? 0)),
                    ["results"] = results
                };
            }, timeoutMs: 180000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> DRow(int id, string? name, string status, string? error, string? doc) => new()
    {
        ["element_id"] = id,
        ["name"] = name,
        ["status"] = status,
        ["error"] = error,
        ["document"] = doc
    };

    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }

    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String)
        {
            var s = el.GetString();
            return string.IsNullOrWhiteSpace(s) ? null : s;
        }
        return null;
    }
}
