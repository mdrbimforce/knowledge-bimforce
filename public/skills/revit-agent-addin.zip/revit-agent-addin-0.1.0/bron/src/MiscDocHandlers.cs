using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// Kleine document-hulpcommando's:
///
/// query_category_instances — element-stubs van model-instanties per BuiltInCategory (taalonafhankelijk).
///   params: target_document, categories:["OST_Walls","OST_Doors","OST_GenericModel",...], include_types (default false)
///   -> elements:[{element_id, category, name, type_name, level_id, host_id}]
///
/// save_document_as — Document.SaveAs naar een pad (nieuw project zonder pad, of kopie).
///   params: target_document (verplicht), path (.rvt), overwrite (default false), compact (default true)
/// </summary>
public static class MiscDocHandlers
{
    public static CommandResponse QueryCategoryInstances(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        var cats = GetStringList(p, "categories") ?? new List<string>();
        bool includeTypes = GetBool(p, "include_types", false);
        if (cats.Count == 0) return Err("categories:[\"OST_...\"] is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                var elements = new List<Dictionary<string, object?>>();
                var unknown = new List<string>();
                foreach (var cn in cats)
                {
                    if (!Enum.TryParse<BuiltInCategory>(cn, true, out var bic)) { unknown.Add(cn); continue; }
                    var col = new FilteredElementCollector(doc).OfCategory(bic);
                    col = includeTypes ? col.WhereElementIsElementType() : col.WhereElementIsNotElementType();
                    foreach (var e in col)
                    {
                        string? typeName = null; long? levelId = null, hostId = null;
                        try { var t = doc.GetElement(e.GetTypeId()); typeName = t?.Name; } catch { }
                        try { if (e.LevelId != null && e.LevelId != ElementId.InvalidElementId) levelId = e.LevelId.Value; } catch { }
                        try { if (e is FamilyInstance fi && fi.Host != null) hostId = fi.Host.Id.Value; } catch { }
                        // isolatie/lining hangt niet via Host maar via HostElementId aan zijn leiding of fitting (
                        // een filter op host_id vond daardoor stil nul isolaties)
                        try
                        {
                            if (hostId == null && e is Autodesk.Revit.DB.InsulationLiningBase ilb
                                && ilb.HostElementId != ElementId.InvalidElementId) hostId = ilb.HostElementId.Value;
                        }
                        catch { }
                        elements.Add(new Dictionary<string, object?>
                        {
                            ["element_id"] = e.Id.Value, ["category"] = cn, ["revit_class"] = e.GetType().Name,
                            ["name"] = e.Name, ["type_name"] = typeName, ["level_id"] = levelId, ["host_id"] = hostId,
                        });
                    }
                }
                return (object)new Dictionary<string, object?>
                { ["document"] = doc.Title, ["count"] = elements.Count, ["unknown_categories"] = unknown, ["elements"] = elements };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    public static CommandResponse SaveDocumentAs(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? path = GetString(p, "path");
        bool overwrite = GetBool(p, "overwrite", false);   // een bestaand bestand alleen overschrijven als dat gevraagd is
        bool compact = GetBool(p, "compact", true);
        if (string.IsNullOrWhiteSpace(target)) return Err("'target_document' is required");   // anders het eerste open model
        if (string.IsNullOrWhiteSpace(path)) return Err("'path' is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                if (File.Exists(path) && !overwrite) return (object)Fail($"bestaat al: {path}");
                Directory.CreateDirectory(Path.GetDirectoryName(path!)!);
                MainThreadDispatcher.Log($"save_document_as: '{doc.Title}' -> {path}");
                doc.SaveAs(path, new SaveAsOptions { OverwriteExistingFile = overwrite, Compact = compact });
                return (object)new Dictionary<string, object?>
                { ["saved"] = true, ["document"] = doc.Title, ["path"] = doc.PathName, ["bytes"] = new FileInfo(path!).Length };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }


    /// <summary>get_worksets — alleen lezen: user-worksets van een open document met open/dicht-status.
    /// Worksets zijn via de API niet te openen op
    /// een al open document; dit commando toont of een heropen (open_document_ui, alle worksets) nodig is.
    /// params: target_document (verplicht).</summary>
    public static CommandResponse GetWorksets(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        if (string.IsNullOrWhiteSpace(target)) return Err("'target_document' is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (d.Title == target) { doc = d; break; } }
                if (doc == null) return (object)Fail("no matching open document");
                if (!doc.IsWorkshared)
                    return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["workshared"] = false, ["worksets"] = new List<object>(), ["dicht"] = 0 };
                var rows = new List<Dictionary<string, object?>>();
                foreach (var w in new FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset))
                    rows.Add(new Dictionary<string, object?>
                    {
                        ["id"] = w.Id.IntegerValue, ["name"] = w.Name, ["open"] = w.IsOpen, ["editable"] = w.IsEditable,
                        ["owner"] = w.Owner, ["default_visible"] = w.IsVisibleByDefault,
                    });
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["workshared"] = true, ["central_path"] = doc.GetWorksharingCentralModelPath() is { } cp ? ModelPathUtils.ConvertModelPathToUserVisiblePath(cp) : null,
                    ["worksets"] = rows, ["dicht"] = rows.Count(r => r["open"] is false), ["totaal"] = rows.Count,
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return Err($"Failed: {ex.InnerException?.Message ?? ex.Message}"); }
    }

    /// <summary>close_document — sluit een open document op Title zonder opslaan (stray edit-docs na een mislukte EditFamily).
    /// params: target_document (verplicht), save (default false). Weigert het actieve UI-document.</summary>
    public static CommandResponse CloseDocument(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        bool save = GetBool(p, "save", false);
        if (string.IsNullOrWhiteSpace(target)) return Err("'target_document' is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (d.Title == target) { doc = d; break; } }
                if (doc == null) return (object)Fail("no matching open document");
                try { if (app.ActiveUIDocument?.Document?.Equals(doc) == true) return (object)Fail("document is actief in de UI; sluit het handmatig"); } catch { }
                MainThreadDispatcher.Log($"close_document: '{doc.Title}' save={save}");
                bool okc = doc.Close(save);
                return (object)new Dictionary<string, object?> { ["closed"] = okc, ["document"] = target, ["saved"] = save };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }


    private class FamLoadOpts : IFamilyLoadOptions
    {
        public bool Overwrite = true;
        public bool SharedFromProject = false;   // shared_source=project: geneste gedeelde families uit het project gebruiken
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues) { overwriteParameterValues = Overwrite; return true; }
        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        { source = SharedFromProject ? FamilySource.Project : FamilySource.Family; overwriteParameterValues = Overwrite; return true; }
    }

    /// <summary>Failure-afhandeling bij LoadFamily: warnings weg, errors met een resolutie (bv. "Les contraintes
    /// ne sont pas satisfaites" -> Supprimer les contraintes) oplossen zoals een gebruiker in de UI zou doen, en alles rapporteren.</summary>
    internal sealed class LoadFailurePreprocessor : IFailuresPreprocessor
    {
        public readonly List<string> Messages = new();
        public bool Resolve = true;
        public FailureProcessingResult PreprocessFailures(FailuresAccessor fa)
        {
            bool resolved = false;
            foreach (var f in fa.GetFailureMessages())
            {
                string desc; try { desc = f.GetDescriptionText(); } catch { desc = "?"; }
                FailureSeverity sev; try { sev = f.GetSeverity(); } catch { sev = FailureSeverity.Error; }
                if (sev == FailureSeverity.Warning) { Messages.Add("warning: " + desc); try { fa.DeleteWarning(f); } catch { } }
                else if (Resolve && f.HasResolutions())
                {
                    string res; try { res = f.GetCurrentResolutionType().ToString(); } catch { res = "?"; }
                    try { fa.ResolveFailure(f); resolved = true; Messages.Add($"error resolved ({res}): {desc}"); }
                    catch (Exception ex) { Messages.Add($"error (resolve failed: {ex.Message}): {desc}"); return FailureProcessingResult.ProceedWithRollBack; }
                }
                else { Messages.Add("error: " + desc); return FailureProcessingResult.ProceedWithRollBack; }
            }
            return resolved ? FailureProcessingResult.ProceedWithCommit : FailureProcessingResult.Continue;
        }
    }

    private static int CommonPrefix(string a, string b)
    {
        int n = Math.Min(a.Length, b.Length), i = 0;
        while (i < n && char.ToLowerInvariant(a[i]) == char.ToLowerInvariant(b[i])) i++;
        return i;
    }

    /// <summary>load_family — laad een .rfa van schijf in het project of in een open family-doc (Document.LoadFamily), met of zonder
    /// overschrijven van parameterwaarden. params: target_document, path, overwrite_values (default true), shared_source
    /// ("family"|"project"), resolve_failures (default true: warnings weg, errors met resolutie oplossen), purge_stale_types
    /// (default false: types van de geladen family die niet in de rfa zitten -> instanties omhangen naar het best passende
    /// type en verwijderen; tegen dubbele typen na een typenaam-wijziging), dry_run (default true).
    /// Let op: Revit geeft stil false als de rfa sinds de vorige load in dit document niet veranderd is ("al up-to-date").</summary>
    public static CommandResponse LoadFamily(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? path = GetString(p, "path");
        bool overwrite = GetBool(p, "overwrite_values", true);
        bool sharedProj = string.Equals(GetString(p, "shared_source"), "project", StringComparison.OrdinalIgnoreCase);
        bool resolve = GetBool(p, "resolve_failures", true);
        bool purge = GetBool(p, "purge_stale_types", false);
        bool purgeOnly = GetBool(p, "purge_only", false);   // geen LoadFamily, alleen typen opruimen t.o.v. de rfa
        var typeMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);   // oud type -> nieuw type (instanties omhangen)
        if (p != null && p.TryGetValue("type_map", out var tm) && tm.ValueKind == JsonValueKind.Object)
            foreach (var kv in tm.EnumerateObject()) if (kv.Value.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(kv.Value.GetString())) typeMap[kv.Name] = kv.Value.GetString()!;
        bool dryRun = GetBool(p, "dry_run", true);
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return Err($"'path' ontbreekt of bestaat niet: {path}");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                if (dryRun) return (object)new Dictionary<string, object?> { ["status"] = "would_load", ["path"] = path, ["overwrite_values"] = overwrite };
                string famName = Path.GetFileNameWithoutExtension(path);
                MainThreadDispatcher.Log($"load_family: {path} -> '{doc.Title}' overwrite={overwrite} shared={(sharedProj ? "project" : "family")}");
                using var swallow = new DialogSwallowScope(app);
                swallow.BlindOkForTextless = true; swallow.Context = famName;
                var pre = new LoadFailurePreprocessor { Resolve = resolve };
                bool okl = purgeOnly;
                if (!purgeOnly)
                    using (var t = new Transaction(doc, "Revit Agent: load family"))
                    {
                        t.Start();
                        try { t.SetFailureHandlingOptions(t.GetFailureHandlingOptions().SetFailuresPreprocessor(pre).SetClearAfterRollback(true)); } catch { }
                        okl = doc.LoadFamily(path, new FamLoadOpts { Overwrite = overwrite, SharedFromProject = sharedProj }, out Family? _);
                        var st = t.Commit();
                        if (st != TransactionStatus.Committed) okl = false;
                    }
                if (purgeOnly) purge = true;
                Family? fam = new FilteredElementCollector(doc).OfClass(typeof(Family)).Cast<Family>().FirstOrDefault(f => string.Equals(f.Name, famName, StringComparison.OrdinalIgnoreCase));
                var purged = new List<Dictionary<string, object?>>();
                if (okl && purge && fam != null)
                {
                    var rfaTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    Document? rdoc = null;
                    try { rdoc = app.Application.OpenDocumentFile(path); foreach (FamilyType ft in rdoc.FamilyManager.Types) rfaTypes.Add(ft.Name); }
                    catch (Exception ex) { purged.Add(new Dictionary<string, object?> { ["status"] = "error", ["error"] = "rfa types lezen: " + ex.Message }); }
                    finally { try { rdoc?.Close(false); } catch { } }
                    if (rfaTypes.Count > 0)
                    {
                        using var t2 = new Transaction(doc, "Revit Agent: purge stale types");
                        t2.Start();
                        var syms = fam.GetFamilySymbolIds().Select(id => doc.GetElement(id) as FamilySymbol).Where(s2 => s2 != null).Cast<FamilySymbol>().ToList();
                        var keep = syms.Where(s2 => rfaTypes.Contains(s2.Name)).ToList();
                        foreach (var s2 in syms.Where(s2 => !rfaTypes.Contains(s2.Name)).ToList())
                        {
                            if (keep.Count == 0) break;
                            var tgt = (typeMap.TryGetValue(s2.Name, out var mapped) ? keep.FirstOrDefault(k => string.Equals(k.Name, mapped, StringComparison.OrdinalIgnoreCase)) : null)
                                      ?? keep.OrderByDescending(k => CommonPrefix(k.Name, s2.Name)).First();
                            var insts = new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>().Where(i => i.Symbol != null && i.Symbol.Id == s2.Id).ToList();
                            int moved = 0, associated = 0;
                            foreach (var i in insts)
                            {
                                // in een family-doc: instantie waarvan het type aan een FamilyType-parameter hangt NIET omhangen (dat breekt de
                                // koppeling); die volgt de parameterwaarde en verdwijnt van dit type als de waarde omgaat.
                                bool assoc = false;
                                try { if (doc.IsFamilyDocument) { var tp = i.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM); assoc = tp != null && doc.FamilyManager.GetAssociatedFamilyParameter(tp) != null; } } catch { }
                                if (assoc) { associated++; continue; }
                                try { i.Symbol = tgt; moved++; } catch { }
                            }
                            var row = new Dictionary<string, object?> { ["type"] = s2.Name, ["moved_to"] = tgt.Name, ["instances"] = moved, ["associated_instances"] = associated };
                            if (associated > 0) { row["status"] = "kept_in_use_by_parameter"; purged.Add(row); continue; }
                            try { doc.Delete(s2.Id); row["status"] = "deleted"; } catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                            purged.Add(row);
                        }
                        t2.Commit();
                    }
                }
                return (object)new Dictionary<string, object?>
                {
                    ["status"] = purgeOnly ? "purge_only" : (okl ? "loaded" : "failed"), ["family"] = fam?.Name, ["path"] = path, ["shared_source"] = sharedProj ? "project" : "family",
                    ["failures"] = pre.Messages, ["purged_types"] = purged, ["notable_dialogs"] = swallow.NotableReport(),
                    ["hint"] = okl ? null : (pre.Messages.Count == 0 ? "Revit gaf false zonder failure: meestal 'rfa ongewijzigd sinds vorige load' (al up-to-date)" : null)
                };
            }, timeoutMs: 590000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    /// <summary>unbind_shared_parameters — haal de projectbinding van shared parameters weg maar houd (of maak) de
    /// SharedParameterElement-definitie (zelfde GUID, naam uit het SP-bestand), zodat families die de parameter dragen
    /// hem onder de vertaalde naam tonen zonder dat ELKE family in de categorie hem krijgt.
    /// params: target_document, guids:[...], shared_param_file (voor herstel van de definitie), dry_run (default true).</summary>
    public static CommandResponse UnbindSharedParameters(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? spf = GetString(p, "shared_param_file");
        var guids = GetStringList(p, "guids") ?? new List<string>();
        bool dryRun = GetBool(p, "dry_run", true);
        if (guids.Count == 0) return Err("guids:[...] is required");
        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents) { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");
                var spByGuid = new Dictionary<string, SharedParameterElement>(StringComparer.OrdinalIgnoreCase);
                foreach (var sp in new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>())
                { try { spByGuid[sp.GuidValue.ToString()] = sp; } catch { } }
                DefinitionFile? df = null; string? prev = null;
                if (spf != null)
                {
                    try { prev = app.Application.SharedParametersFilename; app.Application.SharedParametersFilename = spf; df = app.Application.OpenSharedParameterFile(); }
                    catch (Exception ex) { return (object)Fail($"shared_param_file: {ex.Message}"); }
                }
                var results = new List<Dictionary<string, object?>>();
                var bindings = doc.ParameterBindings;
                using (var t = new Transaction(doc, "Revit Agent: unbind shared parameters"))
                {
                    t.Start();
                    foreach (var g in guids)
                    {
                        var row = new Dictionary<string, object?> { ["guid"] = g };
                        spByGuid.TryGetValue(g, out var sp);
                        row["name_before"] = sp?.Name;
                        bool bound = sp != null && bindings.get_Item(sp.GetDefinition()) != null;
                        row["was_bound"] = bound;
                        if (dryRun) { row["status"] = bound ? "would_unbind" : (sp == null ? "would_create" : "definition_only_already"); results.Add(row); continue; }
                        try
                        {
                            if (bound) { bindings.Remove(sp!.GetDefinition()); row["unbound"] = true; }
                            // definitie nog aanwezig? anders herstellen uit SP-bestand
                            bool stillThere = sp != null && sp.IsValidObject && new FilteredElementCollector(doc).OfClass(typeof(SharedParameterElement)).Cast<SharedParameterElement>().Any(x => { try { return x.GuidValue.ToString().Equals(g, StringComparison.OrdinalIgnoreCase); } catch { return false; } });
                            if (!stillThere)
                            {
                                ExternalDefinition? ed = null;
                                if (df != null)
                                    foreach (DefinitionGroup grp in df.Groups) foreach (Definition d in grp.Definitions)
                                        if (d is ExternalDefinition e && e.GUID.ToString().Equals(g, StringComparison.OrdinalIgnoreCase)) { ed = e; break; }
                                if (ed == null) { row["status"] = "definition_lost_not_in_file"; results.Add(row); continue; }
                                var created = SharedParameterElement.Create(doc, ed);
                                row["status"] = "recreated"; row["name_after"] = created.Name;
                            }
                            else row["status"] = bound ? "unbound_definition_kept" : "definition_only_already";
                        }
                        catch (Exception ex) { row["status"] = "error"; row["error"] = ex.Message; }
                        results.Add(row);
                    }
                    if (dryRun) t.RollBack(); else t.Commit();
                }
                if (prev != null) { try { app.Application.SharedParametersFilename = prev; } catch { } }
                return (object)new Dictionary<string, object?> { ["document"] = doc.Title, ["dry_run"] = dryRun, ["results"] = results };
            }, timeoutMs: 300000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex) { return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" }; }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) return el.GetString();
        return null;
    }
    private static List<string>? GetStringList(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.Array)
            return el.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).ToList();
        return null;
    }
}
