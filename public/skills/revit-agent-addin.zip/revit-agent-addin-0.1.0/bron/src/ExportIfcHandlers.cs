using System.IO;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// export_ifc — IFC-export van een open project via IFCExportOptions (bv. IFC4 met
/// user-defined Pset-bestand per taal). doc.Export moet binnen een transactie draaien (IFC-exporter schrijft
/// IfcGUID-parameters terug); de transactie wordt na de export teruggerold zodat het model ongewijzigd blijft,
/// tenzij keep_guids=true (dan commit: IfcGUIDs blijven stabiel voor volgende exports).
///
/// params:
///   target_document   : scope op Title
///   folder, file_name : doelpad (file_name zonder .ifc)
///   ifc_version       : "IFC4" (default) | "IFC4RV" | "IFC4DTV" | "IFC2x3CV2" | "IFC2x3"
///   user_pset_file    : pad naar user-defined PropertySet-definitiebestand (optioneel)
///   view_name         : 3D-view om op te filteren (optioneel; anders hele model)
///   export_base_quantities : bool (default true)
///   export_ifc_common_psets : bool (default true)
///   export_internal_revit_psets : bool (default false)
///   keep_guids        : bool (default false)
///   config_file       : pad naar een export-setup uit de IFC-dialoog (JSON, "Save setup"). Alle enkelvoudige
///                       waarden gaan als optie mee, zoals de dialoog dat doet; zonder dit bestand kwamen er via
///                       de API geen property sets mee. De expliciete params hierboven gaan voor.
///   mapping_file      : pad naar een parametermappingtabel (Pset, property, Revit-parameter); zonder dit veld de
///                       ExportUserDefinedParameterMappingFileName uit de setup als de mapping daar aan staat. Gaat
///                       via IFCParameterTemplate.ImportPropertySetupFromFile in het sjabloon. Bekend:
///                       de oude mappingtabel (Pset, property, parameter) levert 0 property sets op (mapping_psets in
///                       het antwoord); het formaat dat dit leest is nog onbekend. Ongevaarlijk, maar nog geen oplossing.
///   dry_run           : bool (default true) — rapporteert de opties zonder te exporteren
/// </summary>
public static class ExportIfcHandlers
{
    public static CommandResponse ExportIfc(CommandRequest request)
    {
        var p = request.Params;
        string? target = GetString(p, "target_document");
        string? folder = GetString(p, "folder");
        string? fileName = GetString(p, "file_name");
        string version = (GetString(p, "ifc_version") ?? "IFC4").ToUpperInvariant();
        string? psetFile = GetString(p, "user_pset_file");
        string? viewName = GetString(p, "view_name");
        bool baseQty = GetBool(p, "export_base_quantities", true);
        bool commonPsets = GetBool(p, "export_ifc_common_psets", true);
        bool internalPsets = GetBool(p, "export_internal_revit_psets", false);
        bool keepGuids = GetBool(p, "keep_guids", false);
        bool dryRun = GetBool(p, "dry_run", true);
        string? configFile = GetString(p, "config_file");
        if (configFile != null && !File.Exists(configFile)) return Err($"config_file bestaat niet: {configFile}");
        string? mappingFile = GetString(p, "mapping_file");
        if (mappingFile != null && !File.Exists(mappingFile)) return Err($"mapping_file bestaat niet: {mappingFile}");
        bool versionGiven = GetString(p, "ifc_version") != null;
        if (string.IsNullOrWhiteSpace(folder) || string.IsNullOrWhiteSpace(fileName)) return Err("'folder' and 'file_name' are required");
        if (psetFile != null && !File.Exists(psetFile)) return Err($"user_pset_file bestaat niet: {psetFile}");

        IFCVersion ver = version switch
        {
            "IFC4" => IFCVersion.IFC4,
            "IFC4RV" => IFCVersion.IFC4RV,
            "IFC4DTV" => IFCVersion.IFC4DTV,
            "IFC2X3CV2" => IFCVersion.IFC2x3CV2,
            "IFC2X3" => IFCVersion.IFC2x3,
            _ => IFCVersion.Default,
        };
        if (ver == IFCVersion.Default) return Err($"onbekende ifc_version '{version}'");

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>
            {
                Document? doc = null;
                foreach (Document d in app.Application.Documents)
                { if (target != null && d.Title != target) continue; doc = d; break; }
                if (doc == null) return (object)Fail("no matching open document");

                // Opties eerst verzamelen (een naam mag maar een keer naar AddOption), dan in een keer toevoegen
                var named = new Dictionary<string, string>(StringComparer.Ordinal);
                var fileVersion = ver;
                if (configFile != null)
                {
                    using var cfg = JsonDocument.Parse(File.ReadAllText(configFile));
                    foreach (var prop in cfg.RootElement.EnumerateObject())
                    {
                        if (prop.Name == "Name") continue;
                        if (prop.Name == "IFCVersion")
                        {
                            if (!versionGiven && prop.Value.ValueKind == JsonValueKind.Number) fileVersion = (IFCVersion)prop.Value.GetInt32();
                            continue;
                        }
                        switch (prop.Value.ValueKind)
                        {
                            case JsonValueKind.True: named[prop.Name] = "True"; break;
                            case JsonValueKind.False: named[prop.Name] = "False"; break;
                            case JsonValueKind.Number: named[prop.Name] = prop.Value.GetRawText(); break;
                            case JsonValueKind.String: named[prop.Name] = prop.Value.GetString() ?? ""; break;
                            // ClassificationSettings en ProjectAddress: de IFC-dialoog geeft ze als JSON-tekst mee;
                            // zonder deze regel viel de NL-SfB-classificatie stil weg
                            case JsonValueKind.Object: named[prop.Name] = prop.Value.GetRawText(); break;
                        }
                    }
                }
                else
                {
                    named["ExportIFCCommonPropertySets"] = commonPsets ? "true" : "false";
                    named["ExportInternalRevitPropertySets"] = internalPsets ? "true" : "false";
                    named["ExportSchedulesAsPsets"] = "false";
                    named["ExportBoundingBox"] = "false";
                    named["IncludeSiteElevation"] = "true";
                    named["Use2DRoomBoundaryForVolume"] = "false";
                    named["UseFamilyAndTypeNameForReference"] = "true";
                }
                if (configFile == null || psetFile != null)
                {
                    named["ExportUserDefinedPsets"] = psetFile != null ? "true" : "false";
                    if (psetFile != null) named["ExportUserDefinedPsetsFileName"] = psetFile;
                }
                named["StoreIFCGUID"] = keepGuids ? "true" : "false";
                named["VisibleElementsOfCurrentView"] = viewName != null ? "true" : "false";
                named["ExportLinkedFiles"] = "false";

                bool qty = configFile != null && named.TryGetValue("ExportBaseQuantities", out var q) ? q == "True" : baseQty;
                var opts = new IFCExportOptions { FileVersion = fileVersion, ExportBaseQuantities = qty, WallAndColumnSplitting = false };
                foreach (var kv in named) opts.AddOption(kv.Key, kv.Value);

                if (viewName != null)
                {
                    var view = new FilteredElementCollector(doc).OfClass(typeof(View3D)).Cast<View3D>()
                        .FirstOrDefault(v => !v.IsTemplate && v.Name.Equals(viewName, StringComparison.OrdinalIgnoreCase));
                    if (view == null) return (object)Fail($"3D-view '{viewName}' niet gevonden");
                    opts.FilterViewId = view.Id;
                }

                string path = Path.Combine(folder!, fileName! + ".ifc");
                var info = new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["path"] = path, ["ifc_version"] = fileVersion.ToString(), ["config_file"] = configFile, ["options"] = named.Count,
                    ["user_pset_file"] = psetFile, ["view"] = viewName, ["export_base_quantities"] = baseQty,
                    ["export_ifc_common_psets"] = commonPsets, ["export_internal_revit_psets"] = internalPsets, ["keep_guids"] = keepGuids,
                    // met keep_guids blijft de transactie staan: de export wijzigt dan het model
                    ["wijzigt_model"] = keepGuids,
                };
                if (dryRun) { info["status"] = "would_export"; return (object)info; }

                Directory.CreateDirectory(folder!);
                MainThreadDispatcher.Log($"export_ifc: '{doc.Title}' -> {path} ({fileVersion})");
                using (var t = new Transaction(doc, "Revit Agent: IFC export"))
                {
                    t.Start();
                    // Revit 2025+: property sets lopen via een IFCParameterTemplate dat de dialoog als optie
                    // "PropertyMapping" meegeeft. Zonder sjabloon kwamen er via de API nul property sets mee,
                    // ook met alle opties uit de setup. Het in-session-sjabloon krijgt de vlaggen
                    // uit de setup; de transactie wordt teruggerold, dus het model houdt er niets aan over.
#if REVIT2025
                    // IFCParameterTemplate bestaat niet in de Revit 2025-API (R2025-build)
                    info["property_mapping_error"] = "IFCParameterTemplate niet beschikbaar in Revit 2025";
#else
                    try
                    {
                        var tpl = IFCParameterTemplate.GetOrCreateInSessionTemplate(doc);
                        bool Flag(string key, bool dflt) => named.TryGetValue(key, out var v) ? v.Equals("true", StringComparison.OrdinalIgnoreCase) : dflt;
                        tpl.ExportIFCCommonPropertySets = Flag("ExportIFCCommonPropertySets", commonPsets);
                        tpl.ExportRevitElementParameters = Flag("ExportInternalRevitPropertySets", internalPsets);
                        tpl.ExportRevitMaterialParameters = Flag("ExportMaterialPsets", false);
                        tpl.ExportIFCBaseQuantities = qty;
                        tpl.ExportRevitSchedules = Flag("ExportSchedulesAsPsets", false);
                        tpl.ExportUserDefinedPropertySets = Flag("ExportUserDefinedPsets", false);
                        // Mappingtabel (Pset, property, Revit-parameter): de oude optie
                        // ExportUserDefinedParameterMappingFileName leest de exporter via de API niet meer; het
                        // sjabloon kan hem wel importeren. Bron: mapping_file, of de
                        // setup als ExportUserDefinedParameterMapping aan staat.
                        string? mapFile = mappingFile;
                        if (mapFile == null && Flag("ExportUserDefinedParameterMapping", false)
                            && named.TryGetValue("ExportUserDefinedParameterMappingFileName", out var mf) && !string.IsNullOrWhiteSpace(mf))
                            mapFile = mf;
                        if (mapFile != null)
                        {
                            info["mapping_file"] = mapFile;
                            try
                            {
                                tpl.ImportPropertySetupFromFile(mapFile);
                                var tel = new Dictionary<string, object?>();
                                foreach (PropertySetupType st in Enum.GetValues(typeof(PropertySetupType)))
                                {
                                    try { tel[st.ToString()] = tpl.GetPropertySetNames(st, PropertySelectionType.All).Count; }
                                    catch (Exception ex2) { tel[st.ToString()] = ex2.Message; }
                                }
                                info["mapping_psets"] = tel;
                            }
                            catch (Exception ex) { info["mapping_error"] = ex.Message; }
                        }
                        opts.AddOption("PropertyMapping", tpl.Name);
                        info["property_mapping"] = tpl.Name;
                    }
                    catch (Exception ex) { info["property_mapping_error"] = ex.Message; }
#endif
                    bool ok;
                    try { ok = doc.Export(folder!, fileName! + ".ifc", opts); }
                    catch (Exception ex) { t.RollBack(); info["status"] = "error"; info["error"] = ex.Message; return (object)info; }
                    if (keepGuids) t.Commit(); else t.RollBack();
                    info["status"] = ok ? "exported" : "failed";
                }
                if (File.Exists(path)) info["bytes"] = new FileInfo(path).Length;
                return (object)info;
            }, timeoutMs: 3540000); // met property sets kan één verdieping tot een half uur duren
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }

    private static Dictionary<string, object?> Fail(string msg) => new() { ["error"] = msg, ["ok"] = false };
    private static CommandResponse Err(string msg) => new() { Success = false, Error = msg };
    private static bool GetBool(Dictionary<string, JsonElement>? p, string key, bool dflt)
    {
        if (p != null && p.TryGetValue(key, out var el))
        {
            if (el.ValueKind == JsonValueKind.True) return true;
            if (el.ValueKind == JsonValueKind.False) return false;
        }
        return dflt;
    }
    private static string? GetString(Dictionary<string, JsonElement>? p, string key)
    {
        if (p != null && p.TryGetValue(key, out var el) && el.ValueKind == JsonValueKind.String) return el.GetString();
        return null;
    }
}
