// Pattern C: Loadable Family workflow — three-layer access (Family / FamilySymbol / FamilyInstance)
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

public static class PatternC_Handlers
{
    // ── Query handlers ──────────────────────────────────────────────

    public static List<Dictionary<string, object?>> GetLoadableFamilies(
        Document doc, string? categoryFilter = null)
    {
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var result = new List<Dictionary<string, object?>>();

        var families = new FilteredElementCollector(doc)
            .OfClass(typeof(Family))
            .Cast<Family>()
            .Where(f => !f.IsInPlace && f.IsValidObject);

        foreach (var family in families)
        {
            var cat = ResolveFamilyCategory(family, doc);
            var catName = cat?.Name ?? "";
            if (categoryFilter != null &&
                !catName.Equals(categoryFilter, StringComparison.OrdinalIgnoreCase))
                continue;

            var (desc, model, supplier) = FamilyText(family, doc);
            result.Add(BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(family.Id), "Family",
                cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null,
                family.Name, null, owner, "C",
                categoryName: cat?.Name, familyName: family.Name,
                description: desc, model: model, supplier: supplier));
        }
        return result;
    }

    // Description + Model + Leverancier live on the TYPE (FamilySymbol), not the Family; read the first
    // symbol's so a poorly-named family ('BI deur links') can still expose its descriptive text and
    // supplier to the naming layer.
    private static (string? desc, string? model, string? supplier) FamilyText(Family family, Document doc)
    {
        try
        {
            var sid = family.GetFamilySymbolIds().FirstOrDefault();
            if (sid != null && sid != ElementId.InvalidElementId && doc.GetElement(sid) is Element sym)
                return (BasePatternHandlers.SafeText(sym, BuiltInParameter.ALL_MODEL_DESCRIPTION),
                        BasePatternHandlers.SafeText(sym, BuiltInParameter.ALL_MODEL_MODEL),
                        BasePatternHandlers.SafeSupplier(sym));
        }
        catch { }
        return (null, null, null);
    }

    public static List<Dictionary<string, object?>> GetProfileFamilies(Document doc)
    {
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var result = new List<Dictionary<string, object?>>();

        var families = new FilteredElementCollector(doc)
            .OfClass(typeof(Family))
            .Cast<Family>()
            .Where(f => !f.IsInPlace && f.IsValidObject);

        foreach (var family in families)
        {
            var cat = ResolveFamilyCategory(family, doc);
            if (cat == null) continue;
            var bic = (BuiltInCategory)cat.Id.Value;
            if (bic != BuiltInCategory.OST_ProfileFamilies) continue;

            result.Add(BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(family.Id), "Family",
                bic.ToString(),
                family.Name, null, owner, "C"));
        }
        return result;
    }

    public static List<Dictionary<string, object?>> GetFamilySymbols(
        Document doc, int? familyId = null)
    {
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var result = new List<Dictionary<string, object?>>();

        if (familyId.HasValue)
        {
            var family = doc.GetElement(new ElementId((long)familyId.Value)) as Family;
            if (family == null) return result;
            foreach (var symId in family.GetFamilySymbolIds())
            {
                var sym = doc.GetElement(symId) as FamilySymbol;
                if (sym == null) continue;
                var cat = sym.Category;
                result.Add(BasePatternHandlers.ToStub(
                    RevitIdUtil.Fid(sym.Id), "FamilySymbol",
                    cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null,
                    sym.Name, familyId.Value, owner, "C"));
            }
        }
        else
        {
            foreach (FamilySymbol sym in new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol)).Cast<FamilySymbol>().Where(s => s.IsValidObject))
            {
                var fam = sym.Family;
                var cat = sym.Category;
                int? famId = fam?.Id.Value != null ? RevitIdUtil.Fid(fam.Id) : null;
                result.Add(BasePatternHandlers.ToStub(
                    RevitIdUtil.Fid(sym.Id), "FamilySymbol",
                    cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null,
                    sym.Name, famId, owner, "C"));
            }
        }
        return result;
    }

    public static List<Dictionary<string, object?>> GetFamilyInstances(Document doc)
    {
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var result = new List<Dictionary<string, object?>>();

        foreach (FamilyInstance fi in new FilteredElementCollector(doc)
            .OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>().Where(fi => fi.IsValidObject))
        {
            var sym = fi.Symbol;
            var cat = fi.Category;
            int? symId = sym?.Id.Value != null ? RevitIdUtil.Fid(sym.Id) : null;
            result.Add(BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(fi.Id), "FamilyInstance",
                cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null,
                $"{sym?.Name ?? "?"} ({RevitIdUtil.Fid(fi.Id)})", symId, owner, "C"));
        }
        return result;
    }

    public static List<Dictionary<string, object?>> GetGenericAnnotations(Document doc)
    {
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var result = new List<Dictionary<string, object?>>();

        var families = new FilteredElementCollector(doc)
            .OfClass(typeof(Family))
            .Cast<Family>()
            .Where(f => !f.IsInPlace && f.IsValidObject);

        foreach (var family in families)
        {
            var cat = ResolveFamilyCategory(family, doc);
            if (cat == null) continue;
            var bic = (BuiltInCategory)cat.Id.Value;
            if (bic != BuiltInCategory.OST_GenericAnnotation) continue;

            result.Add(BasePatternHandlers.ToStub(
                RevitIdUtil.Fid(family.Id), "Family",
                bic.ToString(),
                family.Name, null, owner, "C"));
        }
        return result;
    }

    // ── Detail handlers ────────────────────────────────────────────

    public static Dictionary<string, object?> GetFamilyDetail(Document doc, long elementId)
    {
        var owner = BasePatternHandlers.ResolveOwner(doc);
        var family = doc.GetElement(new ElementId((long)elementId)) as Family;
        if (family == null)
            throw new ElementNotFoundException($"Family {elementId} not found");

        var cat = ResolveFamilyCategory(family, doc);
        var catName = cat?.Name;
        var catBic = cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null;
        int? catId = cat?.Id.Value != null ? RevitIdUtil.Fid(cat.Id) : null;

        var symbolIds = family.GetFamilySymbolIds();
        var symbolCount = symbolIds.Count;

        string? hostType = null;
        try { hostType = family.FamilyPlacementType.ToString(); } catch { }

        Dictionary<string, object?>? nlrsParsed = null;
        try { nlrsParsed = ParseNlrsFamilyName(family.Name); } catch { }

        var symbols = new List<Dictionary<string, object?>>();
        foreach (var symId in symbolIds)
        {
            var sym = doc.GetElement(symId) as FamilySymbol;
            if (sym == null) continue;
            symbols.Add(new Dictionary<string, object?>
            {
                ["element_id"] = RevitIdUtil.Fid(sym.Id),
                ["name"] = sym.Name,
                ["is_active"] = sym.IsActive
            });
        }

        return new Dictionary<string, object?>
        {
            ["stub"] = BasePatternHandlers.ToStub(RevitIdUtil.Fid(family.Id), "Family", catBic, family.Name, null, owner, "C"),
            ["metadata"] = new Dictionary<string, object?>
            {
                ["revit_version_introduced"] = null,
                ["revit_version_deprecated"] = null,
                ["is_system_family"] = false,
                ["is_in_place"] = false
            },
            ["properties"] = new Dictionary<string, object?>
            {
                ["family_category"] = catName,
                ["family_category_id"] = catId,
                ["is_editable"] = family.IsEditable,
                ["host_type"] = hostType,
                ["symbol_count"] = symbolCount,
                ["nlrs_position_parsed"] = nlrsParsed
            },
            ["relationships"] = new List<Dictionary<string, object?>>
            {
                new() { ["kind"] = "category",
                        ["role"] = null,
                        ["ref"] = cat != null
                            ? new Dictionary<string, object?> { ["element_id"] = RevitIdUtil.Fid(cat.Id), ["revit_class"] = "Category" }
                            : null }
            },
            ["symbols"] = symbols
        };
    }

    public static Dictionary<string, object?> GetFamilySymbolDetail(Document doc, long elementId)
    {
        var symbol = doc.GetElement(new ElementId((long)elementId)) as FamilySymbol;
        if (symbol == null)
            throw new ElementNotFoundException($"FamilySymbol {elementId} not found");

        var family = symbol.Family;
        var cat = symbol.Category;
        var catBic = cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null;
        int? familyId = family?.Id.Value != null ? RevitIdUtil.Fid(family.Id) : null;

        var typeParams = new List<Dictionary<string, object?>>();
        foreach (Parameter p in symbol.Parameters)
        {
            if (p == null || p.Definition == null) continue;
            typeParams.Add(new Dictionary<string, object?>
            {
                ["name"] = p.Definition.Name,
                ["value"] = GetParamValue(p),
                ["storage_type"] = p.StorageType.ToString(),
                ["is_read_only"] = p.IsReadOnly
            });
        }

        return new Dictionary<string, object?>
        {
            ["stub"] = BasePatternHandlers.ToStub(RevitIdUtil.Fid(symbol.Id), "FamilySymbol", catBic, symbol.Name,
                familyId, BasePatternHandlers.ResolveOwner(doc), "C"),
            ["metadata"] = new Dictionary<string, object?>
            {
                ["revit_version_introduced"] = null,
                ["revit_version_deprecated"] = null,
                ["is_system_family"] = false,
                ["is_in_place"] = false
            },
            ["properties"] = new Dictionary<string, object?>
            {
                ["family_id"] = familyId,
                ["is_active"] = symbol.IsActive,
                ["parameter_count"] = typeParams.Count
            },
            ["relationships"] = new List<Dictionary<string, object?>>
            {
                new() { ["kind"] = "parent",
                        ["role"] = null,
                        ["ref"] = familyId != null
                            ? new Dictionary<string, object?> { ["element_id"] = familyId, ["revit_class"] = "Family" }
                            : null }
            },
            ["parameters"] = typeParams
        };
    }

    public static Dictionary<string, object?> GetFamilyInstanceDetail(Document doc, long elementId)
    {
        var fi = doc.GetElement(new ElementId((long)elementId)) as FamilyInstance;
        if (fi == null)
            throw new ElementNotFoundException($"FamilyInstance {elementId} not found");

        var sym = fi.Symbol;
        var cat = fi.Category;
        var catBic = cat != null ? ((BuiltInCategory)cat.Id.Value).ToString() : null;
        int? symId = sym?.Id.Value != null ? RevitIdUtil.Fid(sym.Id) : null;

        Dictionary<string, object?>? location = null;
        try
        {
            if (fi.Location is LocationPoint lp)
            {
                var pt = lp.Point;
                location = new Dictionary<string, object?>
                {
                    ["x"] = Math.Round(pt.X * 304.8, 1),
                    ["y"] = Math.Round(pt.Y * 304.8, 1),
                    ["z"] = Math.Round(pt.Z * 304.8, 1)
                };
            }
        }
        catch { }

        int? hostId = fi.Host?.Id.Value != null ? RevitIdUtil.Fid(fi.Host.Id) : null;
        string? hostClass = fi.Host?.GetType().Name;

        int? levelId = fi.LevelId?.Value != null ? RevitIdUtil.Fid(fi.LevelId) : null;
        int? phaseCreatedId = fi.CreatedPhaseId?.Value != null ? RevitIdUtil.Fid(fi.CreatedPhaseId) : null;
        int? phaseDemolishedId = fi.DemolishedPhaseId?.Value != null ? RevitIdUtil.Fid(fi.DemolishedPhaseId) : null;

        double? rotation = null;
        try { if (fi.Location is LocationPoint lp2) rotation = Math.Round(lp2.Rotation, 4); } catch { }

        return new Dictionary<string, object?>
        {
            ["stub"] = BasePatternHandlers.ToStub(RevitIdUtil.Fid(fi.Id), "FamilyInstance", catBic,
                $"{sym?.Name ?? "?"} ({RevitIdUtil.Fid(fi.Id)})", symId, BasePatternHandlers.ResolveOwner(doc), "C"),
            ["metadata"] = new Dictionary<string, object?>
            {
                ["revit_version_introduced"] = null,
                ["revit_version_deprecated"] = null,
                ["is_system_family"] = false,
                ["is_in_place"] = false
            },
            ["properties"] = new Dictionary<string, object?>
            {
                ["symbol_id"] = symId,
                ["host_id"] = hostId,
                ["host_class"] = hostClass,
                ["location"] = location,
                ["level_id"] = levelId,
                ["phase_created_id"] = phaseCreatedId,
                ["phase_demolished_id"] = phaseDemolishedId,
                ["mirrored"] = fi.Mirrored,
                ["rotation"] = rotation
            },
            ["relationships"] = new List<Dictionary<string, object?>>
            {
                new() { ["kind"] = "parent",
                        ["role"] = null,
                        ["ref"] = symId != null
                            ? new Dictionary<string, object?> { ["element_id"] = symId, ["revit_class"] = "FamilySymbol" }
                            : null },
                new() { ["kind"] = "host",
                        ["role"] = null,
                        ["ref"] = hostId != null
                            ? new Dictionary<string, object?> { ["element_id"] = hostId, ["revit_class"] = hostClass ?? "Element" }
                            : null },
                new() { ["kind"] = "assigned_to_phase",
                        ["role"] = null,
                        ["ref"] = phaseCreatedId != null
                            ? new Dictionary<string, object?> { ["element_id"] = phaseCreatedId, ["revit_class"] = "Phase" }
                            : null }
            }
        };
    }

    // ── Dispatch ──────────────────────────────────────────────────

    public static List<Dictionary<string, object?>> Query(
        string typeId, Document doc, Dictionary<string, JsonElement>? extraParams = null)
    {
        return typeId switch
        {
            "loadable_family" => GetLoadableFamilies(doc,
                extraParams?.TryGetValue("category_filter", out var cf) == true ? cf.GetString() : null),
            "profile_families" => GetProfileFamilies(doc),
            "generic_annotations" => GetGenericAnnotations(doc),
            "family_symbol" => GetFamilySymbols(doc,
                extraParams?.TryGetValue("family_id", out var fid) == true ? fid.GetInt32() : null),
            "family_instance" => GetFamilyInstances(doc),
            _ => throw new ArgumentException($"Unknown Pattern-C type: {typeId}")
        };
    }

    public static Dictionary<string, object?> Detail(
        string typeId, Document doc, long elementId) => typeId switch
    {
        "loadable_family" => GetFamilyDetail(doc, elementId),
        "profile_families" => GetFamilyDetail(doc, elementId),
        "generic_annotations" => GetFamilyDetail(doc, elementId),
        "family_symbol" => GetFamilySymbolDetail(doc, elementId),
        "family_instance" => GetFamilyInstanceDetail(doc, elementId),
        _ => throw new NotImplementedException($"Pattern C detail for {typeId} not yet implemented")
    };

    // ── Helpers ───────────────────────────────────────────────────

    private static Category? ResolveFamilyCategory(Family family, Document doc)
    {
        var cat = family.Category;
        if (cat != null) return cat;
        var symbolIds = family.GetFamilySymbolIds();
        if (symbolIds.Count > 0)
        {
            var firstSym = doc.GetElement(symbolIds.First()) as FamilySymbol;
            cat = firstSym?.Category;
        }
        return cat;
    }

    private static Dictionary<string, object?>? ParseNlrsFamilyName(string name)
    {
        var parts = name.Split('_');
        if (parts.Length < 3) return null;

        var result = new Dictionary<string, object?>
        {
            ["raw"] = name,
            ["position_count"] = parts.Length
        };

        if (parts.Length >= 1) result["pos1_landcode"] = parts[0];
        if (parts.Length >= 2) result["pos2_classification"] = parts[1];
        if (parts.Length >= 3) result["pos3_family_category_code"] = parts[2];
        if (parts.Length >= 4) result["pos4_host_type_code"] = parts[3];
        if (parts.Length >= 5) result["pos5_description"] = parts[4];
        if (parts.Length >= 6) result["pos6_vendor"] = parts[5];
        if (parts.Length >= 7) result["pos7_content"] = parts[6];

        return result;
    }

    private static object? GetParamValue(Parameter p)
    {
        if (p == null) return null;
        try
        {
            if (p.StorageType == StorageType.Integer) return p.AsInteger();
            if (p.StorageType == StorageType.Double) return p.AsDouble();
            if (p.StorageType == StorageType.String) return p.AsString();
            if (p.StorageType == StorageType.ElementId) return RevitIdUtil.Fid(p.AsElementId());
        }
        catch { }
        return null;
    }
}
