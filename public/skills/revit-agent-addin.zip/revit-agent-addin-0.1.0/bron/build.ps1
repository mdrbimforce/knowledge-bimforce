<#
.SYNOPSIS
  Bouwt de Revit Agent-addin voor één Revit-jaar en zet het resultaat in dist\<jaar>\.

.DESCRIPTION
  Werkt vanuit zijn eigen map; er staat geen pad naar een repo in.
  Revit 2025 en 2026 bouwen met de .NET 8 SDK. Revit 2027 draait op .NET 10 en vraagt de .NET 10 SDK;
  ontbreekt die, dan stopt het script met een melding.
  Zonder -Sign tekent de build de DLL niet. Revit vraagt dan bij de eerste start of de addin geladen
  mag worden ("Always Load"). Met -Sign tekent hij de DLL met een code-signing-certificaat uit
  Cert:\CurrentUser\My; de private sleutel blijft op de bouwcomputer.

.PARAMETER RevitYear
  2025, 2026 of 2027.
.PARAMETER RevitApiDir
  Map met RevitAPI.dll en RevitAPIUI.dll. Standaard de Revit-installatie van dat jaar.
.PARAMETER Sign
  Optioneel: teken de DLL met een eigen code-signing-certificaat (onderwerp in -CertSubject).
.PARAMETER CertSubject
  Het onderwerp van het certificaat, precies zoals in Cert:\CurrentUser\My.
.PARAMETER TimestampServer
  Tijdstempelserver bij het tekenen; met een tijdstempel blijft de handtekening geldig nadat het
  certificaat verlopen is. Leeg = geen tijdstempel (werkt ook zonder internet).
.PARAMETER ExportCertificate
  Met -Sign: zet het publieke deel van het certificaat in dist\cert\revit-agent-uitgever.cer, zodat
  install.ps1 -TrustPublisher het bij een gebruiker als vertrouwde uitgever kan toevoegen.

.EXAMPLE
  .\build.ps1 -RevitYear 2026
  .\build.ps1 -RevitYear 2026 -Sign -CertSubject "CN=Mijn bedrijf, O=Mijn bedrijf" -ExportCertificate
#>
param(
    [Parameter(Mandatory = $true)][ValidateSet("2025", "2026", "2027")][string]$RevitYear,
    [string]$RevitApiDir = "",
    [switch]$Sign,
    [string]$CertSubject = "CN=Revit Agent (eigen build)",
    [string]$TimestampServer = "http://timestamp.digicert.com",
    [switch]$ExportCertificate
)
$ErrorActionPreference = "Stop"
$Hier = $PSScriptRoot
$Project = Join-Path $Hier "RevitAgent.Addin.csproj"
$Dist = Join-Path $Hier "dist\$RevitYear"
if (-not $RevitApiDir) { $RevitApiDir = "C:\Program Files\Autodesk\Revit $RevitYear\" }
if (-not $RevitApiDir.EndsWith("\")) { $RevitApiDir += "\" }

if (-not (Test-Path (Join-Path $RevitApiDir "RevitAPI.dll"))) {
    Write-Host "RevitAPI.dll niet gevonden in $RevitApiDir. Is Revit $RevitYear geinstalleerd? Geef anders -RevitApiDir mee." -ForegroundColor Red
    exit 1
}

$tfm = "net8.0-windows"
if ([int]$RevitYear -ge 2027) {
    $tfm = "net10.0-windows"
    $sdks = (& dotnet --list-sdks) -join "`n"
    if ($sdks -notmatch "(?m)^1[0-9]\.") {
        Write-Host "Revit $RevitYear draait op .NET 10; de .NET 10 SDK staat niet op deze computer (dotnet --list-sdks)." -ForegroundColor Red
        Write-Host "Installeer de .NET 10 SDK van Microsoft en draai dit script opnieuw." -ForegroundColor Red
        exit 3
    }
}

Write-Host "== Revit Agent bouwen voor Revit $RevitYear ($tfm) ==" -ForegroundColor Cyan
# Zonder slot-backslash doorgeven: "...\" ontsnapt in Windows PowerShell 5.1 het sluitende aanhalingsteken en dan
# schuift -nologo in het pad. Het project zet de backslash er zelf weer achter.
& dotnet build $Project -c Release "-p:RevitYear=$RevitYear" "-p:RevitApiDir=$($RevitApiDir.TrimEnd('\'))" -nologo
if ($LASTEXITCODE -ne 0) { Write-Host "Bouwen mislukte." -ForegroundColor Red; exit 1 }

$Uit = Join-Path $Hier "bin\$RevitYear\Release\$tfm"
$Dll = Join-Path $Uit "RevitAgent.Addin.dll"
if (-not (Test-Path $Dll)) { Write-Host "Bouwuitvoer niet gevonden: $Dll" -ForegroundColor Red; exit 1 }

if ($Sign) {
    $cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert | Where-Object Subject -eq $CertSubject | Select-Object -First 1
    if (-not $cert) { Write-Host "Geen code-signing-certificaat met onderwerp '$CertSubject' gevonden; zie de handleiding." -ForegroundColor Red; exit 1 }
    $tekenArgs = @{ Certificate = $cert; FilePath = $Dll; HashAlgorithm = "SHA256" }
    if ($TimestampServer) { $tekenArgs.TimestampServer = $TimestampServer }
    try { $handtekening = Set-AuthenticodeSignature @tekenArgs }
    catch { Write-Host "Tekenen mislukte: $($_.Exception.Message) (tijdstempelserver onbereikbaar? probeer -TimestampServer '')" -ForegroundColor Red; exit 1 }
    # Valid = getekend en het certificaat wordt op deze computer vertrouwd.
    # UnknownError = getekend met een certificaat dat hier (nog) niet vertrouwd is; bij een eigen certificaat is dat normaal.
    if ($handtekening.Status -notin @("Valid", "UnknownError") -or -not $handtekening.SignerCertificate) {
        Write-Host "Tekenen gaf status '$($handtekening.Status)': $($handtekening.StatusMessage)" -ForegroundColor Red; exit 1
    }
    $stempel = if ($handtekening.TimeStamperCertificate) { "met tijdstempel" } else { "zonder tijdstempel" }
    Write-Host "Getekend met '$CertSubject' ($stempel, status $($handtekening.Status))." -ForegroundColor Green
    if ($ExportCertificate) {
        $certMap = Join-Path $Hier "dist\cert"
        New-Item -ItemType Directory -Path $certMap -Force | Out-Null
        # Alleen het publieke certificaat (.cer); de private sleutel gaat nooit mee.
        [IO.File]::WriteAllBytes((Join-Path $certMap "revit-agent-uitgever.cer"),
            $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert))
        Write-Host "Publiek certificaat: dist\cert\revit-agent-uitgever.cer ($($cert.Thumbprint))" -ForegroundColor Green
    }
}
elseif ($ExportCertificate) { Write-Host "-ExportCertificate werkt alleen samen met -Sign." -ForegroundColor Red; exit 1 }

if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
New-Item -ItemType Directory -Path (Join-Path $Dist "RevitAgent") -Force | Out-Null
Copy-Item $Dll (Join-Path $Dist "RevitAgent\") -Force
$pdb = Join-Path $Uit "RevitAgent.Addin.pdb"
if (Test-Path $pdb) { Copy-Item $pdb (Join-Path $Dist "RevitAgent\") -Force }
Copy-Item (Join-Path $Hier "RevitAgent.addin") (Join-Path $Dist "RevitAgent.addin") -Force

Write-Host "Klaar: $Dist" -ForegroundColor Green
Get-ChildItem $Dist -Recurse -File | ForEach-Object { Write-Host ("  " + $_.FullName.Substring($Dist.Length + 1)) }
