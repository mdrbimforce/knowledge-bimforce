# Sjabloon: een eigen opdracht

Een complete handler in de stijl van de addin. Dit voorbeeld zet het commentaar (Comments) op elementen, met een proef. Kopieer het naar `bron\src\<Naam>Handlers.cs`, pas het aan, en meld de opdracht aan.

## 1. De handler

```csharp
using System.Text.Json;
using Autodesk.Revit.DB;

namespace RevitAgent.Addin;

/// <summary>
/// set_comments: het commentaar (Comments) van elementen zetten.
/// params: target_document · element_ids [..] · text · dry_run (true)
/// Antwoord: per element de oude en de nieuwe waarde, en de status.
/// </summary>
public static class CommentHandlers
{
    public static CommandResponse SetComments(CommandRequest request)
    {
        var p = request.Params;
        var target = HandlerUtil.Str(p, "target_document");
        var ids = HandlerUtil.LongList(p, "element_ids");
        var tekst = HandlerUtil.Str(p, "text") ?? "";
        bool dryRun = HandlerUtil.Bool(p, "dry_run", true);          // proef is de standaard
        if (target == null || ids.Count == 0)
            return new CommandResponse { Success = false, Error = "target_document en element_ids zijn verplicht" };

        try
        {
            var result = MainThreadDispatcher.GetResult<object>(app =>   // alles hierbinnen op de hoofdthread
            {
                var doc = HandlerUtil.FindDoc(app, target);
                if (doc == null) return (object)DocumentHandlers.Fail($"target_document '{target}' is niet open");

                var rows = new List<Dictionary<string, object?>>();
                List<string> meldingen;
                using (var t = new Transaction(doc, "Revit Agent: commentaar zetten"))
                {
                    t.Start();
                    var fv = HandlerUtil.ZetFailureVerzamelaar(t);       // waarschuwingen weg, fouten terugdraaien
                    foreach (var id in ids)
                    {
                        var row = new Dictionary<string, object?> { ["element_id"] = id };
                        rows.Add(row);
                        var el = doc.GetElement(new ElementId(id));
                        var par = el?.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
                        if (par == null || par.IsReadOnly) { row["status"] = "geen schrijfbaar commentaar"; continue; }
                        row["oud"] = par.AsString();
                        bool ok = par.Set(tekst);                        // Set kan false geven zonder exception
                        row["status"] = !ok ? "geweigerd" : dryRun ? "zou zetten" : "gezet";
                        row["nieuw"] = par.AsString();                   // teruglezen
                    }
                    meldingen = fv.Meldingen;
                    if (dryRun) t.RollBack();                            // proef: echt doen, dan terugdraaien
                    else if (t.Commit() != TransactionStatus.Committed)
                        return (object)DocumentHandlers.Fail("teruggedraaid: " + string.Join("; ", meldingen));
                }
                return (object)new Dictionary<string, object?>
                {
                    ["document"] = doc.Title, ["dry_run"] = dryRun, ["results"] = rows, ["meldingen"] = meldingen,
                };
            }, timeoutMs: 120000);
            return new CommandResponse { Success = true, Data = result };
        }
        catch (Exception ex)
        {
            return new CommandResponse { Success = false, Error = $"Failed: {ex.InnerException?.Message ?? ex.Message}" };
        }
    }
}
```

## 2. Aanmelden

In `RevitAgentCommandServer.cs`, in het blok met `Reg(...)`-regels, één regel:

```csharp
Reg("set_comments", true, true, "Het commentaar (Comments) van elementen zetten.", CommentHandlers.SetComments);
```

De vier waarden: naam, schrijft hij (true/false), kent hij `dry_run` (true/false), korte uitleg, en de handler. `list_commands` en `references/opdrachten.md` lezen deze regel.

## 3. Wat je meeneemt in elke handler

| Regel | Waarom |
|---|---|
| `target_document` verplicht en via `HandlerUtil.FindDoc` | Element-id's zijn per model. |
| `dry_run` standaard `true` | De gebruiker ziet eerst wat er gebeurt. |
| Nooit `doc.Save()` | Bewaren is aan de gebruiker. |
| Failure-preprocessor op elke transactie | Anders een modale dialoog en een stille bridge. |
| Commit-status lezen en teruglezen na schrijven | `Set` en `Commit` kunnen stil mislukken. |
| Coördinaten in mm in de JSON, intern omrekenen (304.8 mm per voet) | De gebruiker denkt in mm. |
| Een `DialogSwallowScope` om EditFamily, LoadFamily of openen | Meldingen komen in het antwoord. |
| Ruime `timeoutMs` voor zwaar werk | Anders een time-out terwijl Revit gewoon bezig is. |

## 4. Bouwen, installeren, testen

1. `build.ps1 -RevitYear <jaar>` tot de build slaagt.
2. De gebruiker sluit Revit (werk bewaren); dan `install.ps1 -RevitYear <jaar>`.
3. De gebruiker start Revit en kiest "Always Load".
4. `python scripts/revit.py opdrachten set_comments`, dan de opdracht met `"dry_run": true` op één element.
