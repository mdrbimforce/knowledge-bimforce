# Revit-API-lessen

De lessen die het vaakst tijd kostten bij het bouwen van bridge-opdrachten, voor Revit 2025 en 2026. Per les: wat je doet, en waarom.

## 1. Hoofdthread

- **Alle Revit-API-aanroepen op de hoofdthread.** De bridge ontvangt verzoeken op een eigen thread. Elke handler stuurt zijn werk via `MainThreadDispatcher.GetResult(app => ..., timeoutMs)`. Buiten die lambda raak je geen `Document`, `Element` of `Transaction` aan.
- **Eén opdracht tegelijk.** De dispatcher laat een tweede opdracht wachten tot de eerste klaar is. Loopt een opdracht over zijn tijd, dan maakt Revit hem af; de volgende wacht daarop.
- **Geef lange opdrachten een ruime time-out** (`timeoutMs`), en zet in de client een iets langere time-out. Een opdracht die nog niet begonnen was bij de time-out, wordt ingetrokken.
- **Een modale dialoog blokkeert de hoofdthread.** Dan antwoordt de bridge niet meer tot de gebruiker hem wegklikt. Voorkom dialogen (failures afvangen, zie 2) in plaats van ze achteraf weg te klikken.

## 2. Transacties en failures

- **Elke wijziging in een `Transaction`**, in een `using`-blok, met een duidelijke naam ("Revit Agent: ..."). Die naam ziet de gebruiker bij Ctrl+Z.
- **Lees de uitkomst van `Commit()`.** `TransactionStatus.Committed` is gelukt; alles anders is teruggedraaid. Meld nooit "gelukt" zonder die toets.
- **Een failure-preprocessor op elke transactie.** Waarschuwingen weg (`DeleteWarning`) en meenemen in het antwoord; bij een fout `ProceedWithRollBack`. Een preprocessor die alleen logt, laat Revit een modale dialoog tonen. Hulpje: `HandlerUtil.ZetFailureVerzamelaar(t)`.
- **`dry_run` = echt uitvoeren en terugdraaien.** Doe het werk in de transactie, lees het resultaat, en roep `RollBack()` aan. Zo is de proef eerlijk: wat Revit weigert, weigert hij ook in de proef.
- **Onafhankelijke wijzigingen in eigen transacties.** Eén fout rolt de hele transactie terug; vijftig wanden in één transactie met één fout geeft nul wanden.
- **`doc.Regenerate()` alleen binnen een transactie.** Na regeneratie kunnen objecten die je vasthield ongeldig zijn; werk met `ElementId`s en haal het element opnieuw op.
- **Een open transactie blokkeert alles daarna.** Bij een exception: `if (t.HasStarted() && !t.HasEnded()) t.RollBack();`.

## 3. Dialogen

- **`DialogBoxShowing` geeft je één kans.** Een ongeldig antwoord in `OverrideResult` gooit geen fout; Revit annuleert dan stil. Ken het antwoord per dialoog-id.
- **TaskDialogs met keuzeknoppen**: 1001 is de eerste keuze, 1002 de tweede. "Unresolved References" bij openen: 1002 ("Ignore and continue opening the project").
- **Een dialoog zonder tekst** kan een spook zijn: elk antwoord annuleert dan de lopende actie. Beantwoord hem alleen als je zeker weet wat hij is.
- **Bewaar-dialogen nooit automatisch beantwoorden.**
- **Eén eigenaar per moment.** Binnen een opdracht beslist de `DialogSwallowScope` van die opdracht; de globale handler van de addin wijkt dan.
- **Nooit stil wegklikken.** Wat weggeklikt is, komt in het antwoord (`dialogs_dismissed`, `dialogs_notable`).

## 4. Parameters en units

- **Revit rekent intern in voet** (lengte), vierkante voet en kubieke voet. Zet om met `UnitUtils.ConvertToInternalUnits(waarde, UnitTypeId.Millimeters)` en terug met `ConvertFromInternalUnits`. In de bridge zijn coördinaten in mm.
- **`Parameter.SetValueString("3000")`** gebruikt de eenheden van het project (meestal mm). Handig voor waarden die de gebruiker zo typt.
- **`Parameter.Set(...)` geeft `false` terug zonder exception** als Revit de waarde weigert. Lees altijd terug na het schrijven.
- **`LookupParameter(naam)` geeft `null`** als de parameter op het type zit of niet bestaat. Zoek eerst op de instantie, dan op het type, en meld wat ontbreekt.
- **Een type-parameter geldt voor alle instanties van dat type.** Meld vooraf hoeveel elementen het raakt.
- **Namen in Revit**: de tekens `{ } [ ] | ; < > ? ` ~ \ :` weigert Revit in veel namen. Controleer na een hernoeming de nieuwe naam.

## 5. ElementId in 2024 en later

- **`ElementId.Value` is een `long`** (sinds 2024). Gebruik `new ElementId((long)x)`; de constructor met `int` is verouderd.
- **Element-id's zijn per model.** Twee open modellen kunnen hetzelfde id hebben voor verschillende elementen. Geef altijd `target_document` mee en zoek het document op met `HandlerUtil.FindDoc`.
- **Na een kopie, reload of typewissel kunnen id's veranderen.** Bewaar `UniqueId` als je een element later terug wilt vinden.

## 6. Families

- **`FamilySymbol.Activate()` vóór plaatsing** van een type dat nog niet in het model gebruikt is.
- **Families bewerken**: `doc.EditFamily(family)` opent een familiedocument; na de wijziging `LoadFamily(doc, new FamilyLoadOptions())` terug in het project en het familiedocument sluiten zonder bewaren. Zet een `DialogSwallowScope` om dit hele traject.
- **Bij herladen** bepaalt `IFamilyLoadOptions` of parameterwaarden in het project overschreven worden. Kies bewust, en meld het.
- **"Pak de eerste" is bijna altijd fout** (eerste type, eerste titleblock, eerste level). Vraag de naam of laat de keuze aan de gebruiker.

## 7. Documenten, worksets en links

- **Een central model** (worksharing) bewaar je niet met `Save`; de gebruiker synchroniseert zelf.
- **Elementen in een gesloten workset zijn onzichtbaar** voor collectors. Open met `WorksetConfigurationOption.OpenAllWorksets` als je alles wilt zien.
- **`OpenAndActivateDocument` mag niet in elke context.** De melding "Switching active documents is not allowed" betekent: open met `OpenDocumentFile` op de achtergrond.
- **Links**: `RevitLinkType.IsLoaded(doc, id)` zegt of een link geladen is. Een link toevoegen gaat met `RevitLinkType.Create` en daarna `RevitLinkInstance.Create` (plaatsing origin of shared coordinates). Coördinaten in een link zijn link-coördinaten; zet om met `GetTotalTransform()`.

## 8. Views en sheets

- **Een view kan op één sheet staan.** Toets met `Viewport.CanAddViewToSheet`. Schedules en legends werken anders (`ScheduleSheetInstance.Create`).
- **Posities op een sheet in voet**, vanaf de oorsprong van de sheet; die valt niet altijd samen met de hoek van het titleblock.
- **View Type is iets anders dan View Template.** Een template met V/G-instellingen overschrijft wat je per view zet.
- **Viewnamen zijn niet altijd uniek** in een groot model. Zoek op id als dat kan.

## 9. Bouwen en installeren

- **Revit 2025 en 2026: .NET 8. Revit 2027: .NET 10.** Bouw per jaar tegen de `RevitAPI.dll` van dat jaar.
- **Een draaiende Revit houdt de DLL vast.** Installeren kan pas als Revit gesloten is.
- **Een ongetekende addin** laat Revit bij de start vragen of hij geladen mag worden ("Always Load"). Wie zelf tekent: een code-signing-certificaat in `Cert:\CurrentUser\My` en `build.ps1 -Sign -CertSubject "CN=..." -ExportCertificate`. Met een eigen (self-signed) certificaat verdwijnt de vraag alleen op computers die dat certificaat vertrouwen (`install.ps1 -TrustPublisher`).
- **Een exception in `OnStartup`** laat Revit de hele addin weigeren. Vang alles af wat mis kan gaan (bijvoorbeeld een bezette poort).
