# Opdrachten van de Revit Agent-addin

Gemaakt uit de broncode met `tools/opdrachten_lijst.py`; pas de code aan, niet dit bestand.
Aantal opdrachten: 101. Lezen: 40. Wijzigen of bewaren: 61.

Zo lees je de tabel:

- **Schrijft**: ja = de opdracht wijzigt een model, bewaart, sluit of maakt een bestand.
- **dry_run**: ja = de opdracht kent een proef (`"dry_run": true`). Bij bijna alle opdrachten is de proef de standaard; geef `"dry_run": false` pas na akkoord van de gebruiker.
- **Parameters**: wat de code uit het verzoek leest. `target_document` (de titel uit `get_open_documents`) werkt bij bijna elke opdracht en staat er niet steeds bij.
- Een antwoord met `"success": true` kan in `data` toch `{"error": ..., "ok": false}` hebben (bijvoorbeeld als het document niet open is). Kijk dus ook in `data`.

## Bewaren

Geen enkele opdracht bewaart uit zichzelf een model. Deze opdrachten kunnen het wel als je het vraagt, met `save_first: true` (eerst een genummerde backup), `save_after: true` of `save: true`; die staan in deze addin standaard uit (in de oudere interne addin stond `save_first` aan): `close_document`, `rename_element`, `delete_element`, `set_parameter_value`, `set_parameter_binding`, `mirror_parameter_binding`, `swap_parameter`, `couple_builtin_parameter`, `rename_nested_families`, `swap_family_parameter`, `rename_family_parameter`, `delete_family_parameter`, `set_family_formula`, `set_family_type_values`, `rename_family_materials`, `place_family_grid`, `copy_elements`, `transfer_family`, `set_material_fill_pattern`, `replace_material`, `asset_rename`, `asset_swap`, `create_views`, `assign_view_template`, `relink_type_templates`, `set_view_property`, `create_filter`, `repoint_filter_parameter`, `assign_view_filter`, `set_line_style_graphics`, `create_filled_region_type`.
Opdrachten met `rfa_path` bewerken een familiebestand op schijf en bewaren dat bestand; `export_families_to_folder` en `export_ifc` schrijven nieuwe bestanden. `save_document`, `save_document_as` en `close_document` alleen op verzoek van de gebruiker.

Standaard `dry_run` is overal waar hij bestaat `true`; bij `rename_element`, `delete_element`, `copy_elements` en `transfer_family` stond hij in de oudere interne addin op `false`.

## Alle opdrachten

| Opdracht | Schrijft | dry_run | Wat hij doet | Parameters |
|---|---|---|---|---|
| `ping` | nee | nee | Leeft de bridge? Werkt zonder token; geeft de versie van de addin. | geen |
| `list_commands` | nee | nee | Alle opdrachten met korte uitleg, of ze schrijven en of ze dry_run kennen. | geen |
| `get_info` | nee | nee | Versie en build van Revit. | geen |
| `get_diagnostics` | nee | nee | Stand van de dispatcher en de laatste logregels van de addin. | geen |
| `reset_counters` | nee | nee | Tellers en log van de dispatcher leegmaken. | geen |
| `get_open_documents` | nee | nee | Welke modellen en families staan open (titel, pad, onbewaard werk). | geen |
| `open_document` | nee | nee | Een .rvt of .rfa openen op de achtergrond (zonder venster), ook met ontbrekende links. | `path`, `worksets`, `detach`, `audit` |
| `open_document_ui` | nee | nee | Een model openen en tonen in Revit (met venster), ook met ontbrekende links. | `path`, `worksets`, `detach`, `audit` |
| `save_document` | ja | nee | Een open model bewaren. Alleen als de gebruiker erom vraagt. | geen |
| `save_document_as` | ja | nee | Een open model bewaren onder een nieuwe naam. Alleen als de gebruiker erom vraagt. | `path`, `overwrite`, `compact` |
| `close_document` | ja | nee | Een open model sluiten (standaard zonder bewaren). Alleen als de gebruiker erom vraagt. | `save` |
| `new_project` | ja | nee | Een nieuw, leeg project maken (optioneel uit een sjabloon). Wordt niet bewaard. | `template` |
| `get_worksets` | nee | nee | Worksets van een model met open/dicht. | geen |
| `list_link_instances` | nee | nee | Revit-links in een model: naam, pad, geladen of niet. | geen |
| `load_links` | ja | ja | Revit-links toevoegen uit paden of een map (plaatsing origin of shared). | `paths`, `folder`, `name_contains`, `placement`, `dry_run` |
| `reload_link` | ja | ja | Een Revit-link opnieuw laden, eventueel vanaf een ander pad. | `dry_run`, `link_titles`, `link_title` |
| `list_type_catalog` | nee | nee | De type_id's die query_elements en get_element_detail kennen. | `pattern` |
| `query_elements` | nee | nee | Alle elementen van één soort (type_id uit list_type_catalog), zoals wall_type of materials. | `type_id` |
| `get_element_detail` | nee | nee | Alle eigenschappen en parameters van één element (type_id + element_id). | `type_id`, `element_id` |
| `query_category_instances` | nee | nee | Instanties van een categorie met familie, type en gevraagde parameters. | `categories`, `include_types` |
| `get_family_instances` | nee | nee | Family-instanties met hun parameters (begrensd met limit). | `limit`, `skip_categories` |
| `get_families_loaded` | nee | nee | Geladen families per categorie met aantal types. | geen |
| `get_family_detail` | nee | nee | Eén familie met haar types en parameters. | `name` |
| `get_levels` | nee | nee | Alle levels met hoogte (voet en meter) en parameters. | geen |
| `get_door_room_relations` | nee | nee | Per deur de ruimte aan beide kanten (van/naar). | `phase`, `include_links`, `category`, `geometrie`, `offset_mm`, `probe_height_mm`, `element_ids` |
| `get_room_geometry` | nee | nee | Grenslijnen en hoogte van ruimten. | `levels` |
| `change_element_type` | ja | ja | Elementen een ander type geven (op id of naam). | `element_ids`, `new_type_id`, `new_type_name`, `family_name`, `dry_run` |
| `rename_element` | ja | ja | Elementen (types, views, materialen) hernoemen. Standaard eerst als proef. | `dry_run`, `save_first`, `renames`, `element_id`, `new_name`, `expected_name` |
| `delete_element` | ja | ja | Elementen verwijderen; met expected_name als controle. Standaard eerst als proef. | `dry_run`, `save_first`, `deletes`, `element_id`, `expected_name`, `element_ids` |
| `read_parameter_values` | nee | nee | Parameterwaarden lezen voor een categorie of een lijst elementen, met telling gevuld/leeg/ontbreekt. | `categories`, `element_ids`, `params`, `include_all`, `limit`, `offset` |
| `set_parameter_value` | ja | ja | Eén parameter op een element of type zetten. | `dry_run`, `save_first`, `edits`, `element_id`, `family`, `param_name`, `new_value`, `expected_current` |
| `set_parameter_values_bulk` | ja | ja | Veel parameterwaarden tegelijk zetten, in batches, met voorbeeld bij dry_run. | `dry_run`, `only_if_empty`, `batch_size`, `edits`, `value` |
| `list_parameter_bindings` | nee | nee | Alle project- en shared parameters met hun categorieën en groep. | geen |
| `bind_shared_parameters` | ja | ja | Shared parameters uit een bestand aan categorieën binden (nieuw of uitbreiden). | `shared_param_file`, `dry_run`, `bindings`, `categories` |
| `unbind_shared_parameters` | ja | ja | Bindingen van shared parameters weghalen. | `shared_param_file`, `guids`, `dry_run` |
| `set_parameter_binding` | ja | ja | Een parameterbinding aanpassen (categorieën, instance/type, groep). | `dry_run`, `save_first`, `shared_param_file`, `bindings`, `categories` |
| `mirror_parameter_binding` | ja | ja | De binding van een parameter overnemen op een andere parameter. | `dry_run`, `save_first`, `category_source`, `mappings`, `source`, `target` |
| `report_parameter_usage` | nee | nee | Waar een parameter gebruikt wordt (bindingen, filters, schedules, families). | `scan_instances`, `guids` |
| `swap_parameter` | ja | ja | Een project-parameter vervangen door een andere en de waarden overzetten. | `source_guid`, `source_builtin`, `target_guid`, `dry_run`, `categories`, `shared_param_file`, `save_first` |
| `couple_builtin_parameter` | ja | ja | Waarden van een ingebouwde parameter naar een eigen parameter kopiëren. | `source_name`, `source_guid`, `target_guid`, `shared_param_file`, `dry_run`, `scan_all`, `families`, `save_first` |
| `enum_system_family_parameters` | nee | nee | Parameters van systeemfamilies (wanden, vloeren, ...) per type. | `ignore_params` |
| `load_family` | ja | ja | Een .rfa laden in een project, met keuze voor overschrijven van waarden. | `path`, `overwrite_values`, `shared_source`, `resolve_failures`, `purge_stale_types`, `purge_only`, `type_map`, `dry_run` |
| `enum_family_parameters` | nee | nee | Parameters binnen families (opent de familie op de achtergrond). | `scan_all`, `dialog_ok`, `dialog_result`, `families` |
| `enum_nested_families` | nee | nee | Geneste families binnen families. | `scan_all`, `families`, `family_ids`, `max_depth` |
| `rename_nested_families` | ja | ja | Geneste families hernoemen in hun moederfamilies. | `dry_run`, `save`, `max_depth`, `families`, `renames`, `old`, `new` |
| `rename_nested_families_rfa` | ja | ja | Geneste families hernoemen in een .rfa-bestand. | `rfa_path`, `dry_run`, `dialog_ok`, `regex_from`, `regex_to`, `renames` |
| `swap_family_parameter` | ja | ja | Een parameter in families vervangen door een (shared) parameter. | `source_guid`, `source_name`, `target_guid`, `shared_param_file`, `dry_run`, `scan_all`, `families`, `save_first` |
| `rename_family_parameter` | ja | ja | Een family-parameter hernoemen. | `dry_run`, `dialog_ok`, `dialog_result`, `save_first`, `rfa_path`, `edits` |
| `delete_family_parameter` | ja | ja | Een family-parameter verwijderen. | `dry_run`, `save_first`, `deletes`, `family`, `guid`, `param_name`, `expected_name` |
| `set_family_formula` | ja | ja | Een formule op een family-parameter zetten. | `dry_run`, `save_first`, `rfa_path`, `dialog_ok`, `dialog_result`, `edits`, `formula` |
| `set_family_type_values` | ja | ja | Waarden per type in een familie zetten. | `family`, `rfa_path`, `dry_run`, `save_first`, `dialog_ok`, `dialog_result`, `force_reload`, `params`, `edits`, `value`, `rename_types` |
| `set_family_param_kind` | ja | ja | Een family-parameter instance of type maken. | `family`, `rfa_path`, `dry_run`, `dialog_ok`, `overwrite_values`, `edits`, `is_instance` |
| `delete_family_types` | ja | ja | Types uit een familie verwijderen. | `family`, `rfa_path`, `dry_run`, `dialog_ok`, `types`, `keep_types` |
| `copy_family_type` | ja | ja | Een type in een familie dupliceren. | `family`, `rfa_path`, `dry_run`, `dialog_ok`, `delete_source`, `edits` |
| `rename_family_materials` | ja | ja | Materialen binnen families hernoemen. | `dry_run`, `save_first`, `dialog_ok`, `nested`, `dialog_result`, `families`, `rfa_path`, `renames` |
| `export_families_to_folder` | nee | ja | Families uit het project als .rfa naar een map bewaren (het project blijft gelijk); een bestaand bestand alleen overschrijven met overwrite=true. | `folder`, `prefix`, `dry_run`, `dialog_ok`, `dialog_result`, `overwrite`, `families`, `subfolders`, `file_names` |
| `place_family_instances` | ja | ja | Family-instanties plaatsen op punten (mm), met level en rotatie. | `dry_run`, `items`, `params`, `host`, `face_down`, `kind`, `z_mm` |
| `place_family_grid` | ja | ja | Alle types van families in een raster plaatsen (catalogus-view). | `family_symbol`, `family_name`, `family_path`, `level_name`, `dry_run`, `save_first`, `origin_mm`, `spacing_mm`, `count`, `instance_params` |
| `place_hosted_family` | ja | ja | Een family in een host plaatsen (deur of raam in een wand). | `dry_run`, `items`, `host` |
| `inventory_copy` | nee | nee | Vooraf nagaan wat kopiëren tussen twee open modellen zou doen. | `source_document`, `scratch_document`, `mode`, `cleanup`, `source_element_ids` |
| `copy_elements` | ja | ja | Elementen (types, materialen, views, ...) van het ene naar het andere open model kopiëren. | `source_document`, `mode`, `save_first`, `dry_run`, `skip_duplicates`, `source_element_ids`, `scratch_document`, `cleanup` |
| `diagnose_family_copy` | nee | nee | Nagaan waarom het kopiëren van een familie mislukt. | `source_document`, `scratch_document`, `category`, `include_warnings`, `source_element_ids`, `limit` |
| `transfer_family` | ja | ja | Een familie van het ene naar het andere open model overzetten; een familie met dezelfde naam alleen overschrijven met overwrite=true. | `source_document`, `category`, `save_first`, `overwrite`, `dry_run`, `source_element_ids`, `family_names` |
| `get_materials` | nee | nee | Alle materialen met naam, klasse, kleur, patronen en assets. | `name_contains` |
| `create_material` | ja | ja | Een nieuw materiaal maken (naam, klasse, kleur, optioneel patronen). | `name`, `source`, `dry_run`, `duplicate_assets`, `material_class`, `color`, `transparency` |
| `duplicate_material` | ja | ja | Een materiaal dupliceren onder een nieuwe naam, optioneel met nieuwe klasse of kleur. | `name`, `source`, `dry_run`, `duplicate_assets`, `material_class`, `color`, `transparency` |
| `set_material_class` | ja | ja | De klasse (Material Class) van materialen zetten. | `filter`, `dry_run`, `edits`, `name`, `element_id`, `material_class`, `material_category` |
| `set_material_fill_pattern` | ja | ja | Oppervlakte- en snijpatronen van een materiaal zetten. | `dry_run`, `save_first`, `edits`, `material_name` |
| `replace_material` | ja | ja | Een materiaal overal vervangen door een ander (types, families, parameters). | `dry_run`, `save_first`, `replacements`, `source_id` |
| `enum_material_parameters` | nee | nee | Parameters van materialen. | geen |
| `enum_material_usage` | nee | nee | Waar elk materiaal gebruikt wordt. | geen |
| `asset_rename` | ja | ja | Een appearance-, physical- of thermal-asset hernoemen. | `dry_run`, `save_first`, `edits` |
| `asset_swap` | ja | ja | Een materiaal een ander asset geven. | `dry_run`, `save_first`, `edits`, `material_id` |
| `get_view_structure` | nee | nee | Views, view templates en view types met hun samenhang. | `include_views` |
| `create_views` | ja | ja | Views maken (plattegrond, plafond, doorsnede, 3D, drafting), optioneel met template. | `dry_run`, `save_first`, `save_after`, `source_document`, `copy_params`, `plans`, `threed`, `area_plans`, `sections`, `details`, `drafting`, `elevations`, `source_name`, `target_name`, `view_type`, `target_level`, `view_type_name`, `source_element_id` |
| `assign_view_template` | ja | ja | Een view template aan views koppelen. | `mode`, `source_document`, `dry_run`, `save_first`, `only_unset`, `view_types`, `assignments`, `template_name`, `view_name`, `view_id` |
| `relink_type_templates` | ja | ja | De standaard-template van view types opnieuw koppelen. | `source_document`, `dry_run`, `save_first` |
| `set_view_property` | ja | ja | Een eigenschap van een view zetten (schaal, detailniveau, ...). | `dry_run`, `save_first`, `edits`, `view_id`, `view_name`, `scale`, `detail_level`, `discipline`, `transparency`, `crop_active`, `crop_visible`, `far_clip_active`, `phase`, `phase_filter` |
| `get_filter_rules` | nee | nee | De regels van view filters. | `name_contains`, `param_name` |
| `create_filter` | ja | ja | Een view filter maken met categorieën en regels. | `dry_run`, `save_first`, `filters`, `name`, `logic`, `rules`, `categories` |
| `repoint_filter_parameter` | ja | ja | De parameter in filterregels vervangen. | `dry_run`, `save_first`, `delete_source`, `mappings`, `source`, `target` |
| `assign_view_filter` | ja | ja | Een filter aan een view of template hangen, met zichtbaarheid en overrides. | `dry_run`, `save_first`, `assignments`, `overrides` |
| `set_line_style_graphics` | ja | ja | Dikte, kleur en patroon van lijnstijlen zetten. | `dry_run`, `save_first`, `edits`, `category_id`, `expected_name`, `line_weight`, `line_color`, `line_pattern` |
| `query_filled_region_types` | nee | nee | Filled region types met hun patronen. | geen |
| `create_filled_region_type` | ja | ja | Een filled region type maken. | `dry_run`, `save_first`, `types` |
| `get_sheet_detail` | nee | nee | Eén sheet: viewports, schedules en titleblock met parameters. | `sheet_name` |
| `create_sheet` | ja | ja | Een sheet maken (nummer, naam, titleblock), optioneel met views op een positie. | `sheet_number`, `sheet_name`, `titleblock`, `dry_run`, `views`, `view`, `x_mm`, `y_mm` |
| `export_views_image` | nee | nee | Views als PNG exporteren naar een map. | `output_dir`, `view_names`, `view_types`, `name_contains`, `pixel_size` |
| `create_walls` | ja | ja | Wanden maken langs lijnen (mm), met type, level en hoogte. | `dry_run`, `walls` |
| `create_room` | ja | ja | Een ruimte plaatsen op een punt of binnen begrenzing, met naam en nummer. | `level`, `number`, `name`, `phase`, `upper_limit`, `dry_run`, `point_mm`, `limit_offset_mm`, `base_offset_mm`, `parameters` |
| `create_shaft_opening` | ja | ja | Een schachtsparing maken tussen twee levels. | `dry_run`, `openings`, `boundary_mm` |
| `list_mep_types` | nee | nee | Leiding-, kanaal- en systeemtypes. | geen |
| `create_mep_runs` | ja | ja | Leidingen of kanalen tekenen langs punten. | `dry_run`, `runs` |
| `connect_to_pipe` | ja | ja | Een element aansluiten op een leiding. | `dry_run`, `connections`, `min_fitting_distance_mm` |
| `get_connectors` | nee | nee | Connectoren van een element met positie en status. | `element_ids` |
| `cap_open_ends` | ja | ja | Open einden van leidingen afdoppen. | `dry_run`, `include_fittings`, `element_ids`, `system`, `cap_pipe_type`, `within_bbox` |
| `insert_pipe_accessory` | ja | ja | Een appendage in een leiding zetten. | `dry_run`, `items`, `min_fitting_distance_mm`, `point_mm`, `punt_mm` |
| `duplicate_mep_type` | ja | ja | Een leiding- of kanaaltype dupliceren. | `dry_run`, `apply_params_if_exists`, `source_type`, `bron`, `new_name`, `nieuwe_naam`, `kind`, `params` |
| `export_ifc` | ja | ja | IFC exporteren met een export-setup of opties; schrijft een bestand. Met keep_guids=true zet hij de IfcGUID-parameters in het model (een transactie, model daarna gewijzigd); zonder keep_guids blijft het model ongewijzigd. | `folder`, `file_name`, `ifc_version`, `user_pset_file`, `view_name`, `export_base_quantities`, `export_ifc_common_psets`, `export_internal_revit_psets`, `keep_guids`, `dry_run`, `config_file`, `mapping_file` |
| `get_ifc_export_setups` | nee | nee | De IFC-exportsetups die in het model bewaard zijn, met psetbestand en mappingtabel. | `raw` |
| `create_ifc_export_views` | ja | ja | 3D-views voor IFC-export maken per bouwlaag of deel. | `prefix`, `categories`, `skip_levels`, `margin_mm`, `dry_run`, `mode`, `exclude_families`, `include_families` |

## Voorbeelden

Claude stuurt ze met het script `scripts/revit_agent/bridge.py`:

```
python scripts/revit_agent/bridge.py <opdracht> "<params als JSON>"
```

### ping

```json
{"command": "ping", "params": {}}
```

### get_open_documents

```json
{"command": "get_open_documents", "params": {}}
```

### get_levels

```json
{"command": "get_levels", "params": {"target_document": "Voorbeeldproject"}}
```

### query_elements

```json
{"command": "query_elements", "params": {"type_id": "wall_type", "target_document": "Voorbeeldproject"}}
```

### read_parameter_values

```json
{"command": "read_parameter_values", "params": {"target_document": "Voorbeeldproject", "categories": ["OST_Doors"], "params": ["Mark", "Fire Rating"]}}
```

### set_parameter_value

```json
{"command": "set_parameter_value", "params": {"target_document": "Voorbeeldproject", "edits": [{"element_id": 352187, "param_name": "Mark", "new_value": "D01"}], "dry_run": true}}
```

### create_sheet

```json
{"command": "create_sheet", "params": {"target_document": "Voorbeeldproject", "sheet_number": "A101", "sheet_name": "Plattegrond begane grond", "views": [{"view": "00 begane grond", "x_mm": 400, "y_mm": 300}], "dry_run": true}}
```

### create_material

```json
{"command": "create_material", "params": {"target_document": "Voorbeeldproject", "name": "Beton prefab", "material_class": "Beton", "color": "#B4B4B4", "dry_run": true}}
```

### duplicate_material

```json
{"command": "duplicate_material", "params": {"target_document": "Voorbeeldproject", "source": "Beton - in het werk gestort", "name": "Beton - zichtwerk", "dry_run": true}}
```

### get_materials

```json
{"command": "get_materials", "params": {"target_document": "Voorbeeldproject", "name_contains": "beton"}}
```

### open_document

```json
{"command": "open_document", "params": {"path": "D:\\Projecten\\Voorbeeldproject.rvt", "worksets": "alle"}}
```

### save_document

```json
{"command": "save_document", "params": {"target_document": "Voorbeeldproject"}}
```

### create_walls

```json
{"command": "create_walls", "params": {"target_document": "Voorbeeldproject", "walls": [{"wall_type": "Generic - 200mm", "level": "00 begane grond", "start_mm": [0, 0], "end_mm": [5000, 0], "height_mm": 3000}], "dry_run": true}}
```

### export_ifc

```json
{"command": "export_ifc", "params": {"target_document": "Voorbeeldproject", "folder": "D:\\Export", "dry_run": true}}
```

## Toelichting per opdracht uit de code

Het commentaar dat boven de handler staat, letterlijk overgenomen. Sommige toelichtingen zijn Engels.

### open_document

```text
open_document: een .rvt/.rfa openen op de achtergrond (geen venster, wel volledig bruikbaar via de bridge).
params: path · worksets ("alle" standaard | "geen" | "laatste") · detach ("nee" standaard | "behoud" | "weggooien")
        · audit (false)
Ontbrekende links: de melding "Unresolved References" wordt beantwoord met "doorgaan met openen";
het antwoord noemt welke links niet geladen zijn (links_niet_geladen).
```

### open_document_ui

```text
open_document_ui: als open_document, maar het model wordt getoond en actief in Revit.
```

### save_document

```text
save_document: een open model bewaren. params: target_document. Alleen op verzoek van de gebruiker.
```

### close_document

```text
close_document — sluit een open document op Title zonder opslaan (stray edit-docs na een mislukte EditFamily).
params: target_document (verplicht), save (default false). Weigert het actieve UI-document.
```

### get_worksets

```text
get_worksets — alleen lezen: user-worksets van een open document met open/dicht-status.
Worksets zijn via de API niet te openen op
een al open document; dit commando toont of een heropen (open_document_ui, alle worksets) nodig is.
params: target_document (verplicht).
```

### list_link_instances

```text
list_link_instances — RevitLinkInstances in target_document, alleen lezen.
params: target_document.
Per instantie: element_id, name, type_name, type_id, linked_document (Title van het geladen gelinkte document =
target_document voor get_room_geometry, null als niet geladen), geladen, status (LinkedFileStatus), pad,
attachment, genest, pinned, transform {origin_mm, basis_x, basis_y, basis_z, rotatie_xy_deg}
(GetTotalTransform: van gelinkte interne coördinaten naar die van target_document), origin_op_origin (origin
≤ 1 mm en basis = identiteit).
```

### load_links

```text
load_links: Revit-links toevoegen.
params: target_document · paths [..] of folder (alle *.rvt, optioneel name_contains)
        · placement ("origin" standaard | "shared") · dry_run (true)
Een link waarvan de bestandsnaam al als link in het model staat, wordt overgeslagen.
```

### reload_link

```text
reload_link — RevitLinkType herladen, zodat het hoofdmodel wijzigingen in de link ziet (bv. RE na nieuwe wanden in
Bouwkundig: room bounding). Aanvulling op relink_links (dat zet links om naar bestanden in andere mappen, LoadFrom)
en load_links (nieuwe links maken): dit commando houdt het pad en laadt opnieuw.
params: target_document, dry_run (default TRUE), link_titles?: [naam, ...] (naam van het RevitLinkType, met of zonder
".rvt", of de Title van het gelinkte document; zonder lijst: alle niet-geneste links).
Geladen link → RevitLinkType.Reload; niet geladen → Load. Buiten een transactie (eigen Revit-operatie).
Resultaat per link: {index, naam, type_id, status: zou_herladen|zou_laden|herladen|geladen|fout, load_result,
geladen_voor, geladen_na, status_voor, status_na, pad, fouten}; niet_gevonden: gevraagde namen zonder link.
Let op: is het gelinkte model als hoofddocument open in deze sessie, dan kan Revit het laden weigeren.
```

### get_room_geometry

```text
get_room_geometry — rooms met geometrie, alleen lezen. Werkt ook op een gelinkt model dat geladen is: geef dan
de Title van het gelinkte document als target_document (list_link_instances noemt die); coördinaten zijn dan
in het interne stelsel van dat model (omrekenen met de totale transformatie van de link).
params: target_document, levels?: [levelnaam, ...] (filter; onbekende namen in notes).
Per room: id, unique_id, name, number, level, phase, area_m2, geplaatst, omsloten, location_point_mm [x,y,z],
bbox_mm {min, max} ([x,y,z]), boundary_mm (buitenste lus, [[x,y], ...], bogen getesselleerd, laatste punt ≠
eerste), boundary_z_mm, lussen (aantal boundary-lussen, incl. de buitenste), deuren [{element_id, mark, family,
type, from_room_number, to_room_number}] (deuren in hetzelfde document met deze room als FromRoom of ToRoom).
Boundary: SpatialElementBoundaryOptions met SpatialElementBoundaryLocation.Finish; buitenste lus = de lus met
het grootste oppervlak in XY. FromRoom/ToRoom gelden voor de laatste fase van het project.
```

### change_element_type

```text
change_element_type: elementen een ander type geven.
params: target_document · element_ids [..] · new_type_id of new_type_name (+ optioneel family_name) · dry_run (true)
```

### delete_element

```text
delete_element — remove elements from the model (NLRS remediation status="delete").
Same backup-gate as rename: doc.Save first (numbered backup) before any mutation. doc.Delete
also removes dependent elements — the returned count reflects everything Revit removed.
Safety: pass expected_name per element so a stale/colliding id (resolving
to a different element than intended) is SKIPPED as stale_id instead of deleting the wrong thing;
target_document scopes to one open doc by Title.
  deletes    : [{element_id[, expected_name]}]  |  element_ids:[int]  |  element_id:int
  dry_run/save_first : bool                      |  target_document : string
```

### read_parameter_values

```text
read_parameter_values — bulk lezen voor inventaris en controle (alleen lezen).
Selectie: categories:["OST_Doors", ...] (of UI-namen) of element_ids:[...]. Parameters: params:[namen], eerst op de
instantie, dan op het type (bron "instance"|"type"). include_all (default false): alle parameters met waarde
(instance + type), gecapt op 500 rijen. Paginering met limit (default 5000) en offset, gesorteerd op element-id.
Rij: {element_id, unique_id, category, family, type, level, ifc_guid, values:{naam:{value, raw, bron}}}.
summary per param (over de hele selectie, niet alleen de pagina): {met_waarde, zonder_waarde, ontbreekt}.
```

### set_parameter_values_bulk

```text
set_parameter_values_bulk — schrijf waarden op instanties of op hun type, in batches (één transactie per batch).
Waarde per StorageType: String → Set(string); Integer → Yes/No (bool, ja/nee, true/false, 1/0) of int;
Double → string = SetValueString (met eenheid, project-display-eenheden), getal = in de display-eenheid van de
parameter (UnitUtils.ConvertToInternalUnits met Parameter.GetUnitTypeId); ElementId → geweigerd.
target "type": schrijft op het ElementType; dezelfde type+param+waarde één keer, tegenstrijdige waarden = conflict
(niets geschreven voor dat type+param). Groepsleden met een parameter die niet per groep mag variëren: fout
group_member (geen schrijfpoging, geen modale dialoog). Read-back na commit bepaalt "geschreven".
params: target_document, edits:[{element_id, param | guid, value, target: "instance"|"type"}],
        only_if_empty (default false), dry_run (default TRUE), batch_size (default 500).
Rapport: {gevraagd, geschreven, overgeslagen_niet_leeg, ongewijzigd_al_gelijk, type_dubbel_samengevoegd,
          fouten:[{element_id, param, reden}] (max 200), fouten_totaal, per_param:{naam:{geschreven, fout}}}.
```

### list_parameter_bindings

```text
list_parameter_bindings — alle project- en shared-parameterbindingen van een document (alleen lezen).
params: target_document.
Rij: {name, guid (alleen shared), shared, instance_or_type, group, group_id, data_type, varies_across_groups,
      categories:[OST_-naam of UI-naam]}.
```

### bind_shared_parameters

```text
bind_shared_parameters — bind shared parameters uit een SP-bestand aan categorieën.
Zoekt de definitie op GUID (voorkeur) of naam. Bestaande binding: alleen ontbrekende categorieën erbij
(ReInsert, zelfde soort en groep; nooit categorieën weg, nooit instance↔type omzetten). Parameter met
dezelfde naam maar een andere GUID in het document: niet binden, status "conflict".
SharedParametersFilename wordt altijd in finally hersteld.
params: target_document, shared_param_file (verplicht),
        bindings:[{name?, guid?, categories:["OST_Doors",...], instance (default true),
                   group ("Data" | "IdentityData" | "IfcParameters" | "PG_IDENTITY_DATA" ...; default Data)}],
        dry_run (default TRUE).
Rapport per binding: {name, guid, status: nieuw|uitgebreid|al_gebonden|conflict|niet_in_bestand|fout,
                      categorieen_toegevoegd, categorieen_onbekend, notes}.
```

### unbind_shared_parameters

```text
unbind_shared_parameters — haal de projectbinding van shared parameters weg maar houd (of maak) de
SharedParameterElement-definitie (zelfde GUID, naam uit het SP-bestand), zodat families die de parameter dragen
hem onder de vertaalde naam tonen zonder dat ELKE family in de categorie hem krijgt.
params: target_document, guids:[...], shared_param_file (voor herstel van de definitie), dry_run (default true).
```

### set_parameter_binding

```text
set_parameter_binding — (re)bind a project shared parameter to an EXPLICIT category list with a
chosen instance/type binding (review SP-binding-edit). Replace-semantics: the given
categories are the desired end-state. Category names are resolved fail-on-mismatch — one unknown
name fails that row with no mutation. Reuses the ReInsert/Insert + NewInstance/TypeBinding motor
from MirrorParameterBinding, but fed from an explicit list instead of a source param/filters.
params:
  target_document : scope by Title
  bindings : [{guid? | param_name?, kind: "instance"|"type", categories:[UI category names], expected?}]
  dry_run    : bool (default TRUE)
  save_first : bool (default false)
```

### load_family

```text
load_family — laad een .rfa van schijf in het project of in een open family-doc (Document.LoadFamily), met of zonder
overschrijven van parameterwaarden. params: target_document, path, overwrite_values (default true), shared_source
("family"|"project"), resolve_failures (default true: warnings weg, errors met resolutie oplossen), purge_stale_types
(default false: types van de geladen family die niet in de rfa zitten -> instanties omhangen naar het best passende
type en verwijderen; tegen dubbele typen na een typenaam-wijziging), dry_run (default true).
Let op: Revit geeft stil false als de rfa sinds de vorige load in dit document niet veranderd is ("al up-to-date").
```

### delete_family_types

```text
delete_family_types — family-types van de ROOT-family in een family-doc verwijderen (FamilyManager.DeleteCurrentType).
params: target_document, family (projectfamily) óf rfa_path; types:[...] te verwijderen óf keep_types:[...] (alle andere weg);
dry_run (default true), dialog_ok (default true).
```

### copy_family_type

```text
copy_family_type — een family-type dupliceren onder een nieuwe naam (FamilyManager.NewType kopieert de waarden van het
huidige type) en optioneel het brontype verwijderen. Workaround voor RenameCurrentType dat op sommige typen stil niet doorkomt.
params: target_document, family óf rfa_path, edits:[{source_type, new_name}], delete_source (default false),
dry_run (default true), dialog_ok (default true).
```

### place_family_instances

```text
place_family_instances — plaats family-instanties.
  Zonder host: niet-gehost (NewFamilyInstance met Level en StructuralType.NonStructural), alleen placement_type
  OneLevelBased.
  Met host:{height_mm, face_down (default true)}: op een horizontaal referentievlak op height_mm boven het level
  (NewFamilyInstance(refplane.GetReference, punt, refDir, symbol)), voor WorkPlaneBased (vlakgebonden) en
  werkvlakgebonden OneLevelBased families. face_down true = normaal −Z (onderkant van een plafond: de family
  hangt omlaag, voor plafondelementen); false = normaal +Z (op de vloer). Eén vlak per (level, hoogte, richting)
  met de vaste naam BF_host_&lt;level&gt;_&lt;hoogte mm&gt;_&lt;down|up&gt;; bestaat hij, dan wordt hij hergebruikt (mits normaal en
  hoogte kloppen), anders aangemaakt in een eigen, gecommitte transactie in een plattegrond van het level (nooit
  in de ActiveView), vóór de plaatsing. refDir = (cos rotation_deg, sin rotation_deg, 0); geen RotateElement.
  z_mm mag dan ontbreken of moet gelijk zijn aan host.height_mm. Schedule Level wordt op het level gezet.
  OneLevelBasedHosted (wand/plafond), CurveBased e.d. en in-place families worden per item geweigerd.
params: target_document, dry_run (default TRUE),
        items:[{family?, type, level, x_mm, y_mm, z_mm (hoogte boven het level, default 0), rotation_deg (default 0),
                host?:{height_mm, face_down?}, params:{naam: waarde}}].
family is optioneel zolang de typenaam uniek is. Waarden: tekst; getal in projecteenheden (getal → de
projecteenheid van die grootheid, tekst met eenheid → UnitFormatUtils.TryParse); ja/nee (true/false, ja/nee, 1/0).
ElementId-parameters en type-parameters worden niet gezet (gemeld).
Per item een TransactionGroup: transactie 1 plaatst (+ rotatie, hoogte), transactie 2 zet de parameters. Rolt
transactie 2 terug, dan blijft het element staan en staan de parameters als fout in het resultaat.
Resultaat per item: {index, status: zou_plaatsen|geplaatst|geplaatst_met_fouten|fout, element_id, locatie
(read-back), params:{naam:{gevraagd, gelezen, status}}, fouten:[...]}.
```

### place_hosted_family

```text
place_hosted_family — wandgehoste family plaatsen in een bestaande wand (of ander host-element).
params: target_document, dry_run (default TRUE),
  items:[{host_id (getal) | host (getal = id, tekst = Comments van de host, exact of eindigend op " " + tekst, zoals
          de scripts '&lt;MARKER&gt; &lt;sleutel&gt;' zetten), family?, type, level, point_mm:[x,y] of [x,y,z] (z boven het level,
          default 0), flip_facing?, flip_hand?, face? ("auto"|"exterior"|"interior", alleen vlakgebonden families),
          params?{}, comments?}].
OneLevelBasedHosted (deur, raam, wandgehoste armatuur): punt geprojecteerd op de wandas, dan
NewFamilyInstance(punt, symbol, host, level, NonStructural). WorkPlaneBased (vlakgebonden, bv. handmelder uit een
"Hosted"-sjabloon): zijvlak van de wand (HostObjectUtils.GetSideFaces), punt geprojecteerd op dat vlak,
NewFamilyInstance(vlakreferentie, punt, wandrichting, symbol). Niet-gehoste families: geweigerd (place_family_instances).
Idempotent: Comments gelijk → bestond; zonder Comments een instantie van hetzelfde type in dezelfde host binnen
10 mm → bestond. In een dry-run bestaan wanden uit dezelfde batch nog niet: dan host_niet_gevonden.
Resultaat per item: {index, status, element_id, host_id, placement_type, projectie_afstand_mm, locatie (read-back),
params, fouten}.
```

### copy_elements

```text
copy_elements — the real apply counterpart of inventory_copy: copies the view set from source
INTO the target and commits it. Same drag-along as the probe, but it lands for real.
Reports every newly-created element (the manifest), flags which ones duplicate a name that
already existed in the target pre-copy (so the post-copy material/filter remediation knows what
to swap), and lists the cleaned-up-category concerns. save_first writes a numbered backup first.
params: source_document, target_document (required) · mode | source_element_ids ·
        save_first (default false) · dry_run (default true; when true it delegates to a scratch
        probe so nothing lands; use inventory_copy directly for richer probe output).
```

### diagnose_family_copy

```text
diagnose_family_copy — non-destructive per-family copy probe that CAPTURES the failures a
cross-document family copy raises, instead of letting Revit pop a modal dialog (which blocks the
main thread and hangs the bridge). Copies each source loadable family ALONE into the disposable
scratch canvas with a failure-capturing preprocessor, records which families fail and with which
failure(s) + failing element names, then rolls back / deletes so nothing persists. Returns a
per-family report so the reviewer can fix the offending families in a targeted way.
Because every error-severity failure is handled programmatically (rollback), no
dialog appears and the probe never hangs.
params:
  source_document    : string (required) — project to copy FROM (e.g. Bron_…)
  scratch_document   : string (optional) — disposable canvas; default first open non-family doc
                        that is neither source nor a family (typically "Project1").
  source_element_ids : [int]  (optional) — explicit family element ids; default = every loadable
                        Family in the source.
  category           : string (optional) — restrict the default family set to this category name.
  include_warnings   : bool   (default false) — also record Warning-severity failures.
  limit              : int    (optional) — cap the number of families probed (smoke test).
```

### transfer_family

```text
transfer_family — robustly transfer loadable families source -> target via the LOAD path
(EditFamily -> SaveAs .rfa -> LoadFamily) instead of ElementTransformUtils.CopyElements. A raw
cross-document copy drops the symbols of hosted/nested families (they land as a typeless shell);
LoadFamily brings the family with ALL its
types. The family loads under its SOURCE name; a same-named family in the target is only
overwritten with overwrite=true. Reconciling to the NLRS target name is a separate rename step.
params:
  source_document    : string (required) — project to transfer FROM
  target_document    : string (required) — project to load INTO
  source_element_ids : [int]  (optional) — family element ids in the source; OR
  family_names       : [str]  (optional) — family names in the source to transfer
  category           : string (optional) — restrict a default (all-families) run to one category
  save_first         : bool   (default false) — save a target backup before the first load
  overwrite          : bool   (default false) — overwrite a same-named family already in target
  dry_run            : bool   (default true) — resolve + report the set WITHOUT loading anything
```

### get_materials

```text
get_materials: alle materialen. params: target_document · name_contains (optioneel).
Per materiaal: element_id, name, material_class, material_category, color ("R,G,B"), transparency, shininess,
surface_pattern(+_color), cut_pattern(+_color), achtergrondpatronen, appearance/structural/thermal_asset.
```

### create_material

```text
create_material: params target_document · name · material_class · color ("#RRGGBB" of "R,G,B")
· transparency (0-100) · surface_pattern / surface_pattern_color · cut_pattern / cut_pattern_color
(patroon = naam van een fill pattern) · dry_run (true).
```

### duplicate_material

```text
duplicate_material: params target_document · source (bestaande naam) · name (nieuwe naam)
· duplicate_assets (false: de kopie deelt de appearance asset met de bron; true: eigen kopie)
· en optioneel dezelfde velden als create_material · dry_run (true).
```

### enum_material_usage

```text
enum_material_usage — per material, count the DISTINCT element-types that reference it
("aan hoeveel element-types is dit materiaal toegekend"). Drives the
is_toegepast column on the Materials tab so a delete decision shows its blast-radius, and is the
precursor to the delete+replace workflow (replace_material). Type-level (not instance) on purpose.
Three reference paths are unioned per type: (1) Element.GetMaterialIds(false) — geometry/assigned
materials; (2) CompoundStructure layer materials for HostObjAttributes types (Wall/Floor/Roof/
Ceiling); (3) ElementId-typed parameters whose value resolves to a Material (the NLRS family
material-parameter pattern). A capped name list is returned for context.
params: target_document (scope by Title).
```

### get_view_structure

```text
get_view_structure — read-only report for an Excel export: view templates with the
filters applied to them, view types with their default template, and (the
complete non-template-view enumeration) the ACTUAL views —
plans/elevations/sections/etc. — with the view template applied to each and that view's own
filter set, level, discipline, scale, detail level and whether it sits on a sheet. Doc-scoped
(target_document). include_views=false skips the (potentially large) view enumeration.
```

### assign_view_template

```text
assign_view_template — set View.ViewTemplateId on actual (non-template) views, by name. The
view-INSTANCE counterpart of relink_type_templates (which sets a view TYPE's default template).
After a cross-document view copy the copied views lose their ViewTemplateId; this re-establishes it.
params:
  target_document : string (required)
  mode            : "mirror_from_source" (default) | "explicit"
  source_document : string (required for mirror) — for each target view, the same-named source
                    view's applied ViewTemplate NAME is read, and the target template of that same
                    name is assigned (analogous to relink's name-match).
  assignments     : [{view_name|view_id, template_name}]  (explicit mode)
  view_types      : [string] (optional) — restrict to these ViewType names (e.g. Elevation, Section)
  only_unset      : bool (default true) — only assign where the view currently has NO template
                    (never silently overwrite a template the user already set)
  dry_run         : bool (default true)
  save_first      : bool (default false) — numbered backup before any write
```

### create_filter

```text
create_filter — create ParameterFilterElements from a reviewed spec. Mirrors the
get_filter_rules output so a source filter can be re-created in the target: name + category UI-names + a flat
AND of rules (param_name + evaluator + value). Rules resolve their parameter by shared-parameter name
in the target doc; a rule whose parameter or evaluator can't be resolved makes the whole filter SKIP
(reported, never partially built). An existing filter with the same name is skipped as a duplicate.
params:
  target_document : string (required)
  filters : [{ name, categories:[UI name], rules:[{param_name, evaluator, value, inverted?}] }]
  dry_run : bool (default true) · save_first : bool (default false)
```

### repoint_filter_parameter

```text
repoint_filter_parameter — rewrite filter rules that target an OLD shared parameter to target a
NEW one, keeping operator + value (e.g. copied filters that reference
FireRating/IsExternal/LoadBearing which were swapped to brandwerendheid_eis/buiten/dragend).
Only flat-AND filter structures are rewritten (single ElementParameterFilter or a LogicalAndFilter
of them). Unmatched rules are preserved as-is (their original objects are reused — no lossy
reconstruction). A filter using OR or a matched rule we cannot safely rebuild (inverse / unknown
string evaluator) is SKIPPED and reported, never partially rewritten.
params:
  target_document : string (required) — doc to rewrite (ids collide between docs)
  mappings        : [{source, target}]  — param names; source=old, target=new (canonical)
  dry_run         : bool (default true)
  save_first      : bool (default false) — numbered backup before any write
  delete_source   : bool (default false) — delete the (now unreferenced) source params after
```

### get_sheet_detail

```text
get_sheet_detail: één sheet lezen. params: target_document · sheet_name (deel van nummer of naam).
Antwoord: sheet_number, sheet_name, viewports [{view_name, view_type, scale, view_template, viewport_type,
center_mm, filters}], schedules [{name, point_mm}], titleblocks [{family, type, parameters}].
```

### export_views_image

```text
export_views_image: views als PNG naar een map. Wijzigt het model niet.
params: target_document · output_dir · view_names [..] of view_types (standaard ["DraftingView","FloorPlan"])
        · name_contains · pixel_size (2048)
```

### create_walls

```text
create_walls — wanden maken.
params: target_document, dry_run (default TRUE),
  walls:[{wall_type, level, start_mm:[x,y], end_mm:[x,y], base_offset_mm? (0), top_level? + top_offset_mm? (0) |
          height_mm (zonder top_level: onverbonden hoogte), location_line? (WallCenterline | CoreCenterline |
          FinishFaceExterior | FinishFaceInterior | CoreExterior | CoreInterior; default WallCenterline),
          room_bounding? (bool), structural? (bool, default false), flip? (bool), params?{}, comments?}].
Wall.Create met de lijn als wandas; bij een andere location_line wordt de parameter gezet en de lijn opnieuw
toegewezen, zodat die referentielijn op start→eind ligt. Idempotent: Comments gelijk → bestond; zonder Comments
een wand van hetzelfde type op hetzelfde level met dezelfde eindpunten (≤ 1 mm, beide richtingen) → bestond.
Per wand: transactie 1 maakt de wand met alle beperkingen (alles of niets), transactie 2 zet params.
Resultaat per wand: {index, status: zou_maken|gemaakt|gemaakt_met_fouten|bestond|fout, element_id, wand (read-back:
type, levels, offsets, location_line, room_bounding, start/eind, lengte, dikte), params, fouten}.
```

### create_shaft_opening

```text
create_shaft_opening — schachtsparing (shaft opening) die vloeren, daken en plafonds van het eigen model snijdt.
params: target_document, dry_run (default TRUE),
  openings:[{base_level, base_offset_mm? (0), top_level, top_offset_mm? (0), boundary_mm:[[x,y], ...] (≥ 3 punten,
             gesloten polygoon; een herhaald eerste punt aan het eind mag), params?{}, comments?}].
doc.Create.NewOpening(baseLevel, topLevel, CurveArray) met de lijnen op de hoogte van het basislevel, daarna
WALL_BASE_OFFSET en WALL_TOP_OFFSET (de offsets van een shaft opening; terugval op "Base Offset"/"Top Offset").
Idempotent: Comments gelijk → bestond; zonder Comments een shaft opening met hetzelfde basislevel en dezelfde
hoekpunten (≤ 1 mm, volgorde vrij) → bestond.
Resultaat per sparing: {index, status, element_id, sparing (read-back: levels, offsets, hoekpunten, oppervlak_m2), fouten}.
```

### list_mep_types

```text
list_mep_types — inventaris van wat create_mep_runs en place_family_instances kunnen gebruiken. Alleen lezen.
params: target_document.
Rapport: pipe_types, duct_types {rond, rechthoekig, ovaal}, piping_system_types, mechanical_system_types
(met system_classification), cable_tray_types, levels {name, elevation_mm, project_elevation_mm} en
families {categorie: [{family, placement_type, plaatsbaar, types:[{id, name, active}]}]}.
Pipe- en DuctTypes tonen hun routing preferences per regelgroep (onderdelen), want bochten vereisen een
Elbows-regel en leidingen een Segments-regel.
```

### create_mep_runs

```text
create_mep_runs — leiding- en kanaalruns uit punten. Per run: segmenten tussen opeenvolgende punten
(Pipe.Create / Duct.Create), bochten met NewElbowFitting. Rechte doorloop (collineair tussenpunt): het punt
vervalt en de segmenten worden samengevoegd (geen union). Terugkerende richting: fout.
params: target_document, dry_run (default TRUE),
        runs:[{kind: "pipe"|"duct", system_type (PipingSystemType / MechanicalSystemType), segment_type (PipeType- of
               DuctType-naam), level, diameter_mm (pipe, rond kanaal) | width_mm + height_mm (rechthoekig/ovaal kanaal),
               points_mm:[[x,y,z],...] (z boven het level), connect_start_to?: element_id, connect_end_to?: element_id,
               segment_diameters_mm?: [d0, d1, ...] (alleen pipe; één diameter per segment points_mm[k] → points_mm[k+1];
               vervangt diameter_mm)}].
Verloop (gekozen boven een los insert_transition): met segment_diameters_mm krijgt elk segment zijn eigen
diameter. Een collineair tussenpunt met een diameterwissel blijft staan en krijgt NewTransitionFitting (het
Transitions-onderdeel uit de routing preference; zonder Transitions-regel: run geweigerd); een diameterwissel in een
bocht wordt geweigerd (zet een tussenpunt op het rechte stuk). Zo plaatst Revit het verloop zelf, in dezelfde
transactie als segmenten en bochten (alles of niets), en hoeven er geen bestaande leidingen geknipt te worden.
Een verbinding (connect_start_to/connect_end_to) krijgt de diameter van het eindsegment aan die kant.
Resultaat extra: segment_diameters_mm, segment_diameters_gelezen_mm, verloop_ids, verlopen_gepland (dry-run).
Verbinden met een element: de dichtstbijzijnde vrije End-connector van het juiste domein (piping/HVAC). Methoden:
  direct          — connector valt samen met het run-uiteinde (≤ 1 mm): ConnectTo.
  verlengen       — connector ligt in het verlengde van het eindsegment en kijkt ertegenin: segment verlengen + ConnectTo.
  stub            — korte verbinding: stuk langs de connectoras tot het run-uiteinde (of het verlengde ervan), met
                    één bocht, of met een tussenstuk en twee bochten.
  Kijkt de connector van de run af of snijdt de as het segment: niet verbonden, gemeld, niet geforceerd.
Per run een TransactionGroup: transactie 1 maakt segmenten en bochten (alles of niets), transactie 2 en 3
maken de begin- en eindverbinding; een mislukte verbinding rolt alleen zichzelf terug.
Vooraf: pipe-type zonder Segments-regel of bochten nodig zonder Elbows-regel in de routing preferences →
run niet gemaakt, fout gemeld.
Resultaat per run: {index, status, segment_ids, fitting_ids, lengte_totaal_mm, maat (read-back), verbindingen
{start, end: {element_id, methode, gelukt, reden}}, fouten, notes}.
```

### get_connectors

```text
get_connectors — alleen lezen. params: target_document, element_ids:[...].
Per element: {element_id, categorie, family, type, connectors:[{index (Connector.Id), connector_type, domein, vorm,
origin_mm (z absoluut), richting (BasisZ), diameter_mm | breedte_mm + hoogte_mm, systeemclassificatie
(PipeSystemType / DuctSystemType / ElectricalSystemType), flow_direction, systeem (MEPSystem-naam), systeemtype
(PipingSystemType-naam), beschrijving, is_connected, verbonden_met:[owner-ids, alleen leidingen/kanalen/fittingen/
appendages/equipment], verbonden_details:[{id, categorie}]}], open_connectors (aantal vrije End-connectors)}.
```

### cap_open_ends

```text
cap_open_ends — open leidingeinden afdoppen (lasbodem, eindkap) met PlumbingUtils.PlaceCapOnOpenEnds en het
Caps-onderdeel uit de routing preference van het leidingtype.
params: target_document, dry_run (default TRUE), minstens één selectie:
  element_ids?:[...] (leidingen; met include_fittings ook fittingen/appendages), system?: naam van een PipingSystemType
  of MEP-systeem (alle leidingen daarvan), within_bbox?: {min_mm:[x,y,z], max_mm:[x,y,z]} (alleen open einden
  binnen de box), cap_pipe_type?: naam van het PipeType waarvan de Caps-regel geldt (default het type van de
  leiding zelf), include_fittings? (default false: PlaceCapOnOpenEnds op een fitting/appendage is niet getoetst).
PlaceCapOnOpenEnds dopt ALLE open einden van een element af; valt maar een deel van de open einden van een leiding in
within_bbox, dan wordt die leiding overgeslagen (status deels_buiten_box).
Per element één TransactionGroup/transactie; read-back: de einden zijn daarna verbonden met een nieuwe fitting.
Resultaat per element: {index, element_id, status: zou_afdoppen|afgedopt|geen_open_einden|deels_buiten_box|geweigerd|fout,
open_einden:[{index, origin_mm, diameter_mm}], cap_type (Caps-regels), cap_ids, fouten}.
```

### insert_pipe_accessory

```text
insert_pipe_accessory — appendage (afsluiter, inregelafsluiter, ontluchter, aftapper) in een bestaande leiding.
params: target_document, dry_run (default TRUE), min_fitting_distance_mm (default 100),
  items:[{pipe_id, family?, type, point_mm:[x,y,z] (alias punt_mm; z absoluut; geprojecteerd op de hartlijn,
          max_offset_mm default 50), reverse? (bool: stroomrichting omdraaien), at_end? ("start"|"end"|"open"),
          params?{}, comments?}].
at_end (aftapper/ontluchter op het laagste/hoogste punt): geen knip; de appendage (1 of 2 leidingconnectors) wordt
met haar aansluitconnector op het open einde gezet, langs de leiding naar buiten gericht en verbonden; point_mm is
dan optioneel (alleen nodig bij at_end open en twee open einden).
Methode (knippen + aansluiten, zoals de UI het doet): transactie 1 PlumbingUtils.BreakCurve op het punt (commit;
een directe pipe-op-pipe-koppeling wordt losgemaakt), transactie 2 de appendage plaatsen op het punt
(NewFamilyInstance op het level van de leiding), de as van de twee leidingconnectors gelijkrichten met de leiding
(draaien om z; bij een niet-horizontale leiding om de as loodrecht op beide), de maat van de connectors op de
leidingdiameter zetten (Connector.Radius, waar de family dat toelaat), het midden tussen de connectors op het punt
schuiven, beide leidinghelften inkorten tot de connectors en verbinden. Nooit een union of fitting in de
knip-transactie. Faalt transactie 2, dan rolt de groep ook de knip terug.
Geweigerd: geen Pipe of placeholder; punt verder dan max_offset_mm van de hartlijn; punt binnen
min_fitting_distance_mm van een einde of fitting; family zonder twee leidingconnectors; categorie geen
Pipe Accessory (waarschuwing, geen weigering).
Idempotent: Comments gelijk → bestond; zonder Comments een appendage van hetzelfde type binnen 10 mm van het punt
en verbonden met de leiding → bestond.
Resultaat per item: {index, status, element_id, pipe_ids_na (beide helften), projectiepunt_mm, diameters, connectors
(read-back), fouten, waarschuwingen}.
```

### duplicate_mep_type

```text
duplicate_mep_type — PipeType of PipingSystemType dupliceren.
params: target_document, dry_run (default TRUE), source_type (naam; alias bron), new_name (alias nieuwe_naam), kind? ("pipe_type" |
  "piping_system_type"; default: gezocht in beide, moet uniek zijn), params?{typeparameter: waarde},
  apply_params_if_exists? (default false).
ElementType.Duplicate(new_name); bij een PipeType gaan de routing preferences mee (read-back: aantal regels per groep
gelijk aan de bron; zo niet, dan worden de regels met hun criteria gekopieerd en opnieuw geteld). Typeparameters
in een tweede transactie met read-back. Bestaat new_name al in dezelfde klasse: status bestond (niets gewijzigd,
params alleen met apply_params_if_exists: true, want een typewijziging raakt alle elementen van dat type).
Namen met \ : { } [ ] | ; &lt; &gt; ? ` ~ worden geweigerd.
Resultaat: {status: zou_maken|gemaakt|gemaakt_met_fouten|bestond|fout, kind, bron_id, element_id, routing_regels
{groep: [bron, nieuw]}, params, fouten}.
```

Gemaakt door bimforce (bimforce.com)
