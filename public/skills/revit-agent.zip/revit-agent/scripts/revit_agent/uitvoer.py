"""Lange antwoorden van de bridge naar een bestand, met een korte samenvatting voor in het gesprek.

Een antwoord van bv. read_parameter_values kan duizenden regels zijn. Dat hoort in een bestand;
in het gesprek komt alleen hoe groot het is en waar het staat.

Gebruik als module:
    from revit_agent.uitvoer import bewaar, samenvatting
    pad = bewaar("read_parameter_values", data)
    print(samenvatting(data))

Vanaf de opdrachtregel (stuurt de opdracht en bewaart het antwoord):
    python -m revit_agent.uitvoer read_parameter_values @params.json [map]
Alleen de standaardbibliotheek.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import re
import sys
import tempfile
from pathlib import Path

from .bridge import BridgeError, call_raw

GRENS_TEKENS = 4000  # langer dan dit: naar een bestand


def standaard_map() -> Path:
    """%TEMP%/revit-agent, of REVIT_AGENT_UITVOER als die gezet is."""
    return Path(os.environ.get("REVIT_AGENT_UITVOER") or Path(tempfile.gettempdir()) / "revit-agent")


def bewaar(naam: str, data, map: str | Path | None = None) -> Path:
    """Schrijft data als JSON naar <map>/<naam>-<tijd>.json en geeft het pad terug."""
    doel = Path(map) if map else standaard_map()
    doel.mkdir(parents=True, exist_ok=True)
    veilig = re.sub(r"[^A-Za-z0-9_.-]+", "_", naam)[:60] or "antwoord"
    tijd = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    pad = doel / f"{veilig}-{tijd}.json"
    n = 2
    while pad.exists():
        pad = doel / f"{veilig}-{tijd}-{n}.json"
        n += 1
    pad.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    return pad


def samenvatting(data, diepte: int = 0) -> str:
    """Korte beschrijving van de vorm: sleutels, lengtes van lijsten, losse getallen en teksten."""
    if isinstance(data, dict):
        delen = []
        for k, v in list(data.items())[:25]:
            if isinstance(v, list):
                delen.append(f"{k}: lijst van {len(v)}")
            elif isinstance(v, dict):
                delen.append(f"{k}: {{{len(v)} sleutels}}" if diepte else f"{k}: {{{samenvatting(v, 1)}}}")
            elif isinstance(v, str):
                delen.append(f"{k}: {v[:60]!r}")
            else:
                delen.append(f"{k}: {v!r}")
        return ", ".join(delen)
    if isinstance(data, list):
        return f"lijst van {len(data)}"
    return repr(data)[:200]


def toon_of_bewaar(naam: str, data, map: str | Path | None = None, grens: int = GRENS_TEKENS) -> str:
    """Geeft de tekst voor in het gesprek: het hele antwoord als het kort is, anders samenvatting + pad."""
    tekst = json.dumps(data, ensure_ascii=False, indent=1)
    if len(tekst) <= grens:
        return tekst
    pad = bewaar(naam, data, map)
    return f"Antwoord ({len(tekst)} tekens) bewaard in {pad}\nVorm: {samenvatting(data)}"


def _main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd = argv[1]
    params: dict = {}
    if len(argv) > 2:
        bron = argv[2]
        if bron.startswith("@"):
            bron = Path(bron[1:]).read_text(encoding="utf-8-sig")
        params = json.loads(bron)
    map_ = argv[3] if len(argv) > 3 else None
    try:
        antwoord = call_raw(cmd, params)
    except BridgeError as e:
        print(json.dumps({"success": False, "error": str(e), "soort": e.soort}, ensure_ascii=False))
        return 2
    print(toon_of_bewaar(cmd, antwoord, map_))
    return 0 if antwoord.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
