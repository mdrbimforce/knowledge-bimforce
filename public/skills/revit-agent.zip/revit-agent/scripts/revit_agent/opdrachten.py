"""Welke opdrachten kent de bridge?

Vraagt het aan de addin met `list_commands`. Kent de addin die opdracht niet (de oudere interne
addin), dan valt hij terug op de meegeleverde lijst `opdrachten_statisch.json`.

Gebruik als module:
    from revit_agent.opdrachten import opdrachten, zoek, schrijft
    for o in opdrachten(): print(o["name"], o["schrijft"])

Vanaf de opdrachtregel:
    python -m revit_agent.opdrachten            # tabel
    python -m revit_agent.opdrachten material   # alleen namen met 'material'
    python -m revit_agent.opdrachten --json
Alleen de standaardbibliotheek.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from .bridge import BridgeError, call_raw

_STATISCH = Path(__file__).resolve().parent / "opdrachten_statisch.json"


def statische_lijst() -> list[dict]:
    """De lijst die met de skill is meegeleverd (gemaakt uit de broncode van de addin)."""
    try:
        return json.loads(_STATISCH.read_text(encoding="utf-8"))["commands"]
    except (OSError, ValueError, KeyError):
        return []


def opdrachten(timeout: float = 15, alleen_statisch: bool = False) -> list[dict]:
    """Lijst van {name, beschrijving, schrijft, dry_run[, params]}.

    Eerst live via list_commands; bij een onbekende opdracht of geen verbinding de statische lijst.
    Elk item krijgt "bron": "addin" of "statisch".
    """
    if not alleen_statisch:
        try:
            antwoord = call_raw("list_commands", timeout=timeout)
            data = antwoord.get("data") if antwoord.get("success") else None
            if isinstance(data, dict) and isinstance(data.get("commands"), list):
                statisch = {o["name"]: o for o in statische_lijst()}
                uit = []
                for o in data["commands"]:
                    item = dict(o)
                    item.setdefault("params", statisch.get(o.get("name"), {}).get("params", []))
                    item["bron"] = "addin"
                    uit.append(item)
                return uit
        except BridgeError:
            pass
    return [dict(o, bron="statisch") for o in statische_lijst()]


def zoek(naam: str, lijst: list[dict] | None = None) -> dict | None:
    for o in (lijst if lijst is not None else opdrachten()):
        if o.get("name") == naam:
            return o
    return None


def schrijft(naam: str, lijst: list[dict] | None = None) -> bool:
    """True als de opdracht een model wijzigt (onbekend telt als schrijvend: voorzichtig)."""
    o = zoek(naam, lijst)
    return True if o is None else bool(o.get("schrijft"))


def _main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    als_json = "--json" in argv
    filt = [a for a in argv[1:] if not a.startswith("--")]
    lijst = opdrachten(alleen_statisch="--statisch" in argv)
    if filt:
        lijst = [o for o in lijst if filt[0].lower() in o["name"].lower()]
    if als_json:
        print(json.dumps(lijst, ensure_ascii=False, indent=1))
        return 0
    bron = lijst[0]["bron"] if lijst else "-"
    print(f"{len(lijst)} opdrachten (bron: {bron})")
    for o in lijst:
        teken = "S" if o.get("schrijft") else "L"
        proef = "proef" if o.get("dry_run") else "     "
        print(f"  [{teken}] {proef} {o['name']:30} {o.get('beschrijving', '')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
