"""Client voor de Revit Agent-bridge: één regel JSON heen, één regel JSON terug.

De addin in Revit luistert op 127.0.0.1 (alleen de eigen computer). Een verzoek is
{"command": "...", "params": {...}, "token": "..."} en het antwoord is
{"success": true, "data": ...} of {"success": false, "error": "..."}.

Alleen de standaardbibliotheek van Python, zodat elk script dit bestand kan meenemen.

Gebruik als module:
    from revit_agent.bridge import call, BridgeError
    data = call("get_open_documents")

Gebruik vanaf de opdrachtregel:
    python -m revit_agent.bridge ping
    python -m revit_agent.bridge query_elements "{\"category\": \"Walls\"}"
    python -m revit_agent.bridge query_elements @params.json
"""
from __future__ import annotations

import json
import os
import socket
import sys
from pathlib import Path

STANDAARD_POORT = 9877
HOST = "127.0.0.1"


class BridgeError(RuntimeError):
    """De bridge is niet bereikbaar, antwoordt niet op tijd, of meldt een fout."""

    def __init__(self, bericht: str, soort: str = "fout"):
        super().__init__(bericht)
        # soort: "geen-verbinding" | "time-out" | "fout" | "ongeldig-antwoord"
        self.soort = soort


def _instellingen_pad() -> Path:
    basis = os.environ.get("APPDATA") or str(Path.home())
    return Path(basis) / "RevitAgent" / "bridge.json"


def instellingen() -> dict:
    """Poort en token. Volgorde: omgevingsvariabelen, dan bridge.json van de addin."""
    uit: dict = {"port": STANDAARD_POORT, "token": None}
    pad = _instellingen_pad()
    if pad.is_file():
        try:
            bestand = json.loads(pad.read_text(encoding="utf-8-sig"))
            if isinstance(bestand.get("port"), int):
                uit["port"] = bestand["port"]
            if bestand.get("token"):
                uit["token"] = str(bestand["token"])
        except (OSError, ValueError):
            pass
    if os.environ.get("REVIT_AGENT_PORT"):
        uit["port"] = int(os.environ["REVIT_AGENT_PORT"])
    if "REVIT_AGENT_TOKEN" in os.environ:
        uit["token"] = os.environ["REVIT_AGENT_TOKEN"] or None
    return uit


def call_raw(command: str, params: dict | None = None, timeout: float = 120,
             port: int | None = None) -> dict:
    """Stuur één opdracht en geef het hele antwoord terug, ook als success false is."""
    inst = instellingen()
    verzoek: dict = {"command": command, "params": params or {}}
    if inst["token"]:
        verzoek["token"] = inst["token"]
    doel = (HOST, port or inst["port"])
    try:
        s = socket.create_connection(doel, timeout=min(timeout, 10))
    except OSError as e:
        raise BridgeError(
            f"Geen verbinding met Revit op {doel[0]}:{doel[1]} ({e}). "
            "Draait Revit, en is de Revit Agent-addin geladen?", "geen-verbinding") from e
    try:
        s.settimeout(timeout)
        s.sendall((json.dumps(verzoek, ensure_ascii=False) + "\n").encode("utf-8"))
        buf = b""
        while not buf.endswith(b"\n"):
            deel = s.recv(65536)
            if not deel:
                break
            buf += deel
    except socket.timeout as e:
        raise BridgeError(
            f"Revit antwoordde niet binnen {timeout:g} s op '{command}'. Revit kan bezig zijn "
            "of op een dialoogvenster wachten. Kijk in Revit; stuur de opdracht niet blind opnieuw.",
            "time-out") from e
    except OSError as e:
        raise BridgeError(f"Verbinding verbroken tijdens '{command}': {e}", "geen-verbinding") from e
    finally:
        s.close()
    if not buf.strip():
        raise BridgeError(f"Leeg antwoord op '{command}'.", "ongeldig-antwoord")
    try:
        antwoord = json.loads(buf.decode("utf-8"))
    except ValueError as e:
        raise BridgeError(f"Antwoord op '{command}' is geen JSON: {e}", "ongeldig-antwoord") from e
    if not isinstance(antwoord, dict):
        raise BridgeError(f"Antwoord op '{command}' heeft een onverwachte vorm.", "ongeldig-antwoord")
    return antwoord


def call(command: str, params: dict | None = None, timeout: float = 120,
         port: int | None = None):
    """Stuur één opdracht; geef `data` terug of gooi BridgeError met de foutmelding van Revit."""
    antwoord = call_raw(command, params, timeout, port)
    if not antwoord.get("success"):
        raise BridgeError(str(antwoord.get("error") or f"'{command}' mislukte zonder melding."))
    data = antwoord.get("data")
    # Veel opdrachten melden een fout als success true met in data {"ok": false, "error": ...}.
    if isinstance(data, dict) and data.get("ok") is False and data.get("error"):
        raise BridgeError(str(data["error"]))
    return data


def bereikbaar(timeout: float = 5) -> bool:
    """True als de bridge op ping antwoordt. Gooit niet."""
    try:
        return bool(call_raw("ping", timeout=timeout).get("success"))
    except BridgeError:
        return False


def _main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    command = argv[1]
    params: dict = {}
    if len(argv) > 2:
        bron = argv[2]
        if bron.startswith("@"):
            bron = Path(bron[1:]).read_text(encoding="utf-8-sig")
        params = json.loads(bron)
    timeout = float(argv[3]) if len(argv) > 3 else 120
    try:
        antwoord = call_raw(command, params, timeout)
    except BridgeError as e:
        print(json.dumps({"success": False, "error": str(e), "soort": e.soort}, ensure_ascii=False))
        return 2
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    print(json.dumps(antwoord, ensure_ascii=False, indent=1))
    return 0 if antwoord.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
