"""Eén ingang voor Claude om met Revit te praten via de Revit Agent-bridge.

    python scripts/revit.py status                     # staat alles klaar? (stap 0)
    python scripts/revit.py ping
    python scripts/revit.py opdrachten [zoekwoord]     # welke opdrachten kent de addin
    python scripts/revit.py <opdracht> [params] [--timeout 120] [--volledig]

params is JSON tussen aanhalingstekens, of @bestand.json. Een lang antwoord komt in een bestand
(map %TEMP%\\revit-agent); in beeld komen dan de vorm en het pad. Met --volledig komt alles in beeld.

Voorbeelden:
    python scripts/revit.py get_open_documents
    python scripts/revit.py get_levels "{\\"target_document\\": \\"Mijn project\\"}"
    python scripts/revit.py set_parameter_value @wijziging.json
Alleen de standaardbibliotheek.
"""
from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):   # in de zip: scripts/; in de repo: shared/
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from revit_agent.bridge import BridgeError, call_raw, instellingen  # noqa: E402
from revit_agent import opdrachten as _opd  # noqa: E402
from revit_agent.uitvoer import toon_of_bewaar  # noqa: E402


def _print(o):
    print(json.dumps(o, ensure_ascii=False, indent=1) if not isinstance(o, str) else o)


def status() -> int:
    """Stap 0: Python, bridge.json, ping, Revit-versie, open modellen."""
    inst = instellingen()
    regels = [f"Python {platform.python_version()}"]
    from revit_agent.bridge import _instellingen_pad  # type: ignore
    pad = _instellingen_pad()
    regels.append(f"bridge.json: {'gevonden' if pad.is_file() else 'niet gevonden'} ({pad})")
    regels.append(f"poort {inst['port']}, token {'aanwezig' if inst['token'] else 'geen'}")
    uitslag = {"python": True, "bridge_json": pad.is_file(), "bridge": False, "revit": None,
               "addin": None, "modellen": None}
    try:
        p = call_raw("ping", timeout=5)
        uitslag["bridge"] = bool(p.get("success"))
        uitslag["addin"] = (p.get("data") or {}).get("addin_version") or (p.get("data") or {}).get("version")
        regels.append(f"bridge: antwoordt ({json.dumps(p.get('data'), ensure_ascii=False)})")
    except BridgeError as e:
        regels.append(f"bridge: {e.soort}: {e}")
    if uitslag["bridge"]:
        try:
            info = call_raw("get_info", timeout=10)
            if info.get("success"):
                uitslag["revit"] = info["data"].get("name") or info["data"].get("version")
                regels.append(f"Revit: {uitslag['revit']}")
            else:
                regels.append(f"get_info: {info.get('error')}")
            docs = call_raw("get_open_documents", timeout=20)
            if docs.get("success"):
                uitslag["modellen"] = docs["data"]
                for d in docs["data"]:
                    soort = "familie" if d.get("is_family") else ("link" if d.get("is_linked") else "project")
                    onbewaard = ", ONBEWAARD WERK" if d.get("is_modified") else ""
                    regels.append(f"  open: {d['title']} ({soort}{onbewaard})")
                if not docs["data"]:
                    regels.append("  er staat geen model open")
            else:
                regels.append(f"get_open_documents: {docs.get('error')}")
        except BridgeError as e:
            regels.append(f"Revit antwoordt niet op tijd: {e}")
    print("\n".join(regels))
    print("\nUITSLAG " + json.dumps({k: v for k, v in uitslag.items() if k != "modellen"}, ensure_ascii=False))
    return 0 if uitslag["bridge"] else 2


def main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    args = [a for a in argv[1:] if not a.startswith("--")]
    vlaggen = [a for a in argv[1:] if a.startswith("--")]
    timeout = 120.0
    for i, a in enumerate(argv):
        if a == "--timeout" and i + 1 < len(argv):
            timeout = float(argv[i + 1])
            if argv[i + 1] in args:
                args.remove(argv[i + 1])
    cmd = args[0]
    if cmd == "status":
        return status()
    if cmd == "opdrachten":
        return _opd._main(["opdrachten"] + args[1:])
    params: dict = {}
    if len(args) > 1:
        bron = args[1]
        if bron.startswith("@"):
            bron = Path(bron[1:]).read_text(encoding="utf-8-sig")
        params = json.loads(bron)
    try:
        antwoord = call_raw(cmd, params, timeout=timeout)
    except BridgeError as e:
        _print({"success": False, "error": str(e), "soort": e.soort})
        return 2
    if "--volledig" in vlaggen:
        _print(antwoord)
    else:
        print(toon_of_bewaar(cmd, antwoord))
    return 0 if antwoord.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
