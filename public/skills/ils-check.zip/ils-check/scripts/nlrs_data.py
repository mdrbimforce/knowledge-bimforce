"""Kleine lezers voor de NLRS-bestanden in data/nlrs/ (NLRS 3.1.1, MIT, Revit Standards Foundation).

Bewust klein en zonder afhankelijkheden: de skill ils-check moet op zichzelf werken. De bestanden zijn
UTF-16 met BOM; een paar NLRS-bestanden zijn dubbel gecodeerd, dat herstelt lees_tekst().
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"
NLRS = DATA / "nlrs"
SP_BESTAND = NLRS / "NLRS_Shared Parameters - Totaal.txt"

# Revit-categorie (Engelse naam zoals in de NLRS-exportmapping) -> BuiltInCategory.
# Alleen modelcategorieën; de bridge accepteert ook de naam zoals Revit hem in de eigen taal toont.
OST = {
    "Air Terminals": "OST_DuctTerminal", "Areas": "OST_Areas", "Assemblies": "OST_Assemblies",
    "Cable Tray Fittings": "OST_CableTrayFitting", "Cable Trays": "OST_CableTray", "Casework": "OST_Casework",
    "Ceilings": "OST_Ceilings", "Columns": "OST_Columns", "Communication Devices": "OST_CommunicationDevices",
    "Conduit Fittings": "OST_ConduitFitting", "Conduits": "OST_Conduit", "Curtain Panels": "OST_CurtainWallPanels",
    "Curtain Systems": "OST_Curtain_Systems", "Curtain Wall Mullions": "OST_CurtainWallMullions",
    "Data Devices": "OST_DataDevices", "Doors": "OST_Doors", "Duct Accessories": "OST_DuctAccessory",
    "Duct Fittings": "OST_DuctFitting", "Duct Insulations": "OST_DuctInsulations", "Duct Linings": "OST_DuctLinings",
    "Duct Placeholders": "OST_PlaceHolderDucts", "Ducts": "OST_DuctCurves",
    "Electrical Equipment": "OST_ElectricalEquipment", "Electrical Fixtures": "OST_ElectricalFixtures",
    "Entourage": "OST_Entourage", "Fire Alarm Devices": "OST_FireAlarmDevices", "Flex Ducts": "OST_FlexDuctCurves",
    "Flex Pipes": "OST_FlexPipeCurves", "Floors": "OST_Floors", "Furniture": "OST_Furniture",
    "Furniture Systems": "OST_FurnitureSystems", "Generic Models": "OST_GenericModel", "Grids": "OST_Grids",
    "Levels": "OST_Levels", "Lighting Devices": "OST_LightingDevices", "Lighting Fixtures": "OST_LightingFixtures",
    "Mass": "OST_Mass", "Mechanical Equipment": "OST_MechanicalEquipment",
    "Nurse Call Devices": "OST_NurseCallDevices", "Parking": "OST_Parking", "Parts": "OST_Parts",
    "Pipe Accessories": "OST_PipeAccessory", "Pipe Fittings": "OST_PipeFitting",
    "Pipe Insulations": "OST_PipeInsulations", "Pipe Placeholders": "OST_PlaceHolderPipes", "Pipes": "OST_PipeCurves",
    "Planting": "OST_Planting", "Plumbing Fixtures": "OST_PlumbingFixtures", "Railings": "OST_StairsRailing",
    "Ramps": "OST_Ramps", "Roads": "OST_Roads", "Roofs": "OST_Roofs", "Rooms": "OST_Rooms",
    "Security Devices": "OST_SecurityDevices", "Shaft Openings": "OST_ShaftOpening", "Site": "OST_Site",
    "Spaces": "OST_MEPSpaces", "Specialty Equipment": "OST_SpecialityEquipment", "Sprinklers": "OST_Sprinklers",
    "Stairs": "OST_Stairs", "Structural Area Reinforcement": "OST_AreaRein",
    "Structural Beam Systems": "OST_StructuralFramingSystem", "Structural Columns": "OST_StructuralColumns",
    "Structural Connections": "OST_StructConnections", "Structural Foundations": "OST_StructuralFoundation",
    "Structural Framing": "OST_StructuralFraming", "Structural Rebar": "OST_Rebar",
    "Structural Stiffeners": "OST_StructuralStiffener", "Structural Trusses": "OST_StructuralTruss",
    "Telephone Devices": "OST_TelephoneDevices", "Topography": "OST_Topography", "Walls": "OST_Walls",
    "Windows": "OST_Windows", "Wires": "OST_Wire", "Project Information": "OST_ProjectInformation",
}

# Klassen die Revit uit iets anders dan een categorie maakt (de exportmapping noemt ze niet).
EXTRA_KLASSE = {
    "IFCPROJECT": ["Project Information"], "IFCBUILDING": ["Project Information"],
    "IFCSITE": ["Project Information", "Site", "Topography"], "IFCBUILDINGSTOREY": ["Levels"],
    "IFCZONE": ["Rooms", "Spaces"],
}


def lees_tekst(pad: Path) -> str:
    b = Path(pad).read_bytes()
    try:
        t = b.decode("utf-16") if b[:2] in (b"\xff\xfe", b"\xfe\xff") else b.decode("utf-8-sig")
    except UnicodeDecodeError:
        t = b[2:].decode("utf-16-le", errors="replace")
    if t.startswith("﻿"):
        t = t[1:]
    if "\x00" in t or (t[:1] == "\xff"):
        try:
            t = b.decode("utf-16").encode("latin-1").decode("utf-16")
        except (UnicodeDecodeError, UnicodeEncodeError):
            pass
    return t


def _regels(pad: Path):
    for r in lees_tekst(pad).splitlines():
        if r.strip() and not r.lstrip().startswith("#"):
            yield r.rstrip("\r")


@lru_cache(maxsize=None)
def parametermapping() -> dict:
    """(PSET, PROPERTY) in hoofdletters -> {"pset", "property", "params": [Revit-parameters]}, uit de
    NLRS-parametermappingtabel (IFC4). Een regel zonder Revit-parameter geeft een lege lijst (de pset en
    property staan in de tabel, maar NLRS koppelt er niets aan). Eén property kan meer regels hebben."""
    uit = {}
    for r in _regels(NLRS / "RSF_NLRS_3.1.1_IfcParameterMapping_IFC4.txt"):
        d = r.split("\t")
        if len(d) >= 2 and d[0].strip() and d[1].strip():
            x = uit.setdefault((d[0].strip().upper(), d[1].strip().upper()),
                               {"pset": d[0].strip(), "property": d[1].strip(), "params": []})
            par = d[2].strip() if len(d) > 2 else ""
            if par and par not in x["params"]:
                x["params"].append(par)
    return uit


@lru_cache(maxsize=None)
def custom_psets() -> dict:
    """PSET in hoofdletters -> {naam, soort (I/T), klassen, props: {PROPERTY: {property, datatype, params}}}.
    Eén property kan meer Revit-parameters hebben (bijvoorbeeld _01 tot _10 voor meer materialen)."""
    uit, huidig = {}, None
    for r in _regels(NLRS / "RSF_NLRS_3.1.1_CustomPSets.txt"):
        d = r.split("\t")
        if d[0].startswith("PropertySet:"):
            klassen = [k.strip().upper() for k in ",".join(d[3:]).split(",") if k.strip()]
            huidig = {"naam": d[1].strip(), "soort": d[2].strip() if len(d) > 2 else "", "klassen": klassen,
                      "props": {}}
            uit[huidig["naam"].upper()] = huidig
        elif huidig is not None and d[0] == "" and len(d) >= 2 and d[1].strip():
            prop = d[1].strip()
            x = huidig["props"].setdefault(prop.upper(), {"property": prop,
                                                          "datatype": d[2].strip() if len(d) > 2 else "",
                                                          "params": []})
            par = (d[3].strip() if len(d) > 3 else "") or prop
            if par not in x["params"]:
                x["params"].append(par)
    return uit


@lru_cache(maxsize=None)
def exportmapping() -> list:
    """[(categorie, IFCKLASSE, PREDEFINEDTYPE|None)] voor hoofdcategorieën (zonder subcategorie)."""
    uit = []
    for r in _regels(NLRS / "RSF_NLRS_3.1.1_IfcExportMapping.txt"):
        d = r.split("\t")
        if len(d) < 3 or d[1].strip() or not d[2].strip() or d[2].strip() == "Not Exported":
            continue
        klasse = d[2].strip().upper()
        if klasse.endswith("TYPE"):
            klasse = klasse[:-4]
        uit.append((d[0].strip(), klasse, (d[3].strip().upper() if len(d) > 3 and d[3].strip() else None)))
    return uit


def basisklasse(klasse: str) -> str:
    k = klasse.upper()
    return re.sub(r"(STANDARDCASE|ELEMENTEDCASE)$", "", k)


def categorieen_voor(klasse: str) -> list[dict]:
    """Revit-categorieën die volgens de NLRS-exportmapping naar deze IFC-klasse exporteren."""
    k = basisklasse(klasse)
    uit = [{"categorie": c, "ost": OST.get(c), "predefined_type": pt, "herkomst": "nlrs-exportmapping"}
           for c, kl, pt in exportmapping() if kl == k and not c.endswith("Tags")]
    for c in EXTRA_KLASSE.get(k, []):
        if not any(x["categorie"] == c for x in uit):
            uit.append({"categorie": c, "ost": OST.get(c), "predefined_type": None, "herkomst": "revit-standaard"})
    return uit


@lru_cache(maxsize=None)
def shared_parameters() -> dict:
    """NLRS-parameternaam -> {guid, datatype, groep}, uit 'NLRS_Shared Parameters - Totaal.txt'."""
    groepen, uit = {}, {}
    for r in _regels(SP_BESTAND):
        d = r.split("\t")
        if d[0] == "GROUP" and len(d) > 2:
            groepen[d[1]] = d[2]
        elif d[0] == "PARAM" and len(d) > 5:
            uit[d[2]] = {"guid": d[1], "datatype": d[3], "groep": groepen.get(d[5], d[5])}
    return uit


@lru_cache(maxsize=None)
def adsk_parameters() -> dict:
    """Naam -> [GUID, datatype, instance|type] van de IFC Shared Parameters van Autodesk."""
    pad = NLRS / "adsk_ifc_parameters.json"
    return json.loads(pad.read_text(encoding="utf-8")) if pad.is_file() else {}


@lru_cache(maxsize=None)
def ils_kolommen() -> dict:
    pad = NLRS / "nlrs_ils_kolommen.json"
    return json.loads(pad.read_text(encoding="utf-8")) if pad.is_file() else {}
