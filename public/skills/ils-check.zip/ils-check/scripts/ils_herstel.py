"""Voer een goedgekeurd herstelplan uit: parameters binden en waarden vullen. Standaard als proef.

    python ils_herstel.py <uitmap van ils_revit_check> [--document "<naam>"] [--echt] [--alleen binden|vullen]
                          [--alleen-leeg]

Leest herstelplan.json en te-vullen.csv uit de uitmap. Alleen regels met een nieuwe_waarde worden
geschreven. Zonder --echt gaat alles als proef (dry_run): Revit meldt wat er zou veranderen, er verandert
niets. Met --echt moet in herstelplan.json "goedgekeurd": true staan (de gebruiker keurt het plan goed,
daarna zet Claude die vlag). Het script bewaart het model nooit. Elke stap komt in herstel-logboek.json.

Bridge-opdrachten: bind_shared_parameters en set_parameter_values_bulk.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

TIMEOUT = 300


def lees_vulregels(pad: Path) -> list[dict]:
    if not pad.is_file():
        return []
    with open(pad, encoding="utf-8-sig", newline="") as f:
        tekst = f.read()
    scheiding = ";" if tekst.split("\n", 1)[0].count(";") >= tekst.split("\n", 1)[0].count(",") else ","
    return [r for r in csv.DictReader(tekst.splitlines(), delimiter=scheiding)
            if (r.get("nieuwe_waarde") or "").strip() != ""]


def edits_uit(regels: list[dict]) -> list[dict]:
    uit, gezien = [], set()
    for r in regels:
        try:
            eid = int(str(r["element_id"]).strip())
        except (KeyError, ValueError):
            continue
        sleutel = (eid, r["param"], r.get("target") or "instance")
        if sleutel in gezien:
            continue
        gezien.add(sleutel)
        uit.append({"element_id": eid, "param": r["param"], "value": r["nieuwe_waarde"].strip(),
                    "target": (r.get("target") or "instance").strip() or "instance"})
    return uit


def voer_uit(uitmap: Path, document: str | None = None, echt: bool = False, alleen: str | None = None,
             alleen_leeg: bool = False, call=None) -> dict:
    plan = json.loads((uitmap / "herstelplan.json").read_text(encoding="utf-8-sig"))
    document = document or plan.get("document")
    if echt and not plan.get("goedgekeurd"):
        raise SystemExit("Het plan is niet goedgekeurd: zet \"goedgekeurd\": true in herstelplan.json nadat de "
                         "gebruiker het plan (de proef) heeft gezien en akkoord gaf.")
    if call is None:
        from revit_agent.bridge import call  # noqa: WPS433
    logboek = {"document": document, "echt": echt, "begin": dt.datetime.now().isoformat(timespec="seconds"),
               "stappen": []}

    def stap(naam, params):
        regel = {"stap": naam, "tijd": dt.datetime.now().isoformat(timespec="seconds"),
                 "dry_run": params.get("dry_run"), "aantal": len(params.get("bindings") or params.get("edits") or [])}
        try:
            regel["antwoord"] = call(naam, params, timeout=TIMEOUT)
            regel["gelukt"] = True
        except Exception as e:  # noqa: BLE001 - elke fout komt in het logboek en stopt de rest
            regel["gelukt"] = False
            regel["fout"] = f"{type(e).__name__}: {e}"
        logboek["stappen"].append(regel)
        return regel

    binden = [{k: b[k] for k in ("name", "guid", "categories", "instance", "group") if b.get(k) is not None}
              for b in plan.get("te_binden", []) if b.get("guid") and b.get("categories")]
    if alleen in (None, "binden") and binden:
        r = stap("bind_shared_parameters", {"target_document": document, "shared_param_file": plan["shared_param_file"],
                                            "bindings": binden, "dry_run": not echt})
        if not r["gelukt"]:
            return _bewaar(uitmap, logboek)
    edits = edits_uit(lees_vulregels(Path(plan.get("te_vullen_csv") or uitmap / "te-vullen.csv")))
    if alleen in (None, "vullen") and edits:
        if not echt and binden and alleen is None:
            logboek["opmerking"] = ("proef: parameters die nog gebonden moeten worden, bestaan in de proef nog niet; "
                                    "het vullen van die parameters meldt in de proef 'parameter ontbreekt'")
        stap("set_parameter_values_bulk", {"target_document": document, "edits": edits, "dry_run": not echt,
                                           "only_if_empty": alleen_leeg})
    return _bewaar(uitmap, logboek)


def _bewaar(uitmap: Path, logboek: dict) -> dict:
    logboek["einde"] = dt.datetime.now().isoformat(timespec="seconds")
    pad = uitmap / "herstel-logboek.json"
    oud = []
    if pad.is_file():
        try:
            oud = json.loads(pad.read_text(encoding="utf-8"))
        except ValueError:
            oud = []
    oud = oud if isinstance(oud, list) else [oud]
    oud.append(logboek)
    pad.write_text(json.dumps(oud, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    return logboek


def samenvatting(logboek: dict) -> str:
    regels = [f"{'ECHT' if logboek['echt'] else 'PROEF'} op {logboek['document']}"]
    for s in logboek["stappen"]:
        if not s["gelukt"]:
            regels.append(f"  {s['stap']}: MISLUKT {s['fout']}")
            continue
        a = s["antwoord"] or {}
        if s["stap"] == "bind_shared_parameters":
            rs = a.get("results") or a.get("resultaten") or a.get("bindings") or []
            telling = {}
            for x in rs:
                telling[x.get("status")] = telling.get(x.get("status"), 0) + 1
            regels.append(f"  binden: {s['aantal']} parameters {telling or ''}")
        else:
            regels.append(f"  vullen: gevraagd {a.get('gevraagd')}, geschreven {a.get('geschreven')}, "
                          f"fouten {a.get('fouten_totaal')}, al gelijk {a.get('ongewijzigd_al_gelijk')}")
    if logboek.get("opmerking"):
        regels.append("  " + logboek["opmerking"])
    regels.append("Het model is niet bewaard.")
    return "\n".join(regels)


def main(argv=None) -> int:
    for stroom in (sys.stdout, sys.stderr):
        try:
            stroom.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description="Voer het herstelplan uit (standaard als proef).")
    ap.add_argument("uitmap")
    ap.add_argument("--document")
    ap.add_argument("--echt", action="store_true", help="echt uitvoeren (alleen na akkoord van de gebruiker)")
    ap.add_argument("--alleen", choices=["binden", "vullen"])
    ap.add_argument("--alleen-leeg", action="store_true", help="schrijf alleen in lege velden")
    a = ap.parse_args(argv)
    lb = voer_uit(Path(a.uitmap), a.document, a.echt, a.alleen, a.alleen_leeg)
    print(samenvatting(lb))
    return 0 if all(s["gelukt"] for s in lb["stappen"]) else 1


if __name__ == "__main__":
    sys.exit(main())
