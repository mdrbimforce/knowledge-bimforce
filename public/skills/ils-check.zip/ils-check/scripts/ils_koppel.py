"""Koppel elke eis uit een ILS (IDS) aan Revit: welke categorieën, welke parameter, langs welke weg.

    python ils_koppel.py <eisen.json | ids-bestand | map> [--koppeling ils-koppeling.json]
                         [--json koppeling.json] [--md koppeling.md]

Volgorde (de eerste die iets vindt, wordt de koppeling; de rest staat bij 'alternatieven'):
  1. gebruiker         eigen aanvulling in ils-koppeling.json (gaat altijd voor)
  2. nlrs-custom-pset  NLRS custom property sets (RSF_NLRS_3.1.1_CustomPSets.txt)
  3. nlrs-mappingtabel NLRS parametermappingtabel IFC4 (RSF_NLRS_3.1.1_IfcParameterMapping_IFC4.txt)
  4. autodesk-ifc      parameter met de naam die de IFC-exporter zelf leest (Pset_X.Y, IfcName, ...),
                       zoals in de IFC Shared Parameters van Autodesk
  5. revit-zelf        wat Revit zonder eigen parameter vult (Name, LongName van ruimten, bouwlaag, materiaal)
Elke koppeling krijgt een zekerheid: hoog, midden of nagaan. Wat niet te koppelen is, staat onder
'vraagt een keuze'.

Let op: de parametermappingtabel wordt bij een export via de API (de bridge) niet gelezen. Een
koppeling via de mappingtabel werkt alleen bij een export vanuit het Revit-venster met die tabel in de
export-setup. Daarom staat bij elke koppeling de exportweg, en bij de mappingtabel een alternatief.
"""
from __future__ import annotations

import argparse
import collections
import json
import re
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import ids_lezen  # noqa: E402
import nlrs_data as nd  # noqa: E402

ZEKERHEID = ("hoog", "midden", "nagaan")

# Wat Revit zelf vult, zonder eigen parameter. Bewust bescheiden: alleen wat vaststaat staat op 'hoog'.
# (klasse of '*', attribuut) -> (Revit-bron, zekerheid, opmerking)
REVIT_ATTRIBUUT = {
    ("*", "GLOBALID"): ("IfcGUID (Revit maakt hem bij de export)", "hoog", "altijd gevuld"),
    ("*", "NAME"): ("familie- en typenaam (standaard van de exporter)", "midden",
                    "altijd gevuld; een eigen waarde of een patroon vraagt de parameter IfcName"),
    ("*", "OBJECTTYPE"): ("typenaam (standaard van de exporter)", "nagaan",
                          "een vaste waarde vraagt de parameter IfcObjectType"),
    ("*", "DESCRIPTION"): ("leeg tenzij IfcDescription gevuld is", "nagaan", "vul de parameter IfcDescription"),
    ("*", "TAG"): ("element-id van Revit (standaard van de exporter)", "nagaan", "een eigen waarde vraagt IfcTag"),
    ("IFCSPACE", "NAME"): ("Number (ruimtenummer)", "hoog", "standaard van de exporter voor ruimten"),
    ("IFCSPACE", "LONGNAME"): ("Name (ruimtenaam)", "hoog", "standaard van de exporter voor ruimten"),
    ("IFCBUILDINGSTOREY", "NAME"): ("naam van het level", "hoog", "elk level met 'Building Story' aan wordt een bouwlaag"),
    ("IFCBUILDINGSTOREY", "ELEVATION"): ("hoogte van het level", "hoog", ""),
}
SETUP_KLASSEN = {"IFCMAPCONVERSION", "IFCMAPCONVERSIONSCALED", "IFCPROJECTEDCRS", "IFCGEOMETRICREPRESENTATIONCONTEXT", "IFCCOORDINATEREFERENCESYSTEM",
                 "IFCUNITASSIGNMENT", "IFCSIUNIT", "IFCOWNERHISTORY", "IFCAPPLICATION"}
ADSK_ATTRIBUUT = {"NAME": "IfcName", "DESCRIPTION": "IfcDescription", "LONGNAME": "IfcLongName",
                  "OBJECTTYPE": "IfcObjectType", "TAG": "IfcTag"}


def _upper(x):
    return (x or "").upper()


def _waarden(w) -> list[str]:
    """Letterlijke namen uit een waarde (vast of lijst); bij een patroon een lege lijst."""
    if not w:
        return []
    return list(w.get("waarden") or [])


def _sleutel(eis) -> str:
    s = eis["soort"]
    if s == "eigenschap":
        return f"{eis.get('pset')}.{eis.get('eigenschap')}"
    if s == "attribuut":
        return f"attribuut:{eis.get('eigenschap')}"
    if s == "onderdeel-van":
        return f"onderdeel-van:{eis.get('doel_klasse')}"
    return s


def laad_gebruiker(pad) -> dict:
    """ils-koppeling.json: {"koppelingen": [{"sleutel" | "pset"+"eigenschap", "klasse"?, "param",
    "binding"?, "exportweg"?, "opmerking"?}], "categorieen": {"IFCWALL": ["OST_Walls", ...]}}"""
    if not pad:
        return {"koppelingen": [], "categorieen": {}}
    d = json.loads(Path(pad).read_text(encoding="utf-8-sig"))
    for k in d.get("koppelingen", []):
        if not k.get("sleutel"):
            k["sleutel"] = f"{k.get('pset')}.{k.get('eigenschap')}" if k.get("pset") else k.get("eigenschap", "")
    d.setdefault("categorieen", {})
    return d


def _kandidaat(param, herkomst, zekerheid, exportweg, opmerking="", binding=None):
    sp = nd.shared_parameters().get(param) if param else None
    adsk = nd.adsk_parameters().get(param) if param else None
    uit = {"param": param, "herkomst": herkomst, "zekerheid": zekerheid, "exportweg": exportweg,
           "opmerking": opmerking, "binding": binding}
    if sp:
        uit.update(guid=sp["guid"], datatype_revit=sp["datatype"], bron_parameter="nlrs")
    elif adsk:
        uit.update(guid=adsk[0], datatype_revit=adsk[1], bron_parameter="autodesk-ifc",
                   binding=binding or adsk[2])
    elif param:
        uit["bron_parameter"] = "ingebouwd-of-familie"  # bv. Fire Rating, Assembly Code: geen GUID, niet te binden
    return uit


def categorieen(eis, gebruiker) -> dict:
    klassen = [k for k in eis.get("klassen", []) if not k.startswith("patroon ")]
    if klassen and all(k in SETUP_KLASSEN for k in klassen):
        return {"alle": False, "lijst": [], "opmerking": "geen element: komt uit de export-setup "
                "(gedeelde coördinaten, georeferentie, eenheden)"}
    if klassen and all(k in ("IFCELEMENT", "IFCPRODUCT", "IFCBUILDINGELEMENT", "IFCBUILTELEMENT", "IFCOBJECT")
                       for k in klassen):
        return {"alle": True, "lijst": [], "opmerking": f"de eis geldt voor elk element ({', '.join(klassen)})"}
    if not klassen:
        return {"alle": True, "lijst": [], "opmerking": "de eis noemt geen IFC-klasse: hij geldt voor elk object"}
    lijst, zonder = [], []
    for k in klassen:
        eigen = gebruiker["categorieen"].get(k) or gebruiker["categorieen"].get(nd.basisklasse(k))
        if eigen:
            lijst += [{"klasse": k, "categorie": c, "ost": c if c.startswith("OST_") else nd.OST.get(c),
                       "herkomst": "gebruiker"} for c in eigen]
            continue
        gevonden = nd.categorieen_voor(k)
        if not gevonden:
            zonder.append(k)
        lijst += [dict(g, klasse=k) for g in gevonden]
    # ontdubbelen op categorie
    gezien, uniek = set(), []
    for c in lijst:
        if c["categorie"] not in gezien:
            gezien.add(c["categorie"])
            uniek.append(c)
    opm = ""
    if zonder:
        opm = ("geen Revit-categorie exporteert naar " + ", ".join(zonder) +
               " volgens de NLRS-exportmapping; kan wel per familie met 'Export Type to IFC As' (IfcExportAs)")
    if eis.get("predefined_type"):
        opm += ("; " if opm else "") + "predefined type " + ", ".join(eis["predefined_type"]) + \
            " komt uit de exportmapping of uit IfcExportType per familie"
    return {"alle": False, "lijst": uniek, "zonder_categorie": zonder, "opmerking": opm}


_ADSK_HOOFD: dict = {}


def _adsk_hoofdletters() -> dict:
    if not _ADSK_HOOFD:
        _ADSK_HOOFD.update({k.upper(): k for k in nd.adsk_parameters()})
    return _ADSK_HOOFD


def kandidaten_eigenschap(eis, gebruiker) -> list[dict]:
    psets = _waarden(eis.get("pset_waarde")) or ([eis["pset"]] if eis.get("pset") else [])
    props = _waarden(eis.get("naam_waarde")) or ([eis["eigenschap"]] if eis.get("eigenschap") else [])
    pset_patroon = (eis.get("pset_waarde") or {}).get("patroon")
    uit = []
    for k in gebruiker["koppelingen"]:
        if any(k["sleutel"].upper() == f"{p}.{q}".upper() for p in psets for q in props) or \
                (k["sleutel"].upper() in {q.upper() for q in props} and not psets):
            if not k.get("klasse") or k["klasse"].upper() in eis.get("klassen", []):
                uit.append(_kandidaat(k["param"], "gebruiker", "hoog", k.get("exportweg", "zoals de gebruiker aangeeft"),
                                      k.get("opmerking", ""), k.get("binding")))
    if pset_patroon:  # pset als patroon: alle bekende psets die erop passen
        try:
            rx = re.compile(pset_patroon)
            psets = sorted({v["pset"] for v in nd.parametermapping().values() if rx.fullmatch(v["pset"])} |
                           {v["naam"] for v in nd.custom_psets().values() if rx.fullmatch(v["naam"])})
        except re.error:
            pass
    for p in psets:
        for q in props:
            cp = nd.custom_psets().get(p.upper())
            if cp and q.upper() in cp["props"]:
                x = cp["props"][q.upper()]
                for i, par in enumerate(x["params"]):
                    uit.append(_kandidaat(par, "nlrs-custom-pset", "hoog" if i == 0 else "midden",
                                          f"custom property set '{cp['naam']}' in de export-setup",
                                          "" if len(x["params"]) == 1 else
                                          f"{len(x['params'])} NLRS-parameters vullen deze eigenschap; nagaan welke de exporter neemt"))
            pm = nd.parametermapping().get((p.upper(), q.upper()))
            if pm:
                for par in pm["params"]:
                    uit.append(_kandidaat(par, "nlrs-mappingtabel", "midden", "parametermappingtabel in de export-setup",
                                          "de mappingtabel wordt bij een export via de API (bridge) niet gelezen; "
                                          "alternatief: dezelfde waarde in de parameter "
                                          f"'{pm['pset']}.{pm['property']}' of in een custom property set"))
            naam = f"{p}.{q}"
            adsk = _adsk_hoofdletters()
            if naam.upper() in adsk:
                echte = adsk[naam.upper()]
                uit.append(_kandidaat(echte, "autodesk-ifc", "hoog",
                                      "de exporter leest een parameter met deze naam (optie IFC common property sets)",
                                      "staat in de IFC Shared Parameters van Autodesk; binden uit dat bestand"))
                if (naam + "[Type]").upper() in adsk:
                    uit.append(_kandidaat(adsk[(naam + "[Type]").upper()], "autodesk-ifc", "hoog",
                                          "zelfde, als typeparameter", ""))
            if p.upper().startswith("QTO_"):
                uit.append(_kandidaat(None, "revit-zelf", "midden", "exportoptie 'Export base quantities'",
                                      "Revit berekent de hoeveelheid bij de export; geen parameter nodig"))
    # NLRS-bronbestand: kolom 'Mapping ILS O&E' en 'Mapping UVIP Aedes ILS'
    if any(re.search(r"ILS|O&E|UVIP|AEDES", p.upper()) for p in psets):
        for par, w in nd.ils_kolommen().items():
            if any(_upper(w.get(k)) in {q.upper() for q in props} for k in ("ils_oe", "uvip_aedes")):
                if not any(c["param"] == par for c in uit):
                    uit.append(_kandidaat(par, "nlrs-bronbestand", "midden", "custom property set (zelf toevoegen)",
                                          "uit de kolom 'Mapping ILS O&E' of 'Mapping UVIP Aedes ILS' van het NLRS-bronbestand"))
    return uit


def kandidaten_overig(eis, gebruiker) -> list[dict]:
    s = eis["soort"]
    uit = []
    sleutel = _sleutel(eis).upper()
    for k in gebruiker["koppelingen"]:
        if k["sleutel"].upper() == sleutel:
            uit.append(_kandidaat(k["param"], "gebruiker", "hoog", k.get("exportweg", "zoals de gebruiker aangeeft"),
                                  k.get("opmerking", ""), k.get("binding")))
    if s == "attribuut":
        naam = _upper(eis.get("eigenschap"))
        klassen = eis.get("klassen") or ["*"]
        vast = eis.get("waarde") is not None
        if all(k in SETUP_KLASSEN for k in klassen):
            uit.append(_kandidaat(None, "revit-zelf", "nagaan",
                                  "gedeelde coördinaten (survey point) en de georeferentie in de export-setup",
                                  "geen parameter: nagaan in de export-setup en na de export in de IFC toetsen"))
            return uit
        for kl in klassen:
            r = REVIT_ATTRIBUUT.get((nd.basisklasse(kl), naam)) or REVIT_ATTRIBUUT.get(("*", naam))
            if r:
                zeker = r[1]
                if vast and zeker == "hoog" and naam not in ("NAME", "LONGNAME", "ELEVATION"):
                    zeker = "midden"
                uit.append(_kandidaat(None, "revit-zelf", zeker, r[0], r[2]))
                break
        if naam in ADSK_ATTRIBUUT:
            uit.append(_kandidaat(ADSK_ATTRIBUUT[naam], "autodesk-ifc", "hoog",
                                  "de exporter leest deze parameter en zet de waarde in het attribuut",
                                  "nodig als de eis een vaste waarde of een patroon vraagt"))
        if any(nd.basisklasse(k) in ("IFCPROJECT", "IFCBUILDING", "IFCSITE") for k in klassen):
            uit.append(_kandidaat(None, "revit-zelf", "nagaan", "Projectinformatie (Project Name, Building Name, ...)",
                                  "welk veld van Projectinformatie naar welk attribuut gaat, nagaan in de export-setup"))
    elif s == "classificatie":
        uit.append(_kandidaat("Assembly Code", "revit-zelf", "midden",
                              "ingebouwde typeparameter, via de classificatie-instelling van de export-setup",
                              "de naam van het systeem in de IFC komt uit de export-setup; controleer dat hij "
                              "past bij het gevraagde systeem" + (f" ({eis.get('systeem')})" if eis.get("systeem") else ""),
                              binding="type"))
        uit.append(_kandidaat("ClassificationCode", "autodesk-ifc", "hoog",
                              "de exporter leest ClassificationCode (vorm '[Systeem]Code:Omschrijving')",
                              "staat in de IFC Shared Parameters van Autodesk; los van de export-setup"))
    elif s == "materiaal":
        uit.append(_kandidaat(None, "revit-zelf", "midden", "materiaal van het element (lagen of materiaalparameter)",
                              "systeemfamilies met lagen krijgen altijd materiaal; bij laadbare families nagaan"))
    elif s == "onderdeel-van":
        doel = nd.basisklasse(eis.get("doel_klasse") or "")
        tabel = {"IFCBUILDINGSTOREY": ("level van het element", "hoog", ""),
                 "IFCBUILDING": ("ruimtelijke structuur van de export", "hoog", ""),
                 "IFCSITE": ("ruimtelijke structuur van de export", "hoog", ""),
                 "IFCELEMENTASSEMBLY": ("Revit-assembly", "midden", "alleen elementen in een assembly"),
                 "IFCSYSTEM": ("MEP-systeem", "midden", "exportoptie voor systemen"),
                 "IFCDISTRIBUTIONSYSTEM": ("MEP-systeem", "midden", "exportoptie voor systemen")}
        if doel in tabel:
            r = tabel[doel]
            uit.append(_kandidaat(None, "revit-zelf", r[1], r[0], r[2]))
        if doel in ("IFCZONE", "IFCGROUP"):
            uit.append(_kandidaat("ZoneName", "autodesk-ifc", "hoog", "de exporter maakt een IfcZone per waarde van ZoneName",
                                  "ook ZoneObjectType, ZoneLongName, ZoneDescription; voor een tweede zone 'ZoneName 2'"))
    elif s == "klasse":
        uit.append(_kandidaat(None, "revit-zelf", "midden", "categorie via de exportmapping, of 'Export Type to IFC As' per familie", ""))
    elif s == "bestaan":
        uit.append(_kandidaat(None, "revit-zelf", "midden", "elementen van de juiste categorie in het model", ""))
    return uit


def koppel_eis(eis, gebruiker) -> dict:
    kand = kandidaten_eigenschap(eis, gebruiker) if eis["soort"] == "eigenschap" else kandidaten_overig(eis, gebruiker)
    uit = {k: eis.get(k) for k in ("id", "bestand", "specificatie", "soort", "gebruik", "spec_gebruik", "klassen",
                                   "predefined_type", "voorwaarden", "pset", "eigenschap", "datatype", "waarde",
                                   "waarde_tekst", "systeem", "doel_klasse", "instructies")}
    uit["sleutel"] = _sleutel(eis)
    uit["categorieen"] = categorieen(eis, gebruiker)
    uit["koppeling"] = kand[0] if kand else None
    uit["alternatieven"] = kand[1:]
    uit["vraagt_keuze"] = None
    if not kand:
        if eis["soort"] == "eigenschap":
            uit["vraagt_keuze"] = ("geen NLRS-parameter of exporter-parameter gevonden voor "
                                   f"{eis.get('pset')}.{eis.get('eigenschap')}: kies een bestaande parameter of maak er "
                                   "een, en voeg een regel toe aan een custom property set (of aan ils-koppeling.json)")
        else:
            uit["vraagt_keuze"] = f"geen bekende Revit-bron voor {uit['sleutel']}; bespreek hoe dit in de IFC komt"
    elif uit["categorieen"].get("zonder_categorie"):
        uit["vraagt_keuze"] = uit["categorieen"]["opmerking"]
    return uit


def koppel(eisen: list[dict], gebruiker=None) -> dict:
    gebruiker = gebruiker or {"koppelingen": [], "categorieen": {}}
    rijen = [koppel_eis(e, gebruiker) for e in eisen]
    per_herkomst = collections.Counter((r["koppeling"] or {}).get("herkomst", "geen") for r in rijen)
    per_zekerheid = collections.Counter((r["koppeling"] or {}).get("zekerheid", "geen") for r in rijen)
    gekoppeld = sum(1 for r in rijen if r["koppeling"])
    return {"aantal": len(rijen), "gekoppeld": gekoppeld,
            "procent": round(100 * gekoppeld / len(rijen), 1) if rijen else 0.0,
            "per_herkomst": dict(per_herkomst), "per_zekerheid": dict(per_zekerheid),
            "vraagt_keuze": [{"id": r["id"], "sleutel": r["sleutel"], "reden": r["vraagt_keuze"]}
                             for r in rijen if r["vraagt_keuze"]],
            "eisen": rijen}


def _cel(t, n=110):
    t = str(t if t is not None else "").replace("|", "\\|").replace("\n", " ")
    return t if len(t) <= n else t[:n - 1] + "…"


def markdown(k: dict) -> str:
    r = ["# Koppeling ILS-eisen aan Revit", "",
         f"{k['aantal']} eisen, {k['gekoppeld']} gekoppeld ({k['procent']} %).", "",
         "| Herkomst | Aantal |", "|---|---|"]
    r += [f"| {h} | {n} |" for h, n in sorted(k["per_herkomst"].items(), key=lambda x: -x[1])]
    r += ["", "| Zekerheid | Aantal |", "|---|---|"]
    r += [f"| {h} | {n} |" for h, n in sorted(k["per_zekerheid"].items(), key=lambda x: -x[1])]
    r += ["", "## Per eis", "", "| Id | Eis | Klasse | Revit-categorieën | Parameter | Herkomst | Zekerheid | Exportweg |",
          "|---|---|---|---|---|---|---|---|"]
    for e in k["eisen"]:
        c = e["categorieen"]
        cats = "(alle)" if c.get("alle") else ", ".join(x["categorie"] for x in c["lijst"][:5]) + \
            (f" en {len(c['lijst']) - 5} meer" if len(c["lijst"]) > 5 else "")
        kp = e["koppeling"] or {}
        r.append(f"| {e['id']} | {_cel(e['sleutel'])} | {_cel(', '.join(e['klassen'][:3]) or '(elk)')} | {_cel(cats)} | "
                 f"{_cel(kp.get('param') or ('(geen parameter)' if kp else '-'))} | {kp.get('herkomst', '-')} | "
                 f"{kp.get('zekerheid', '-')} | {_cel(kp.get('exportweg', ''))} |")
    if k["vraagt_keuze"]:
        r += ["", "## Vraagt een keuze", ""]
        r += [f"- **{v['id']}** {v['sleutel']}: {v['reden']}" for v in k["vraagt_keuze"]]
    return "\n".join(r) + "\n"


def lees_eisen(bronnen) -> list[dict]:
    if len(bronnen) == 1 and str(bronnen[0]).lower().endswith(".json"):
        d = json.loads(Path(bronnen[0]).read_text(encoding="utf-8-sig"))
        return d["eisen"] if isinstance(d, dict) else d
    return ids_lezen.lees(bronnen)["eisen"]


def main(argv=None) -> int:
    for stroom in (sys.stdout, sys.stderr):
        try:
            stroom.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description="Koppel ILS-eisen aan Revit-parameters.")
    ap.add_argument("bron", nargs="+", help="eisen.json (van ids_lezen.py), IDS-bestand(en) of map")
    ap.add_argument("--koppeling", help="eigen aanvulling ils-koppeling.json (gaat voor)")
    ap.add_argument("--json", dest="json_uit")
    ap.add_argument("--md", dest="md_uit")
    a = ap.parse_args(argv)
    k = koppel(lees_eisen(a.bron), laad_gebruiker(a.koppeling))
    if a.json_uit:
        Path(a.json_uit).write_text(json.dumps(k, ensure_ascii=False, indent=1), encoding="utf-8")
    if a.md_uit:
        Path(a.md_uit).write_text(markdown(k), encoding="utf-8")
    print(f"{k['aantal']} eisen, {k['gekoppeld']} gekoppeld ({k['procent']} %); per herkomst {k['per_herkomst']}; "
          f"per zekerheid {k['per_zekerheid']}; vraagt een keuze: {len(k['vraagt_keuze'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
