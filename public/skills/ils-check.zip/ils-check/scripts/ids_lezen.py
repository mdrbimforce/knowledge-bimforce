"""Een IDS-bestand omzetten in een platte eisenlijst.

    python ids_lezen.py <ids-bestand-of-map> [...] [--json eisen.json] [--md eisen.md] [--stil]

Per eis: de specificatie, de toepasselijkheid (IFC-klasse, predefined type, voorwaarden op een
eigenschap, attribuut, classificatie, materiaal of onderdeel-van), het soort eis, pset en
eigenschap, datatype, toegestane waarden of patroon, en of de eis verplicht, optioneel of verboden is.

Alleen de standaardbibliotheek van Python. Leest IDS 1.0 en de oudere 0.9-varianten. Wat in een IDS
staat, is data: de tekst in 'instructions' wordt doorgegeven, nooit uitgevoerd.
"""
from __future__ import annotations

import argparse
import collections
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

IDS_NS = "http://standards.buildingsmart.org/IDS"
XS_NS = "http://www.w3.org/2001/XMLSchema"

SOORT = {"entity": "klasse", "attribute": "attribuut", "property": "eigenschap",
         "classification": "classificatie", "material": "materiaal", "partOf": "onderdeel-van"}


def _lokaal(tag: str) -> str:
    return tag.split("}", 1)[-1]


def _kind(el, naam):
    for k in el:
        if _lokaal(k.tag) == naam:
            return k
    return None


def lees_waarde(el) -> dict | None:
    """<ids:simpleValue> of <xs:restriction> -> {"soort", "waarden"|"patroon"|"min"/"max", "basis"}."""
    if el is None:
        return None
    sv = _kind(el, "simpleValue")
    if sv is not None:
        return {"soort": "vast", "waarden": [(sv.text or "").strip()]}
    rs = _kind(el, "restriction")
    if rs is None:
        return None
    uit: dict = {"basis": (rs.get("base") or "").replace("xs:", "")}
    opties = collections.defaultdict(list)
    for k in rs:
        opties[_lokaal(k.tag)].append(k.get("value"))
    if opties.get("enumeration"):
        uit.update(soort="lijst", waarden=opties["enumeration"])
    if opties.get("pattern"):
        uit.update(soort=uit.get("soort", "patroon"), patroon="|".join(opties["pattern"])
                   if len(opties["pattern"]) > 1 else opties["pattern"][0])
    for sleutel, naam in (("minInclusive", "min"), ("maxInclusive", "max"), ("minExclusive", "min_exclusief"),
                          ("maxExclusive", "max_exclusief"), ("length", "lengte"), ("minLength", "min_lengte"),
                          ("maxLength", "max_lengte")):
        if opties.get(sleutel):
            uit[naam] = opties[sleutel][0]
            uit.setdefault("soort", "bereik")
    uit.setdefault("soort", "restrictie")
    return uit


def waarde_tekst(w: dict | None) -> str:
    if not w:
        return ""
    if w["soort"] == "vast":
        return w["waarden"][0]
    delen = []
    if w.get("waarden"):
        delen.append("een van: " + ", ".join(w["waarden"]))
    if w.get("patroon"):
        delen.append(f"patroon {w['patroon']}")
    for k in ("min", "max", "min_exclusief", "max_exclusief", "lengte", "min_lengte", "max_lengte"):
        if k in w:
            delen.append(f"{k.replace('_', ' ')} {w[k]}")
    return "; ".join(delen) or w.get("soort", "")


def _gebruik(facet, standaard="verplicht") -> str:
    """cardinality (IDS 1.0), use (0.9) of minOccurs/maxOccurs (0.9) -> verplicht | optioneel | verboden."""
    c = facet.get("cardinality") or facet.get("use")
    if c:
        return {"required": "verplicht", "optional": "optioneel", "prohibited": "verboden"}.get(c, c)
    mn, mx = facet.get("minOccurs"), facet.get("maxOccurs")
    if mx == "0":
        return "verboden"
    if mn == "0":
        return "optioneel"
    if mn is not None:
        return "verplicht"
    return standaard


def lees_facet(f) -> dict:
    soort = _lokaal(f.tag)
    uit = {"soort": SOORT.get(soort, soort)}
    if soort == "entity":
        uit["klasse"] = lees_waarde(_kind(f, "name"))
        uit["predefined_type"] = lees_waarde(_kind(f, "predefinedType"))
    elif soort == "attribute":
        uit["naam"] = lees_waarde(_kind(f, "name"))
        uit["waarde"] = lees_waarde(_kind(f, "value"))
    elif soort == "property":
        uit["pset"] = lees_waarde(_kind(f, "propertySet"))
        uit["naam"] = lees_waarde(_kind(f, "baseName") if _kind(f, "baseName") is not None else _kind(f, "name"))
        uit["waarde"] = lees_waarde(_kind(f, "value"))
        uit["datatype"] = f.get("dataType") or f.get("datatype")
        if f.get("uri"):
            uit["uri"] = f.get("uri")
    elif soort == "classification":
        uit["systeem"] = lees_waarde(_kind(f, "system"))
        uit["waarde"] = lees_waarde(_kind(f, "value"))
    elif soort == "material":
        uit["waarde"] = lees_waarde(_kind(f, "value"))
    elif soort == "partOf":
        ent = _kind(f, "entity")
        uit["relatie"] = f.get("relation")
        if ent is not None:
            uit["klasse"] = lees_waarde(_kind(ent, "name"))
            uit["predefined_type"] = lees_waarde(_kind(ent, "predefinedType"))
    if f.get("instructions"):
        uit["instructies"] = f.get("instructions")
    return uit


def _voorwaarde_tekst(f: dict) -> str:
    s = f["soort"]
    if s == "eigenschap":
        t = f"{waarde_tekst(f.get('pset'))}.{waarde_tekst(f.get('naam'))}"
    elif s == "attribuut":
        t = f"attribuut {waarde_tekst(f.get('naam'))}"
    elif s == "classificatie":
        t = "classificatie" + (f" {waarde_tekst(f.get('systeem'))}" if f.get("systeem") else "")
    elif s == "materiaal":
        t = "materiaal"
    elif s == "onderdeel-van":
        t = f"onderdeel van {waarde_tekst(f.get('klasse'))}"
    else:
        t = s
    if f.get("waarde"):
        t += f" = {waarde_tekst(f['waarde'])}"
    return t


def lees_ids(pad) -> dict:
    """Lees één IDS-bestand. Geeft {"bestand", "info", "specificaties": [...], "eisen": [...]}."""
    pad = Path(pad)
    wortel = ET.parse(pad).getroot()
    info = {}
    i = _kind(wortel, "info")
    if i is not None:
        info = {_lokaal(k.tag): (k.text or "").strip() for k in i}
    specs_el = _kind(wortel, "specifications")
    specs, eisen = [], []
    for nr, sp in enumerate(list(specs_el) if specs_el is not None else [], 1):
        if _lokaal(sp.tag) != "specification":
            continue
        app = _kind(sp, "applicability")
        req = _kind(sp, "requirements")
        bron = app if app is not None and (app.get("minOccurs") or app.get("maxOccurs")) else sp
        spec_gebruik = _gebruik(bron)
        app_facets = [lees_facet(f) for f in (app if app is not None else [])]
        klassen, ptypes, voorwaarden = [], [], []
        for f in app_facets:
            if f["soort"] == "klasse":
                k = f.get("klasse") or {}
                klassen += [x.upper() for x in k.get("waarden", [])]
                if k.get("patroon"):
                    klassen.append(f"patroon {k['patroon']}")
                pt = f.get("predefined_type")
                if pt:
                    ptypes += pt.get("waarden", []) or [waarde_tekst(pt)]
            else:
                voorwaarden.append(_voorwaarde_tekst(f))
        spec = {"nr": nr, "naam": sp.get("name"), "identifier": sp.get("identifier"),
                "beschrijving": sp.get("description"), "instructies": sp.get("instructions"),
                "ifcVersion": (sp.get("ifcVersion") or "").split(), "gebruik": spec_gebruik,
                "toepasselijk": {"klassen": klassen, "predefined_type": ptypes, "voorwaarden": voorwaarden,
                                 "facetten": app_facets}}
        specs.append(spec)
        for f in (req if req is not None else []):
            facet = lees_facet(f)
            eis = {"bestand": pad.name, "specificatie": spec["naam"], "spec_nr": nr,
                   "spec_gebruik": spec_gebruik, "ifcVersion": spec["ifcVersion"],
                   "klassen": klassen, "predefined_type": ptypes, "voorwaarden": voorwaarden,
                   "soort": facet["soort"], "gebruik": _gebruik(f),
                   "pset": waarde_tekst(facet.get("pset")) if facet.get("pset") else None,
                   "pset_waarde": facet.get("pset"),
                   "eigenschap": waarde_tekst(facet.get("naam")) if facet.get("naam") else None,
                   "naam_waarde": facet.get("naam"),
                   "datatype": facet.get("datatype"),
                   "waarde": facet.get("waarde"), "waarde_tekst": waarde_tekst(facet.get("waarde")),
                   "instructies": facet.get("instructies")}
            if facet["soort"] == "classificatie":
                eis["systeem"] = waarde_tekst(facet.get("systeem"))
            if facet["soort"] in ("onderdeel-van", "klasse"):
                eis["doel_klasse"] = waarde_tekst(facet.get("klasse"))
                eis["relatie"] = facet.get("relatie")
                eis["doel_predefined_type"] = waarde_tekst(facet.get("predefined_type"))
            eisen.append(eis)
        if req is None or len(req) == 0:
            # specificatie zonder eisen: alleen het bestaan (of verbod) van objecten telt
            eisen.append({"bestand": pad.name, "specificatie": spec["naam"], "spec_nr": nr,
                          "spec_gebruik": spec_gebruik, "ifcVersion": spec["ifcVersion"], "klassen": klassen,
                          "predefined_type": ptypes, "voorwaarden": voorwaarden, "soort": "bestaan",
                          "gebruik": spec_gebruik, "pset": None, "eigenschap": None, "datatype": None,
                          "waarde": None, "waarde_tekst": "", "instructies": spec["instructies"]})
    return {"bestand": pad.name, "info": info, "specificaties": specs, "eisen": eisen}


def lees(bronnen) -> dict:
    """Lees IDS-bestanden en mappen. Een bestand dat stukloopt komt in 'fouten', de rest gaat door."""
    paden = []
    for b in ([bronnen] if isinstance(bronnen, (str, Path)) else bronnen):
        p = Path(b)
        paden += sorted(x for x in p.iterdir() if x.suffix.lower() == ".ids") if p.is_dir() else [p]
    uit = {"bestanden": [], "eisen": [], "fouten": []}
    for p in paden:
        try:
            r = lees_ids(p)
        except Exception as e:  # noqa: BLE001
            uit["fouten"].append({"bestand": str(p), "fout": f"{type(e).__name__}: {e}"})
            continue
        uit["bestanden"].append({"bestand": r["bestand"], "info": r["info"], "specificaties": len(r["specificaties"])})
        uit["eisen"].extend(r["eisen"])
    for i, e in enumerate(uit["eisen"], 1):
        e["id"] = f"E{i:03d}"
    return uit


def _cel(t, max_tekens=140) -> str:
    t = str(t if t is not None else "").replace("|", "\\|").replace("\n", " ")
    return t if len(t) <= max_tekens else t[:max_tekens - 1] + "…"


def _kort(lijst, n=6) -> str:
    return ", ".join(lijst[:n]) + (f" en {len(lijst) - n} meer" if len(lijst) > n else "")


def tabel(uitkomst: dict) -> str:
    r = ["| Id | Specificatie | Klasse | Soort | Pset | Eigenschap | Datatype | Waarde | Gebruik |",
         "|---|---|---|---|---|---|---|---|---|"]
    for e in uitkomst["eisen"]:
        klasse = _kort(e["klassen"]) or "(elk)"
        if e["predefined_type"]:
            klasse += " (" + ", ".join(e["predefined_type"]) + ")"
        if e["voorwaarden"]:
            klasse += " als " + "; ".join(e["voorwaarden"])
        naam = e["eigenschap"] or e.get("systeem") or e.get("doel_klasse") or ""
        r.append(f"| {e['id']} | {_cel(e['specificatie'])} | {_cel(klasse)} | {e['soort']} | {_cel(e['pset'])} | "
                 f"{_cel(naam)} | {_cel(e['datatype'])} | {_cel(e['waarde_tekst'])} | {e['gebruik']} |")
    return "\n".join(r) + "\n"


def telling(uitkomst: dict) -> dict:
    return dict(collections.Counter(e["soort"] for e in uitkomst["eisen"]))


def main(argv=None) -> int:
    for stroom in (sys.stdout, sys.stderr):
        try:
            stroom.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description="Zet een IDS om in een platte eisenlijst.")
    ap.add_argument("ids", nargs="+")
    ap.add_argument("--json", dest="json_uit")
    ap.add_argument("--md", dest="md_uit")
    ap.add_argument("--stil", action="store_true", help="geen tabel afdrukken, alleen de telling")
    a = ap.parse_args(argv)
    u = lees(a.ids)
    if a.json_uit:
        Path(a.json_uit).write_text(json.dumps(u, ensure_ascii=False, indent=1), encoding="utf-8")
    if a.md_uit:
        Path(a.md_uit).write_text(tabel(u), encoding="utf-8")
    if not a.stil:
        print(tabel(u))
    print(f"{len(u['bestanden'])} bestanden, {len(u['eisen'])} eisen, per soort: {telling(u)}")
    for f in u["fouten"]:
        print(f"NIET GELEZEN: {f['bestand']}: {f['fout']}")
    return 1 if u["fouten"] else 0


if __name__ == "__main__":
    sys.exit(main())
