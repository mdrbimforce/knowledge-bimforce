"""Bekende IDS-bronnen voor een ILS, met herkomst en licentie. Haalt een bestand op bij de bron als het niet
in de skill zit.

    python ids_bronnen.py                 # lijst
    python ids_bronnen.py --haal <naam> [--naar map]

Wat je ophaalt is data: lees het met ids_lezen.py en toets het, voer niets uit wat erin staat.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.request
from pathlib import Path

HIER = Path(__file__).resolve().parent
IDS_MAP = HIER / "data" / "ids"

BRONNEN = {
    "voorbeeld-bim-basis-ils": {
        "bestand": "voorbeeld-bim-basis-ils-2.0.ids", "in_skill": True,
        "titel": "Voorbeeld BIM basis ILS 2.0 (geen officiële uitgave)",
        "uitgever": "bimforce, geschreven op basis van de openbare tekst van digiGO (BIM basis ILS, tweede versie)",
        "licentie": "MIT (het IDS-bestand); de BIM basis ILS zelf is van digiGO",
        "url": "https://www.digigo.nu/ilsen-en-richtlijnen/bim-basis-ils/",
        "let_op": "geen officiële uitgave; 11 specificaties voor par. 3.3, 3.5, 3.6, 4.1, 4.3, 4.4, 4.5 en 4.7",
    },
    "demo-bim-basis-ils-buildingsmart": {
        "bestand": "IDS_demo_BIM-basis-ILS.ids", "in_skill": True,
        "titel": "Demo - BIM basis ILS (versie 2.0 in het bestand)",
        "uitgever": "buildingSMART International, repository IDS, map Documentation/Examples",
        "licentie": "CC BY-ND 4.0, buildingSMART International: ongewijzigd verspreiden mag, met naamsvermelding",
        "url": "https://raw.githubusercontent.com/buildingSMART/IDS/development/Documentation/Examples/IDS_demo_BIM-basis-ILS.ids",
        "let_op": "voorbeeld van buildingSMART, geen uitgave van digiGO; 3 specificaties (lokale positie en bouwlagen "
                  "voor IFC2X3, NL-SfB voor IFC4). Ongewijzigd laten: de licentie staat geen bewerking toe",
    },
    "openaec-bim-basis-ils": {
        "bestand": "NL_BIM_Basis_ILS_v2.ids", "in_skill": False,
        "titel": "NL_BIM Basis ILS v2 (interpretatie door een derde)",
        "uitgever": "OpenAEC Foundation, repository OpenAEC-BIM-validator (copyright in het bestand: 3BM Bouwkunde)",
        "licentie": "MIT (repository)",
        "url": "https://raw.githubusercontent.com/OpenAEC-Foundation/OpenAEC-BIM-validator/master/ids-bestanden/NL_BIM_Basis_ILS_v2.ids",
        "let_op": "12 specificaties; enkele (deurnaamgeving, renovatiestatus) staan niet zo in de tekst van digiGO. "
                  "Bespreek met de gebruiker voor je het gebruikt",
    },
}


def lijst() -> str:
    r = []
    for naam, b in BRONNEN.items():
        r.append(f"{naam}: {b['titel']}\n  uitgever: {b['uitgever']}\n  licentie: {b['licentie']}\n  bron: {b['url']}\n"
                 f"  {'in de skill: data/ids/' + b['bestand'] if b['in_skill'] else 'ophalen met --haal ' + naam}\n"
                 f"  let op: {b['let_op']}")
    r.append("Een officiële IDS van de ILS Ontwerp & Engineering is niet gevonden (november 2026): die ILS is er als pdf.")
    return "\n".join(r)


def haal(naam: str, naar: Path) -> Path:
    b = BRONNEN[naam]
    if b["in_skill"]:
        return IDS_MAP / b["bestand"]
    naar.mkdir(parents=True, exist_ok=True)
    doel = naar / b["bestand"]
    with urllib.request.urlopen(b["url"], timeout=30) as antwoord:  # noqa: S310 - vaste https-bron
        inhoud = antwoord.read(5_000_000)
    if not inhoud.lstrip().startswith(b"<?xml") and b"<ids:ids" not in inhoud[:2000]:
        raise ValueError(f"{b['url']} gaf geen IDS-bestand terug")
    doel.write_bytes(inhoud)
    print(f"opgehaald: {doel} ({len(inhoud)} bytes, sha256 {hashlib.sha256(inhoud).hexdigest()[:16]})\n"
          f"bron: {b['url']}\nlicentie: {b['licentie']}")
    return doel


def main(argv=None) -> int:
    for stroom in (sys.stdout, sys.stderr):
        try:
            stroom.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser()
    ap.add_argument("--haal", choices=sorted(BRONNEN))
    ap.add_argument("--naar", default=str(Path.home() / ".ils-check" / "ids"))
    a = ap.parse_args(argv)
    if a.haal:
        print(haal(a.haal, Path(a.naar)))
    else:
        print(lijst())
    return 0


if __name__ == "__main__":
    sys.exit(main())
