"""IDS-toets: een IFC-bestand toetsen tegen een of meer IDS-bestanden.

    from ids_toets import toets
    uitslag = toets("model.ifc", ["eisen.ids"])          # of een map met .ids-bestanden

    python -m ids_toets <ifc> <ids-bestand-of-map> [--json uit.json] [--md uit.md]

Per specificatie een status:

    goed                 alle toepasselijke objecten voldoen (of de specificatie is optioneel en
                         er zijn geen objecten)
    fout                 een of meer objecten voldoen niet, of een verboden object komt voor
    niet-van-toepassing  de specificatie geldt voor een ander IFC-schema (ifcVersion)
    komt-niet-voor       de specificatie eist objecten, maar het model heeft er geen. In een
                         deelmodel (bijvoorbeeld alleen constructie) hoeft dat geen fout te zijn.

Gebruikt ifcopenshell en ifctester (getest met 0.9.0). Ontbreken die, dan geeft de module een
duidelijke melding met de installatieopdracht.
"""
from __future__ import annotations

import collections
import os
import re
import sys
import tempfile
from pathlib import Path

__all__ = ["toets", "markdown", "InstallatieFout", "controleer_installatie", "STATUSSEN"]

STATUSSEN = ("goed", "fout", "komt-niet-voor", "niet-van-toepassing", "leesfout")
MAX_VOORBEELDEN = 10
INSTALLATIE = "python -m pip install ifcopenshell==0.9.0.post1 ifctester==0.9.0"

UITLEG_KOMT_NIET_VOOR = (
    "De specificatie eist objecten van deze soort, maar het model heeft er geen. "
    "In een deelmodel (bijvoorbeeld alleen constructie of alleen installaties) hoeft dat geen fout "
    "van het model te zijn: het object hoort dan in een ander deelmodel.")


class InstallatieFout(RuntimeError):
    """ifcopenshell of ifctester ontbreekt."""


def controleer_installatie():
    """Geef (ifcopenshell, ifctester.ids) terug, of gooi InstallatieFout met de installatieopdracht."""
    ontbreekt = []
    try:
        import ifcopenshell  # noqa: F401
    except ImportError:
        ontbreekt.append("ifcopenshell")
    try:
        from ifctester import ids as _ids  # noqa: F401
    except ImportError:
        ontbreekt.append("ifctester")
    if ontbreekt:
        raise InstallatieFout(
            f"De IDS-toets heeft {' en '.join(ontbreekt)} nodig, en dat is niet geïnstalleerd in deze "
            f"Python ({sys.executable}). Installeer het met:\n    {INSTALLATIE}")
    import ifcopenshell
    from ifctester import ids as idsmod
    return ifcopenshell, idsmod


# --------------------------------------------------------------------------------------- IDS lezen
_KOP = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<ids:ids xmlns:ids="http://standards.buildingsmart.org/IDS" '
    'xmlns:xs="http://www.w3.org/2001/XMLSchema" '
    'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
    'xsi:schemaLocation="http://standards.buildingsmart.org/IDS '
    'http://standards.buildingsmart.org/IDS/1.0/ids.xsd">\n'
    "<ids:info><ids:title>{titel}</ids:title></ids:info>\n<ids:specifications>\n")


def ids_bestanden(bronnen) -> list[Path]:
    """Alle .ids-bestanden uit een lijst met bestanden en mappen (mappen niet recursief, gesorteerd)."""
    if isinstance(bronnen, (str, os.PathLike)):
        bronnen = [bronnen]
    uit: list[Path] = []
    for b in bronnen:
        p = Path(b)
        if p.is_dir():
            uit.extend(sorted(x for x in p.iterdir() if x.suffix.lower() == ".ids"))
        elif p.is_file():
            uit.append(p)
        else:
            raise FileNotFoundError(f"IDS-bestand of map bestaat niet: {p}")
    return uit


def _specificaties(idsmod, pad: Path):
    """Lijst van (specificatie, None) of (None, (naam, foutmelding)) per specificatie in het bestand.

    Eerst het hele bestand; lukt dat niet (bijvoorbeeld een kopblok dat ifctester niet leest), dan
    elke specificatie los met een eenvoudige kop, zodat één kapotte specificatie de rest niet tegenhoudt."""
    try:
        return [(s, None) for s in idsmod.open(str(pad)).specifications]
    except Exception as heel:  # noqa: BLE001 - elke leesfout valt terug op per specificatie
        tekst = pad.read_text(encoding="utf-8-sig", errors="replace")
        blokken = re.findall(r"(<(?:ids:)?specification\b.*?</(?:ids:)?specification>)", tekst, re.S)
        if not blokken:
            return [(None, (pad.name, f"bestand niet te lezen als IDS: {type(heel).__name__}: {str(heel)[:300]}"))]
        uit = []
        for blok in blokken:
            naam = (re.search(r'\bname="([^"]*)"', blok) or [None, "?"])[1]
            try:
                xml = _KOP.format(titel=pad.stem) + blok + "\n</ids:specifications>\n</ids:ids>\n"
                uit.extend((s, None) for s in idsmod.from_string(xml).specifications)
            except Exception as e:  # noqa: BLE001
                uit.append((None, (naam, f"specificatie niet te lezen: {type(e).__name__}: {str(e)[:300]}")))
        return uit


# --------------------------------------------------------------------------------------- uitleg in gewone taal
_VERTALING = [
    (r'^The entity class "(.*)" does not meet the required IFC class$', r'de IFC-klasse \1 is niet de gevraagde klasse'),
    (r'^The predefined type "(.*)" does not meet the required type$', r'het predefined type \1 is niet het gevraagde type'),
    (r"^The required attribute did not exist$", "het attribuut ontbreekt of is leeg"),
    (r'^The attribute value "(.*)" is empty$', "het attribuut is leeg"),
    (r'^The attribute value "(.*)" does not match the requirement$', r'de waarde "\1" van het attribuut past niet bij de eis'),
    (r"^An invalid attribute name was specified in the IDS$", "de IDS noemt een attribuut dat deze klasse niet heeft"),
    (r"^The attribute value should not have met the requirement$", "het attribuut had niet aanwezig mogen zijn"),
    (r"^The entity has no classification$", "het object heeft geen classificatie"),
    (r'^The references "(.*)" do not match the requirements$', r'de classificatiecode(s) \1 passen niet bij de eis'),
    (r'^The systems "(.*)" do not match the requirements$', r'het classificatiesysteem \1 is niet het gevraagde systeem'),
    (r"^The classification should not have met the requirement$", "deze classificatie had er niet mogen zijn"),
    (r"^The entity has no relationship$", "het object hangt niet onder het gevraagde object (onderdeel-van ontbreekt)"),
    (r'^The entity has a relationship with incorrect entities: "(.*)"$', r'het object hangt onder de verkeerde soort object: \1'),
    (r'^The entity has a relationship with incorrect predefined type: "(.*)"$', r'het object hangt onder een object met het verkeerde predefined type: \1'),
    (r"^The relationship should not have met the requirement$", "deze relatie had er niet mogen zijn"),
    (r"^The required property set does not exist$", "de property set ontbreekt"),
    (r"^The property set does not contain the required property$", "de eigenschap ontbreekt of is leeg"),
    (r'^The property\'s data type "(.*)" does not match the required data type of "(.*)"$', r'het datatype is \1, de eis vraagt \2'),
    (r'^The property values? "(.*)" do(?:es)? not match the requirements$', r'de waarde "\1" past niet bij de eis'),
    (r"^The property should not have met the requirement$", "deze eigenschap had er niet mogen zijn"),
    (r"^The entity has no material$", "het object heeft geen materiaal"),
    (r'^The material names and categories of "(.*)" does not match the requirement$', r'het materiaal \1 past niet bij de eis'),
    (r"^The material should not have met the requirement$", "dit materiaal had er niet mogen zijn"),
]


def gewone_taal(reden: str) -> str:
    for patroon, vervang in _VERTALING:
        if re.match(patroon, reden or ""):
            return re.sub(patroon, vervang, reden)
    return reden or "voldoet niet"


def _waarde(v) -> str:
    """Beschrijving van een IDS-waarde (simpleValue of restrictie) in een paar woorden."""
    if v is None:
        return ""
    if isinstance(v, str):
        return v
    opties = getattr(v, "options", None)
    if isinstance(opties, dict):
        delen = []
        for k, w in opties.items():
            if k == "enumeration":
                delen.append("een van " + ", ".join(map(str, w if isinstance(w, list) else [w])))
            elif k == "pattern":
                delen.append(f"patroon {w}")
            else:
                delen.append(f"{k} {w}")
        return "; ".join(delen)
    return str(v)


def facet_omschrijving(facet) -> str:
    """Korte Nederlandse omschrijving van een eis (facet)."""
    soort = type(facet).__name__
    if soort == "Property":
        tekst = f"eigenschap {_waarde(facet.propertySet)}.{_waarde(facet.baseName)}"
    elif soort == "Attribute":
        tekst = f"attribuut {_waarde(facet.name)}"
    elif soort == "Classification":
        tekst = "classificatie" + (f" in {_waarde(facet.system)}" if getattr(facet, "system", None) else "")
    elif soort == "Material":
        tekst = "materiaal"
    elif soort == "PartOf":
        tekst = f"onderdeel van {_waarde(facet.name)}"
    elif soort == "Entity":
        tekst = f"klasse {_waarde(facet.name)}"
    else:
        tekst = soort
    waarde = getattr(facet, "value", None)
    if waarde is not None:
        tekst += f" = {_waarde(waarde)}"
    return tekst


# --------------------------------------------------------------------------------------- toets
def _status(spec, toepasselijk: int) -> str:
    if spec.status is None:
        return "niet-van-toepassing"
    if spec.status:
        return "goed"
    if toepasselijk == 0 and spec.minOccurs != 0:
        return "komt-niet-voor"
    return "fout"


def _object(el) -> dict:
    return {"id": el.id(), "GlobalId": getattr(el, "GlobalId", None), "klasse": el.is_a(),
            "naam": getattr(el, "Name", None)}


def toets(ifc_pad, ids_paden, model=None) -> dict:
    """Toets een IFC tegen een of meer IDS-bestanden (of mappen). Geeft een dict terug:

    {"ifc", "schema", "ids": [paden], "samenvatting": {status: aantal}, "specificaties": [
        {"bestand", "naam", "identifier", "beschrijving", "ifcVersion", "gebruik", "status",
         "toepasselijk", "afgekeurd", "eisen": [{"eis", "afgekeurd"}], "voorbeelden": [
            {"GlobalId", "klasse", "naam", "redenen": [...]}], "uitleg"}]}
    """
    ifcopenshell, idsmod = controleer_installatie()
    if model is None:
        model = ifcopenshell.open(str(ifc_pad))
    schema = getattr(model, "schema_identifier", None) or model.schema
    bestanden = ids_bestanden(ids_paden)
    rijen = []
    for pad in bestanden:
        for spec, fout in _specificaties(idsmod, pad):
            if fout is not None:
                rijen.append({"bestand": pad.name, "naam": fout[0], "status": "leesfout", "toepasselijk": 0,
                              "afgekeurd": 0, "eisen": [], "voorbeelden": [], "uitleg": fout[1]})
                continue
            versies = [v.upper() for v in (spec.ifcVersion or [])]
            rij = {"bestand": pad.name, "naam": spec.name, "identifier": getattr(spec, "identifier", None),
                   "beschrijving": getattr(spec, "description", None), "ifcVersion": versies,
                   "gebruik": spec.get_usage(), "status": None, "toepasselijk": 0, "afgekeurd": 0,
                   "eisen": [], "voorbeelden": [], "uitleg": ""}
            rijen.append(rij)
            if versies and schema.upper() not in versies:
                rij["status"] = "niet-van-toepassing"
                rij["uitleg"] = f"geldt alleen voor {' '.join(versies)}; dit model is {schema}"
                continue
            try:
                spec.reset_status()
                spec.check_ifc_version(model)
                spec.validate(model)
            except Exception as e:  # noqa: BLE001
                rij["status"] = "leesfout"
                rij["uitleg"] = f"toets liep stuk: {type(e).__name__}: {str(e)[:300]}"
                continue
            toepasselijk = len(spec.applicable_entities)
            rij["toepasselijk"] = toepasselijk
            rij["afgekeurd"] = len(spec.failed_entities)
            rij["status"] = _status(spec, toepasselijk)
            if rij["status"] == "komt-niet-voor":
                rij["uitleg"] = UITLEG_KOMT_NIET_VOOR
            elif spec.maxOccurs == 0 and toepasselijk:
                rij["uitleg"] = f"deze objecten zijn verboden en komen {toepasselijk} keer voor"
                rij["afgekeurd"] = toepasselijk
                rij["voorbeelden"] = [dict(_object(el), redenen=["dit object had er niet mogen zijn"])
                                      for el in list(spec.applicable_entities)[:MAX_VOORBEELDEN]]
            per_object: dict = collections.OrderedDict()
            for facet in spec.requirements:
                oms = facet_omschrijving(facet)
                rij["eisen"].append({"eis": oms, "afgekeurd": len(facet.failures),
                                     "gebruik": getattr(facet, "cardinality", None)})
                for f in facet.failures:
                    el = f.get("element") if isinstance(f, dict) else getattr(f, "element", None)
                    reden = f.get("reason") if isinstance(f, dict) else getattr(f, "reason", "")
                    if el is None:
                        continue
                    o = per_object.setdefault(el.id(), dict(_object(el), redenen=[]))
                    o["redenen"].append(f"{oms}: {gewone_taal(str(reden))}")
            if per_object:
                rij["voorbeelden"] = list(per_object.values())[:MAX_VOORBEELDEN]
    samenvatting = collections.Counter(r["status"] for r in rijen)
    return {"ifc": str(ifc_pad), "schema": schema, "ids": [str(p) for p in bestanden],
            "samenvatting": {s: samenvatting.get(s, 0) for s in STATUSSEN if samenvatting.get(s, 0) or s != "leesfout"},
            "specificaties": rijen}


# --------------------------------------------------------------------------------------- rapport
_TEKEN = {"goed": "goed", "fout": "FOUT", "komt-niet-voor": "komt niet voor",
          "niet-van-toepassing": "n.v.t.", "leesfout": "leesfout"}


def _cel(t) -> str:
    return str(t if t is not None else "").replace("|", "\\|").replace("\n", " ")


def markdown(uitslag: dict) -> str:
    s = uitslag["samenvatting"]
    r = [f"# IDS-toets {Path(uitslag['ifc']).name}", "",
         f"Schema {uitslag['schema']}, {len(uitslag['specificaties'])} specificaties uit "
         f"{len(uitslag['ids'])} IDS-bestand(en).", "",
         "| Status | Aantal | Betekenis |", "|---|---|---|",
         f"| goed | {s.get('goed', 0)} | alle toepasselijke objecten voldoen |",
         f"| fout | {s.get('fout', 0)} | een of meer objecten voldoen niet |",
         f"| komt niet voor | {s.get('komt-niet-voor', 0)} | de specificatie eist objecten die het model niet heeft; "
         "in een deelmodel hoeft dat geen fout te zijn |",
         f"| n.v.t. | {s.get('niet-van-toepassing', 0)} | geldt voor een ander IFC-schema |"]
    if s.get("leesfout"):
        r.append(f"| leesfout | {s['leesfout']} | de specificatie was niet te lezen of te toetsen |")
    r += ["", "## Per specificatie", "", "| Status | Specificatie | Toepasselijk | Afgekeurd | Bestand |",
          "|---|---|---|---|---|"]
    for x in uitslag["specificaties"]:
        r.append(f"| {_TEKEN.get(x['status'], x['status'])} | {_cel(x['naam'])} | {x['toepasselijk']} | "
                 f"{x['afgekeurd']} | {_cel(x['bestand'])} |")
    fouten = [x for x in uitslag["specificaties"] if x["status"] in ("fout", "komt-niet-voor", "leesfout")]
    if fouten:
        r += ["", "## Wat niet voldoet", ""]
        for x in fouten:
            r += [f"### {x['naam']} ({_TEKEN.get(x['status'])})", ""]
            if x.get("uitleg"):
                r += [x["uitleg"], ""]
            for e in x["eisen"]:
                if e["afgekeurd"]:
                    r.append(f"- {e['eis']}: niet voldaan bij {e['afgekeurd']} object(en)")
            if x["voorbeelden"]:
                r += ["", f"Eerste {len(x['voorbeelden'])} afgekeurde objecten:", "",
                      "| GlobalId | Klasse | Naam | Reden |", "|---|---|---|---|"]
                for o in x["voorbeelden"]:
                    r.append(f"| {o['GlobalId']} | {o['klasse']} | {_cel(o['naam'])} | {_cel('; '.join(o['redenen']))} |")
            r.append("")
    return "\n".join(r) + "\n"
