"""python -m ids_toets <ifc> <ids-bestand-of-map> [meer ids] [--json uit.json] [--md uit.md]

Toetst een IFC tegen IDS-bestanden en drukt de samenvatting en de specificaties met fouten af.
Exitcode 0 als alles goed of n.v.t. is, 1 bij fout of komt-niet-voor, 2 bij een gebruiksfout.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

if __package__ in (None, ""):  # python shared/ids_toets/__main__.py
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ids_toets import InstallatieFout, markdown, toets  # noqa: E402


def main(argv=None) -> int:
    for stroom in (sys.stdout, sys.stderr):
        try:
            stroom.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(prog="python -m ids_toets", description="Toets een IFC tegen IDS-bestanden.")
    ap.add_argument("ifc")
    ap.add_argument("ids", nargs="+", help="IDS-bestand(en) of map(pen) met .ids-bestanden")
    ap.add_argument("--json", dest="json_uit")
    ap.add_argument("--md", dest="md_uit")
    a = ap.parse_args(argv)
    try:
        uitslag = toets(a.ifc, a.ids)
    except InstallatieFout as e:
        print(e, file=sys.stderr)
        return 2
    except FileNotFoundError as e:
        print(e, file=sys.stderr)
        return 2
    s = uitslag["samenvatting"]
    print(f"{Path(a.ifc).name} ({uitslag['schema']}): " + ", ".join(f"{k} {v}" for k, v in s.items()))
    for x in uitslag["specificaties"]:
        if x["status"] in ("fout", "komt-niet-voor", "leesfout"):
            print(f"  {x['status']:15} {x['naam']}  (toepasselijk {x['toepasselijk']}, afgekeurd {x['afgekeurd']})")
    if a.json_uit:
        Path(a.json_uit).write_text(json.dumps(uitslag, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    if a.md_uit:
        Path(a.md_uit).write_text(markdown(uitslag), encoding="utf-8")
    return 1 if (s.get("fout") or s.get("komt-niet-voor")) else 0


if __name__ == "__main__":
    sys.exit(main())
