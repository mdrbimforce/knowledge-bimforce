# Herkomst en licentie van IDS_demo_BIM-basis-ILS.ids

- **Bron:** buildingSMART International, repository IDS (https://github.com/buildingSMART/IDS), bestand `Documentation/Examples/IDS_demo_BIM-basis-ILS.ids`.
- **Maker:** buildingSMART International.
- **Licentie:** Creative Commons Naamsvermelding-GeenAfgeleideWerken 4.0 Internationaal (CC BY-ND 4.0).
- **Licentietekst:** https://creativecommons.org/licenses/by-nd/4.0/legalcode
- **Wijzigingen:** geen. Het bestand is ongewijzigd opgenomen; de skill leest het alleen.
