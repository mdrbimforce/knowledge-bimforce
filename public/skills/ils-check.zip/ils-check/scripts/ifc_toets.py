"""Toets een geëxporteerde IFC tegen de IDS: het bewijs na de export.

    python ifc_toets.py <ifc> <ids-bestand-of-map> [--json uit.json] [--md uit.md]

Roept de gedeelde module ids_toets aan (in de zip: scripts/ids_toets/, in de repo: shared/ids_toets/).
Heeft ifcopenshell en ifctester nodig (requirements.txt).
"""
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from ids_toets.__main__ import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
