"""Ga vóór de export in het Revit-model na of de parameters voor de ILS-eisen er zijn, goed hangen en gevuld zijn.

    python ils_revit_check.py <koppeling.json> --document "<naam>" [--uit uitmap]
    python ils_revit_check.py <koppeling.json> --uit-bestand model.json [--uit uitmap]
    python ils_revit_check.py <koppeling.json> --document "<naam>" --haal model.json

Alleen lezen. Met --document haalt het script de gegevens via de bridge op met twee leesopdrachten:
list_parameter_bindings en read_parameter_values (per categorie, in pagina's). --haal bewaart die
gegevens in een bestand zonder te toetsen; --uit-bestand toetst een eerder bewaard bestand, zodat het
ook zonder Revit kan.

Vorm van het modelbestand:
    {"document": "...", "bindings": [<rijen van list_parameter_bindings>],
     "elementen": {"OST_Walls": [<rijen van read_parameter_values>], ...}}

Uitvoer in de uitmap: revit-check.json, revit-check.md, herstelplan.json, te-vullen.csv en
herstel-shared-parameters.txt (alleen de parameters die gebonden moeten worden, met hun GUID).
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
import re
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import nlrs_data as nd  # noqa: E402

STAND = {
    "in-orde": "in orde",
    "parameter-ontbreekt": "parameter ontbreekt",
    "niet-gebonden": "niet gebonden aan categorie",
    "leeg": "leeg op een deel van de elementen",
    "waarde-past-niet": "waarde past niet",
    "geen-elementen": "geen elementen in deze categorieën",
    "revit-zelf": "Revit vult dit zelf: na de export toetsen",
    "geen-koppeling": "vraagt een keuze (geen koppeling)",
}
WAAR = {"TRUE", "JA", "YES", "WAAR", "1"}
ONWAAR = {"FALSE", "NEE", "NO", "ONWAAR", "0"}
PAGINA = 2000
TIMEOUT = 20


# ------------------------------------------------------------------------------------------ ophalen
def haal_model(koppeling: dict, document: str, timeout: float = TIMEOUT) -> dict:
    """Haal bindingen en waarden op via de bridge (alleen leesopdrachten)."""
    from revit_agent.bridge import call  # noqa: WPS433 - pas nodig als er een bridge is
    b = call("list_parameter_bindings", {"target_document": document}, timeout=timeout)
    per_cat = collections.defaultdict(set)
    for e in koppeling["eisen"]:
        par = (e.get("koppeling") or {}).get("param")
        if not par:
            continue
        for c in _cats(e, b.get("bindings", []), par):
            per_cat[c].add(par)
    elementen = {}
    for cat, params in sorted(per_cat.items()):
        rijen, offset = [], 0
        while offset is not None:
            d = call("read_parameter_values", {"target_document": document, "categories": [cat],
                                               "params": sorted(params), "limit": PAGINA, "offset": offset},
                     timeout=timeout)
            rijen += d.get("rows", [])
            offset = d.get("volgende_offset")
        elementen[cat] = rijen
    return {"document": document, "bindings": b.get("bindings", []), "elementen": elementen}


def _cats(eis, bindings, param) -> list[str]:
    """OST-namen van de categorieën die deze eis raakt. 'alle': de categorieën waar de parameter aan hangt."""
    c = eis.get("categorieen") or {}
    if c.get("alle"):
        for b in bindings:
            if b.get("name") == param:
                return [x for x in b.get("categories", []) if x.startswith("OST_")]
        return []
    return [x.get("ost") or x["categorie"] for x in c.get("lijst", []) if (x.get("ost") or "/" not in x["categorie"])]


# ------------------------------------------------------------------------------------------ waarden
def _leeg(v) -> bool:
    if v is None:
        return True
    w, raw = v.get("value"), v.get("raw")
    return (w is None or str(w).strip() == "") and (raw is None or str(raw).strip() == "")


def _als_tekst(v, datatype) -> str:
    w, raw = v.get("value"), v.get("raw")
    if (datatype or "").upper() == "IFCBOOLEAN" or str(w).upper() in WAAR | ONWAAR:
        for x in (raw, w):
            if x is not None and str(x).strip().upper() in WAAR:
                return "TRUE"
            if x is not None and str(x).strip().upper() in ONWAAR:
                return "FALSE"
    return str(w if w is not None else raw)


def past(v, eis) -> tuple[bool | None, str]:
    """Past de Revit-waarde bij de waarde-eis uit de IDS? (True/False/None=niet na te gaan, uitleg)"""
    w = eis.get("waarde")
    if not w:
        return True, ""
    t = _als_tekst(v, eis.get("datatype"))
    soort = w.get("soort")
    if soort in ("vast", "lijst") and w.get("waarden"):
        toegestaan = w["waarden"]
        if (eis.get("datatype") or "").upper() == "IFCBOOLEAN":
            return t.upper() in {x.upper() for x in toegestaan}, f"toegestaan: {', '.join(toegestaan)}"
        return t in toegestaan, f"toegestaan: {', '.join(toegestaan[:8])}{' ...' if len(toegestaan) > 8 else ''}"
    if w.get("patroon"):
        try:
            return re.fullmatch(w["patroon"], t) is not None, f"patroon {w['patroon']}"
        except re.error:
            return None, "patroon niet te lezen"
    if any(k in w for k in ("min", "max", "min_exclusief", "max_exclusief")):
        m = re.match(r"\s*(-?\d+(?:[.,]\d+)?)", t)
        if not m:
            return None, "geen getal"
        x = float(m.group(1).replace(",", "."))
        ok = all([("min" not in w or x >= float(w["min"])), ("max" not in w or x <= float(w["max"])),
                  ("min_exclusief" not in w or x > float(w["min_exclusief"])),
                  ("max_exclusief" not in w or x < float(w["max_exclusief"]))])
        return ok, "bereik (in de eenheid zoals Revit hem toont; eenheid nagaan)"
    return None, "waarde-eis niet na te gaan in Revit"


# ------------------------------------------------------------------------------------------ check
def check(koppeling: dict, model: dict) -> dict:
    bindings = {b.get("name"): b for b in model.get("bindings", [])}
    elementen = model.get("elementen", {})
    rijen, te_binden, te_vullen = [], {}, []
    for eis in koppeling["eisen"]:
        kp = eis.get("koppeling") or {}
        par = kp.get("param")
        rij = {"id": eis["id"], "sleutel": eis["sleutel"], "specificatie": eis.get("specificatie"),
               "gebruik": eis.get("gebruik"), "param": par, "herkomst": kp.get("herkomst"),
               "zekerheid": kp.get("zekerheid"), "standen": [], "details": []}
        rijen.append(rij)
        if not kp:
            rij["standen"].append("geen-koppeling")
            continue
        if not par:
            rij["standen"].append("revit-zelf")
            rij["details"].append(kp.get("exportweg", ""))
            continue
        if eis.get("voorwaarden"):
            rij["details"].append("voorwaarde uit de IDS (" + "; ".join(eis["voorwaarden"]) +
                                  ") niet nagegaan in Revit: alle elementen van de categorie zijn meegeteld")
        cats = _cats(eis, model.get("bindings", []), par)
        binding = bindings.get(par)
        if binding is None:
            # kan nog een familieparameter of ingebouwde parameter zijn: kijk op de elementen
            ergens = any(r.get("values", {}).get(par) is not None for c in cats for r in elementen.get(c, []))
            if not ergens:
                rij["standen"].append("parameter-ontbreekt")
                _plan_binden(te_binden, par, kp, cats, eis)
                for c in cats:
                    for r in elementen.get(c, []):
                        te_vullen.append(_vulregel(eis, par, c, r, None, kp))
                continue
            rij["details"].append("geen project- of shared-parameterbinding, wel op de elementen (familie- of "
                                  "ingebouwde parameter)")
        else:
            gebonden = set(binding.get("categories", []))
            mist = [c for c in cats if c.startswith("OST_") and c not in gebonden]
            if mist:
                rij["standen"].append("niet-gebonden")
                rij["details"].append("niet gebonden aan " + ", ".join(mist))
                _plan_binden(te_binden, par, kp, mist, eis, binding)
            if kp.get("binding") and binding.get("instance_or_type") not in (None, "onbekend", kp["binding"]):
                rij["details"].append(f"gebonden als {binding.get('instance_or_type')}, de koppeling verwacht "
                                      f"{kp['binding']}")
        totaal = leeg = fout = 0
        voorbeelden_fout = []
        for c in cats:
            for r in elementen.get(c, []):
                totaal += 1
                v = r.get("values", {}).get(par)
                if _leeg(v):
                    leeg += 1
                    te_vullen.append(_vulregel(eis, par, c, r, v, kp))
                    continue
                ok, uitleg = past(v, eis)
                if ok is False:
                    fout += 1
                    if len(voorbeelden_fout) < 5:
                        voorbeelden_fout.append(f"{r.get('element_id')}: '{_als_tekst(v, eis.get('datatype'))}' ({uitleg})")
                    te_vullen.append(_vulregel(eis, par, c, r, v, kp, uitleg))
        rij.update(elementen=totaal, leeg=leeg, waarde_past_niet=fout, categorieen=cats)
        if totaal == 0 and "niet-gebonden" not in rij["standen"]:
            rij["standen"].append("geen-elementen")
        if leeg:
            if eis.get("gebruik") == "optioneel":
                rij["details"].append(f"optioneel: leeg op {leeg} van {totaal} elementen")
            else:
                rij["standen"].append("leeg")
                rij["details"].append(f"leeg op {leeg} van {totaal} elementen")
        if fout:
            rij["standen"].append("waarde-past-niet")
            rij["details"].append(f"waarde past niet op {fout} van {totaal} elementen: " + "; ".join(voorbeelden_fout))
        if not rij["standen"]:
            rij["standen"].append("in-orde")
    telling = collections.Counter(s for r in rijen for s in r["standen"])
    return {"document": model.get("document"), "telling": dict(telling), "eisen": rijen,
            "herstelplan": {"te_binden": list(te_binden.values()), "te_vullen_aantal": len(te_vullen)},
            "_te_vullen": te_vullen}


def _plan_binden(te_binden, par, kp, cats, eis, binding=None):
    x = te_binden.setdefault(par, {"name": par, "guid": kp.get("guid"), "categories": [],
                                   "instance": (kp.get("binding") or (binding or {}).get("instance_or_type") or
                                                "instance") != "type",
                                   "group": "IfcParameters" if kp.get("bron_parameter") == "autodesk-ifc" else "Data",
                                   "datatype": kp.get("datatype_revit"), "bron": kp.get("bron_parameter"),
                                   "eisen": []})
    for c in cats:
        if c.startswith("OST_") and c not in x["categories"]:
            x["categories"].append(c)
    x["eisen"].append(eis["id"])
    if not x["guid"]:
        x["opmerking"] = ("ingebouwde parameter of familieparameter: niet te binden, nagaan in het type of de familie"
                          if kp.get("bron_parameter") == "ingebouwd-of-familie" else
                          "geen GUID bekend: niet in het NLRS-bestand of de Autodesk-lijst; zelf een shared parameter kiezen")


def _vulregel(eis, par, cat, r, v, kp, uitleg=""):
    w = eis.get("waarde") or {}
    hint = uitleg or (("een van: " + ", ".join(w.get("waarden", [])[:10])) if w.get("waarden") else
                      (f"patroon {w['patroon']}" if w.get("patroon") else (eis.get("datatype") or "")))
    return {"eis": eis["id"], "element_id": r.get("element_id"), "categorie": cat, "familie": r.get("family"),
            "type": r.get("type"), "level": r.get("level"), "param": par,
            "target": (v or {}).get("bron") or ("type" if kp.get("binding") == "type" else "instance"),
            "huidige_waarde": "" if v is None else _als_tekst(v, eis.get("datatype")),
            "nieuwe_waarde": "", "toegestaan": hint}


# ------------------------------------------------------------------------------------------ uitvoer
def schrijf_sp_bestand(pad: Path, te_binden: list[dict]) -> int:
    """Shared-parameterbestand met alleen de te binden parameters (Revit-formaat, UTF-16)."""
    regels = ["# This is a Revit shared parameter file.", "# Do not edit manually.", "*META\tVERSION\tMINVERSION",
              "META\t2\t1", "*GROUP\tID\tNAME", "GROUP\t1\tILS-check",
              "*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE"]
    n = 0
    for b in te_binden:
        if b.get("guid") and b.get("datatype"):
            regels.append(f"PARAM\t{b['guid']}\t{b['name']}\t{b['datatype']}\t\t1\t1\t\t1\t0")
            n += 1
    pad.write_text("\r\n".join(regels) + "\r\n", encoding="utf-16")
    return n


def markdown(u: dict) -> str:
    r = [f"# ILS-check in Revit: {u.get('document')}", "", "| Stand | Aantal eisen |", "|---|---|"]
    for s, n in sorted(u["telling"].items(), key=lambda x: -x[1]):
        r.append(f"| {STAND.get(s, s)} | {n} |")
    r += ["", "| Id | Eis | Parameter | Stand | Toelichting |", "|---|---|---|---|---|"]
    for e in u["eisen"]:
        r.append(f"| {e['id']} | {e['sleutel']} | {e['param'] or '-'} | {', '.join(STAND.get(s, s) for s in e['standen'])} | "
                 f"{'; '.join(d for d in e['details'] if d).replace('|', '/')[:300]} |")
    hp = u["herstelplan"]
    r += ["", "## Herstelplan", "", f"Te binden parameters: {len(hp['te_binden'])}. "
          f"Te vullen waarden: {hp['te_vullen_aantal']} (in te-vullen.csv, kolom nieuwe_waarde).", ""]
    if hp["te_binden"]:
        r += ["| Parameter | GUID | Categorieën | Instance | Bron |", "|---|---|---|---|---|"]
        r += [f"| {b['name']} | {b.get('guid') or '-'} | {', '.join(b['categories'])} | {'ja' if b['instance'] else 'type'} | "
              f"{b.get('bron') or '-'} |" for b in hp["te_binden"]]
    return "\n".join(r) + "\n"


def schrijf(u: dict, uitmap: Path) -> dict:
    uitmap.mkdir(parents=True, exist_ok=True)
    te_vullen = u.pop("_te_vullen")
    sp = uitmap / "herstel-shared-parameters.txt"
    n_sp = schrijf_sp_bestand(sp, u["herstelplan"]["te_binden"])
    with open(uitmap / "te-vullen.csv", "w", newline="", encoding="utf-8-sig") as f:
        velden = ["eis", "element_id", "categorie", "familie", "type", "level", "param", "target",
                  "huidige_waarde", "nieuwe_waarde", "toegestaan"]
        w = csv.DictWriter(f, fieldnames=velden, delimiter=";")
        w.writeheader()
        w.writerows(te_vullen)
    plan = {"document": u.get("document"), "shared_param_file": str(sp.resolve()), "in_sp_bestand": n_sp,
            "te_binden": u["herstelplan"]["te_binden"], "te_vullen_csv": str((uitmap / "te-vullen.csv").resolve()),
            "goedgekeurd": False}
    (uitmap / "herstelplan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    (uitmap / "revit-check.json").write_text(json.dumps(u, ensure_ascii=False, indent=1), encoding="utf-8")
    (uitmap / "revit-check.md").write_text(markdown(u), encoding="utf-8")
    return plan


def main(argv=None) -> int:
    for stroom in (sys.stdout, sys.stderr):
        try:
            stroom.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description="Ga de ILS-koppeling na in het Revit-model (alleen lezen).")
    ap.add_argument("koppeling")
    ap.add_argument("--document", help="titel van het open Revit-document")
    ap.add_argument("--uit-bestand", help="eerder opgehaalde modelgegevens (JSON)")
    ap.add_argument("--haal", help="alleen ophalen en in dit bestand bewaren")
    ap.add_argument("--uit", default="ils-check-uit")
    ap.add_argument("--timeout", type=float, default=TIMEOUT)
    a = ap.parse_args(argv)
    koppeling = json.loads(Path(a.koppeling).read_text(encoding="utf-8-sig"))
    if a.uit_bestand:
        model = json.loads(Path(a.uit_bestand).read_text(encoding="utf-8-sig"))
    elif a.document:
        from revit_agent.bridge import BridgeError
        try:
            model = haal_model(koppeling, a.document, a.timeout)
        except BridgeError as e:
            print(f"Bridge: {e}", file=sys.stderr)
            print("Herhaal niet blind: kijk eerst in Revit of er een dialoogvenster openstaat.", file=sys.stderr)
            return 2
        if a.haal:
            Path(a.haal).write_text(json.dumps(model, ensure_ascii=False, indent=1), encoding="utf-8")
            print(f"opgehaald: {sum(len(v) for v in model['elementen'].values())} elementen in "
                  f"{len(model['elementen'])} categorieën -> {a.haal}")
            return 0
    else:
        ap.error("geef --document of --uit-bestand")
    u = check(koppeling, model)
    plan = schrijf(u, Path(a.uit))
    print(f"{u['document']}: " + ", ".join(f"{STAND.get(s, s)} {n}" for s, n in u["telling"].items()))
    print(f"herstelplan: {len(plan['te_binden'])} parameters binden, {u['herstelplan']['te_vullen_aantal']} waarden "
          f"te vullen -> {Path(a.uit).resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
