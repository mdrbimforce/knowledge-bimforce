# De BIM basis ILS in het kort

De BIM basis ILS is de Nederlandse basisafspraak over informatie in IFC-modellen. Hij is van digiGO. Deze samenvatting volgt de tekst op https://www.digigo.nu/ilsen-en-richtlijnen/bim-basis-ils/ (de "tweede versie", 2.0; gelezen 25-11-2026; de pagina noemt geen datum en geen licentie, de voettekst zegt "© 2023 digiGO"). De samenvatting is in eigen woorden; lees de bron voor de precieze tekst.

## Hoofdstuk 3: afspraken voor eenduidige uitwisseling

| Par. | Onderwerp | Kort |
|---|---|---|
| 3.1 | Bestandsnaam | Eén vaste naamgeving voor de aspectmodellen in een project. |
| 3.2 | Lokale positie | Aspectmodellen onderling afgestemd, dicht bij het nulpunt. |
| 3.3 | Bouwlagen | Consistente namen, elk object aan de juiste bouwlaag, bouwlagen alleen als `IfcBuildingStorey`. |
| 3.4 | Entiteiten | De best passende IFC-klasse, met een predefined type waar dat kan. |
| 3.5 | Structuur en naamgeving | Elk object een Name en een Type die samen zeggen wat het is. |
| 3.6 | Classificatie | Een viercijferige NL-SfB-code, laatste gepubliceerde versie. |
| 3.7 | Property sets | Waar het kan de property sets van buildingSMART gebruiken. |
| 3.8 | Doublures en doorsnijdingen | Geen dubbele objecten in een aspectmodel; doorsnijdingen in principe niet. |

## Hoofdstuk 4: minimale informatie

| Par. | Onderwerp | Kort |
|---|---|---|
| 4.1 | Ruimten | `IfcSpace` met een benoemde functie; groeperen met `IfcZone`. |
| 4.2 | Installatiesystemen | Objecten van één systeem in een `IfcSystem`, waar van toepassing. |
| 4.3 | Dragend | `LoadBearing` waar of onwaar, waar van toepassing. |
| 4.4 | Binnen of buiten | `IsExternal` waar of onwaar, waar van toepassing. |
| 4.5 | Brandveiligheid | WBDBO en brandwerendheid; `FireRating` voor de WBDBO-waarde. |
| 4.6 | Bouwfysica | Relevante bouwfysische eigenschappen in de objecten. |
| 4.7 | Materiaal | Elk object een `IfcMaterial`; bij samengestelde objecten het dominante materiaal. |
| 4.8 | Projectspecifiek | Per project afspreken wat er verder nodig is. |

## IDS-bestanden

digiGO publiceert de BIM basis ILS als tekst en pdf. Een officieel IDS-bestand van digiGO hebben we niet gevonden (november 2026). In de skill zitten:

- `voorbeeld-bim-basis-ils-2.0.ids`: zelf geschreven op basis van de tekst hierboven, **geen officiële uitgave**. Het toetst 3.3, 3.5, 3.6, 4.1, 4.3, 4.4, 4.5 (optioneel) en 4.7. Keuzes: "waar van toepassing" gelezen als wanden, vloeren, kolommen, liggers, deuren en ramen; het classificatiesysteem moet met NL-SfB beginnen; alle specificaties zijn optioneel, zodat een deelmodel zonder wanden niet faalt op de wandeisen. Niet in de IDS: 3.1, 3.2, 3.4, 3.7, 3.8, 4.2, 4.6 en 4.8, omdat een IDS die niet eenduidig kan toetsen.
- `IDS_demo_BIM-basis-ILS.ids`: demo van buildingSMART International (lokale positie, bouwlagen, NL-SfB). Licentie CC BY-ND 4.0: ongewijzigd laten.

Een derde interpretatie (OpenAEC, MIT) haal je op met `python ids_bronnen.py --haal openaec-bim-basis-ils`. Enkele eisen daarin (deurnaamgeving, renovatiestatus) staan niet zo in de tekst van digiGO.
