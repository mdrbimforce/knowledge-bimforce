# Hoe Revit eigenschappen in een IFC zet

Een eigenschap komt langs een van drie wegen in de IFC. Welke weg werkt, hangt af van de export-setup en van hoe je exporteert: vanuit het Revit-venster, of via de API (zoals de bridge en de skill `ifc-ils-export` doen).

## Weg 1. De exporter leest een parameter met een vaste naam

De IFC-exporter van Revit zoekt parameters met een bepaalde naam en zet die waarde in de IFC. De namen staan in de IFC Shared Parameters van Autodesk (in de skill: `scripts/data/nlrs/adsk_ifc_parameters.json`, overgenomen uit de repository NLRS_Shared_Parameters).

| Parameternaam | Wordt in de IFC |
|---|---|
| `Pset_WallCommon.LoadBearing` (vorm `Pset.Eigenschap`) | die eigenschap in die property set, bij de optie voor IFC common property sets |
| `Pset_WallCommon.LoadBearing[Type]` | hetzelfde, als typeparameter |
| `IfcName`, `IfcDescription`, `IfcObjectType`, `IfcLongName`, `IfcTag` | het attribuut met die naam |
| `ClassificationCode` (vorm `[Systeem]Code:Omschrijving`) | een classificatie |
| `ZoneName`, `ZoneObjectType`, `ZoneLongName`, `ZoneDescription` | een `IfcZone` waar de ruimte in komt |

Deze weg werkt ook bij een export via de API. In het rapport heet hij `autodesk-ifc`.

## Weg 2. Custom property sets

Een tekstbestand met eigen property sets: per set een regel `PropertySet:` met naam, I (instance) of T (type) en de IFC-klassen, daaronder per eigenschap de naam, het datatype en de Revit-parameter. De NLRS levert er een (`RSF_NLRS_3.1.1_CustomPSets.txt`, met onder meer `ILS_O&E` en `ILS_UVIP Aedes`). De export-setup moet het bestand noemen. In het rapport heet dit `nlrs-custom-pset`.

Let op: één eigenschap kan meer Revit-parameters hebben (in `ILS_O&E` bijvoorbeeld `_01` tot `_10` voor meer materialen). Welke de exporter dan neemt, is nog niet nagegaan.

## Weg 3. De parametermappingtabel

Een tekstbestand `PropertySet<tab>IFC Property<tab>Revit Parameter` dat bestaande parameters naar standaard property sets stuurt. De NLRS levert er een (`RSF_NLRS_3.1.1_IfcParameterMapping_IFC4.txt`, 1761 regels, 929 met een Revit-parameter). In het rapport heet dit `nlrs-mappingtabel`.

**De les:** bij een export via de API wordt de parametermappingtabel niet gelezen. Een eis die via deze tabel gekoppeld is, staat na zo'n export niet in de IFC, ook al is de parameter in Revit netjes gevuld. Kies dan een van deze oplossingen:

1. exporteer vanuit het Revit-venster met de NLRS-setup en de mappingtabel;
2. zet dezelfde eigenschap in een custom property set (weg 2) met dezelfde Revit-parameter;
3. gebruik de parameter met de vaste naam (weg 1), bijvoorbeeld `Pset_WallCommon.LoadBearing`.

Toets in elk geval na de export met `ifc_toets.py`.

## Wat Revit zelf vult

Zonder eigen parameter vult de exporter onder meer:

| In de IFC | Uit Revit | Zekerheid |
|---|---|---|
| `GlobalId` | IfcGUID van het element | hoog |
| `IfcSpace.Name` en `LongName` | nummer en naam van de ruimte | hoog |
| `IfcBuildingStorey.Name` | naam van het level | hoog |
| bouwlaag van een element | het level van het element | hoog |
| `Name` van een element | familie- en typenaam | midden: altijd gevuld, de inhoud bepaal je met `IfcName` |
| materiaal | lagen of materiaalparameter | midden: bij laadbare families nagaan |
| classificatie | `Assembly Code` via de classificatie-instelling | midden: de systeemnaam komt uit de setup |
| `Qto_*` | berekend bij de optie base quantities | midden |
| common psets uit ingebouwde parameters | bijvoorbeeld de functie van een wand | nagaan |

## Van IFC-klasse naar Revit-categorie

Welke categorie naar welke klasse exporteert, staat in de exportmapping (`RSF_NLRS_3.1.1_IfcExportMapping.txt`). Per familie kan dat anders met de parameter `Export Type to IFC As` (`IfcExportAs`). Sommige klassen hebben geen categorie, zoals `IfcSpatialZone` en `IfcExternalSpatialElement`: die vragen een keuze (een nabewerking van de IFC, of een familie met `IfcExportAs`).
