# Herkomst en licenties van de meegeleverde bestanden

| Bestand in `scripts/data/` | Bron | Versie | Licentie |
|---|---|---|---|
| `nlrs/RSF_NLRS_3.1.1_IfcParameterMapping_IFC4.txt` | Revit Standards Foundation, repository NLRS_IFC_settings | NLRS 3.1.1 | MIT, zie `nlrs/LICENSE-NLRS_IFC_settings.txt` |
| `nlrs/RSF_NLRS_3.1.1_CustomPSets.txt` | idem | NLRS 3.1.1 | MIT |
| `nlrs/RSF_NLRS_3.1.1_IfcExportMapping.txt` | idem | NLRS 3.1.1 | MIT |
| `nlrs/NLRS_Shared Parameters - Totaal.txt` | Revit Standards Foundation, repository NLRS_Shared_Parameters | bestand van 08-02-2024 | MIT, zie `nlrs/LICENSE-NLRS_Shared_Parameters.txt` |
| `nlrs/adsk_ifc_parameters.json` | Afgeleid uit de IFC-parameterbestanden `IFC Shared Parameters-RevitIFCBuiltIn_ALL.txt` en `IFC Shared Parameters-RevitIFCBuiltIn-Type_ALL.txt` in de MIT-repository NLRS_Shared_Parameters van de Revit Standards Foundation (https://github.com/RevitStandards/NLRS_Shared_Parameters). Die bestanden komen oorspronkelijk van Autodesk (de IFC Shared Parameters van de Revit IFC-exporter). | zoals in die repository | MIT, zoals de repository, zie `nlrs/LICENSE-NLRS_Shared_Parameters.txt` |
| `nlrs/nlrs_ils_kolommen.json` | Afgeleid uit `NLRS_Shared Parameters - Bronbestand.xlsx`, kolommen "Mapping ILS O&E", "Mapping UVIP Aedes ILS" en "Mapping ADSK IFC Parameters" | zoals in die repository | MIT (repository) |
| `ids/voorbeeld-bim-basis-ils-2.0.ids` | Zelf geschreven door bimforce op basis van de openbare tekst van de BIM basis ILS 2.0 (digiGO). Geen officiële uitgave. | 0.1.0 | MIT |
| `ids/IDS_demo_BIM-basis-ILS.ids` | buildingSMART International, repository IDS, `Documentation/Examples/IDS_demo_BIM-basis-ILS.ids` | versie 2.0 in het bestand | CC BY-ND 4.0, buildingSMART International. Ongewijzigd opgenomen; bron, licentie en link naar de licentietekst in `ids/IDS_demo_BIM-basis-ILS.LICENTIE.md`. |

Niet meegeleverd, op te halen met `ids_bronnen.py`: `NL_BIM_Basis_ILS_v2.ids` van OpenAEC Foundation (MIT).

De twee JSON-bestanden in `nlrs/` maak je opnieuw na een nieuwe NLRS-uitgave met het script `tests/ils/maak_data.py` in de repository van deze skill.
