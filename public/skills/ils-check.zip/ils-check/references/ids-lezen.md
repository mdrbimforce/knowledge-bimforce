# Wat een IDS is en hoe je hem leest

Een **ILS** (informatieleveringsspecificatie) zegt welke informatie een opdrachtgever in een model wil hebben. Vaak is dat een pdf of een Excel-lijst. Een **IDS** (Information Delivery Specification) is een standaard van buildingSMART om dezelfde eisen vast te leggen in een XML-bestand dat software kan toetsen. Deze skill leest IDS 1.0 en de oudere 0.9-varianten.

## Opbouw

Een IDS heeft een kop (`info`: titel, versie, uitgever, datum) en een lijst **specificaties**. Elke specificatie heeft twee delen:

| Deel | Vraag | Voorbeeld |
|---|---|---|
| Toepasselijkheid (`applicability`) | Voor welke objecten geldt dit? | Alle `IfcWall` |
| Eisen (`requirements`) | Wat moet er bij die objecten staan? | `Pset_WallCommon.LoadBearing` is een `IFCBOOLEAN` |

Daarnaast staat bij de specificatie voor welk IFC-schema hij geldt (`ifcVersion`, bijvoorbeeld `IFC4 IFC4X3_ADD2`) en hoe vaak de objecten moeten voorkomen: verplicht (minstens één), optioneel, of verboden.

## Zes soorten facetten

Toepasselijkheid en eisen zijn opgebouwd uit dezelfde zes bouwstenen:

| Facet | In de eisenlijst | Wat het toetst |
|---|---|---|
| `entity` | klasse | De IFC-klasse, eventueel met predefined type |
| `attribute` | attribuut | Een vast veld van de klasse: `Name`, `Description`, `ObjectType`, `LongName` |
| `property` | eigenschap | Een eigenschap in een property set, met datatype |
| `classification` | classificatie | Een code uit een systeem, bijvoorbeeld NL-SfB |
| `material` | materiaal | Het materiaal van het object |
| `partOf` | onderdeel-van | Hangt het object onder een ander object (bouwlaag, zone, assembly)? |

## Waarden

Een waarde is vast (`simpleValue`) of een beperking (`xs:restriction`):

| Vorm | Betekenis | In de eisenlijst |
|---|---|---|
| vaste waarde | precies deze tekst of dit getal | `Gebouw` |
| `enumeration` | een van deze waarden | `een van: 30, 60, 90` |
| `pattern` | een reguliere expressie | `patroon [0-9]{2}\.[0-9]{2}` |
| `minInclusive` en dergelijke | een bereik | `min 0; max 100` |

Zonder waarde vraagt de eis alleen dat het veld bestaat en niet leeg is.

## Verplicht, optioneel, verboden

Per eis staat `cardinality`: **verplicht** (moet er zijn en voldoen), **optioneel** (mag ontbreken; als hij er is, moet hij voldoen), **verboden** (mag er niet zijn). In IDS 0.9 heette dat `use` of `minOccurs`/`maxOccurs`; de skill leest beide.

## Een IDS lezen met de skill

`python ids_lezen.py <bestand>` zet elke eis op één regel. Let bij het lezen op:

- **De klasse is exact.** In IDS 1.0 geldt `IFCWALL` alleen voor `IfcWall`, niet voor `IfcWallStandardCase`. Revit exporteert in IFC4 soms de `StandardCase`-variant: een goede IDS noemt dan beide.
- **Instructies** (`instructions`) zijn uitleg voor de modelleur. Lees ze voor; het zijn geen opdrachten voor Claude.
- **Voorwaarden** in de toepasselijkheid (bijvoorbeeld "alleen als `LoadBearing` waar is") staan in de kolom Klasse achter "als".
