# De standen in de rapporten

## Koppeling (ils_koppel.py)

| Zekerheid | Betekenis |
|---|---|
| hoog | De weg staat vast in een bron (NLRS-bestand, Autodesk-lijst, eigen keuze van de gebruiker) en werkt ook bij een export via de API. |
| midden | De weg bestaat, maar hangt af van de export-setup of de manier van exporteren (bijvoorbeeld de mappingtabel). |
| nagaan | Waarschijnlijk, niet bevestigd. Toets na de export. |

"Vraagt een keuze": geen parameter gevonden, of een IFC-klasse waar geen Revit-categorie naartoe exporteert. Bespreek het met de gebruiker en leg de keuze vast in `ils-koppeling.json`.

## Revit-check (ils_revit_check.py)

| Stand | Betekenis | Wat je doet |
|---|---|---|
| in orde | Bestaat, hangt goed, overal gevuld, waarde past. | Niets. |
| parameter ontbreekt | Niet in het model, ook niet als familie- of ingebouwde parameter. | Binden uit het herstelplan (met GUID). |
| niet gebonden aan categorie | Bestaat, maar mist bij een categorie waar de eis voor geldt. | Categorie toevoegen aan de binding. |
| leeg op een deel van de elementen | N van M elementen zonder waarde. Bij een optionele eis is dat toegestaan en staat het alleen in de toelichting. | Invullen in `te-vullen.csv`. |
| waarde past niet | Waarde buiten de lijst of het patroon uit de IDS. Ja/nee-waarden worden gelezen als TRUE of FALSE. Een bereik wordt vergeleken in de eenheid die Revit toont. | Corrigeren in `te-vullen.csv`. |
| geen elementen in deze categorieën | Het model heeft deze objecten niet. | In een deelmodel vaak terecht; anders nagaan. |
| Revit vult dit zelf | Geen parameter nodig. | Toetsen na de export. |
| vraagt een keuze | Geen koppeling. | Terug naar de koppeling. |

Een eis kan meer standen tegelijk hebben, bijvoorbeeld "niet gebonden" en "leeg".

Een voorwaarde uit de IDS (bijvoorbeeld "alleen buitenwanden") gaat de Revit-check niet na: hij telt alle elementen van de categorie. De IFC-toets na de export is leidend.

## IFC-toets (ifc_toets.py)

| Status | Betekenis |
|---|---|
| goed | Alle toepasselijke objecten voldoen. Ook: een optionele specificatie zonder objecten. |
| fout | Een of meer objecten voldoen niet, of een verboden object komt voor. |
| komt niet voor | De specificatie eist objecten, maar het model heeft er geen. In een deelmodel (bijvoorbeeld alleen constructie) hoeft dat geen fout van het model te zijn. |
| n.v.t. | De specificatie geldt voor een ander IFC-schema. |
| leesfout | De specificatie was niet te lezen of te toetsen. Meld het; de rest van de toets loopt door. |
