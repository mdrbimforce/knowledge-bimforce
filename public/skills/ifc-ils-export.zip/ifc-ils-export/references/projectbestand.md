# Het projectbestand ifc-export.json

Eén bestand per export. Alles wat per project anders is, staat hier; de scripts bevatten alleen de regels. Paden zijn relatief aan de map van het projectbestand. Een sleutel die met `_` begint is uitleg en wordt overgeslagen; zet daar de reden van een keuze.

Een volledig voorbeeld staat in `voorbeeld/ruimtemodel-ils-omgevingsvergunning/ifc-export.json`.

## Hoofdvelden

| Veld | Verplicht | Betekenis |
|---|---|---|
| `model` | ja | Naam van het Revit-model zoals Revit hem toont (Title, zonder `.rvt`). |
| `uitmap` | nee | Map voor de IFC en het verslag. Standaard `uit`. |
| `bestandsnaam` | nee | Naam van de IFC zonder `.ifc`. Standaard de modelnaam. |
| `export` | nee | Instellingen voor de export (hieronder). |
| `voorcontrole` | nee | Wat de voorcontrole toetst. |
| `nabewerking` | nee | Welke stappen, met hun instellingen. Een stap die ontbreekt of `false` is, draait niet. `true` is de stap met standaardinstellingen. |
| `toets` | nee | `{"ids": ...}`: `ils-omgevingsvergunning`, een map met .ids-bestanden of één .ids-bestand. |

## export

| Veld | Standaard | Betekenis |
|---|---|---|
| `setup` | `ruimtemodel-ifc4` | Naam van een meegeleverde setup of pad naar een eigen setup (.json). |
| `ifc_versie` | `IFC4` | `IFC4`, `IFC4RV`, `IFC4DTV`, `IFC2X3CV2` of `IFC2X3`. |
| `fase` | leeg | Naam of id van de fase. Leeg: de laatste fase (met een waarschuwing). |
| `view` | leeg | Naam van een 3D-view; alleen wat daarin zichtbaar is gaat mee. |
| `uitsluiten` | leeg | Lijst van IFC-klassen die niet mee mogen, bv. `["IfcSlab"]`. |
| `ruimtevolume_uit_2d` | uit de setup | Volume van ruimten uit de 2D-contour. |
| `guids_bewaren` | `true` | IfcGUID in het model bewaren (het model raakt gewijzigd). |
| `nlsfb_editie` | `2005` | Editie van NL-SfB in de classificatie. |
| `nlsfb_editiedatum` | 1 januari van de editie | Datum van de editie, `JJJJ-MM-DD`. |
| `classificatie` | `true` | `false`: geen classificatie uit de setup. |
| `pset_bestand` | uit de setup | Eigen psetbestand. |
| `mapping_bestand` | leeg | Mappingtabel; komt via de API niet aan (lessen, les 1). |
| `instellingen` | leeg | Andere setupvelden, bv. `{"SpaceBoundaries": 2}`. |

## voorcontrole

| Veld | Standaard | Betekenis |
|---|---|---|
| `links_geladen` | `true` | Fout als een link niet geladen is (vraagt `list_link_instances`). |
| `ruimten_omsloten` | `true` | Fout als ruimten niet omsloten zijn (vraagt `get_room_geometry`). |
| `verwacht_aantal_ruimten` | leeg | Fout als het aantal omsloten ruimten anders is. |

## nabewerking

### schema, dubbele_globalids, psetnamen

`true` is genoeg. `dubbele_globalids` kent `{"herstellen": false}` (alleen melden). `psetnamen` kent `verboden` (reguliere expressie, standaard `nlrs|revit`) en `hernoemen` (`{"oude naam": "nieuwe naam"}`).

### georeferentie

| Veld | Voorbeeld | Betekenis |
|---|---|---|
| `epsg` | `EPSG:28992` | Coördinatenstelsel (RD New). |
| `naam_crs`, `geodetisch_datum`, `projectie` | `Amersfoort / RD New`, `Amersfoort`, `Oblique Stereographic` | Beschrijving van het stelsel. |
| `verticaal_datum` | `EPSG:5709` | NAP. |
| `oost`, `noord` | `155000.0`, `463000.0` | RD-coördinaten van het nulpunt van het model, in meter. |
| `hoogte` | `0.0` | NAP-hoogte van het nulpunt, in meter. |
| `rotatie_graden` | `0.0` | Hoek van de x-as van het model ten opzichte van het oosten van de kaart, tegen de klok in positief. Controleer het resultaat met een bekend punt in een viewer. |
| `ref_breedte`, `ref_lengte`, `ref_hoogte` | `[52, 9, 22, 178000]` | RefLatitude, RefLongitude (graden, minuten, seconden, miljoenste seconden) en RefElevation van IfcSite. |

De schaal volgt uit de lengte-eenheid van het model (0,001 bij millimeters).

### bouwlagen

Met een tabel (lijst in het projectbestand, of een pad naar CSV of JSON):

| Kolom | Betekenis |
|---|---|
| `nummer` | Bouwlaagnummer, bv. `-1`, `00`, `01`. |
| `naam` | Naam, bv. `begane grond`. |
| `hoogte_mm` | Hoogte van het level; een IfcBuildingStorey binnen `tolerantie_mm` (standaard 150) hoort erbij. |
| `entree` | `true` voor de entreelaag (EntranceLevel). |
| `boven_maaiveld` | optioneel, AboveGround. |

Zonder tabel leest hij nummer en naam uit de huidige naam met `patroon` (standaard: een getal, dan spatie, `_` of `.`, dan de naam). `nummer_formaat: "ils"` (standaard) maakt van `-01` `-1` en van `0` `00`; `naam_kleine_letters` (standaard `true`).

Verder: `stijl` (`nummer-en-naam` of `ils-9.06`), `objecttype` (bv. `Bouwlaag`), `peilen_samenvoegen` (standaard `true`: een IfcBuildingStorey die geen bouwlaag is, gaat op in de bouwlaag eronder).

### ruimten

| Veld | Standaard | Betekenis |
|---|---|---|
| `nummer_patroon` | iets zonder spaties met een cijfer | Hoe een ruimtenummer eruitziet. |
| `splits_patroon` | nummer, spatie, naam | Staat nummer en naam samen in Name, dan splitst hij. |
| `omwisselen` | `true` | Staat het nummer in LongName en de naam in Name, dan wisselt hij ze. |
| `description` | leeg | Description van elke ruimte, bv. `Netto Inhoud`. |
| `hoogtecontrole` | aan | `standaardhoogte_mm` (3048), `afwijking_procent` (5), `doorlopend` (namen die over meer bouwlagen mogen lopen). `false` zet de controle uit. |

### indeling

| Veld | Standaard | Betekenis |
|---|---|---|
| `tabel` | verplicht | De indelingstabel (CSV of JSON, hieronder). |
| `zones_opruimen` | `true` | Een zone van een soort uit de tabel die zelf niet in de tabel staat, gaat eruit. |
| `bezetting_optellen` | `["Verblijfsgebied"]` | Zonesoorten die Pset_SpaceOccupancyRequirements krijgen als som van hun ruimten. |
| `bezetting_type` | uit de ruimten | OccupancyType op de zone, bv. `Onderwijsfunctie`. |

**CSV** (puntkomma of komma), één regel per ruimte en per zone van die ruimte:

```
ruimtenummer;ruimtenaam;ruimtesoort;zone;zonesoort;zone_omschrijving;zone_langenaam
00.17;docentenkamer;Verblijfsruimte;;;;
00.17;;;VG 00;Verblijfsgebied;Netto Inhoud;verblijfsgebied begane grond
00.17;;;BC 00;Brandcompartiment;Bruto Inhoud;brandcompartiment begane grond
```

`ruimtenaam` is alleen ter herkenning. Een zone mag op elke regel dezelfde soort, omschrijving en langenaam hebben, of alleen op de eerste.

**JSON**:

```json
{"ruimten": {"00.17": {"soort": "Verblijfsruimte", "zones": ["VG 00", "BC 00"]}},
 "zones": {"VG 00": {"soort": "Verblijfsgebied", "omschrijving": "Netto Inhoud", "langenaam": "verblijfsgebied begane grond"}}}
```

### eigenschappen

`tabel` (CSV of JSON) en/of `regels` (lijst in het projectbestand). Een regel in JSON:

```json
{"doel": "IfcBuilding", "objecttype": null, "naam": null,
 "attributen": {"Name": "Onderwijsgebouw", "ObjectType": "Gebouw"},
 "adres": {"regels": ["Straat 1"], "postcode": "1234 AB", "plaats": "Plaats", "land": "NL"},
 "psets": {"Pset_BuildingCommon": {"BuildingID": "...", "IsPermanentID": true}}}
```

`doel` is een IFC-klasse; `objecttype` en `naam` beperken de keuze. Een adres kan op IfcSite en IfcBuilding. Als CSV: kolommen `doel;objecttype;naam;pset;property;waarde;type`, met een lege `pset` voor een attribuut. `type` is optioneel (`tekst`, `bool`, `geheel`, `getal`); zonder type wordt `waar`/`true` een ja/nee-waarde en de rest tekst.

### classificatie

| Veld | Standaard | Betekenis |
|---|---|---|
| `woordenboek` | Omgevingswet-Ruimten 0.3.0 | uri van een bSDD-woordenboek. |
| `naam`, `editie`, `bron`, `datum` | uit de uri | Gegevens van IfcClassification. |
| `vast` | Project, Perceel, Gebouw, Bouwlaag | Klasse per IFC-klasse. |
| `op_objecttype` | IfcSpace, IfcZone, IfcSpatialZone, IfcExternalSpatialElement | Deze klassen krijgen de klasse van hun ObjectType. |
| `codes` | `Kadastraal perceel`, ... | ObjectType naar klassecode als die verschillen. |
| `controleer_klassen` | `true` | Klassen controleren tegen de bSDD (eerste keer ophalen). |
