# De export-setup veld voor veld

Een export-setup is het JSON-bestand dat de IFC-dialoog van Revit maakt met *Save setup*. `export_ifc` geeft elk veld als optie aan de exporter, zoals de dialoog dat doet. De skill levert twee setups in `scripts/setups/`:

| Setup | Voor | Verschil |
|---|---|---|
| `ruimtemodel-ifc4` | een softwareneutrale IFC4, ruimtemodellen en vergunningen | eigen psetbestand zonder software- of standaardnamen, base quantities aan, geen 2D, geen materiaalpsets |
| `nlrs-ifc4` | uitwisseling binnen een team dat de NLRS-psets gebruikt | de NLRS 3.0.1 R2024-setup, met het NLRS-psetbestand (`NLRS_...`-psets) |

Beide zijn afgeleid van *NLRS 3.0.1 IFC Export Setup R2024 IFC4* van de Revit Standards Foundation (MIT). Het persoonlijke pad naar het psetbestand is vervangen door `{SETUPS}`; `ifc_export.py` vult bij het uitvoeren het echte pad in en schrijft de runtime-kopie als `_setup_<naam>.json` in de uitmap. Die kopie kun je ook in de Revit-dialoog laden (*Load setup*): `ifc_export.py <project> --setup-alleen`.

Een eigen setup kan ook: zet het pad in `export.setup`. Velden die je per project wilt overschrijven, zet je in `export.instellingen`.

## De velden

Waar `ruimtemodel-ifc4` afwijkt van de NLRS-setup, staat dat erbij.

| Veld | Waarde | Wat het doet |
|---|---|---|
| `IFCVersion` | 25 | Het IFC-schema in de dialoog. `export_ifc` krijgt de versie apart (`ifc_version`, uit `export.ifc_versie`) en die gaat voor. |
| `ExchangeRequirement` | 0 | Geen exchange requirement (MVD-filter). |
| `IFCFileType` | 0 | `.ifc` als tekst (STEP). |
| `ActivePhaseId` | -1 | Welke fase. -1 is de laatste fase van het model. `export.fase` vult hier het id in; zonder fase vallen ruimten in een andere fase weg. |
| `SpaceBoundaries` | 1 | Ruimtegrenzen op niveau 1 (welk element grenst aan welke ruimte). 0 is geen, 2 is voor energieberekening. |
| `SplitWallsAndColumns` | false | Wanden en kolommen niet per bouwlaag knippen. |
| `IncludeSteelElements` | false | Geen staalverbindingen. |
| `ProjectAddress` | genest | Of het adres uit Project Information naar IfcSite of IfcBuilding gaat. Gaat als tekst mee (les 2). Een gesplitst adres zet de stap `eigenschappen`. |
| `Export2DElements` | false (NLRS: true) | Geen 2D-annotatie. Een afnemer heeft er niets aan. |
| `ExportLinkedFiles` | 0 | Links niet meeexporteren. `export_ifc` zet dit altijd uit; exporteer elk model apart. |
| `VisibleElementsOfCurrentView` | false | Het hele model. Met `export.view` exporteert hij alleen wat in die 3D-view zichtbaar is. |
| `ExportRoomsInView` | false | Ruimten niet beperken tot de view. |
| `ExportInternalRevitPropertySets` | false | Geen psets met alle Revit-parameters. Aan geeft psets met Revit-namen: niet softwareneutraal. |
| `ExportIFCCommonPropertySets` | true | De standaardpsets (`Pset_SpaceCommon`, `Pset_WallCommon`, ...). |
| `ExportBaseQuantities` | true (NLRS: false) | `Qto_...BaseQuantities` met oppervlak, volume en hoogte. Nodig voor de hoogtecontrole en de bezetting. |
| `ExportMaterialPsets` | false (NLRS: true) | Geen materiaalpsets; die nemen materiaalparameters met eigen namen mee. |
| `ExportSchedulesAsPsets`, `ExportSpecificSchedules` | false | Geen staten als pset. |
| `ExportUserDefinedPsets` | true | Eigen psets uit het psetbestand. |
| `ExportUserDefinedPsetsFileName` | `{SETUPS}/...txt` | Het psetbestand. `ruimtemodel-psets-ifc4.txt` heeft alleen `Pset_SpaceOccupancyRequirements` voor ruimten; pas de Revit-parameters in de derde kolom aan je model aan. Een eigen bestand: `export.pset_bestand`. |
| `ExportUserDefinedParameterMapping` | false | De mappingtabel. Via de API komt die niet aan (les 1), dus staat hij uit. Wie via de Revit-dialoog exporteert, kan hem aanzetten met de tabel uit de NLRS-repository. |
| `ClassificationSettings` | genest | Eén classificatie die de exporter uit een parameter leest: NL-SfB uit *Assembly Code*, bron Bimloket. De editie kies je met `export.nlsfb_editie` (standaard `2005`) en eventueel `export.nlsfb_editiedatum`; vraag de afnemer welke editie hij wil. Gaat als tekst mee (les 2). De classificatie Omgevingswet-Ruimten zet de nabewerking. |
| `TessellationLevelOfDetail` | 0.5 | Hoe fijn gebogen vormen in driehoeken worden opgedeeld (0 grof, 1 fijn). |
| `ExportPartsAsBuildingElements` | false | Parts als onderdeel van hun element. |
| `ExportSolidModelRep` | true | Vaste-stofgeometrie waar het kan (extrusies, breps). |
| `UseActiveViewGeometry` | false (NLRS: true) | Geometrie uit het model zelf. Via de bridge is de actieve view niet te sturen. |
| `UseFamilyAndTypeNameForReference` | false | Reference wordt de typenaam. |
| `Use2DRoomBoundaryForVolume` | false | Volume van ruimten uit de 3D-vorm. Op true (via `export.ruimtevolume_uit_2d`) rekent hij met de 2D-contour maal de hoogte. Nodig als gelinkte wanden de 3D-vorm laten falen. |
| `IncludeSiteElevation` | false | Hoogte van de site niet in de plaatsing. De hoogte ten opzichte van NAP zet de stap `georeferentie`. |
| `StoreIFCGUID` | true | Revit bewaart de GlobalId per element in de parameter IfcGUID. Zo houden objecten bij een volgende export dezelfde GlobalId. Het model is daarna gewijzigd; bewaren doet de gebruiker. Uit te zetten met `export.guids_bewaren: false`. |
| `ExportBoundingBox` | false (NLRS: true) | Geen extra bounding box per element. |
| `UseOnlyTriangulation` | false | Ook andere vormen dan driehoeken. |
| `UseTypeNameOnlyForIfcType` | true | Het IFC-type heet naar het Revit-type, zonder familienaam. |
| `UseVisibleRevitNameAsEntityName` | true | Name van een element is de naam die Revit toont. |
| `SelectedSite`, `SitePlacement` | Internal, 0 | Welke site en welk nulpunt. De georeferentie zet de nabewerking. |
| `GeoRef...` | leeg | Georeferentie uit de dialoog. Via de bridge is het gedeelde coördinatensysteem niet te zetten; de stap `georeferentie` doet het in de IFC. |
| `ExcludeFilter` | leeg | IFC-klassen die niet mee mogen, gescheiden door `;`. Uit `export.uitsluiten`; voor een ruimtemodel `IfcSlab` (Mass Floors). |
| `COBie...` | leeg | Alleen voor COBie. |
| `Name` | tekst | De naam van de setup in de dialoog. |

## Wat de setup niet kan

Psets op een IfcZone, een gesplitst adres, een classificatie met uri, georeferentie in RD en IFC-klassen voor objecten die er in Revit niet zijn (inhouden, terrein). Daar is de nabewerking voor, of een object in Revit.
