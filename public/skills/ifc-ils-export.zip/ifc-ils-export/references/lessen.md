# Lessen bij het exporteren van ruimtemodellen

Deze lessen komen uit het werk aan het ruimtemodel van het NLRS-onderwijsmodel (november 2026): elf Revit-modellen, IFC4, de ILS Omgevingsvergunning als eis. Ze gelden voor elke export via de Revit-API, dus ook via deze skill.

## 1. De parametermappingtabel komt via de API niet aan

In de IFC-dialoog van Revit kun je een *parameter mapping table* kiezen: per pset en property welke Revit-parameter erin moet. Via de API leest de exporter die tabel niet. Ook de nieuwere route via een `IFCParameterTemplate` gaf in de test nul property sets. De opdracht `export_ifc` meldt dan `property_mapping_error` of `mapping_psets` met nullen.

Wat wel werkt:

- **De IFC-parameters van Autodesk.** Parameters met de namen die de exporter zelf kent, zoals `IfcName`, `IfcLongName`, `IfcObjectType` en `IfcDescription` op een level of ruimte, en `ZoneName`, `ZoneObjectType`, `ZoneDescription`, `ZoneLongName` op een ruimte. Autodesk levert er een shared parameterbestand voor (repository Autodesk/revit-ifc). Gebruik de GUID's uit dat bestand, dan herkent de exporter ze.
- **Een eigen pset met de standaardnaam.** In het psetbestand van de setup mag een pset heten zoals de IFC-standaard hem noemt, bijvoorbeeld `Pset_SpaceOccupancyRequirements`. Die komt wel mee.
- **De nabewerking.** Wat Revit niet kan zetten (een pset op een zone, een gesplitst adres, een classificatie met uri), zet de stap `eigenschappen` of `indeling`.

## 2. Geneste velden van de setup gaan als tekst mee

Een export-setup (JSON uit de IFC-dialoog, *Save setup*) heeft twee geneste velden: `ClassificationSettings` en `ProjectAddress`. De dialoog geeft die als tekst aan de exporter. Gaan ze als object mee, dan vallen ze stil weg; zo verdween de NL-SfB-classificatie uit een export. `ifc_export.py` zet ze daarom altijd als tekst in de runtime-setup, met de datum in de notatie die de exporter verwacht (`\/Date(...)\/`).

## 3. Links, fase en het model vooraan

- **Een link die niet geladen is, laat ruimten open.** Ruimten in het ruimtemodel worden begrensd door wanden in een gelinkt bouwkundig model. Stond die link op *Unloaded*, dan kwamen er 19 van de 153 ruimten mee. Na het laden 153.
- **De fase.** Zonder `ActivePhaseId` neemt de exporter de laatste fase van het model. De ruimten stonden in een andere fase; de export gaf 0 IfcSpace.
- **Het model vooraan.** Een model dat eerder als hoofddocument open stond, liet zich daarna niet als link laden (*Unresolved References*). Exporteer het model dat als hoofddocument open staat, en open het eerst als je het hele project exporteert.
- **De bron telt.** `get_room_geometry` geeft per model het aantal ruimten, geplaatst en omsloten. Vergelijk dat met wat je verwacht (`voorcontrole.verwacht_aantal_ruimten`) voordat je exporteert.

## 4. De hoogte van een ruimte

Een Revit-ruimte loopt standaard 3048 mm (10 voet) door, of tot de *Limit Offset* boven de *Upper Limit*. Staat dat niet goed, dan steekt een ruimte door de vloer erboven of eindigt hij midden in de verdieping. In het voorbeeldmodel BM13 van DigiGO hebben meerdere ruimten precies 3048 mm. In het onderwijsmodel liepen toiletten en technische ruimten 7592 mm door, over twee bouwlagen, en vides 3,3 m door het dak.

Controleer daarom:

- hoogte gelijk aan 3048 mm: waarschijnlijk de standaardwaarde;
- hoogte tegen volume gedeeld door oppervlak: wijkt dat veel af, kijk dan hoe Revit het volume berekent (*Area and Volume Computations*, en `Use2DRoomBoundaryForVolume` in de setup);
- hoogte tegen de afstand tot de volgende bouwlaag: alleen vides, schachten en trappenhuizen mogen doorlopen.

De stap `ruimten` en `ifc_controle.py` melden alle drie. Herstellen doe je in Revit.

## 5. Nummer in Name, naam in LongName

Voor ruimten staat het ruimtenummer in `Name` en de ruimtenaam in `LongName`. Dat doet Revit al zo. Voor bouwlagen geldt hetzelfde: het nummer in `Name` (`00`), de naam in `LongName` (`begane grond`). In Revit mag het level `00 begane grond` heten; met `IfcName` en `IfcLongName` op het level, of met de stap `bouwlagen`, splits je het in de IFC.

Kanttekening: regel 9.06a van de ILS Omgevingsvergunning eist nu nummer en naam samen in `Name` (`00 begane grond`). Er ligt een voorstel om dat aan te passen. Kies in het projectbestand `bouwlagen.stijl`: `nummer-en-naam` of `ils-9.06`, en schrijf de keuze op.

## 6. Wat een IDS-uitslag wel en niet zegt

- **ifcVersion.** ifctester past een specificatie ook toe als die voor een ander IFC-schema is geschreven (bijvoorbeeld alleen IFC4X3). De IDS-toets telt die als *niet van toepassing*.
- **minOccurs 1 voor iets wat er niet is.** Sommige specificaties eisen een object dat in een ruimtemodel niet voorkomt, zoals een balk of een bedruimte in een school. Dan is de uitslag *komt niet voor*. Dat is geen fout van het model; het object hoort in een ander deelmodel of bestaat in dit gebouw niet.

## 7. Dubbele GlobalIds komen uit de exporter

Een sparing in een element dat door andere elementen in stukken geknipt wordt, krijgt in elk stuk dezelfde GlobalId. In een constructiemodel knipten vier liggers een dakvloer in zes stukken: vier sparingen met dezelfde id, twintig dubbelingen. In Revit los je dat alleen op met een modelwijziging (vloer splitsen of de join omkeren). De stap `dubbele_globalids` geeft elk extra exemplaar een vaste eigen id.

## 8. Softwareneutraal

Een IFC die naar een opdrachtgever of een vergunningverlener gaat, hoort softwareneutraal te zijn: geen psets of properties met de naam van een software (`Revit`) of van een eigen afspraak (`NLRS_...`). De afnemer leest de standaardnamen (`Pset_SpaceCommon`) of de namen die zijn eigen eisen noemen. Zet daarom in de setup `ExportInternalRevitPropertySets` uit en kies een psetbestand zonder zulke namen. De stap `psetnamen` en `ifc_controle.py` melden wat er toch in staat. Werk je binnen een team dat juist de NLRS-psets uitwisselt, dan is de setup `nlrs-ifc4` er; spreek dat dan af.

## Kleinere lessen

- De exporter schrijft `InnerBoundaries` van ruimtegrenzen leeg als `$`; IFC4 eist een lege lijst. Elke ruimtegrens geeft dan een schemamelding (255 in het voorbeeld). De stap `schema` herstelt het.
- De exporter deelt één property tussen veel psets (bijvoorbeeld één `LoadBearing = waar` voor alle wanden). Wie die property bewerkt, wijzigt ze allemaal. De nabewerking maakt zo'n property eerst los.
- Massa's (Mass) worden in IFC4 geen IfcSpatialZone, ook niet met `IfcExportAs`. Mass Floors worden IfcSlab; sluit IfcSlab uit in een ruimtemodel (`export.uitsluiten`).
- Revit zet geen pset op een IfcZone. Psets op zones (bezetting, vluchtroute) komen uit de nabewerking.
