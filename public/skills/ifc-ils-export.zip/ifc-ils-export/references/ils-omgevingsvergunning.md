# Wat de ILS Omgevingsvergunning van een ruimtemodel vraagt

De ILS Omgevingsvergunning is een informatieleveringsspecificatie van DigiGO: welke informatie een BIM-model moet bevatten zodat een vergunningverlener het kan toetsen aan het Besluit bouwwerken leefomgeving (Bbl). De eisen staan als IDS-bestanden (één per onderwerp) op de ILS-pagina:

- pagina: https://nl-digigo.github.io/vergunningcontrole/ils-omgevingsvergunning/
- bestanden: github.com/nl-digigo/vergunningcontrole, map `docs/ils-omgevingsvergunning/ids` op de tak `BM13/machineleesbare-regels`
- woordenboek: Omgevingswet-Ruimten 0.3.0 van buildingSMART Nederland in de bSDD

De IDS-bestanden zitten niet in de skill. Op 25-11-2026 had de repository geen licentiebestand; de README noemt een voorstel voor CC BY 4.0 dat nog bevestigd moet worden. `bronnen.py` haalt ze daarom bij eerste gebruik op en schrijft in `bron.json` waar ze vandaan komen. Hetzelfde geldt voor het voorbeeldmodel BM13 en de klassen van het woordenboek (de bSDD noemt daarbij "No license (rights reserved)"). Lees bij twijfel de bron zelf; deze samenvatting volgt de IDS-versie van 25-11-2026.

## De begrippen en waar ze in de IFC staan

| Regel | Begrip | IFC | Wat er gevraagd wordt (kort) |
|---|---|---|---|
| 9.01a/b/f | Georeferentie | IfcMapConversion, IfcProjectedCRS | coördinaten, rotatie en schaal; EPSG:28992 met verticaal datum EPSG:5709 (NAP) |
| 9.02 | Project | IfcProject | Name, Description, Phase uit een vaste lijst |
| 9.03a | Perceel | IfcSite, ObjectType `Perceel` | Pset_LandRegistration met LandID en IsPermanentID |
| 9.03b | Bouwwerkperceel | IfcSpatialZone | terreinvolume |
| 9.04 | Kadastraal perceel | | alleen bij een echt perceel |
| 9.05a | Gebouw | IfcBuilding, ObjectType `Gebouw` | BuildingID, IsPermanentID, MarketCategory uit een vaste lijst |
| 9.05b | Gebouwinhoud | IfcSpatialZone | bruto inhoud |
| 9.06a | Bouwlaag | IfcBuildingStorey, ObjectType `Bouwlaag` | Name met nummer en naam (`00 begane grond`), EntranceLevel |
| 9.06b | Bouwlaaginhoud | IfcSpatialZone | bruto inhoud per bouwlaag |
| 9.07 | Gebruikseenheid | IfcZone | |
| 9.08, 9.09 | Gebruiksfunctie, nevengebruiksfunctie | IfcZone | |
| 9.10a t/m f | Functie-, verblijfs-, gebruiks-, bed- en restgebied | IfcZone | verblijfsgebied met bezetting (Pset_SpaceOccupancyRequirements) |
| 9.11 | Buitengebied | IfcExternalSpatialElement | Pset_SpaceCommon |
| 9.12a t/m d | Functie-, verblijfs-, bed- en restruimte | IfcSpace, ObjectType = ruimtesoort | |
| 9.13 | Buitenruimte | IfcSpace | bij een woonfunctie |
| 9.16a t/d | Brandcompartiment, subbrandcompartiment, vluchtroute, beschermd subbrandcompartiment | IfcZone | vluchtroute met FireExit = waar |
| 9.17 | Tarra ruimte | IfcSpace | |
| 9.18 | Fysieke elementen | IfcWall, IfcSlab, IfcDoor, ... | horen in het bouwkundige en constructieve model |

Elk object krijgt een classificatie naar het woordenboek Omgevingswet-Ruimten (IfcClassificationReference met de uri van de klasse). Een zone heeft in `Description` de soort inhoud (`Gebruiksinhoud`, `Bruto Inhoud`, `Netto Inhoud`) en in `LongName` een leesbare naam.

## Hoe de skill dat invult

| Begrip | Stap | Bron |
|---|---|---|
| georeferentie | `georeferentie` | coördinaten in het projectbestand |
| project, perceel, gebouw | `eigenschappen` | eigenschappentabel |
| bouwlagen | `bouwlagen` | tabel of patroon in het projectbestand |
| ruimtesoort, zones, gebieden, compartimenten, vluchtroutes | `indeling` | indelingstabel |
| bezetting verblijfsgebied | `indeling` | som van de ruimten (OccupancyNumber uit Revit) |
| FireExit op vluchtroutes | `eigenschappen` | regel op IfcZone met ObjectType `Vluchtroute` |
| classificatie | `classificatie` | ObjectType van elk object |
| inhouden en terrein (9.03b, 9.05b, 9.06b, 9.11) | | niet in de skill: modelleer ze in Revit of lever ze apart |

Welke ruimte een verblijfsruimte is, en welke ruimten samen een brandcompartiment vormen, beslist de ontwerper met het Bbl (bijlage I, begripsbepalingen) en het brandveiligheidsplan. De skill neemt over wat in de tabel staat.

## Bekende afwijking: de naam van de bouwlaag

Regel 9.06a eist nummer en naam samen in `Name`. In IFC staat bij ruimten het nummer in `Name` en de naam in `LongName`; voor bouwlagen ligt het voor de hand dat net zo te doen. Er ligt een voorstel bij de ILS om 9.06a daarop aan te passen. Tot dat besloten is, kies je in `bouwlagen.stijl`:

- `nummer-en-naam`: `Name = 00`, `LongName = begane grond`. 9.06a geeft *fout*.
- `ils-9.06`: `Name = 00 begane grond`, `LongName = begane grond`. 9.06a geeft *goed*.

## Wat een uitslag betekent

Volgens de ILS keurt een specificatie waarvan het object niet voorkomt niet af, behalve bij de basisbegrippen (9, 9.01a, 9.01b, 9.02, 9.05a, 9.06a). In de IDS-toets heet dat *komt niet voor*. Een school heeft geen bedruimte en geen buitenruimte; een ruimtemodel heeft geen balken.
