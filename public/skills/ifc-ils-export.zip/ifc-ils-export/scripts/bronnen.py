"""Bestanden van anderen bij eerste gebruik ophalen bij de bron, met een vermelding waar ze vandaan komen.

Wat hier opgehaald wordt, zit niet in de skill, omdat de licentie bundelen niet duidelijk toestaat:

- De IDS-bestanden van de ILS Omgevingsvergunning en het voorbeeldmodel BM13 (DigiGO, repository
  nl-digigo/vergunningcontrole). Stand 25-11-2026: geen LICENSE-bestand in de repository; de README van de
  ILS-pagina noemt "Voorstel: CC BY 4.0 (nog te bevestigen)".
- De klassenlijst van het woordenboek Omgevingswet-Ruimten (buildingSMART Nederland, bSDD). De bSDD noemt bij
  dit woordenboek "No license (rights reserved)".

Alles komt in een cachemap (standaard %LOCALAPPDATA%\\RevitAgent\\ifc-ils-export, of REVIT_AGENT_CACHE) met
een bestand bron.json ernaast: adres, tak, commit en datum van ophalen.

    python bronnen.py ils-ids [--ref <tak>] [--opnieuw]     IDS-bestanden ophalen, pad tonen
    python bronnen.py bm13                                  voorbeeldmodel BM13 (ruimtemodel) ophalen
    python bronnen.py klassen [<woordenboek-uri>]           klassenlijst uit de bSDD ophalen

Alleen de standaardbibliotheek.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

REPO = "nl-digigo/vergunningcontrole"
ILS_REF = "BM13/machineleesbare-regels"   # de tak waarop de ILS-pagina gepubliceerd wordt (stand 25-11-2026)
ILS_MAP = "docs/ils-omgevingsvergunning"
BM13_PAD = f"{ILS_MAP}/voorbeeldmodellen/BM13_SPA_XX_M3D_ZZZ_Qto.ifc"
OMGEVINGSWET_RUIMTEN = "https://identifier.buildingsmart.org/uri/bsnl/Omgevingswet-Ruimten/0.3.0"
BSDD_API = "https://api.bsdd.buildingsmart.org/api/Dictionary/v1/Classes"
KOP = {"User-Agent": "revit-agent-ifc-ils-export", "Accept": "application/json"}


def cachemap() -> Path:
    basis = os.environ.get("REVIT_AGENT_CACHE")
    if basis:
        p = Path(basis)
    else:
        lok = os.environ.get("LOCALAPPDATA")
        p = (Path(lok) / "RevitAgent" if lok else Path.home() / ".revit-agent") / "ifc-ils-export"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _haal(url: str, binair: bool = False, timeout: float = 60):
    req = urllib.request.Request(url, headers=KOP)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    return data if binair else json.loads(data.decode("utf-8"))


def _nu() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def _schrijf_bron(map_: Path, gegevens: dict):
    (map_ / "bron.json").write_text(json.dumps(gegevens, ensure_ascii=False, indent=1), encoding="utf-8")


def ils_ids(ref: str = ILS_REF, opnieuw: bool = False) -> Path:
    """Map met de .ids-bestanden van de ILS Omgevingsvergunning. Haalt ze op als de cache leeg is."""
    doel = cachemap() / "ils-omgevingsvergunning" / ref.replace("/", "_") / "ids"
    if doel.is_dir() and any(doel.glob("*.ids")) and not opnieuw:
        return doel
    doel.mkdir(parents=True, exist_ok=True)
    q = urllib.parse.quote(ref, safe="")
    commits = _haal(f"https://api.github.com/repos/{REPO}/commits?sha={q}&path={ILS_MAP}/ids&per_page=1")
    commit = commits[0]["sha"] if commits else ref
    lijst = _haal(f"https://api.github.com/repos/{REPO}/contents/{ILS_MAP}/ids?ref={q}")
    namen = []
    for item in lijst:
        if item.get("type") == "file" and item["name"].lower().endswith(".ids"):
            raw = f"https://raw.githubusercontent.com/{REPO}/{commit}/{urllib.parse.quote(item['path'])}"
            (doel / item["name"]).write_bytes(_haal(raw, binair=True))
            namen.append(item["name"])
    _schrijf_bron(doel, {"bron": f"https://github.com/{REPO}", "tak": ref, "commit": commit,
                         "map": f"{ILS_MAP}/ids", "opgehaald": _nu(), "bestanden": sorted(namen),
                         "licentie": "geen LICENSE in de repository (25-11-2026); README: voorstel CC BY 4.0, nog te bevestigen",
                         "pagina": "https://nl-digigo.github.io/vergunningcontrole/ils-omgevingsvergunning/"})
    return doel


def bm13(ref: str = ILS_REF, opnieuw: bool = False) -> Path:
    """Het ruimtemodel BM13 (IFC) dat DigiGO als voorbeeld bij de ILS publiceert."""
    doel = cachemap() / "ils-omgevingsvergunning" / ref.replace("/", "_") / "voorbeeldmodellen"
    pad = doel / Path(BM13_PAD).name
    if pad.is_file() and not opnieuw:
        return pad
    doel.mkdir(parents=True, exist_ok=True)
    q = urllib.parse.quote(ref, safe="")
    commits = _haal(f"https://api.github.com/repos/{REPO}/commits?sha={q}&path={BM13_PAD}&per_page=1")
    commit = commits[0]["sha"] if commits else ref
    pad.write_bytes(_haal(f"https://raw.githubusercontent.com/{REPO}/{commit}/{BM13_PAD}", binair=True))
    _schrijf_bron(doel, {"bron": f"https://github.com/{REPO}", "tak": ref, "commit": commit, "bestand": BM13_PAD,
                         "opgehaald": _nu(),
                         "licentie": "geen LICENSE in de repository (25-11-2026); README: voorstel CC BY 4.0, nog te bevestigen"})
    return pad


def klassen(uri: str = OMGEVINGSWET_RUIMTEN, opnieuw: bool = False) -> dict:
    """Klassen van een bSDD-woordenboek: {'code': {'uri', 'name', 'referenceCode'}}. Gooit bij geen verbinding."""
    sleutel = uri.rstrip("/").split("/uri/")[-1].replace("/", "_")
    pad = cachemap() / "bsdd" / f"{sleutel}.json"
    if pad.is_file() and not opnieuw:
        data = json.loads(pad.read_text(encoding="utf-8"))
    else:
        data = _haal(f"{BSDD_API}?Uri={urllib.parse.quote(uri, safe=':/')}&Limit=1000")
        pad.parent.mkdir(parents=True, exist_ok=True)
        data["_opgehaald"] = _nu()
        data["_bron"] = BSDD_API
        pad.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    return {c["code"]: {"uri": c.get("uri"), "name": c.get("name"), "referenceCode": c.get("referenceCode")}
            for c in data.get("classes", [])}


def ids_paden(waarde: str | None, project_map: Path | None = None) -> list[Path]:
    """'ils-omgevingsvergunning' (ophalen bij DigiGO), een map met .ids of een los .ids-bestand."""
    if not waarde:
        return []
    if waarde == "ils-omgevingsvergunning":
        return [ils_ids()]
    p = Path(waarde).expanduser()
    if not p.is_absolute() and project_map is not None:
        p = (project_map / p).resolve()
    if not p.exists():
        raise FileNotFoundError(f"IDS niet gevonden: {p}")
    return [p]


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] in ("-h", "--help"):
        print(__doc__)
        raise SystemExit(0)
    opnieuw = "--opnieuw" in a
    ref = a[a.index("--ref") + 1] if "--ref" in a else ILS_REF
    if a[0] == "ils-ids":
        m = ils_ids(ref, opnieuw)
        print(m, f"({len(list(m.glob('*.ids')))} bestanden)")
    elif a[0] == "bm13":
        print(bm13(ref, opnieuw))
    elif a[0] == "klassen":
        k = klassen(a[1] if len(a) > 1 and not a[1].startswith("--") else OMGEVINGSWET_RUIMTEN, opnieuw)
        print(json.dumps(sorted(k), ensure_ascii=False))
    else:
        raise SystemExit(__doc__)
