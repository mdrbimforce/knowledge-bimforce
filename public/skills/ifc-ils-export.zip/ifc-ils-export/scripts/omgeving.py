"""Een eigen Python-omgeving voor de IFC-scripts (ifcopenshell, ifctester), één keer aanmaken.

    python omgeving.py            maakt de omgeving als die er nog niet is en toont het pad naar python
    python omgeving.py --opnieuw  gooit de omgeving weg en maakt hem opnieuw

De omgeving staat in %LOCALAPPDATA%\\RevitAgent\\venv-ifc (of REVIT_AGENT_VENV). ifc_export.py roept de
nabewerking en de controle met deze python aan; ifc_export.py zelf heeft alleen de standaardbibliotheek nodig.
Wil je een bestaande omgeving gebruiken (met ifcopenshell 0.9), zet dan IFC_PYTHON op het pad naar die python.

Alleen de standaardbibliotheek.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

HIER = Path(__file__).resolve().parent
EISEN = HIER / "requirements.txt"


def venv_map() -> Path:
    if os.environ.get("REVIT_AGENT_VENV"):
        return Path(os.environ["REVIT_AGENT_VENV"])
    lok = os.environ.get("LOCALAPPDATA")
    return (Path(lok) / "RevitAgent" if lok else Path.home() / ".revit-agent") / "venv-ifc"


def _python_in(map_: Path) -> Path:
    return map_ / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def heeft_ifcopenshell(python: str | Path) -> bool:
    r = subprocess.run([str(python), "-c", "import ifcopenshell, ifctester"], capture_output=True)
    return r.returncode == 0


def python_pad(maak: bool = True, opnieuw: bool = False) -> Path:
    """Pad naar een python met ifcopenshell. Volgorde: IFC_PYTHON, de eigen omgeving, deze python."""
    if os.environ.get("IFC_PYTHON"):
        return Path(os.environ["IFC_PYTHON"])
    map_ = venv_map()
    py = _python_in(map_)
    if opnieuw and map_.exists():
        shutil.rmtree(map_)
    if py.is_file() and heeft_ifcopenshell(py):
        return py
    try:
        import ifcopenshell  # noqa: F401
        import ifctester  # noqa: F401
        if not opnieuw:
            return Path(sys.executable)
    except ImportError:
        pass
    if not maak:
        raise RuntimeError("geen python met ifcopenshell gevonden; draai eerst: python omgeving.py")
    print(f"Python-omgeving maken in {map_} (eenmalig, een paar minuten) ...", flush=True)
    subprocess.run([sys.executable, "-m", "venv", str(map_)], check=True)
    subprocess.run([str(py), "-m", "pip", "install", "--quiet", "--upgrade", "pip"], check=True)
    subprocess.run([str(py), "-m", "pip", "install", "--quiet", "-r", str(EISEN)], check=True)
    if not heeft_ifcopenshell(py):
        raise RuntimeError(f"ifcopenshell is niet te laden in {py}; zie de uitvoer van pip hierboven")
    return py


def gebruik_eigen_omgeving(script: str | Path) -> None:
    """Draai `script` opnieuw met de python uit de eigen omgeving als dat een andere python is.

    Zo werkt `python ifc_nabewerking.py ...` en `python ifc_controle.py ...` ook met een python zonder
    ifcopenshell of ifctester (breedtest 25-11-2026: de IDS-toets viel weg met de gewone python)."""
    if os.environ.get("REVIT_AGENT_IN_OMGEVING"):
        return
    try:
        py = python_pad(maak=True)
    except Exception as e:  # noqa: BLE001 - dan faalt de import verderop met een eigen melding
        print(f"Eigen Python-omgeving niet beschikbaar: {e}", file=sys.stderr)
        return
    if Path(py).resolve() == Path(sys.executable).resolve():
        return
    env = dict(os.environ, REVIT_AGENT_IN_OMGEVING="1")
    r = subprocess.run([str(py), str(script), *sys.argv[1:]], env=env)
    raise SystemExit(r.returncode)


if __name__ == "__main__":
    print(python_pad(maak=True, opnieuw="--opnieuw" in sys.argv))
