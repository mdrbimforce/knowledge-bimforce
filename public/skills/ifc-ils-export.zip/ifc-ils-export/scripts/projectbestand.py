"""Het projectbestand ifc-export.json lezen: één plek voor wat er per project anders is.

De scripts ifc_export.py, ifc_nabewerking.py en ifc_controle.py lezen hetzelfde bestand. Alles wat
projectinhoud is (welk model, welke bouwlagen, welke zones, welke georeferentie) staat hier; de regels
zelf staan in de scripts. Uitleg per veld: references/projectbestand.md.

Paden in het projectbestand zijn relatief aan de map van het projectbestand, tenzij ze absoluut zijn.
Sleutels die met "_" beginnen zijn uitleg en worden overgeslagen.

Alleen de standaardbibliotheek, zodat ifc_export.py zonder ifcopenshell kan draaien.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

HIER = Path(__file__).resolve().parent
SETUPS = HIER / "setups"

NABEWERKSTAPPEN = ("schema", "dubbele_globalids", "georeferentie", "bouwlagen", "ruimten", "indeling",
                   "eigenschappen", "classificatie", "psetnamen")


class ProjectFout(ValueError):
    """Het projectbestand klopt niet; de melding zegt welk veld."""


def _zonder_uitleg(x):
    if isinstance(x, dict):
        return {k: _zonder_uitleg(v) for k, v in x.items() if not str(k).startswith("_")}
    if isinstance(x, list):
        return [_zonder_uitleg(v) for v in x]
    return x


class Project:
    def __init__(self, pad: str | Path):
        self.pad = Path(pad).resolve()
        if not self.pad.is_file():
            raise ProjectFout(f"projectbestand niet gevonden: {self.pad}")
        try:
            ruw = json.loads(self.pad.read_text(encoding="utf-8-sig"))
        except ValueError as e:
            raise ProjectFout(f"{self.pad.name} is geen geldige JSON: {e}") from e
        self.data: dict = _zonder_uitleg(ruw)
        self.map = self.pad.parent

    # ---------------------------------------------------------------- algemeen
    def pad_van(self, waarde: str | None) -> Path | None:
        if not waarde:
            return None
        p = Path(str(waarde)).expanduser()
        return p if p.is_absolute() else (self.map / p).resolve()

    @property
    def model(self) -> str:
        m = self.data.get("model")
        if not m:
            raise ProjectFout("veld 'model' ontbreekt: de naam van het model zoals Revit hem toont (Title)")
        return str(m)

    @property
    def uitmap(self) -> Path:
        return self.pad_van(self.data.get("uitmap") or "uit")

    @property
    def bestandsnaam(self) -> str:
        return str(self.data.get("bestandsnaam") or self.model)

    @property
    def ifc_pad(self) -> Path:
        return self.uitmap / (self.bestandsnaam + ".ifc")

    @property
    def export(self) -> dict:
        return self.data.get("export") or {}

    @property
    def voorcontrole(self) -> dict:
        return self.data.get("voorcontrole") or {}

    @property
    def toets(self) -> dict:
        return self.data.get("toets") or {}

    def nabewerking(self) -> dict:
        """Stap -> instellingen, alleen de stappen die aan staan, in de vaste volgorde."""
        nb = self.data.get("nabewerking") or {}
        onbekend = [k for k in nb if k not in NABEWERKSTAPPEN]
        if onbekend:
            raise ProjectFout(f"onbekende nabewerkstap(pen) {onbekend}; bekend zijn {list(NABEWERKSTAPPEN)}")
        uit = {}
        for stap in NABEWERKSTAPPEN:
            v = nb.get(stap)
            if v is None or v is False:
                continue
            uit[stap] = {} if v is True else v
        return uit

    # ---------------------------------------------------------------- setup
    def setup_bron(self) -> Path:
        naam = self.export.get("setup") or "ruimtemodel-ifc4"
        p = self.pad_van(naam) if any(c in str(naam) for c in "/\\") or str(naam).endswith(".json") else None
        if p and p.is_file():
            return p
        p = SETUPS / f"{naam}.json"
        if p.is_file():
            return p
        bekend = sorted(x.stem for x in SETUPS.glob("*.json"))
        raise ProjectFout(f"setup '{naam}' niet gevonden; meegeleverd: {bekend}, of geef een pad naar een .json")


# -------------------------------------------------------------------- tabellen
def lees_tabel(pad: Path) -> list[dict]:
    """CSV (komma of puntkomma, eerste regel = kolomnamen) of JSON (lijst van objecten) als lijst van dicts."""
    if not pad or not Path(pad).is_file():
        raise ProjectFout(f"tabel niet gevonden: {pad}")
    pad = Path(pad)
    if pad.suffix.lower() == ".json":
        data = json.loads(pad.read_text(encoding="utf-8-sig"))
        return _zonder_uitleg(data)
    tekst = pad.read_text(encoding="utf-8-sig")
    eerste = tekst.splitlines()[0] if tekst else ""
    scheiding = ";" if eerste.count(";") >= eerste.count(",") else ","
    rijen = []
    for r in csv.DictReader(tekst.splitlines(), delimiter=scheiding):
        rij = {(k or "").strip().lower(): (v or "").strip() for k, v in r.items() if k is not None}
        if any(rij.values()) and not next(iter(rij.values()), "").startswith("#"):
            rijen.append(rij)
    return rijen
