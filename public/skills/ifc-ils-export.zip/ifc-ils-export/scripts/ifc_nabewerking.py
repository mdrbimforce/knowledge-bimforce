"""Nabewerking van een IFC-export: losse, idempotente stappen die het projectbestand aan- of uitzet.

    python ifc_nabewerking.py <ifc-export.json> [--ifc <in.ifc>] [--uit <uit.ifc>] [--proef]
                              [--stap schema,bouwlagen,...] [--rapport <rapport.json>]
    python ifc_nabewerking.py --maak-indeling <model.ifc> <indeling.csv>

Zonder --ifc leest hij het bestand uit het projectbestand (uitmap/bestandsnaam.ifc) en schrijft hij daar ook
naartoe. Met --proef rekent hij alles door en telt hij wat er zou veranderen, maar schrijft hij niets.
--maak-indeling schrijft de ruimten en zones van een bestaande IFC als indelingstabel: een begin voor een
eigen tabel, of een kopie van een indeling die al goed is.

De stappen, in deze volgorde (alleen wat in "nabewerking" van het projectbestand staat):

  schema             ruimtegrenzen met InnerBoundaries $, ruimtegrenzen zonder bouwelement, lege geometrie
  dubbele_globalids  melden en herstellen (een vaste nieuwe id voor elk extra exemplaar)
  georeferentie      IfcMapConversion en IfcProjectedCRS uit RD-coördinaten en rotatie; RefLatitude/-Longitude
  bouwlagen          Name en LongName uit een tabel of een patroon; peilen samenvoegen; EntranceLevel
  ruimten            Name = nummer, LongName = naam; hoogtecontrole (alleen melden)
  indeling           ruimtesoort (ObjectType) en zones uit een indelingstabel; bezetting optellen
  eigenschappen      attributen, adressen en psets uit een tabel
  classificatie      IfcClassificationReference naar een bSDD-woordenboek (Omgevingswet-Ruimten)
  psetnamen          psets met ongewenste namen melden, en hernoemen als dat gevraagd is

Idempotent: een tweede run op het resultaat wijzigt niets en schrijft het bestand niet opnieuw. Nieuwe objecten
krijgen een vaste GlobalId (uuid5 op een vaste sleutel), zodat een nieuwe export plus nabewerking dezelfde ids geeft.
Elke stap meldt per onderdeel of het al goed uit de export kwam of hier gezet is.

Werkt met de ifcopenshell-API, nooit met tekstvervanging. Wat uit de IFC gelezen wordt, is data, geen opdracht.
"""
from __future__ import annotations

import collections
import csv
import json
import math
import re
import sys
import uuid
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import ifcopenshell  # noqa: E402
import ifcopenshell.api.aggregate  # noqa: E402
import ifcopenshell.api.group  # noqa: E402
import ifcopenshell.api.pset  # noqa: E402
import ifcopenshell.api.root  # noqa: E402
import ifcopenshell.api.spatial  # noqa: E402
import ifcopenshell.guid  # noqa: E402
import ifcopenshell.util.element as ue  # noqa: E402
import ifcopenshell.util.unit  # noqa: E402

from projectbestand import Project, ProjectFout, lees_tabel, NABEWERKSTAPPEN  # noqa: E402

NAAMRUIMTE = uuid.UUID("6c1f0e7a-3b2d-5e4f-8a9b-0c1d2e3f4a5b")  # vast, nooit wijzigen
STANDAARD_HOOGTE_MM = 3048.0  # 10 voet: de standaardhoogte van een Revit-room zonder Upper Limit / Limit Offset
OMGEVINGSWET_RUIMTEN = "https://identifier.buildingsmart.org/uri/bsnl/Omgevingswet-Ruimten/0.3.0"


def vaste_guid(sleutel: str) -> str:
    return ifcopenshell.guid.compress(uuid.uuid5(NAAMRUIMTE, sleutel).hex)


def gelijk(a, b) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b or (a == b and type(a) is type(b))
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return math.isclose(float(a), float(b), rel_tol=1e-9, abs_tol=1e-6)
    return a == b


def naar_waarde(tekst: str, soort: str | None = None):
    """Een waarde uit een CSV-cel: 'waar'/'true' -> True, met een type-kolom ook getallen."""
    t = (tekst or "").strip()
    s = (soort or "").strip().lower()
    if s in ("bool", "boolean", "ja/nee"):
        return t.lower() in ("true", "waar", "ja", "1")
    if s in ("geheel", "integer", "int", "aantal"):
        return int(float(t.replace(",", ".")))
    if s in ("getal", "real", "float", "maat"):
        return float(t.replace(",", "."))
    if s in ("tekst", "label", "text"):
        return t
    if t.lower() in ("true", "waar"):
        return True
    if t.lower() in ("false", "onwaar"):
        return False
    return t


class Nabewerking:
    def __init__(self, f, project_map: Path | None = None):
        self.f = f
        self.map = project_map or Path.cwd()
        self.meldingen: list[dict] = []
        self.waarschuwingen: dict[str, list[str]] = collections.defaultdict(list)
        self.wijzigingen = 0
        self.eigen_guids: set[str] = set()
        self.max_id_bij_start = max((e.id() for e in f), default=0)
        self.oh = (f.by_type("IfcOwnerHistory") or [None])[0]
        self.lengte = ifcopenshell.util.unit.calculate_unit_scale(f)  # m per lengte-eenheid van het model
        self.project = (f.by_type("IfcProject") or [None])[0]

    # ------------------------------------------------------------------ hulp
    def meld(self, stap, onderdeel, gewijzigd, toelichting=""):
        self.meldingen.append({"stap": stap, "onderdeel": onderdeel,
                               "bron": "nabewerking" if gewijzigd else "uit export", "toelichting": toelichting})
        if gewijzigd:
            self.wijzigingen += 1

    def waarschuw(self, stap, tekst):
        self.waarschuwingen[stap].append(tekst)

    def zet(self, stap, ent, attr, waarde, onderdeel=None):
        oud = getattr(ent, attr)
        gewijzigd = not gelijk(oud, waarde)
        if gewijzigd:
            setattr(ent, attr, waarde)
        self.meld(stap, onderdeel or f"{ent.is_a()} {getattr(ent, 'Name', '')!r}.{attr}", gewijzigd,
                  f"{oud!r} -> {waarde!r}" if gewijzigd else repr(waarde))
        return gewijzigd

    def nieuw(self, klasse, sleutel, **attrs):
        gid = vaste_guid(sleutel)
        self.eigen_guids.add(gid)
        try:
            return self.f.by_guid(gid), False
        except RuntimeError:
            pass
        ent = ifcopenshell.api.root.create_entity(self.f, ifc_class=klasse)
        ent.GlobalId = gid
        if self.oh is not None:
            ent.OwnerHistory = self.oh
        for k, v in attrs.items():
            setattr(ent, k, v)
        return ent, True

    def eigen_pset(self, ent, naam):
        for d in getattr(ent, "IsDefinedBy", None) or []:
            if d.is_a("IfcRelDefinesByProperties") and d.RelatingPropertyDefinition.is_a("IfcPropertySet") \
                    and d.RelatingPropertyDefinition.Name == naam:
                return d.RelatingPropertyDefinition, d
        return None, None

    def zet_pset(self, stap, ent, naam, waarden: dict, onderdeel=None):
        """Properties in pset `naam` van dit object zetten. Een pset of property die de exporter met andere objecten
        deelt (bv. één LoadBearing = True voor alle wanden), wordt eerst losgemaakt, zodat alleen dit object wijzigt."""
        huidig = ue.get_psets(ent).get(naam, {})
        nodig = {k: v for k, v in waarden.items() if not gelijk(huidig.get(k), v)}
        for k, v in waarden.items():
            self.meld(stap, f"{onderdeel or ent.is_a() + ' ' + repr(getattr(ent, 'Name', ''))} {naam}.{k}", k in nodig,
                      f"{huidig.get(k)!r} -> {v!r}" if k in nodig else repr(v))
        if not nodig:
            return
        ps, rel = self.eigen_pset(ent, naam)
        if ps is None:
            ps = ifcopenshell.api.pset.add_pset(self.f, product=ent, name=naam)
            rel = (ps.DefinesOccurrence or [None])[0]
        elif rel is not None and len(rel.RelatedObjects) > 1:
            ps = ifcopenshell.api.pset.unshare_pset(self.f, products=[ent], pset=ps)[0]
            rel = (ps.DefinesOccurrence or [None])[0]
        ps.GlobalId = vaste_guid(f"pset/{ent.GlobalId}/{naam}")
        self.eigen_guids.add(ps.GlobalId)
        if rel is not None and rel.id() > self.max_id_bij_start:
            rel.GlobalId = vaste_guid(f"pset-rel/{ent.GlobalId}/{naam}")
            self.eigen_guids.add(rel.GlobalId)
        if self.oh is not None:
            ps.OwnerHistory = ps.OwnerHistory or self.oh
        props = list(ps.HasProperties or [])
        for i, p in enumerate(props):
            if p.Name in nodig and len([x for x in self.f.get_inverse(p) if x.is_a("IfcPropertySet")]) > 1:
                props[i] = self.f.create_entity(p.is_a(), **{k: v for k, v in p.get_info(recursive=False).items()
                                                            if k not in ("id", "type")})
        ps.HasProperties = props
        ifcopenshell.api.pset.edit_pset(self.f, pset=ps, properties=nodig)

    def hoogte_m(self, st):
        return float(st.Elevation or 0.0) * self.lengte

    def laag_van(self, ent):
        for r in getattr(ent, "Decomposes", None) or []:
            if r.RelatingObject.is_a("IfcBuildingStorey"):
                return r.RelatingObject
        for r in getattr(ent, "ContainedInStructure", None) or []:
            if r.RelatingStructure.is_a("IfcBuildingStorey"):
                return r.RelatingStructure
        return None

    def ruimten(self):
        return [s for s in self.f.by_type("IfcSpace") if (s.PredefinedType or "") != "EXTERNAL"]

    # ------------------------------------------------------------------ stappen
    def stap_schema(self, cfg):
        """Fouten tegen het IFC4-schema die de Revit-exporter maakt."""
        f, n = self.f, 0
        for c in f.by_type("IfcCurveBoundedPlane"):
            if c.InnerBoundaries is None:
                c.InnerBoundaries = ()
                n += 1
        self.meld("schema", "IfcCurveBoundedPlane.InnerBoundaries $ -> ()", bool(n), f"{n} ruimtegrensvlakken")
        weg = [b for b in f.by_type("IfcRelSpaceBoundary") if b.RelatedBuildingElement is None]
        for b in weg:
            f.remove(b)
        self.meld("schema", "ruimtegrenzen zonder bouwelement", bool(weg), f"{len(weg)} verwijderd")
        self._lege_geometrie()

    def _lege_geometrie(self):
        f, n_vorm, n_prod = self.f, 0, 0

        def los(item):
            for x in list(f.get_inverse(item)):
                if x.is_a("IfcShapeRepresentation") and item in (x.Items or ()):
                    x.Items = [i for i in x.Items if i != item]
                elif x.is_a("IfcStyledItem"):
                    f.remove(x)
                elif x.is_a("IfcPresentationLayerAssignment"):
                    x.AssignedItems = [i for i in x.AssignedItems if i != item]
                elif x.is_a("IfcProductRepresentation"):
                    x.Representations = [r for r in x.Representations if r != item]
        for sh in [s for s in f.by_type("IfcClosedShell") if not s.CfsFaces]:
            for brep in list(f.get_inverse(sh)):
                los(brep)
                if brep.is_a("IfcFacetedBrep") and not f.get_inverse(brep):
                    f.remove(brep)
            if not f.get_inverse(sh):
                f.remove(sh)
                n_vorm += 1
        for rep in [r for r in f.by_type("IfcShapeRepresentation") if not r.Items]:
            los(rep)
            if not f.get_inverse(rep):
                f.remove(rep)
        for pds in [p for p in f.by_type("IfcProductDefinitionShape") if not p.Representations]:
            for prod in list(f.get_inverse(pds)):
                if prod.is_a("IfcProduct"):
                    prod.Representation = None
                    n_prod += 1
                    self.waarschuw("schema", f"{prod.is_a()} {prod.Name!r} heeft in de export geen geometrie")
            f.remove(pds)
        self.meld("schema", "lege geometrie", bool(n_vorm or n_prod),
                  f"{n_vorm} lege IfcClosedShells weg, {n_prod} producten zonder vorm")

    def stap_dubbele_globalids(self, cfg):
        """De exporter kan één GlobalId aan meer objecten geven, bv. een sparing in een element dat in stukken
        geknipt wordt. Het eerste exemplaar houdt zijn id, de rest krijgt een vaste id uit id + context."""
        per = collections.defaultdict(list)
        for e in self.f.by_type("IfcRoot"):
            per[e.GlobalId].append(e)
        n = 0
        herstel = cfg.get("herstellen", True) if isinstance(cfg, dict) else True

        def context(e):
            v = getattr(e, "VoidsElements", None)
            return v[0].RelatingBuildingElement.GlobalId if v else f"{e.is_a()}#{e.id()}"
        for gid, lijst in per.items():
            if len(lijst) < 2:
                continue
            self.waarschuw("dubbele_globalids", f"{gid}: {len(lijst)}x ({', '.join(sorted({e.is_a() for e in lijst}))})")
            if not herstel:
                continue
            for e in sorted(lijst, key=context)[1:]:
                e.GlobalId = vaste_guid(f"dubbel/{gid}/{context(e)}")
                self.eigen_guids.add(e.GlobalId)
                n += 1
        self.meld("dubbele_globalids", "dubbele GlobalIds", bool(n), f"{n} objecten kregen een eigen vaste GlobalId")

    def stap_georeferentie(self, cfg):
        f = self.f
        for k in ("epsg", "oost", "noord"):
            if cfg.get(k) is None:
                raise ProjectFout(f"nabewerking.georeferentie.{k} ontbreekt")
        epsg = str(cfg["epsg"])
        oost, noord = float(cfg["oost"]), float(cfg["noord"])
        hoogte = float(cfg.get("hoogte", 0.0))
        hoek = math.radians(float(cfg.get("rotatie_graden", 0.0)))
        absc, ordi = round(math.cos(hoek), 9), round(math.sin(hoek), 9)
        vdatum = cfg.get("verticaal_datum")
        ctx = [c for c in f.by_type("IfcGeometricRepresentationContext")
               if not c.is_a("IfcGeometricRepresentationSubContext") and (c.ContextType or "Model") == "Model"]
        if not ctx:
            raise ProjectFout("geen modelcontext (IfcGeometricRepresentationContext 'Model') in de IFC")
        mc, crs = f.by_type("IfcMapConversion"), f.by_type("IfcProjectedCRS")
        klopt = mc and crs and crs[0].Name == epsg and crs[0].VerticalDatum == vdatum \
            and abs(mc[0].Eastings - oost) < 0.001 and abs(mc[0].Northings - noord) < 0.001 \
            and abs(mc[0].OrthogonalHeight - hoogte) < 0.001 and abs((mc[0].XAxisAbscissa or 1.0) - absc) < 1e-7 \
            and abs((mc[0].XAxisOrdinate or 0.0) - ordi) < 1e-7 and abs((mc[0].Scale or 1.0) - self.lengte) < 1e-12
        if klopt:
            self.meld("georeferentie", "IfcMapConversion + IfcProjectedCRS", False, f"{epsg} E {oost} N {noord}")
        else:
            for x in list(mc) + list(crs):
                f.remove(x)
            eenheid = f.createIfcSIUnit(None, "LENGTHUNIT", None, "METRE")
            c = f.createIfcProjectedCRS(epsg, cfg.get("naam_crs"), cfg.get("geodetisch_datum"), vdatum,
                                        cfg.get("projectie"), cfg.get("zone"), eenheid)
            f.createIfcMapConversion(ctx[0], c, oost, noord, hoogte, absc, ordi, self.lengte)
            self.meld("georeferentie", "IfcMapConversion + IfcProjectedCRS", True,
                      f"{epsg}, E {oost} N {noord} h {hoogte}, rotatie {cfg.get('rotatie_graden', 0)} graden, "
                      f"schaal {self.lengte}")
        site = (f.by_type("IfcSite") or [None])[0]
        if site is not None:
            for sleutel, attr in (("ref_breedte", "RefLatitude"), ("ref_lengte", "RefLongitude")):
                if cfg.get(sleutel) is not None:
                    self.zet("georeferentie", site, attr, tuple(int(x) for x in cfg[sleutel]))
            if cfg.get("ref_hoogte") is not None:
                self.zet("georeferentie", site, "RefElevation", float(cfg["ref_hoogte"]))

    # -- bouwlagen
    @staticmethod
    def _nummer(tekst, formaat):
        if formaat != "ils":
            return tekst
        try:
            n = int(tekst)
        except ValueError:
            return tekst
        return f"-{abs(n)}" if n < 0 else f"{n:02d}"

    def stap_bouwlagen(self, cfg):
        f = self.f
        stijl = cfg.get("stijl", "nummer-en-naam")
        if stijl not in ("nummer-en-naam", "ils-9.06"):
            raise ProjectFout("nabewerking.bouwlagen.stijl is 'nummer-en-naam' of 'ils-9.06'")
        tol = float(cfg.get("tolerantie_mm", 150)) / 1000.0
        samenvoegen = cfg.get("peilen_samenvoegen", True)
        lagen = sorted(f.by_type("IfcBuildingStorey"), key=self.hoogte_m)
        doel = {}  # storey -> dict(nummer, naam, entree?, boven_maaiveld?)
        tabel = cfg.get("tabel")
        if isinstance(tabel, str):
            tabel = lees_tabel(Path(self.map, tabel))
        if tabel:
            rijen = []
            for r in tabel:
                rijen.append({"nummer": str(r["nummer"]).strip(), "naam": str(r.get("naam") or "").strip(),
                              "hoogte": float(str(r["hoogte_mm"]).replace(",", ".")) / 1000.0,
                              "entree": r.get("entree"), "boven_maaiveld": r.get("boven_maaiveld")})
            for st in lagen:
                kand = sorted((abs(self.hoogte_m(st) - r["hoogte"]), i) for i, r in enumerate(rijen)
                              if abs(self.hoogte_m(st) - r["hoogte"]) <= tol)
                if kand and not any(d is rijen[kand[0][1]] for d in doel.values()):
                    doel[st] = rijen[kand[0][1]]
            for r in rijen:
                if not any(d is r for d in doel.values()):
                    self.waarschuw("bouwlagen", f"bouwlaag {r['nummer']} {r['naam']} (hoogte {r['hoogte'] * 1000:.0f} mm) "
                                                "staat niet in de IFC")
        else:
            patroon = re.compile(cfg.get("patroon") or r"^\s*(?P<nummer>[-+]?\d+)(?:[ _.]+(?P<naam>.*?))?\s*$")
            for st in lagen:
                m = patroon.match(st.Name or "")
                if not m:
                    continue
                naam = m.groupdict().get("naam") or ""
                if not naam and st.LongName and st.LongName != st.Name:
                    naam = st.LongName
                if cfg.get("naam_kleine_letters", True):
                    naam = naam.lower()
                doel[st] = {"nummer": self._nummer(m.group("nummer"), cfg.get("nummer_formaat", "ils")), "naam": naam}
        # peilen: een IfcBuildingStorey die geen bouwlaag is
        for st in [s for s in lagen if s not in doel]:
            onder = [s for s in doel if self.hoogte_m(s) <= self.hoogte_m(st) + 1e-6]
            if not samenvoegen or not onder:
                self.waarschuw("bouwlagen", f"{st.Name!r} ({self.hoogte_m(st):.3f} m) is geen bouwlaag uit de tabel of "
                                            "het patroon" + ("" if samenvoegen else "; blijft staan"))
                continue
            naar = max(onder, key=self.hoogte_m)
            inhoud = [e for r in st.ContainsElements or [] for e in r.RelatedElements]
            delen = [e for r in st.IsDecomposedBy or [] for e in r.RelatedObjects]
            if inhoud:
                rel = ifcopenshell.api.spatial.assign_container(f, products=inhoud, relating_structure=naar)
                if rel is not None:  # de API voegt samen via een set: vaste volgorde voor een vast bestand
                    rel.RelatedElements = sorted(rel.RelatedElements, key=lambda e: e.GlobalId)
            if delen:
                rel = ifcopenshell.api.aggregate.assign_object(f, products=delen, relating_object=naar)
                if rel is not None:
                    rel.RelatedObjects = sorted(rel.RelatedObjects, key=lambda e: e.GlobalId)
            naam = st.Name
            ifcopenshell.api.root.remove_product(f, product=st)
            self.meld("bouwlagen", f"peil {naam!r}", True,
                      f"geen bouwlaag; {len(inhoud)} elementen en {len(delen)} delen naar {naar.Name!r}")
        for st, d in doel.items():
            name = d["nummer"] if stijl == "nummer-en-naam" else f"{d['nummer']} {d['naam']}".strip()
            self.zet("bouwlagen", st, "Name", name, f"bouwlaag {d['nummer']} Name")
            self.zet("bouwlagen", st, "LongName", d["naam"] or None, f"bouwlaag {d['nummer']} LongName")
            if cfg.get("objecttype"):
                self.zet("bouwlagen", st, "ObjectType", cfg["objecttype"], f"bouwlaag {d['nummer']} ObjectType")
            w = {}
            for sleutel, prop in (("entree", "EntranceLevel"), ("boven_maaiveld", "AboveGround")):
                v = d.get(sleutel)
                if v is not None and v != "":
                    w[prop] = v if isinstance(v, bool) else naar_waarde(str(v), "bool")
            if w:
                self.zet_pset("bouwlagen", st, "Pset_BuildingStoreyCommon", w, f"bouwlaag {d['nummer']}")

    # -- ruimten
    def stap_ruimten(self, cfg):
        nr_pat = re.compile(cfg.get("nummer_patroon") or r"^\S*\d\S*$")
        splits = re.compile(cfg.get("splits_patroon") or r"^\s*(?P<nummer>\S*\d\S*)\s+(?P<naam>\S.*?)\s*$")
        n_split = n_wissel = 0
        for sp in self.ruimten():
            name, lang = (sp.Name or "").strip(), (sp.LongName or "").strip()
            if (not lang or lang == name) and splits.match(name):
                m = splits.match(name)
                self.zet("ruimten", sp, "Name", m.group("nummer"), f"ruimte {name!r} Name")
                self.zet("ruimten", sp, "LongName", m.group("naam"), f"ruimte {name!r} LongName")
                n_split += 1
            elif cfg.get("omwisselen", True) and lang and not nr_pat.match(name or "x y") and nr_pat.match(lang):
                self.zet("ruimten", sp, "Name", lang, f"ruimte {lang!r} Name")
                self.zet("ruimten", sp, "LongName", name or None, f"ruimte {lang!r} LongName")
                n_wissel += 1
            if not (sp.Name or "").strip() or not (sp.LongName or "").strip():
                self.waarschuw("ruimten", f"ruimte {sp.GlobalId} zonder nummer of naam (Name {sp.Name!r}, LongName {sp.LongName!r})")
            if cfg.get("description"):
                self.zet("ruimten", sp, "Description", cfg["description"], f"ruimte {sp.Name} Description")
        self.meld("ruimten", "nummer en naam", bool(n_split or n_wissel),
                  f"{n_split} gesplitst, {n_wissel} omgewisseld")
        hc = cfg.get("hoogtecontrole", True)
        if hc:
            for t in ruimte_hoogtes(self.f, hc if isinstance(hc, dict) else {}):
                self.waarschuw("ruimten", t)

    # -- indeling
    def _lees_indeling(self, cfg):
        bron = cfg.get("tabel")
        if not bron:
            raise ProjectFout("nabewerking.indeling.tabel ontbreekt: een CSV of JSON met ruimtenummer, soort en zones")
        pad = Path(self.map, bron)
        ruimtesoort, zones = {}, collections.OrderedDict()
        if pad.suffix.lower() == ".json":
            data = lees_tabel(pad)
            for nr, r in (data.get("ruimten") or {}).items():
                if r.get("soort"):
                    ruimtesoort[str(nr)] = r["soort"]
                for z in r.get("zones") or []:
                    zones.setdefault(z, {"leden": []})["leden"].append(str(nr))
            for naam, z in (data.get("zones") or {}).items():
                zones.setdefault(naam, {"leden": []}).update(
                    {"soort": z.get("soort"), "omschrijving": z.get("omschrijving"), "langenaam": z.get("langenaam")})
        else:
            for r in lees_tabel(pad):
                nr = r.get("ruimtenummer", "")
                if not nr:
                    continue
                if r.get("ruimtesoort"):
                    if ruimtesoort.get(nr, r["ruimtesoort"]) != r["ruimtesoort"]:
                        self.waarschuw("indeling", f"ruimte {nr}: twee ruimtesoorten in de tabel")
                    ruimtesoort[nr] = r["ruimtesoort"]
                if r.get("zone"):
                    z = zones.setdefault(r["zone"], {"leden": []})
                    for sleutel, kolom in (("soort", "zonesoort"), ("omschrijving", "zone_omschrijving"),
                                           ("langenaam", "zone_langenaam")):
                        if r.get(kolom):
                            if z.get(sleutel) not in (None, r[kolom]):
                                self.waarschuw("indeling", f"zone {r['zone']}: {kolom} wisselt in de tabel")
                            z[sleutel] = r[kolom]
                    z["leden"].append(nr)
        return ruimtesoort, zones

    def stap_indeling(self, cfg):
        f = self.f
        ruimtesoort, zones = self._lees_indeling(cfg)
        per_nr = collections.defaultdict(list)
        for sp in self.ruimten():
            per_nr[(sp.Name or "").strip()].append(sp)
        for nr, lijst in per_nr.items():
            if len(lijst) > 1:
                self.waarschuw("indeling", f"ruimtenummer {nr!r} komt {len(lijst)}x voor in de IFC")
        ontbreekt = sorted({nr for nr in list(ruimtesoort) + [m for z in zones.values() for m in z["leden"]]
                            if nr not in per_nr})
        if ontbreekt:
            self.waarschuw("indeling", f"{len(ontbreekt)} ruimtenummers uit de tabel staan niet in de IFC: {ontbreekt[:15]}")
        zonder = sorted(nr for nr in per_nr if nr not in ruimtesoort)
        if zonder and ruimtesoort:
            self.waarschuw("indeling", f"{len(zonder)} ruimten zonder ruimtesoort in de tabel: {zonder[:15]}")
        for nr, soort in ruimtesoort.items():
            for sp in per_nr.get(nr, []):
                self.zet("indeling", sp, "ObjectType", soort, f"ruimte {nr} ObjectType")
        soorten = {z.get("soort") for z in zones.values() if z.get("soort")}
        bestaand = {}
        for z in f.by_type("IfcZone"):
            if z.Name in zones:
                bestaand[z.Name] = z
            elif cfg.get("zones_opruimen", True) and z.ObjectType in soorten:
                naam = z.Name
                ifcopenshell.api.group.remove_group(f, group=z)
                self.meld("indeling", f"zone {naam!r}", True, "staat niet in de tabel; verwijderd")
        for naam, d in zones.items():
            z = bestaand.get(naam)
            if z is None:
                z, _ = self.nieuw("IfcZone", f"zone/{naam}", Name=naam)
                self.meld("indeling", f"zone {naam!r}", True, f"aangemaakt ({d.get('soort')})")
            else:
                self.meld("indeling", f"zone {naam!r}", False, "uit export")
            for attr, sleutel in (("ObjectType", "soort"), ("Description", "omschrijving"), ("LongName", "langenaam")):
                if d.get(sleutel):
                    self.zet("indeling", z, attr, d[sleutel], f"zone {naam!r} {attr}")
            leden = sorted({sp for nr in d["leden"] for sp in per_nr.get(nr, [])}, key=lambda s: (s.Name or "", s.GlobalId))
            huidig = {m.GlobalId for r in z.IsGroupedBy or [] for m in r.RelatedObjects}
            nodig = {sp.GlobalId for sp in leden}
            if huidig != nodig:
                for r in list(z.IsGroupedBy or []):
                    f.remove(r)
                gid = vaste_guid(f"zone-leden/{naam}")
                self.eigen_guids.add(gid)
                f.createIfcRelAssignsToGroup(gid, self.oh, None, None, leden, None, z)
            self.meld("indeling", f"zone {naam!r} leden", huidig != nodig, f"{len(huidig)} -> {len(nodig)} ruimten")
            if d.get("soort") in cfg.get("bezetting_optellen", ["Verblijfsgebied"]) and leden:
                self._bezetting(z, leden, cfg.get("bezetting_type"))

    def _bezetting(self, z, leden, bezettingtype=None):
        """Pset_SpaceOccupancyRequirements op de zone als som van de ruimten (ILS 9.10b/c)."""
        n = piek = 0
        opp = 0.0
        soorten = set()
        for sp in leden:
            ps = ue.get_psets(sp)
            occ = ps.get("Pset_SpaceOccupancyRequirements", {})
            n += int(round(float(occ.get("OccupancyNumber") or 0)))
            piek += int(round(float(occ.get("OccupancyNumberPeak") or 0)))
            if occ.get("OccupancyType"):
                soorten.add(occ["OccupancyType"])
            opp += float(ps.get("Qto_SpaceBaseQuantities", {}).get("NetFloorArea") or 0)
        typ = bezettingtype or (soorten.pop() if len(soorten) == 1 else None)
        if not n:
            self.waarschuw("indeling", f"zone {z.Name!r}: geen OccupancyNumber op de ruimten; bezetting niet opgeteld")
            if typ:
                self.zet_pset("indeling", z, "Pset_SpaceOccupancyRequirements", {"OccupancyType": typ}, f"zone {z.Name!r}")
            return
        w = {"OccupancyNumber": n, "OccupancyNumberPeak": piek, "AreaPerOccupant": round(opp / n, 2)}
        if typ:
            w["OccupancyType"] = typ
        self.zet_pset("indeling", z, "Pset_SpaceOccupancyRequirements", w, f"zone {z.Name!r}")

    # -- eigenschappen
    def _lees_eigenschappen(self, cfg):
        regels = list(cfg.get("regels") or [])
        if cfg.get("tabel"):
            pad = Path(self.map, cfg["tabel"])
            data = lees_tabel(pad)
            if pad.suffix.lower() == ".json":
                regels += data if isinstance(data, list) else data.get("regels", [])
            else:
                groep = collections.OrderedDict()
                for r in data:
                    sleutel = (r.get("doel"), r.get("objecttype") or None, r.get("naam") or None)
                    g = groep.setdefault(sleutel, {"doel": sleutel[0], "objecttype": sleutel[1], "naam": sleutel[2],
                                                   "attributen": {}, "psets": {}})
                    w = r.get("waarde", "")
                    if (r.get("pset") or "").strip():
                        g["psets"].setdefault(r["pset"], {})[r["property"]] = naar_waarde(w, r.get("type"))
                    else:
                        g["attributen"][r["property"]] = naar_waarde(w, r.get("type") or "tekst")
                regels += list(groep.values())
        return regels

    def stap_eigenschappen(self, cfg):
        for regel in self._lees_eigenschappen(cfg):
            doel = regel.get("doel")
            if not doel:
                raise ProjectFout(f"eigenschappen: regel zonder 'doel' (IFC-klasse): {regel}")
            try:
                objecten = self.f.by_type(doel)
            except RuntimeError as e:
                raise ProjectFout(f"eigenschappen: onbekende IFC-klasse {doel!r}") from e
            if regel.get("objecttype"):
                objecten = [o for o in objecten if getattr(o, "ObjectType", None) == regel["objecttype"]]
            if regel.get("naam"):
                objecten = [o for o in objecten if getattr(o, "Name", None) == regel["naam"]]
            if not objecten:
                self.waarschuw("eigenschappen", f"geen {doel}" + (f" met ObjectType {regel['objecttype']!r}" if regel.get("objecttype") else "")
                               + (f" met Name {regel['naam']!r}" if regel.get("naam") else "") + " in de IFC")
                continue
            for o in objecten:
                for attr, waarde in (regel.get("attributen") or {}).items():
                    self.zet("eigenschappen", o, attr, waarde)
                if regel.get("adres"):
                    self._adres(o, regel["adres"])
                for pset, waarden in (regel.get("psets") or {}).items():
                    self.zet_pset("eigenschappen", o, pset, waarden)

    def _adres(self, o, a):
        attr = "SiteAddress" if o.is_a("IfcSite") else "BuildingAddress" if o.is_a("IfcBuilding") else None
        if attr is None:
            self.waarschuw("eigenschappen", f"een adres kan alleen op IfcSite of IfcBuilding, niet op {o.is_a()}")
            return
        regels = list(a.get("regels") or ([a["straat"]] if a.get("straat") else []))
        oud = getattr(o, attr)
        klopt = oud is not None and list(oud.AddressLines or []) == regels and oud.PostalCode == a.get("postcode") \
            and oud.Town == a.get("plaats") and oud.Country == a.get("land")
        if not klopt:
            setattr(o, attr, self.f.createIfcPostalAddress(None, None, None, None, regels or None, None,
                                                           a.get("plaats"), a.get("provincie"), a.get("postcode"), a.get("land")))
        self.meld("eigenschappen", f"{o.is_a()} {o.Name!r}.{attr}", not klopt,
                  ", ".join(regels + [a.get("postcode") or "", a.get("plaats") or "", a.get("land") or ""]))

    # -- classificatie
    def stap_classificatie(self, cfg):
        f = self.f
        uri = (cfg.get("woordenboek") or OMGEVINGSWET_RUIMTEN).rstrip("/")
        naam = cfg.get("naam") or uri.split("/")[-2]
        editie = cfg.get("editie") or uri.split("/")[-1]
        klassen = None
        if cfg.get("controleer_klassen", True):
            try:
                import bronnen
                klassen = bronnen.klassen(uri)
            except Exception as e:  # noqa: BLE001  geen verbinding: classificeren zonder controle
                self.waarschuw("classificatie", f"klassenlijst niet op te halen ({type(e).__name__}); codes niet gecontroleerd")
        codes = {"Kadastraal perceel": "Kadastraal-Perceel", "Tarra Ruimte": "Tarra-Ruimte",
                 "Eigendom- en gebruikseenheid": "Gebruikseenheid"} if uri == OMGEVINGSWET_RUIMTEN else {}
        codes.update(cfg.get("codes") or {})
        vast = cfg.get("vast", {"IfcProject": "Project", "IfcSite": "Perceel", "IfcBuilding": "Gebouw",
                                "IfcBuildingStorey": "Bouwlaag"})
        op_ot = cfg.get("op_objecttype", ["IfcSpace", "IfcZone", "IfcSpatialZone", "IfcExternalSpatialElement"])
        oud = [c for c in f.by_type("IfcClassification") if c.Name == naam]
        if oud:
            cl = oud[0]
        else:
            cl = f.createIfcClassification(cfg.get("bron"), editie, cfg.get("datum"), naam, cfg.get("omschrijving"), uri, None)
        self.meld("classificatie", f"IfcClassification {naam} {editie}", not oud, uri)
        doelen = collections.defaultdict(list)
        for klasse, ot in vast.items():
            for e in f.by_type(klasse):
                doelen[ot].append(e)
        for klasse in op_ot:
            for e in f.by_type(klasse):
                if getattr(e, "ObjectType", None):
                    doelen[e.ObjectType].append(e)
        refs = {r.Identification: r for r in f.by_type("IfcClassificationReference") if r.ReferencedSource == cl}
        for ot, ents in sorted(doelen.items()):
            code = codes.get(ot, ot.replace(" ", "-"))
            if klassen is not None:
                treffer = next((k for k in klassen if k.lower() == code.lower()), None)
                if treffer is None:
                    self.waarschuw("classificatie", f"ObjectType {ot!r}: geen klasse {code!r} in {naam} {editie}; "
                                                    f"{len(ents)} objecten zonder klasse")
                    continue
                code = treffer
            kuri = (klassen or {}).get(code, {}).get("uri") or f"{uri}/class/{code}"
            ref = refs.get(code) or f.createIfcClassificationReference(kuri, code, code, cl, None, None)
            rels = list(ref.ClassificationRefForObjects or [])
            huidig = {o.GlobalId for r in rels for o in r.RelatedObjects}
            nodig = {e.GlobalId for e in ents}
            if huidig != nodig:
                for r in rels:
                    f.remove(r)
                gid = vaste_guid(f"klasse/{uri}/{code}")
                self.eigen_guids.add(gid)
                f.createIfcRelAssociatesClassification(gid, self.oh, None, None, sorted(ents, key=lambda e: e.GlobalId), ref)
            self.meld("classificatie", f"klasse {code}", huidig != nodig, f"{len(nodig)} objecten")
        for r in f.by_type("IfcClassificationReference"):
            if r.ReferencedSource == cl and not r.ClassificationRefForObjects:
                f.remove(r)

    # -- psetnamen
    def stap_psetnamen(self, cfg):
        verboden = re.compile(cfg.get("verboden") or r"nlrs|revit", re.I)
        hernoem = cfg.get("hernoemen") or {}
        n = 0
        for ps in self.f.by_type("IfcPropertySet"):
            if ps.Name in hernoem:
                oud = ps.Name
                ps.Name = hernoem[oud]
                n += 1
                self.meld("psetnamen", f"pset {oud!r}", True, f"hernoemd naar {ps.Name!r}")
        namen = collections.Counter(ps.Name for ps in self.f.by_type("IfcPropertySet"))
        props = collections.Counter(p.Name for p in self.f.by_type("IfcProperty"))
        for naam, aantal in sorted(namen.items()):
            if verboden.search(naam or ""):
                self.waarschuw("psetnamen", f"pset {naam!r} ({aantal}x)")
        for naam, aantal in sorted(props.items()):
            if verboden.search(naam or ""):
                self.waarschuw("psetnamen", f"property {naam!r} ({aantal}x)")
        self.meld("psetnamen", "pset-namen", bool(n), f"{n} psets hernoemd")

    # ------------------------------------------------------------------ alles
    def draai(self, stappen: dict):
        for stap, cfg in stappen.items():
            getattr(self, f"stap_{stap}")(cfg if isinstance(cfg, dict) else {})
        # De API maakt bij elke wijziging een nieuwe IfcOwnerHistory met de klok van nu. Die wijzen we terug naar
        # die van de export, zodat dezelfde invoer met dezelfde stappen hetzelfde bestand geeft.
        if self.oh is not None:
            for h in [h for h in self.f.by_type("IfcOwnerHistory") if h.id() > self.max_id_bij_start]:
                for x in list(self.f.get_inverse(h)):
                    if hasattr(x, "OwnerHistory") and x.OwnerHistory == h:
                        x.OwnerHistory = self.oh
                if not self.f.get_inverse(h):
                    self.f.remove(h)
        # vaste ids voor objecten die de API zelf aanmaakte (relaties bij samenvoegen, losgemaakte psets)
        for e in self.f.by_type("IfcRoot"):
            if e.id() > self.max_id_bij_start and e.GlobalId not in self.eigen_guids:
                e.GlobalId = vaste_guid(f"nieuw/{e.is_a()}/{e.id()}")
        return self

    def rapport(self):
        per = {}
        for m in self.meldingen:
            p = per.setdefault(m["stap"], {"gewijzigd": 0, "uit_export": 0, "waarschuwingen": []})
            p["gewijzigd" if m["bron"] == "nabewerking" else "uit_export"] += 1
        for stap, lijst in self.waarschuwingen.items():
            per.setdefault(stap, {"gewijzigd": 0, "uit_export": 0, "waarschuwingen": []})["waarschuwingen"] = lijst
        return per


# ---------------------------------------------------------------------- gedeeld met ifc_controle.py
def ruimte_hoogtes(f, cfg: dict | None = None) -> list[str]:
    """Hoogte van de ruimten: standaardhoogte van Revit, hoogte tegen volume/oppervlak, hoogte tegen de bouwlaag."""
    cfg = cfg or {}
    lengte = ifcopenshell.util.unit.calculate_unit_scale(f)
    std = float(cfg.get("standaardhoogte_mm", STANDAARD_HOOGTE_MM)) / 1000.0
    marge = float(cfg.get("afwijking_procent", 5)) / 100.0
    doorlopend = [s.lower() for s in cfg.get("doorlopend", ["vide", "liftschacht", "schacht", "trappenhuis", "trap"])]
    lagen = sorted(f.by_type("IfcBuildingStorey"), key=lambda s: float(s.Elevation or 0))
    uit = []
    for sp in f.by_type("IfcSpace"):
        if (sp.PredefinedType or "") == "EXTERNAL":
            continue
        q = ue.get_psets(sp).get("Qto_SpaceBaseQuantities", {})
        h = q.get("Height") or q.get("FinishCeilingHeight")
        if h is None:
            continue
        h = float(h) * lengte
        naam = f"{sp.Name} {sp.LongName or ''}".strip()
        if abs(h - std) < 0.002:
            uit.append(f"ruimte {naam}: hoogte {h * 1000:.0f} mm = standaardhoogte van Revit; Upper Limit en Limit Offset nagaan")
        v, a = q.get("NetVolume"), q.get("NetFloorArea")
        if v and a and float(a) > 0:
            hv = float(v) / float(a)
            if abs(hv - h) > marge * h:
                uit.append(f"ruimte {naam}: hoogte {h * 1000:.0f} mm, volume/oppervlak {hv * 1000:.0f} mm")
        st = next((r.RelatingObject for r in sp.Decomposes or [] if r.RelatingObject.is_a("IfcBuildingStorey")), None)
        if st is None or any(d in (sp.LongName or "").lower() for d in doorlopend):
            continue
        boven = [float(x.Elevation or 0) * lengte for x in lagen if float(x.Elevation or 0) > float(st.Elevation or 0) + 1e-6]
        if boven and h > boven[0] - float(st.Elevation or 0) * lengte + 0.05:
            uit.append(f"ruimte {naam}: {h * 1000:.0f} mm hoog, hoger dan bouwlaag {st.Name} "
                       f"({(boven[0] - float(st.Elevation or 0) * lengte) * 1000:.0f} mm)")
    return uit


def maak_indeling(ifc_pad: Path, uit: Path) -> int:
    """Schrijf de ruimten en zones van een IFC als indelingstabel (CSV, puntkomma)."""
    f = ifcopenshell.open(str(ifc_pad))
    rijen = []
    for sp in sorted(f.by_type("IfcSpace"), key=lambda s: s.Name or ""):
        if (sp.PredefinedType or "") == "EXTERNAL":
            continue
        zones = [r.RelatingGroup for r in sp.HasAssignments or [] if r.is_a("IfcRelAssignsToGroup") and r.RelatingGroup.is_a("IfcZone")]
        rijen.append([sp.Name or "", sp.LongName or "", sp.ObjectType or "", "", "", "", ""])
        for z in sorted(zones, key=lambda z: z.Name or ""):
            rijen.append([sp.Name or "", "", "", z.Name or "", z.ObjectType or "", z.Description or "", z.LongName or ""])
    with open(uit, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh, delimiter=";")
        w.writerow(["ruimtenummer", "ruimtenaam", "ruimtesoort", "zone", "zonesoort", "zone_omschrijving", "zone_langenaam"])
        w.writerows(rijen)
    return len(rijen)


def nabewerk(project: Project, ifc_in: Path, ifc_uit: Path, proef=False, alleen: list[str] | None = None) -> dict:
    stappen = project.nabewerking()
    if alleen:
        onbekend = [s for s in alleen if s not in NABEWERKSTAPPEN]
        if onbekend:
            raise ProjectFout(f"onbekende stap(pen) {onbekend}")
        stappen = {k: v for k, v in stappen.items() if k in alleen}
    f = ifcopenshell.open(str(ifc_in))
    stempel = f.header.file_name.time_stamp
    nb = Nabewerking(f, project.map).draai(stappen)
    geschreven = False
    if not proef and (nb.wijzigingen or Path(ifc_uit).resolve() != Path(ifc_in).resolve()):
        f.header.file_name.time_stamp = stempel  # zelfde invoer + zelfde stappen = hetzelfde bestand
        Path(ifc_uit).parent.mkdir(parents=True, exist_ok=True)
        f.write(str(ifc_uit))
        geschreven = True
    return {"invoer": str(ifc_in), "uitvoer": str(ifc_uit), "proef": proef, "geschreven": geschreven,
            "stappen": list(stappen), "wijzigingen": nb.wijzigingen, "per_stap": nb.rapport(), "meldingen": nb.meldingen}


def _main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if argv[0] == "--maak-indeling":
        n = maak_indeling(Path(argv[1]), Path(argv[2]))
        print(f"{n} regels geschreven naar {argv[2]}")
        return 0
    opt = {}
    for k in ("--ifc", "--uit", "--stap", "--rapport"):
        if k in argv:
            i = argv.index(k)
            opt[k[2:]] = argv[i + 1]
            del argv[i:i + 2]
    proef = "--proef" in argv
    argv = [a for a in argv if a != "--proef"]
    try:
        project = Project(argv[0])
        ifc_in = Path(opt["ifc"]).resolve() if "ifc" in opt else project.ifc_pad
        ifc_uit = Path(opt["uit"]).resolve() if "uit" in opt else ifc_in
        if not ifc_in.is_file():
            raise ProjectFout(f"IFC niet gevonden: {ifc_in}")
        r = nabewerk(project, ifc_in, ifc_uit, proef, opt["stap"].split(",") if "stap" in opt else None)
    except ProjectFout as e:
        print(f"FOUT: {e}", file=sys.stderr)
        return 2
    if "rapport" in opt:
        Path(opt["rapport"]).write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    print(f"{'PROEF: ' if proef else ''}{r['wijzigingen']} wijzigingen; "
          f"{'geschreven naar ' + r['uitvoer'] if r['geschreven'] else 'niets geschreven'}")
    for stap, p in r["per_stap"].items():
        print(f"  {stap:18} {p['gewijzigd']:4} gezet  {p['uit_export']:4} al goed  {len(p['waarschuwingen']):3} waarschuwingen")
        for w in p["waarschuwingen"][:8]:
            print(f"      - {w}")
        if len(p["waarschuwingen"]) > 8:
            print(f"      ... en {len(p['waarschuwingen']) - 8} meer (zie --rapport)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
