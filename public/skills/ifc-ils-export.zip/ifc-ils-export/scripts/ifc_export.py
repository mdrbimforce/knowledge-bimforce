"""IFC exporteren uit Revit met een export-setup, daarna nabewerken, controleren en een verslag schrijven.

    python ifc_export.py <ifc-export.json>                  proef: voorcontrole en het plan, er wordt niets geëxporteerd
    python ifc_export.py <ifc-export.json> --uitvoeren      echt exporteren, nabewerken, controleren, verslag
    python ifc_export.py <ifc-export.json> --uitvoeren --zonder-nabewerking
    python ifc_export.py <ifc-export.json> --setup-alleen   alleen de setup met echte paden schrijven (voor de Revit-dialoog)

Opties: --negeer-voorcontrole (exporteren ondanks een fout in de voorcontrole; alleen na akkoord van de gebruiker),
--zonder-toets (geen controle en IDS-toets na afloop).

Voorcontrole, alleen leesopdrachten: Revit bereikbaar, model open en geen familie, fase bestaat, levels, links
geladen en ruimten omsloten (die laatste twee alleen als de addin list_link_instances en get_room_geometry kent).
Daarna exporteert hij met export_ifc en een runtime-kopie van de setup waarin de paden en de instellingen uit het
projectbestand zijn ingevuld. Geneste velden van de setup (classificatie, projectadres) gaan als tekst mee.

Met guids_bewaren schrijft Revit de IfcGUID-parameters in het model; het model is daarna gewijzigd. Bewaren doet
dit script nooit: vraag de gebruiker of hij het model wil bewaren.

Dit script gebruikt alleen de standaardbibliotheek. Nabewerking en controle draaien met de python uit omgeving.py.
"""
from __future__ import annotations

import datetime as _dt
import json
import subprocess
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from projectbestand import Project, ProjectFout, SETUPS  # noqa: E402
from revit_agent.bridge import BridgeError, call, call_raw  # noqa: E402

LEESTIJD = 20       # s voor leesopdrachten
EXPORTTIJD = 3600   # s voor de export zelf
# wat export_ifc aanneemt; het getal IFCVersion in de setup laten we staan (de bridge krijgt ifc_version apart)
IFC_VERSIES = ("IFC4", "IFC4RV", "IFC4DTV", "IFC2X3CV2", "IFC2X3")


# ---------------------------------------------------------------------- setup
def _dotnet_datum(iso: str) -> str:
    """'2005-01-01' -> '/Date(1104534000000)/' (middernacht Nederlandse wintertijd), zoals de Revit-dialoog."""
    d = _dt.datetime.fromisoformat(iso).replace(tzinfo=_dt.timezone(_dt.timedelta(hours=1)))
    return f"/Date({int(d.timestamp() * 1000)})/"


def _als_tekst(obj: dict) -> str:
    """Genest setupveld als JSON-tekst, met de .NET-datumnotatie \\/Date(...)\\/ die de exporter verwacht."""
    return json.dumps(obj, ensure_ascii=False).replace('"/Date(', '"\\/Date(').replace(')/"', ')\\/"')


def runtime_setup(pr: Project, fase_id: int | None = None) -> tuple[dict, list[str]]:
    """De setup uit het projectbestand met echte paden en instellingen; plus een lijst met wat er aangepast is."""
    ex = pr.export
    bron = pr.setup_bron()
    tekst = bron.read_text(encoding="utf-8-sig")
    cfg = json.loads(tekst)
    notities = [f"setup {bron.name}"]

    def pad(v):
        return str(Path(str(v).replace("{SETUPS}", str(SETUPS))).resolve()) if v else v
    for veld in ("ExportUserDefinedPsetsFileName", "ExportUserDefinedParameterMappingFileName"):
        if cfg.get(veld):
            cfg[veld] = pad(cfg[veld])
    if ex.get("pset_bestand"):
        cfg["ExportUserDefinedPsets"] = True
        cfg["ExportUserDefinedPsetsFileName"] = str(pr.pad_van(ex["pset_bestand"]))
        notities.append(f"eigen psetbestand {cfg['ExportUserDefinedPsetsFileName']}")
    if ex.get("mapping_bestand"):
        cfg["ExportUserDefinedParameterMapping"] = True
        cfg["ExportUserDefinedParameterMappingFileName"] = str(pr.pad_van(ex["mapping_bestand"]))
        notities.append("mappingtabel opgegeven; via de API komt die niet aan (references/lessen.md, les 1)")
    if cfg.get("ExportUserDefinedPsets") and not Path(cfg.get("ExportUserDefinedPsetsFileName") or "").is_file():
        raise ProjectFout(f"psetbestand niet gevonden: {cfg.get('ExportUserDefinedPsetsFileName')}")
    versie = str(ex.get("ifc_versie") or "IFC4").upper()
    if versie not in IFC_VERSIES:
        raise ProjectFout(f"export.ifc_versie {versie!r}: export_ifc kent {list(IFC_VERSIES)}")
    if fase_id is not None:
        cfg["ActivePhaseId"] = fase_id
        notities.append(f"fase {ex.get('fase')} (id {fase_id})")
    if ex.get("uitsluiten"):
        cfg["ExcludeFilter"] = ";".join(ex["uitsluiten"])
        notities.append(f"uitsluiten {cfg['ExcludeFilter']}")
    if "ruimtevolume_uit_2d" in ex:
        cfg["Use2DRoomBoundaryForVolume"] = bool(ex["ruimtevolume_uit_2d"])
    if "guids_bewaren" in ex:
        cfg["StoreIFCGUID"] = bool(ex["guids_bewaren"])
    cs = cfg.get("ClassificationSettings")
    if isinstance(cs, dict):
        editie = str(ex.get("nlsfb_editie") or "2005")
        datum = ex.get("nlsfb_editiedatum") or (f"{editie}-01-01" if editie.isdigit() and len(editie) == 4 else None)
        cs = {k: (editie if v == "{NLSFB_EDITIE}" else v) for k, v in cs.items()}
        if cs.get("ClassificationEditionDate") == "{NLSFB_DATUM}":
            cs["ClassificationEditionDate"] = _dotnet_datum(datum) if datum else "/Date(-62135596800000)/"
        if ex.get("classificatie") is False:
            cs = {"ClassificationName": None}
        notities.append(f"classificatie {cs.get('ClassificationName')} {cs.get('ClassificationEdition') or ''}".strip())
        cfg["ClassificationSettings"] = cs
    for k, v in (ex.get("instellingen") or {}).items():
        cfg[k] = v
        notities.append(f"instelling {k} = {v!r}")
    cfg["Name"] = f"{cfg.get('Name', 'setup')} ({pr.bestandsnaam})"
    # les 2: geneste velden als tekst, anders komen ze niet bij de exporter
    for k, v in list(cfg.items()):
        if isinstance(v, dict):
            cfg[k] = _als_tekst(v)
    return cfg, notities


# ---------------------------------------------------------------------- voorcontrole
def voorcontrole(pr: Project) -> tuple[list[dict], dict]:
    """Alleen leesopdrachten. Geeft controles [{wat, status, toelichting}] en gelezen gegevens terug."""
    uit: list[dict] = []
    info: dict = {}

    def regel(wat, status, toelichting=""):
        uit.append({"wat": wat, "status": status, "toelichting": toelichting})

    try:
        ping = call_raw("ping", timeout=5)
        if not ping.get("success"):
            raise BridgeError(str(ping.get("error")))
    except BridgeError as e:
        regel("Revit bereikbaar", "fout", str(e))
        return uit, info
    try:
        r = call("get_info", timeout=LEESTIJD)
        info["revit"] = r
        regel("Revit bereikbaar", "goed", f"{r.get('name') or 'Revit'} {r.get('build') or r.get('version') or ''}".strip())
    except BridgeError as e:
        regel("Revit bereikbaar", "goed", f"ping antwoordt; get_info niet: {e}")
    try:
        docs = call("get_open_documents", timeout=LEESTIJD) or []
    except BridgeError as e:
        regel("model open", "fout", str(e))
        return uit, info
    docs = docs.get("documents", docs) if isinstance(docs, dict) else docs
    info["documenten"] = docs
    doc = next((d for d in docs if d.get("title") == pr.model), None)
    if doc is None:
        regel("model open", "fout", f"'{pr.model}' staat niet in de open documenten: {[d.get('title') for d in docs]}")
        return uit, info
    if doc.get("is_family"):
        regel("model open", "fout", "dit is een familiedocument")
        return uit, info
    regel("model open", "goed", doc.get("path") or "")
    if doc.get("is_modified"):
        regel("onbewaard werk", "waarschuwing", "het model heeft onbewaarde wijzigingen; die gaan mee in de export")
    regel("actief document", "onbekend", "de bridge meldt niet welk document actief is; laat de gebruiker in Revit "
                                         "kijken dat dit model vooraan staat en niet alleen als link geladen is")
    # fase
    fase = pr.export.get("fase")
    if fase not in (None, ""):
        try:
            r = call("query_elements", {"type_id": "phases", "target_document": pr.model}, timeout=LEESTIJD)
            fasen = [(e.get("element_id"), e.get("name")) for e in (r or {}).get("elements", [])]
            info["fasen"] = fasen
            treffer = next((i for i, n in fasen if str(fase) in (str(i), str(n))), None)
            if treffer is None:
                regel("fase", "fout", f"fase {fase!r} niet gevonden; het model heeft {[n for _, n in fasen]}")
            else:
                info["fase_id"] = int(treffer)
                regel("fase", "goed", f"{fase} (id {treffer})")
        except BridgeError as e:
            regel("fase", "fout", f"fasen niet te lezen: {e}")
    else:
        regel("fase", "waarschuwing", "geen fase opgegeven: de exporter neemt de laatste fase; ruimten in een "
                                      "andere fase komen dan niet mee")
    # levels
    try:
        r = call("get_levels", {"target_document": pr.model}, timeout=LEESTIJD) or {}
        lv = [(x.get("name"), x.get("elevation_m"), x.get("building_story")) for x in r.get("levels", [])]
        info["levels"] = lv
        regel("levels", "goed", f"{len(lv)} levels, {sum(1 for x in lv if x[2])} als bouwlaag (Building Story)")
    except BridgeError as e:
        regel("levels", "waarschuwing", f"niet te lezen: {e}")
    # links (extra opdracht van de bestaande addin)
    if pr.voorcontrole.get("links_geladen", True):
        try:
            r = call("list_link_instances", {"target_document": pr.model}, timeout=LEESTIJD) or {}
            links = r.get("links", r if isinstance(r, list) else [])
            niet = [l.get("name") for l in links if l.get("status") not in ("Loaded", None) or l.get("geladen") is False]
            info["links"] = links
            regel("links geladen", "fout" if niet else "goed",
                  f"niet geladen: {niet}" if niet else f"{len(links)} links, alle geladen")
        except BridgeError as e:
            regel("links geladen", "onbekend", f"deze addin kan het niet lezen ({e}); laat de gebruiker in Revit "
                                               "onder Manage Links nagaan dat alle links Loaded zijn")
    # ruimten (extra opdracht van de bestaande addin)
    if pr.voorcontrole.get("ruimten_omsloten", True):
        try:
            r = call("get_room_geometry", {"target_document": pr.model}, timeout=300) or {}
            t = r.get("tellers") or {}
            info["ruimten"] = t
            verwacht = pr.voorcontrole.get("verwacht_aantal_ruimten")
            fout = t.get("rooms") != t.get("omsloten") or (verwacht and t.get("omsloten") != verwacht)
            regel("ruimten omsloten", "fout" if fout else "goed",
                  f"{t.get('omsloten')} van {t.get('rooms')} omsloten, {t.get('niet_geplaatst', 0)} niet geplaatst"
                  + (f", verwacht {verwacht}" if verwacht else ""))
        except BridgeError as e:
            regel("ruimten omsloten", "onbekend", f"deze addin kan het niet lezen ({e}); laat de gebruiker een "
                                                  "ruimtestaat bekijken: 'Not Enclosed' of 'Not Placed' gaat niet goed mee")
    return uit, info


# ---------------------------------------------------------------------- uitvoeren
def _python_ifc() -> str:
    from omgeving import python_pad
    return str(python_pad(maak=True))


def _draai(args: list[str]) -> tuple[int, str]:
    r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def verslag(pr: Project, stand: dict) -> Path:
    r = [f"# IFC-export {pr.bestandsnaam}", "",
         f"Model `{pr.model}`, setup `{pr.export.get('setup') or 'ruimtemodel-ifc4'}`, "
         f"{'proef' if stand.get('proef') else 'export'} op {_dt.datetime.now():%d-%m-%Y %H:%M}.", "",
         "## Voorcontrole", "", "| Controle | Uitkomst | Toelichting |", "|---|---|---|"]
    for c in stand.get("voorcontrole", []):
        r.append(f"| {c['wat']} | {c['status']} | {c['toelichting'].replace('|', '/')} |")
    r += ["", "## Export", ""]
    ex = stand.get("export") or {}
    r += [f"- {k}: {v}" for k, v in ex.items() if k not in ("options",)] or ["- niet uitgevoerd"]
    r += ["", "Setup-aanpassingen: " + "; ".join(stand.get("setup_notities", [])), ""]
    if stand.get("nabewerking"):
        nb = stand["nabewerking"]
        r += ["## Nabewerking", "", f"{nb.get('wijzigingen', 0)} wijzigingen.", "",
              "| Stap | Gezet | Al goed uit de export | Waarschuwingen |", "|---|---|---|---|"]
        for s, p in nb.get("per_stap", {}).items():
            r.append(f"| {s} | {p['gewijzigd']} | {p['uit_export']} | {len(p['waarschuwingen'])} |")
        for s, p in nb.get("per_stap", {}).items():
            if p["waarschuwingen"]:
                r += ["", f"**{s}**", ""] + [f"- {w}" for w in p["waarschuwingen"][:20]]
                if len(p["waarschuwingen"]) > 20:
                    r.append(f"- ... en {len(p['waarschuwingen']) - 20} meer (zie het JSON-verslag)")
        r.append("")
    if stand.get("controle"):
        c = stand["controle"]
        r += ["## Controle", "", f"Schema-meldingen: {c.get('schema_meldingen', '-')}, dubbele GlobalIds: "
              f"{c.get('dubbele_globalids')}, georeferentie: {'ja' if c.get('georeferentie') else 'nee'}.", ""]
        r += [f"- [{b['ernst']}] {b['soort']}: {b['tekst']}" for b in c.get("bevindingen", [])]
        ids = c.get("ids") or {}
        if ids.get("fout"):
            r += ["", f"IDS-toets: {ids['fout']}"]
        elif ids.get("totaal"):
            r += ["", "IDS-toets: " + ", ".join(f"{k} {v}" for k, v in ids["totaal"].items()), ""]
            if ids.get("markdown"):
                r += ["<details><summary>IDS per specificatie</summary>", "", ids["markdown"], "</details>"]
    if stand.get("let_op"):
        r += ["", "## Let op", ""] + [f"- {x}" for x in stand["let_op"]]
    pad = pr.uitmap / f"{pr.bestandsnaam}_verslag.md"
    pr.uitmap.mkdir(parents=True, exist_ok=True)
    pad.write_text("\n".join(r) + "\n", encoding="utf-8")
    (pr.uitmap / f"{pr.bestandsnaam}_verslag.json").write_text(
        json.dumps(stand, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    return pad


def main(argv: list[str]) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    vlag = {a for a in argv[1:] if a.startswith("--")}
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    try:
        pr = Project(argv[0])
        if "--setup-alleen" in vlag:
            cfg, notities = runtime_setup(pr)
            pr.uitmap.mkdir(parents=True, exist_ok=True)
            pad = pr.uitmap / f"_setup_{pr.bestandsnaam}.json"
            pad.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
            print(f"setup geschreven: {pad}\n  " + "\n  ".join(notities))
            return 0
        uitvoeren = "--uitvoeren" in vlag
        stand: dict = {"proef": not uitvoeren, "model": pr.model, "ifc": str(pr.ifc_pad), "let_op": []}
        print(f"Voorcontrole voor '{pr.model}' ...", flush=True)
        controles, info = voorcontrole(pr)
        stand["voorcontrole"], stand["gelezen"] = controles, info
        for c in controles:
            print(f"  [{c['status']:11}] {c['wat']}: {c['toelichting']}")
        if any(c["wat"] in ("Revit bereikbaar", "model open") and c["status"] == "fout" for c in controles):
            print("Revit of het model is niet bereikbaar; er is niets gedaan.")
            verslag(pr, stand)
            return 2
        cfg, notities = runtime_setup(pr, info.get("fase_id"))
        stand["setup_notities"] = notities
        pr.uitmap.mkdir(parents=True, exist_ok=True)
        setup_pad = pr.uitmap / f"_setup_{pr.bestandsnaam}.json"
        setup_pad.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
        params = {"target_document": pr.model, "folder": str(pr.uitmap), "file_name": pr.bestandsnaam,
                  "ifc_version": str(pr.export.get("ifc_versie") or "IFC4").upper(), "config_file": str(setup_pad),
                  "keep_guids": bool(pr.export.get("guids_bewaren", True))}
        if pr.export.get("view"):
            params["view_name"] = pr.export["view"]
        stappen = list(pr.nabewerking())
        fouten = [c for c in controles if c["status"] == "fout"]
        print(f"\nPlan: export naar {pr.ifc_pad}\n  setup {setup_pad.name}: " + "; ".join(notities))
        print(f"  nabewerking: {', '.join(stappen) or 'geen'}\n  toets: {pr.toets.get('ids') or 'alleen controle'}")
        if params["keep_guids"]:
            print("  model: de export zet de IfcGUID-parameters in het model (guids_bewaren); het model is daarna gewijzigd")
        if not uitvoeren:
            try:
                stand["export"] = call("export_ifc", dict(params, dry_run=True), timeout=LEESTIJD)
                print(f"  export_ifc (proef): {stand['export'].get('status')}, {stand['export'].get('options')} opties gelezen")
            except BridgeError as e:
                stand["export"] = {"status": f"proef niet gelukt: {e}"}
                print(f"  export_ifc (proef) niet gelukt: {e}")
            p = verslag(pr, stand)
            print(f"\nPROEF: er is niets geëxporteerd. Verslag: {p}")
            if fouten:
                print("Los eerst op: " + "; ".join(f"{c['wat']} ({c['toelichting']})" for c in fouten))
            return 0
        if fouten and "--negeer-voorcontrole" not in vlag:
            print("De voorcontrole vond fouten; niet geëxporteerd. Los ze op, of exporteer met --negeer-voorcontrole "
                  "als de gebruiker daarmee akkoord is.")
            verslag(pr, stand)
            return 1
        print("\nExporteren (dit kan minuten duren; een stille Revit is niet vastgelopen) ...", flush=True)
        try:
            stand["export"] = call("export_ifc", dict(params, dry_run=False), timeout=EXPORTTIJD)
        except BridgeError as e:
            stand["export"] = {"status": "fout", "fout": str(e)}
            print(f"Export mislukt: {e}")
            if e.soort == "time-out":
                print("Laat de gebruiker in Revit kijken (dialoogvenster, lopende export). Niet opnieuw sturen.")
            verslag(pr, stand)
            return 1
        ex = stand["export"] or {}
        print(f"  {ex.get('status')}, {ex.get('bytes', '?')} bytes")
        if ex.get("property_mapping_error") or ex.get("mapping_error"):
            stand["let_op"].append(f"mappingtabel: {ex.get('property_mapping_error') or ex.get('mapping_error')}")
        if params["keep_guids"]:
            stand["let_op"].append("Revit heeft de IfcGUID-parameters in het model gezet; het model is gewijzigd. "
                                   "Vraag de gebruiker of hij het model wil bewaren (dit script bewaart nooit).")
        if ex.get("status") != "exported" or not pr.ifc_pad.is_file():
            print("Er is geen IFC-bestand gemaakt.")
            verslag(pr, stand)
            return 1
        py = None
        if stappen and "--zonder-nabewerking" not in vlag:
            py = _python_ifc()
            rapport = pr.uitmap / f"_nabewerking_{pr.bestandsnaam}.json"
            code, tekst = _draai([py, str(_hier / "ifc_nabewerking.py"), str(pr.pad), "--rapport", str(rapport)])
            print(tekst.rstrip())
            if code:
                stand["let_op"].append("nabewerking mislukt: " + tekst[-500:])
            elif rapport.is_file():
                stand["nabewerking"] = {k: v for k, v in json.loads(rapport.read_text(encoding="utf-8")).items()
                                        if k != "meldingen"}
        if "--zonder-toets" not in vlag:
            py = py or _python_ifc()
            uit = pr.uitmap / f"_controle_{pr.bestandsnaam}.json"
            _, tekst = _draai([py, str(_hier / "ifc_controle.py"), str(pr.ifc_pad), "--project", str(pr.pad), "--json", str(uit)])
            print(tekst.rstrip())
            if uit.is_file():
                stand["controle"] = json.loads(uit.read_text(encoding="utf-8"))
        p = verslag(pr, stand)
        print(f"\nKlaar: {pr.ifc_pad}\nVerslag: {p}")
        for x in stand["let_op"]:
            print(f"LET OP: {x}")
        return 0
    except ProjectFout as e:
        print(f"FOUT in het projectbestand: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
