# Voorbeeld: ruimtemodel volgens de ILS Omgevingsvergunning

Dit voorbeeld maakt van de export van een ruimtemodel een IFC die de ILS Omgevingsvergunning zo goed mogelijk volgt. Het model is het ruimtemodel van het NLRS-onderwijsmodel: een fictieve school met een kelder, drie bouwlagen en een dak, 154 ruimten. Adres, perceel en coördinaten zijn pro forma.

## De bestanden

| Bestand | Inhoud |
|---|---|
| `ifc-export.json` | Het projectbestand: model, setup, fase, de nabewerkstappen en de toets. |
| `indeling.csv` | Per ruimtenummer de ruimtesoort (Bbl) en de zones: gebruiksfunctie, gebruikseenheid, brandcompartiment, subbrandcompartiment of vluchtroute, gebied. |
| `eigenschappen.json` | Project, perceel, gebouw met adres en psets; FireExit op de vluchtroutes. |

## Zo volg je het

1. Open het model in Revit. Staan de links geladen en heet de fase met de ruimten `NLRS_nieuw`?
2. Laat Claude de proef draaien: `python scripts/ifc_export.py voorbeeld/ruimtemodel-ils-omgevingsvergunning/ifc-export.json`.
3. Na akkoord: dezelfde opdracht met `--uitvoeren`.
4. Lees het verslag in `uit/`.

Heb je alleen een IFC van het model (geen Revit), dan begin je bij de nabewerking:
`python scripts/ifc_nabewerking.py voorbeeld/ruimtemodel-ils-omgevingsvergunning/ifc-export.json --ifc <model.ifc> --uit <nieuw.ifc>` en daarna `python scripts/ifc_controle.py <nieuw.ifc> --project voorbeeld/ruimtemodel-ils-omgevingsvergunning/ifc-export.json`.

## Wat eruit kwam

Op de ruwe export van 18-11-2026 (153 ruimten, nog zonder de aanpassingen in Revit), getoetst tegen de 46 specificaties van de ILS (25-11-2026):

| | goed | fout | komt niet voor | n.v.t. |
|---|---|---|---|---|
| ruwe export | 33 | 10 | 2 | 1 |
| na de nabewerking | 42 | 3 | 0 | 1 |

De drie die fout blijven:

- **9.06a Bouwlaag**: de bewuste keuze voor nummer in Name. Met `"stijl": "ils-9.06"` gaat hij goed.
- **9.10c Verblijfsgebied met bezettingsgraad**: de ruimten in deze export hebben nog geen OccupancyNumber. Dat komt uit Revit (parameters in het psetbestand); de nabewerking telt het dan op.
- **9.18g IfcSlab**: de Mass Floors zaten in deze oude export. Het projectbestand sluit IfcSlab uit bij een nieuwe export.

Inhouden en terrein (Gebouwinhoud, Bouwlaaginhoud, Bouwwerkperceel, Buitengebied) maakt de skill niet. In deze toets tellen ze als goed omdat ze ontbreken; een vergunningverlener verwacht ze wel.

## Een eigen model

Kopieer de drie bestanden naar een map naast je eigen model en pas aan:

- `model`, `fase` en de bouwlagentabel in `ifc-export.json`;
- de coördinaten in `georeferentie`;
- `indeling.csv`: maak hem uit een eerdere IFC met `ifc_nabewerking.py --maak-indeling`, of vul hem met de ontwerper;
- `eigenschappen.json`: echte adres-, kadaster- en BAG-gegevens.
