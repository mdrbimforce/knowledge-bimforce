# Bekende problemen

Per probleem: wat de gebruiker ziet, waarom, en wat je zegt of doet. Vraag bij een foutmelding altijd de letterlijke tekst, en vraag de gebruiker nooit om zijn wachtwoord in het gesprek te plakken.

## Verbinding geweigerd op localhost:7687

**Ziet:** een fout als "Couldn't connect to localhost:7687", "Connection refused" of "ServiceUnavailable".
**Waarom:** meestal is de database in Neo4j Desktop niet gestart. De app open hebben is niet genoeg: de instance zelf moet draaien. Ook: Neo4j Desktop is gesloten (dan stopt de instance), of een andere instance draait (er draait er maar één tegelijk).
**Zeg:** "Open Neo4j Desktop en start je instance met de afspeelknop op de kaart. Zeg het als hij draait, dan probeer ik het opnieuw."

## Authenticatie mislukt

**Ziet:** "authentication failure" of "The client is unauthorized".
**Waarom:** het wachtwoord of de gebruikersnaam in `claude_desktop_config.json` klopt niet met die van de instance. Of: het wachtwoord is aangepast, maar een oud exemplaar van de koppeling draait nog met het oude wachtwoord. Na meerdere herstarts van Claude Desktop kunnen zulke processen blijven hangen.
**Zeg:** controleer gebruikersnaam (meestal `neo4j`) en wachtwoord in het bestand. Sluit daarna Claude Desktop volledig af via het systeemvak (Quit), beëindig in Taakbeheer de processen `mcp-neo4j-cypher`, `uvx` of `python` die nog draaien, of herstart de computer. Start dan Claude Desktop opnieuw.

## Wijziging in het instellingenbestand doet niets

**Ziet:** de koppeling verschijnt niet, of de oude instelling (bijvoorbeeld alleen lezen) blijft gelden.
**Waarom:** Claude Desktop leest het bestand alleen bij het opstarten. Het venster sluiten met het kruisje sluit de app niet af; hij blijft in het systeemvak draaien.
**Zeg:** "Klik rechtsonder in het systeemvak met de rechtermuisknop op Claude en kies Quit. Start het daarna opnieuw." (Mac: Cmd+Q.)

## De koppeling verschijnt niet, ook niet na herstart

**Waarom:** meestal ongeldige JSON (een komma te veel of te weinig, een accolade mist, gekrulde aanhalingstekens uit een tekstverwerker). Of Claude Desktop vindt `uvx` niet.
**Doe:** laat de gebruiker de inhoud van het bestand plakken met het wachtwoord vervangen door `xxx`, en wijs de fout aan. Vindt Claude Desktop `uvx` niet, zet dan het volledige pad in `command` (Windows: uitvoer van `where.exe uvx`, met dubbele backslashes; Mac: uitvoer van `which uvx`). Logbestanden: Windows `%APPDATA%\Claude\logs\mcp-server-<naam>.log`, Mac `~/Library/Logs/Claude/`.

## Het schema ophalen faalt

**Ziet:** een fout bij `get_neo4j_schema` met iets als "There is no procedure with the name apoc.meta.schema".
**Waarom:** de uitbreiding APOC is niet geïnstalleerd in de instance.
**Zeg:** "Open in Neo4j Desktop bij je instance het menu […] > Plugins, installeer APOC en herstart de instance." Werk in de tussentijd met `CALL db.labels()`, `CALL db.relationshipTypes()` en `CALL db.schema.visualization()`.

## Schrijven lukt niet

**Ziet:** de tool `write_neo4j_cypher` ontbreekt, of de leestool weigert de query omdat hij iets zou wijzigen.
**Waarom:** de koppeling staat op alleen lezen (`NEO4J_READ_ONLY` op `"true"` of `--read-only` in `args`). Dat is de veilige standaard.
**Zeg:** leg uit hoe schrijven aan gaat (op `"false"` zetten, volledig herstarten) en raad aan het na het werk weer uit te zetten.

## Een MERGE maakt dubbele nodes

**Waarom:** MERGE op meer eigenschappen dan de sleutel (`MERGE (e:Element {code: $c, naam: $n})`): bij een andere naam ontstaat een tweede node. Of er is geen constraint, en er stonden al dubbelingen.
**Doe:** MERGE alleen op de sleutel, de rest met SET. Zoek dubbelingen met:
```cypher
MATCH (e:Element) WITH e.code AS code, count(*) AS n WHERE n > 1 RETURN code, n
```
Ruim ze pas op na overleg en met getoonde aantallen; daarna de constraint aanmaken.

## Een query geeft niets terug, terwijl er wel data is

**Waarom:** verschil in hoofd- en kleine letters in labels of relatietypes (`Element` tegenover `element`), een relatie in de andere richting, een code met spaties, of een getal dat als tekst is opgeslagen (`'21'` tegenover `21`).
**Doe:** lees het schema opnieuw, controleer met een kleine leesquery hoe de waarde echt is opgeslagen (`RETURN e.code, valueType(e.code) LIMIT 5`).

## Een query duurt lang of de tool geeft een time-out

**Waarom:** een patroon zonder label of zonder beperking doorzoekt de hele database, of het resultaat is erg groot.
**Doe:** voeg labels en `LIMIT` toe, zoek op een eigenschap met een constraint of index. De leestool heeft standaard een time-out van 30 seconden.

## De eerste start van de koppeling is traag

**Waarom:** bij de eerste start haalt `uvx` de koppeling en zo'n zestig onderdelen op.
**Zeg:** "Draai één keer in PowerShell of Terminal `uvx mcp-neo4j-cypher@0.6.0 --help`. Daarna start de koppeling snel."
