# Een datamodel ontwerpen vanuit de vragen

Een graph-model is goed als de vragen van de gebruiker er eenvoudig op te beantwoorden zijn. Niet als het de oorspronkelijke tabel zo trouw mogelijk naspeelt. Gidsen van Neo4j: https://neo4j.com/docs/getting-started/data-modeling/

## Werkwijze

1. **Vragen eerst.** Laat de gebruiker drie tot vijf vragen opschrijven die hij straks wil stellen. Voorbeelden uit de bouw:
   - "Welke elementen vallen onder hoofdgroep (2-)?"
   - "Welke eisen gelden voor binnenwanden?"
   - "In welke ruimtes zit een element van deze soort?"
2. **Naamwoorden worden labels.** Hoofdgroep, Element, Eis, Ruimte.
3. **Verbanden worden relaties.** "valt onder" wordt `HOORT_BIJ`, "geldt voor" wordt `GELDT_VOOR`, "zit in" wordt `BEVINDT_ZICH_IN`.
4. **Kenmerken worden eigenschappen.** Code, naam, omschrijving, eenheid.
5. **Sleutel per label.** Welke eigenschap maakt een ding uniek? Codes uit een classificatie zijn vaak een goede sleutel; namen meestal niet.
6. **Toets elke vraag.** Schrijf per vraag de query uit. Is hij kort en leesbaar, dan klopt het model. Moet je omwegen maken, dan ontbreekt er een relatie of is iets een eigenschap dat een node had moeten zijn.
7. **Klein beginnen.** Drie tot vijf voorbeeldnodes per label, dan de vragen echt draaien, dan pas alles inlezen.

Teken het model in tekst voordat je iets schrijft:

```
(Hoofdgroep {code, naam})
(Element {code, naam})-[:HOORT_BIJ]->(Hoofdgroep)
(Eis {id, tekst})-[:GELDT_VOOR]->(Element)
```

## Vuistregels

- **Node of eigenschap?** Wil je erop zoeken, ernaar verwijzen vanuit meerdere dingen, of er zelf weer kenmerken aan hangen, maak er dan een node van. Is het alleen een waarde bij één ding, dan een eigenschap. Voorbeeld: een materiaal dat bij veel elementen voorkomt en eigen kenmerken heeft, wordt een node; een kleurcode bij één element is een eigenschap.
- **Hiërarchie als relaties.** Een classificatie met niveaus (hoofdgroep, element, subelement) wordt een keten van nodes met een relatie naar boven, niet een lange code die je met tekstbewerking uit elkaar haalt.
- **Relaties hebben één duidelijke richting en een werkwoord als naam.** `(Element)-[:HOORT_BIJ]->(Hoofdgroep)`, niet `HOOFDGROEP_ELEMENT`. Lezen kan in beide richtingen; je hoeft geen tweede relatie terug te leggen.
- **Eigenschappen op een relatie** alleen als ze echt bij het verband horen (bijvoorbeeld een geldig-vanaf-datum op `GELDT_VOOR`).
- **Liever specifieke labels dan één generiek label met een eigenschap `type`.** `(:Element)` en `(:Eis)` in plaats van `(:Ding {type: 'element'})`.
- **Versies en bronnen expliciet.** Komen gegevens uit verschillende bronnen of versies, zet dan een eigenschap `bron` of `versie`, of een node per bron met een relatie. Dan kun je later gericht nalopen of opruimen.
- **Externe standaarden.** Volg de codes en benamingen van de standaard letterlijk (bijvoorbeeld NL-SfB of IFC). Wijkt de organisatie bewust af, leg die afwijking dan vast als eigenschap of als aparte node, zodat het zichtbaar blijft.

## Veelgemaakte fouten

| Fout | Gevolg | Beter |
|---|---|---|
| Elke kolom van een tabel een eigenschap op één node | Een graph zonder relaties: een spreadsheet in een andere verpakking | Herhaalde waarden (hoofdgroep, materiaal, ruimte) worden eigen nodes met een relatie |
| Naam als sleutel | Dubbele nodes bij twee dingen met dezelfde naam, of gemiste koppelingen bij een tikfout | Code of nummer als sleutel, naam als gewone eigenschap |
| Geen constraint vóór de eerste import | Stille dubbelingen die later moeilijk te vinden zijn | Eerst `CREATE CONSTRAINT ... IS UNIQUE` |
| Alles in één keer inlezen | Fouten pas zichtbaar na duizenden nodes | Eerst vijf rijen, nakijken, dan de rest |
| Model ontworpen zonder vragen | Queries met lange omwegen | Werkwijze hierboven, stap 1 en 6 |
