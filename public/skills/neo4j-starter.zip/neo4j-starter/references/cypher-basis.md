# Cypher in een notendop

Cypher is de querytaal van Neo4j. Je tekent er als het ware de patronen mee die je zoekt: haakjes zijn nodes, pijlen zijn relaties. Gebruik dit bestand om queries uit te leggen aan iemand die nog nooit code heeft gelezen. Officiële handleiding: https://neo4j.com/docs/cypher-manual/current/

## De bouwstenen

| Wat je ziet | Wat het is | Zo leg je het uit |
|---|---|---|
| `(e)` | een node | "een ding, dat we in deze query e noemen" |
| `(e:Element)` | een node met een label | "een ding van de soort Element" |
| `(e:Element {code: '(21)'})` | met een eigenschap | "het Element met code (21)" |
| `-[:HOORT_BIJ]->` | een relatie met richting | "dat hoort bij" |
| `-[r:HOORT_BIJ]-` | relatie zonder richting, met naam r | "dat verbonden is via HOORT_BIJ, welke kant op ook" |
| `$code` | een parameter | "een waarde die we apart meegeven" |

Labels schrijf je met een hoofdletter (`Element`), relatietypes in hoofdletters met underscores (`HOORT_BIJ`), eigenschappen klein (`code`, `naam`). Neo4j is gevoelig voor hoofd- en kleine letters: `Element` en `element` zijn twee verschillende labels.

## Lezen

```cypher
MATCH (e:Element)-[:HOORT_BIJ]->(h:Hoofdgroep {code: $code})
RETURN e.code AS code, e.naam AS naam
ORDER BY code
LIMIT 25
```

Uitleg per regel:
1. Zoek elk Element dat bij de Hoofdgroep met deze code hoort.
2. Geef van elk Element de code en de naam terug.
3. Sorteer op code.
4. Hooguit 25 regels.

Veelgebruikte toevoegingen:
- `WHERE e.naam CONTAINS 'wand'`: alleen als de naam "wand" bevat.
- `OPTIONAL MATCH`: zoek mee, maar laat de regel staan als er niets gevonden wordt (zoals een "left join").
- `count(*)`, `collect(e.naam)`: tellen en verzamelen per groep.
- `WITH`: tussenresultaat doorgeven aan het volgende deel van de query.

Tellen per soort:

```cypher
MATCH (n) RETURN labels(n) AS soort, count(*) AS aantal ORDER BY aantal DESC
```

## Schrijven

| Opdracht | Wat het doet | Wanneer |
|---|---|---|
| `MERGE` | zoek, en maak aan als het er niet is | standaard, op de sleutel |
| `CREATE` | maak altijd een nieuwe | alleen als het zeker nieuw is |
| `SET` | eigenschap zetten of wijzigen | na MERGE of MATCH |
| `ON CREATE SET` | alleen zetten bij aanmaken | bijvoorbeeld een aanmaakdatum |
| `REMOVE` | eigenschap of label weghalen | |
| `DELETE` | node of relatie weghalen | relatie; node alleen als hij geen relaties heeft |
| `DETACH DELETE` | node met al zijn relaties weghalen | alleen na telling en akkoord |

Een element aanmaken en koppelen:

```cypher
MATCH (h:Hoofdgroep {code: $hoofdgroep})
MERGE (e:Element {code: $code})
SET e.naam = $naam
MERGE (e)-[:HOORT_BIJ]->(h)
```

Uitleg: zoek de hoofdgroep; zoek of maak het element op code; zet de naam; leg de relatie, maar niet nog een keer als hij er al ligt.

Let op: staat de hoofdgroep er niet, dan vindt de eerste regel niets en gebeurt er helemaal niets. Meld dat aan de gebruiker als de tellers nul zijn.

## Constraints en indexen

```cypher
CREATE CONSTRAINT hoofdgroep_code IF NOT EXISTS
FOR (h:Hoofdgroep) REQUIRE h.code IS UNIQUE
```

```cypher
SHOW CONSTRAINTS
```

Een uniciteitsconstraint maakt ook een index: zoeken op die eigenschap gaat dan snel.

## Een verwijdering voorbereiden

Eerst tellen, met dezelfde MATCH:

```cypher
MATCH (e:Element {bron: $bron})
OPTIONAL MATCH (e)-[r]-()
RETURN count(DISTINCT e) AS nodes, count(r) AS relaties
```

Pas na akkoord op die aantallen:

```cypher
MATCH (e:Element {bron: $bron})
DETACH DELETE e
```

## Een query laten uitleggen zonder hem te draaien

`EXPLAIN` vooraan laat Neo4j het plan tonen zonder iets uit te voeren. Handig om te controleren of een query geldig is. De leestool van mcp-neo4j-cypher gebruikt dit zelf om te bepalen of een query iets zou wijzigen.
