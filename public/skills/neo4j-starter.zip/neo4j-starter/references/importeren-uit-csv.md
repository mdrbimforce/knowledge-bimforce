# Importeren uit CSV of Excel

Er zijn twee routes. Kies op grootte en op wat je omgeving kan.

| Route | Wanneer | Hoe |
|---|---|---|
| A. Via de tools | tot een paar duizend rijen, en je kunt het bestand lezen | jij leest het bestand, geeft de rijen als parameter mee aan `write_neo4j_cypher` met `UNWIND` |
| B. Via de importmap van Neo4j | grote bestanden, of je kunt het bestand niet zelf lezen | de gebruiker zet het bestand in de importmap van de instance; jij draait `LOAD CSV` |

Excel eerst als CSV opslaan: in Excel **Bestand > Opslaan als**, type **CSV UTF-8 (met scheidingstekens)**. Let op: een Nederlandse Excel gebruikt vaak een puntkomma als scheidingsteken.

## Voor elke import

1. **Bekijk het bestand.** Toon de kolomnamen en de eerste vijf rijen. Vraag wat elke kolom betekent als het niet duidelijk is.
2. **Model afspreken** (zie `datamodel-ontwerpen.md`): welke kolommen worden nodes, welke relaties, welke eigenschappen, wat is de sleutel.
3. **Constraints eerst** voor elke sleutel.
4. **Proef met vijf rijen**, laat het resultaat zien, en pas na akkoord de rest.
5. **Tel na afloop**: rijen in het bestand tegenover nodes in de database. Wijkt het af, zoek uit waarom (dubbele sleutels, lege cellen).
6. **Bron vastleggen**: zet op elke geïmporteerde node een eigenschap `bron` (bijvoorbeeld de bestandsnaam en datum). Dan kun je een mislukte import later gericht terugdraaien.

## Route A: rijen als parameter

Lees het bestand zelf in (of laat de gebruiker de inhoud plakken), zet de rijen om naar een lijst en geef die mee:

```
query:
UNWIND $rijen AS rij
MATCH (h:Hoofdgroep {code: rij.hoofdgroep})
MERGE (e:Element {code: rij.code})
SET e.naam = rij.naam, e.bron = $bron
MERGE (e)-[:HOORT_BIJ]->(h)

params:
{"bron": "elementen.csv 2026-11-17",
 "rijen": [{"code": "(21)", "naam": "Buitenwanden", "hoofdgroep": "(2-)"}, ...]}
```

Stuur grote lijsten in porties van een paar honderd rijen. Meld na elke portie de tellers.

## Route B: LOAD CSV

Elke instance heeft een eigen importmap. In Neo4j Desktop 2 open je de mappen van een instance via het menu **[…]** van de instance; zoek daar de map `import`. Laat de gebruiker het bestand daar neerzetten. Dan:

```cypher
LOAD CSV WITH HEADERS FROM 'file:///elementen.csv' AS rij FIELDTERMINATOR ';'
WITH rij LIMIT 5
RETURN rij
```

Eerst zo kijken (alleen lezen, `LIMIT 5`). Klopt het, dan de schrijfquery tonen en na akkoord uitvoeren:

```cypher
LOAD CSV WITH HEADERS FROM 'file:///elementen.csv' AS rij FIELDTERMINATOR ';'
MATCH (h:Hoofdgroep {code: rij.hoofdgroep})
MERGE (e:Element {code: rij.code})
SET e.naam = rij.naam, e.bron = 'elementen.csv'
MERGE (e)-[:HOORT_BIJ]->(h)
```

Voor tienduizenden rijen of meer: in porties met `CALL { ... } IN TRANSACTIONS OF 1000 ROWS`. In de Query-tool van Neo4j Desktop moet je dan `:auto` vooraan zetten; via de MCP-tool werkt dit mogelijk niet omdat die zelf een transactie opent. Kies dan route A in porties.

## Valkuilen

- **Alles is tekst.** `LOAD CSV` leest elke cel als tekst. Getallen omzetten met `toInteger(rij.aantal)` of `toFloat(...)`, datums met `date(rij.datum)` (formaat JJJJ-MM-DD).
- **Lege cellen** komen binnen als `null`. `MERGE` op een sleutel die `null` is, faalt. Filter eerst: `WHERE rij.code IS NOT NULL AND rij.code <> ''`.
- **Spaties** aan begin of eind van een code maken twee verschillende sleutels. Gebruik `trim(rij.code)`.
- **Tekens als é, ë en ½** worden verminkt als het bestand niet als UTF-8 is opgeslagen.
- **Kolomnamen met spaties** schrijf je met backticks: ``rij.`NL-SfB code` ``.
