"""Een NLRS-naam ontleden of opbouwen, met uitleg per positie. Werkt zonder Revit.

    python nlrs_naam.py secties                                   # welke naamregels er zijn
    python nlrs_naam.py ontleed "NLRS_31_DO_WB_enkele deur_gen_rsf" [--sectie "3.1 Loadable families"]
    python nlrs_naam.py bouw "3.1 Loadable families" NLRS 31 DO WB "enkele deur" gen rsf
    python nlrs_naam.py lijst "3.1 Loadable families" 4 [--zoek wand]   # keuzelijst van een positie
    python nlrs_naam.py categorie Doors                           # categoriecode van een Revit-categorie

Een sectie mag ook met het begin van de sleutel (bv. "3.2.4" of "4.1").
"""
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):   # in de zip: scripts/; in de repo: shared/
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import argparse  # noqa: E402

from nlrs_bron.grammatica import CONFORM, Nlrs, laad_kennis  # noqa: E402


def zoek_sectie(nlrs: Nlrs, s: str) -> str:
    if s in nlrs.secties:
        return s
    kand = [k for k, v in nlrs.secties.items() if v["soort"] == "naamregel" and k.lower().startswith(s.lower())]
    if len(kand) == 1:
        return kand[0]
    raise SystemExit(f"Sectie '{s}' is niet eenduidig. Kies uit: " + "; ".join(kand or
                     [k for k, v in nlrs.secties.items() if v["soort"] == "naamregel"]))


def raad_sectie(nlrs: Nlrs, naam: str) -> str:
    beste, score = None, None
    for k, s in nlrs.secties.items():
        if s["soort"] != "naamregel":
            continue
        t = nlrs.toets_naam(naam, k)
        n = sum(p["status"] != CONFORM for p in t["posities"]) + (5 if t["status"] == "afwijking" and
                                                                     "posities" in " ".join(t["meldingen"]) else 0)
        if score is None or n < score:
            beste, score = k, n
    return beste


def toon(t: dict, nlrs: Nlrs) -> None:
    s = nlrs.secties[t["sectie"]]
    print(f"Naam:    {t['naam']}")
    print(f"Sectie:  {t['sectie']}  (voorbeeld uit de Naamgenerator: {s['voorbeeld'].replace(chr(160), ' ')})")
    print(f"Uitkomst: {t['status']}")
    for p, spec in zip(t["posities"], s["posities"]):
        print(f"  {p['nr']}. {spec['naam']:<40} '{p['token'] or ''}'  {p['status']}")
        print(f"     {spec['herkomst']}" + ("" if spec["verplicht"] else " (optioneel)"))
        if p["melding"]:
            print(f"     -> {p['melding']}")
    for m in t["meldingen"]:
        if "posities" in m:
            print(f"  -> {m}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="NLRS-naam ontleden of opbouwen")
    sub = ap.add_subparsers(dest="actie", required=True)
    sub.add_parser("secties")
    o = sub.add_parser("ontleed")
    o.add_argument("naam")
    o.add_argument("--sectie")
    o.add_argument("--categorie", help="Revit-categorie van het element (toetst de categoriecode)")
    b = sub.add_parser("bouw")
    b.add_argument("sectie")
    b.add_argument("waarden", nargs="+")
    li = sub.add_parser("lijst")
    li.add_argument("sectie")
    li.add_argument("positie", type=int)
    li.add_argument("--zoek")
    c = sub.add_parser("categorie")
    c.add_argument("naam")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    nlrs = Nlrs(laad_kennis())

    if a.actie == "secties":
        for k, s in nlrs.secties.items():
            if s["soort"] == "naamregel":
                opbouw = "_".join(f"<{p['naam']}>" for p in s["posities"])
                print(f"{k}\n    {opbouw}\n    voorbeeld: {s['voorbeeld'].replace(chr(160), ' ')}")
        return 0
    if a.actie == "ontleed":
        sectie = zoek_sectie(nlrs, a.sectie) if a.sectie else raad_sectie(nlrs, a.naam)
        t = nlrs.toets_naam(a.naam, sectie, {"categorie": a.categorie} if a.categorie else {})
        toon(t, nlrs)
        if t["status"] == "afwijking":
            v = nlrs.voorstel(a.naam, sectie, {"categorie": a.categorie} if a.categorie else {})
            if v:
                print(f"Voorstel: {v[0]}  ({v[1]})")
        return 0
    if a.actie == "bouw":
        sectie = zoek_sectie(nlrs, a.sectie)
        naam = "_".join(a.waarden)
        toon(nlrs.toets_naam(naam, sectie), nlrs)
        return 0
    if a.actie == "lijst":
        sectie = zoek_sectie(nlrs, a.sectie)
        p = nlrs.secties[sectie]["posities"][a.positie - 1]
        kl = p.get("keuzelijst")
        print(f"{sectie}, positie {p['nr']} ({p['naam']}): {p['herkomst']}")
        if not kl:
            print("  vrije tekst" + (f"; uitleg: {p['uitleg']}" if p["uitleg"] else ""))
            return 0
        for code, oms in kl["codes"].items():
            if not a.zoek or a.zoek.lower() in (code + " " + oms).lower():
                print(f"  {code:<8} {oms}")
        if kl.get("uitbreidbaar"):
            print("  (de lijst is uit te breiden met eigen afkortingen)")
        return 0
    if a.actie == "categorie":
        print(nlrs.categorie_code(a.naam) or f"geen code gevonden voor '{a.naam}' (gebruik de Engelse naam uit Revit)")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
