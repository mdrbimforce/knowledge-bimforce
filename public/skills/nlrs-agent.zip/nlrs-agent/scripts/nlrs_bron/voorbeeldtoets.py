"""Legt elk voorbeeld (RESULTAAT) van de Naamgenerator langs de eigen toets.

Per sectie twee vragen:
1. herberekening: bouwt de lezer uit de invoer van de Naamgenerator en de afgeleide keuzelijsten
   hetzelfde voorbeeld als de Naamgenerator zelf? Zo niet, dan klopt de lezer niet.
2. toets: komt het voorbeeld van de NLRS door de eigen controle? Zo niet, dan is dat een bevinding
   over de bron of over de lezer, en staat de reden erbij.

    python voorbeeldtoets.py [--json uit.json]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
if str(_hier.parent) not in sys.path:
    sys.path.insert(0, str(_hier.parent))

from nlrs_bron.grammatica import Nlrs, laad_kennis  # noqa: E402
from nlrs_bron.lezen import schoon  # noqa: E402


def toets_voorbeelden(kennis: dict) -> list[dict]:
    nlrs = Nlrs(kennis)
    uit = []
    for s in kennis["secties"]:
        r = {"sectie": s["sleutel"], "soort": s["soort"]}
        if s["soort"] != "naamregel":
            r["uitkomst"] = "geen naamregel"
            r["regels"] = s.get("regels", [])[:3]
            uit.append(r)
            continue
        vb = s["voorbeeld"]
        r["voorbeeld"] = vb
        hb = nlrs.herbereken_voorbeeld(s["sleutel"])
        r["herberekend"] = hb
        r["herberekening_gelijk"] = hb == "_".join(schoon(t) for t in vb.split("_"))
        t = nlrs.toets_naam(vb, s["sleutel"])
        r["status"] = t["status"]
        r["meldingen"] = t["meldingen"]
        r["uitkomst"] = {"conform": "slaagt", "let op": "slaagt met opmerking", "afwijking": "faalt"}[t["status"]]
        uit.append(r)
    return uit


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json")
    ap.add_argument("--ververs", action="store_true")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    res = toets_voorbeelden(laad_kennis(ververs=a.ververs))
    for r in res:
        if r["uitkomst"] == "geen naamregel":
            print(f"- {r['sectie']}: geen naamregel")
            continue
        hb = "" if r["herberekening_gelijk"] else f" | HERBEREKEND ANDERS: {r['herberekend']!r}"
        print(f"- {r['sectie']}: {r['uitkomst']} | {r['voorbeeld']!r}{hb}")
        for m in r["meldingen"]:
            print(f"    {m}")
    if a.json:
        Path(a.json).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
