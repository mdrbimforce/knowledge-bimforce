"""NLRS-bron: de publieke bestanden van de NLRS (Revit Standards Foundation) ophalen en lezen.

- ophalen.py      haalt NLRS_Revit_Settings, NLRS_Shared_Parameters en NLRS_IFC_settings op naar een cache
- lezen.py        lezers voor de Naamgenerator, de categorielijst, NL-SfB en het shared-parameterbestand
- grammatica.py   de naamregels per sectie, afgeleid uit de formules van de Naamgenerator, en de toets
- voorbeeldtoets.py  legt elk voorbeeld (RESULTAAT) van de Naamgenerator langs de eigen toets

Alleen openpyxl is nodig naast de standaardbibliotheek (voor de xlsx-bestanden).
"""
