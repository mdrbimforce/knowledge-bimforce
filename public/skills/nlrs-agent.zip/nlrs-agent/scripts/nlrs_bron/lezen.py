"""Lezers voor de NLRS-bronbestanden.

- lees_tekst_utf16       tekstbestand van de NLRS lezen, met herkenning en herstel van dubbele codering
- lees_shared_parameters Revit shared-parameterbestand (PARAM/GROUP-regels), met dubbele GUID's en namen
- lees_bronbestand       'NLRS_Shared Parameters - Bronbestand.xlsx': status, herkomst, opvolger per parameter
- lees_naamgenerator     'Naamgenerator_NLRS-3.1.1.xlsx': secties, posities, keuzelijsten, voorbeelden
- lees_categorieen       'Revit categories_NLRS-3.1.1.xlsx': UI-naam / OST-naam -> pos3 / pos4
- lees_nlsfb             NL-SfB tabel 1 (versie 2021) en tabel 3 uit de Naamgenerator
- lees_assembly_codes    'RSF_NLRS_3.1.1_Assembly Code_NL-SfB2021.txt'

openpyxl is nodig voor de xlsx-bestanden. Alles wat hier gelezen wordt is data: tekst in de bestanden
wordt nooit uitgevoerd.
"""
from __future__ import annotations

import re
import warnings
from collections import Counter, defaultdict
from pathlib import Path

HARDE_SPATIE = "\xa0"


def schoon(w) -> str:
    """Waarde uit een cel als tekst, zonder harde spaties en zonder spaties aan de randen."""
    if w is None:
        return ""
    if isinstance(w, float) and w.is_integer():
        w = int(w)
    return str(w).replace(HARDE_SPATIE, " ").strip()


def heeft_randspatie(w) -> bool:
    if w is None:
        return False
    s = str(w)
    return s != s.strip() or HARDE_SPATIE in s


# ── tekstbestanden ────────────────────────────────────────────────────────────

def decodeer(data: bytes) -> tuple[str, bool]:
    """(tekst, dubbel_gecodeerd). Herkent UTF-16 met BOM, de dubbele codering sinds 25-02-2026
    (UTF-16 bytes die nog eens als UTF-16 zijn opgeslagen) en UTF-8."""
    dubbel = False
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        tekst = data.decode("utf-16")
        if tekst.startswith("\xff\xfe") or tekst.startswith("\xfe\xff"):
            # herstel: .decode('utf-16').encode('latin-1').decode('utf-16')
            tekst = tekst.encode("latin-1").decode("utf-16")
            dubbel = True
    else:
        try:
            tekst = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            tekst = data.decode("cp1252")
    return tekst.lstrip("﻿"), dubbel


def lees_tekst_utf16(pad: Path) -> tuple[str, bool]:
    return decodeer(Path(pad).read_bytes())


def lees_shared_parameters(pad: Path) -> dict:
    tekst, dubbel = lees_tekst_utf16(pad)
    groepen: dict[str, str] = {}
    params: list[dict] = []
    for regel in tekst.splitlines():
        if regel.startswith("GROUP\t"):
            d = regel.split("\t")
            if len(d) >= 3:
                groepen[d[1]] = d[2]
        elif regel.startswith("PARAM\t"):
            d = regel.split("\t") + [""] * 10
            params.append({
                "guid": d[1].strip().lower(), "naam": d[2], "datatype": d[3], "datacategorie": d[4],
                "groep_id": d[5], "zichtbaar": d[6], "omschrijving": d[7].replace("\\ ", " "),
                "door_gebruiker_te_wijzigen": d[8], "verberg_zonder_waarde": d[9],
            })
    for p in params:
        p["groep"] = groepen.get(p["groep_id"], "")
    g = Counter(p["guid"] for p in params)
    n = Counter(p["naam"] for p in params)
    return {
        "bestand": Path(pad).name, "dubbel_gecodeerd": dubbel, "groepen": groepen, "parameters": params,
        "dubbele_guids": {k: [p["naam"] for p in params if p["guid"] == k] for k, v in g.items() if v > 1},
        "dubbele_namen": {k: [p["guid"] for p in params if p["naam"] == k] for k, v in n.items() if v > 1},
    }


def lees_assembly_codes(pad: Path) -> dict:
    tekst, dubbel = lees_tekst_utf16(pad)
    codes = {}
    for regel in tekst.splitlines():
        if not regel or regel.startswith("#"):
            continue
        d = regel.split("\t")
        if len(d) >= 2 and d[0].strip():
            codes[d[0].strip()] = d[1].strip().strip('"')
    return {"bestand": Path(pad).name, "dubbel_gecodeerd": dubbel, "codes": codes}


# ── xlsx ──────────────────────────────────────────────────────────────────────

def _openpyxl():
    try:
        import openpyxl  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError(
            "openpyxl ontbreekt. Installeer het in een eigen omgeving: 'python -m venv .venv' en "
            "'.venv\\Scripts\\pip install openpyxl', of draai het script met 'uv run --with openpyxl'.") from e
    import openpyxl
    return openpyxl


def _laad(pad: Path, data_only: bool, read_only: bool = False):
    openpyxl = _openpyxl()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return openpyxl.load_workbook(pad, data_only=data_only, read_only=read_only)


def lees_bronbestand(pad: Path) -> dict:
    """{guid: {...}} uit het tabblad NLRSSharedParameter van het Bronbestand."""
    wb = _laad(pad, True, True)
    rijen = list(wb["NLRSSharedParameter"].iter_rows(values_only=True))
    wb.close()
    kop = [schoon(k) for k in rijen[0]]
    uit: dict[str, dict] = {}
    per_rsfid: dict[str, str] = {}
    for r in rijen[1:]:
        if not r or not r[0]:
            continue
        d = dict(zip(kop, r))
        guid = schoon(d.get("GUID")).lower()
        if not guid:
            continue
        rij = {"rsfid": schoon(d.get("rsfid")), "naam": schoon(d.get("NAME")), "status": schoon(d.get("STATUS")),
               "gekoppeld": schoon(d.get("GEKOPPELD")), "bestand": schoon(d.get("BESTAND")),
               "naam_nlrs_2_5_2": schoon(d.get("Mapping NLRS 2.5.2")), "aanwezig_per": schoon(d.get("AANWEZIG PER"))}
        uit[guid] = rij
        per_rsfid[rij["rsfid"]] = guid
    for rij in uit.values():
        rij["opvolger"] = uit.get(per_rsfid.get(rij["gekoppeld"], ""), {}).get("naam") if rij["gekoppeld"] else None
    return {"bestand": Path(pad).name, "parameters": uit}


def lees_categorieen(pad: Path) -> dict:
    """Tabblad Category: per categorie UI-naam, OST-naam (leeg bij #REF!), integer-id, soort, pos3, pos4."""
    wb = _laad(pad, True, True)
    rijen = list(wb["Category"].iter_rows(values_only=True))
    kop = [schoon(k) for k in rijen[0]]
    lijst, ref_fouten = [], 0
    for r in rijen[1:]:
        d = dict(zip(kop, r))
        ui = schoon(d.get("UIName"))
        if not ui:
            continue
        ost = schoon(d.get("RevitName"))
        if ost.startswith("#"):
            ref_fouten += 1
            ost = ""
        lijst.append({"rsfid": schoon(d.get("rsfid")), "ui": ui, "ost": ost,
                      "id": d.get("integer"), "soort": schoon(d.get("CategoryType")),
                      "pos3": schoon(d.get("POS3-NLRSAbbreviation")), "pos4": schoon(d.get("POS4-NLRShost")),
                      "vervallen": d.get("Deprecated")})
    sub = []
    if "SubCategory" in wb.sheetnames:
        for r in list(wb["SubCategory"].iter_rows(values_only=True))[1:]:
            if r and r[3] and r[4]:
                sub.append({"categorie": schoon(r[3]), "sub": schoon(r[4])})
    wb.close()
    return {"bestand": Path(pad).name, "categorieen": lijst, "revitname_ref_fouten": ref_fouten,
            "subcategorieen": sub}


# ── Naamgenerator ─────────────────────────────────────────────────────────────

KOLOMMEN = "BCDEFGH"            # pos1..pos7
_SECTIE = re.compile(r"^\s*(\d+(?:\.\d+)*)\.?\s+(.+)$")
_CEL = re.compile(r"^\$?([A-Z]{1,2})\$?(\d+)$")


def _split_args(s: str) -> list[str]:
    """Argumenten op het hoogste niveau splitsen; let op aanhalingstekens, haakjes en [..]."""
    uit, buf, diep, blok, quote = [], "", 0, 0, False
    for ch in s:
        if quote:
            buf += ch
            if ch == '"':
                quote = False
            continue
        if ch == '"':
            quote = True
        elif ch == "[":
            blok += 1
        elif ch == "]":
            blok -= 1
        elif ch == "(" and not blok:
            diep += 1
        elif ch == ")" and not blok:
            diep -= 1
        elif ch == "," and not diep and not blok:
            uit.append(buf.strip())
            buf = ""
            continue
        buf += ch
    uit.append(buf.strip())
    return uit


def _functie(s: str) -> tuple[str, list[str]] | None:
    m = re.match(r"^([A-Z]+)\((.*)\)$", s.strip(), re.S)
    return (m.group(1), _split_args(m.group(2))) if m else None


class _Werkboek:
    """Waarden (data_only) en formules/tabellen naast elkaar."""

    def __init__(self, pad: Path):
        self.w = _laad(pad, True)
        self.f = _laad(pad, False)
        self.tabellen = {}
        for ws in self.f.worksheets:
            for t in ws.tables.values():
                self.tabellen[t.name] = (ws.title, t.ref)

    def bereik(self, blad: str, ref: str) -> list[list]:
        return [[c.value for c in rij] for rij in self.w[blad][ref]]

    def tabel(self, naam: str) -> tuple[list[str], list[list]]:
        blad, ref = self.tabellen[naam]
        rijen = self.bereik(blad, ref)
        return [schoon(k) for k in rijen[0]], rijen[1:]

    def lijst_uit_ref(self, ref: str, kolom: int) -> dict:
        """Keuzelijst voor VLOOKUP(x, ref, kolom): {code: omschrijving}, plus herkomst en randspaties."""
        ref = ref.strip()
        m = re.match(r"^'?([^'!]+)'?!\$?([A-Z]+\$?\d+:\$?[A-Z]+\$?\d+)$", ref)
        if m:
            blad, bereik = m.group(1), m.group(2).replace("$", "")
            rijen = self.bereik(blad, bereik)
            bron = f"tabblad {blad} {bereik}"
            kolommen = None
        else:
            m = re.match(r"^([A-Za-z0-9_]+)\[(.*)\]$", ref)
            if not m:
                raise ValueError(f"onbekende verwijzing {ref}")
            naam, deel = m.group(1), m.group(2)
            kop, rijen = self.tabel(naam)
            blad = self.tabellen[naam][0]
            bron = f"tabel {naam} op tabblad {blad}"
            kolommen = kop
            if deel.strip():
                kols = re.findall(r"\[([^\]]*)\]", deel)
                if kols:
                    a = kop.index(schoon(kols[0]))
                    b = kop.index(schoon(kols[-1]))
                    rijen = [r[a:b + 1] for r in rijen]
                    kolommen = kop[a:b + 1]
        codes, randspatie, leeg = {}, [], 0
        for r in rijen:
            if len(r) < kolom:
                continue
            sleutel, code = r[0], r[kolom - 1]
            if code is None or schoon(code) == "":
                leeg += 1
                continue
            if heeft_randspatie(code):
                randspatie.append(str(code))
            codes.setdefault(schoon(code), schoon(sleutel))
        return {"bron": bron, "kolom": kolom, "kolomnaam": (kolommen[kolom - 1] if kolommen and len(kolommen) >= kolom else None),
                "codes": codes, "omschrijving_naar_code": {schoon(r[0]): schoon(r[kolom - 1]) for r in rijen
                                                          if len(r) >= kolom and r[0] is not None and r[kolom - 1] is not None},
                "codes_met_spatie": randspatie, "uitbreidbaar": leeg >= 5}


def _vaste_waarden_uit_titel(titel: str) -> dict[int, list[str]]:
    """'positie 3 is altijd SYM of LAB, positie 4 is altijd UN' -> {3: [SYM, LAB], 4: [UN]}."""
    uit = {}
    for m in re.finditer(r"positie\s+(\d)\s+is\s+altijd\s+([A-Z]{2,4})(?:\s+of\s+([A-Z]{2,4}))?", titel):
        uit[int(m.group(1))] = [v for v in (m.group(2), m.group(3)) if v]
    return uit


def lees_naamgenerator(pad: Path) -> dict:
    """Secties uit het tabblad 'VOL_Naamgeving Objecten (3.1.1)'.

    Per sectie: nummer, titel, sleutel, posities (nr, naam, uitleg, voorbeeld, keuzelijst, verplicht),
    het voorbeeld (RESULTAAT) en de formule waarmee de Naamgenerator dat voorbeeld bouwt.
    De keuzelijst per positie komt uit die formule: VLOOKUP(cel; tabel; kolom) wijst de tabel en de
    kolom aan, IF(...;"DP";"MP") geeft een vaste keuze, een kale cel is vrije tekst. Aanvullend leest de
    lezer 'positie N is altijd X' uit de sectietitel en 'Is altijd X' uit de uitlegregel.
    """
    wb = _Werkboek(pad)
    blad = next(n for n in wb.w.sheetnames if n.startswith("VOL_Naamgeving"))
    ws, wf = wb.w[blad], wb.f[blad]
    rijen = []
    for r in range(1, ws.max_row + 1):
        rijen.append({k: ws[f"{k}{r}"].value for k in "BCDEFGH"} | {"_rij": r})

    secties: list[dict] = []
    huidig = None
    for rij in rijen:
        b = rij["B"]
        rest = [rij[k] for k in "CDEFGH"]
        if isinstance(b, str) and _SECTIE.match(b) and all(v is None for v in rest):
            m = _SECTIE.match(b)
            titel = " ".join(b.split())
            huidig = {"nummer": m.group(1), "titel": titel,
                      "sleutel": (m.group(1) + " " + m.group(2).split("(")[0]).strip().rstrip("."),
                      "_rijen": [], "rij": rij["_rij"]}
            if huidig["sleutel"] == m.group(1):          # '6 (Sub)Categories'
                huidig["sleutel"] = m.group(1) + " " + re.sub(r"[()]", "", m.group(2))
            huidig["sleutel"] = " ".join(huidig["sleutel"].split())
            secties.append(huidig)
        elif huidig is not None and any(v is not None for v in [b] + rest):
            huidig["_rijen"].append(rij)

    for s in secties:
        rs = s.pop("_rijen")
        res = next((r for r in rs if schoon(r["B"]).upper() == "RESULTAAT:"), None)
        if res is None:
            s["soort"] = "geen naamregel"
            s["regels"] = [" ".join(schoon(r[k]) for k in "BC" if r[k] is not None) for r in rs]
            s["posities"] = []
            continue
        i = rs.index(res)
        labels, uitleg, vb = rs[i - 3], rs[i - 2], rs[i - 1]
        s["soort"] = "naamregel"
        s["voorbeeld"] = res["C"]
        formule = wf[f"C{res['_rij']}"].value
        s["formule"] = formule
        f = _functie(formule[1:] if isinstance(formule, str) and formule.startswith("=") else "")
        if not f or f[0] != "CONCATENATE":
            s["posities"] = []
            s["fout"] = f"formule niet te lezen: {formule!r}"
            continue
        vast_titel = _vaste_waarden_uit_titel(s["titel"])
        posities, scheiders = [], []
        for arg in f[1]:
            if arg == "":
                continue
            if arg.startswith('"'):
                scheiders.append(arg.strip('"'))
                continue
            kol, lijst, herkomst = None, None, "vrije tekst (kale cel in de formule)"
            fn = _functie(arg)
            if fn and fn[0] == "VLOOKUP":
                kol = _CEL.match(fn[1][0]).group(1)
                lijst = wb.lijst_uit_ref(fn[1][1], int(fn[1][2]))
                herkomst = f"VLOOKUP in {lijst['bron']}, kolom {lijst['kolom']}"
            elif fn and fn[0] == "IF":
                cond = fn[1][0]
                kol = _CEL.match(cond.split("=")[0].strip()).group(1)
                waarde = cond.split("=", 1)[1].strip().strip('"')
                ja, nee = fn[1][1].strip().strip('"'), fn[1][2].strip().strip('"')
                lijst = {"bron": "keuze in de formule", "codes": {ja: waarde, nee: "anders"},
                         "omschrijving_naar_code": {waarde: ja}, "codes_met_spatie": [], "uitbreidbaar": False,
                         "als": {"waarde": waarde, "dan": ja, "anders": nee}}
                herkomst = f"keuze in de formule: {ja} of {nee}"
            else:
                m = _CEL.match(arg)
                if not m:
                    continue
                kol = m.group(1)
                if "tabblad <pos1>" in schoon(uitleg.get(kol)) and "Tabel3" in wb.tabellen:
                    lijst = wb.lijst_uit_ref("Tabel3[]", 1)
                    herkomst = "uitlegregel 'zie tabblad <pos1>': kolom Code van tabel Tabel3"
            nr = len(posities) + 1
            pos_excel = KOLOMMEN.index(kol) + 1
            naam = schoon(labels.get(kol))
            uitl = schoon(uitleg.get(kol))
            vast = vast_titel.get(pos_excel)
            m_altijd = re.match(r"^is altijd ([A-Z]{1,4})$", uitl, re.I)
            if vast is None and m_altijd:
                vast = [m_altijd.group(1)]
                herkomst_vast = "uitlegregel"
            else:
                herkomst_vast = "sectietitel"
            if vast:
                lijst = {"bron": herkomst_vast, "codes": {v: "" for v in vast}, "omschrijving_naar_code": {},
                         "codes_met_spatie": [], "uitbreidbaar": False}
                herkomst = f"vaste waarde uit de {herkomst_vast}: {' of '.join(vast)}"
            optioneel = "optioneel" in naam.lower() or (vb.get(kol) in (None, "") and "patroon" in naam.lower())
            posities.append({"nr": nr, "kolom_excel": kol, "naam": naam, "uitleg": uitl,
                             "voorbeeld_invoer": schoon(vb.get(kol)), "keuzelijst": lijst, "herkomst": herkomst,
                             "verplicht": not optioneel})
        s["scheiders"] = sorted(set(scheiders))
        s["posities"] = posities
    return {"bestand": Path(pad).name, "tabblad": blad, "secties": secties,
            "_werkboek": wb}


def lees_nlsfb(wb_of_pad) -> dict:
    """NL-SfB tabel 1 (versie 2021) en tabel 3 uit de Naamgenerator."""
    wb = wb_of_pad if isinstance(wb_of_pad, _Werkboek) else _Werkboek(Path(wb_of_pad))
    t1 = {}
    pos2 = set()
    kop, rijen = wb.tabel("Tabel1")
    for r in rijen:
        code = schoon(r[1])
        if code:
            t1[code] = schoon(r[2])
            if schoon(r[0]) == "<pos2>":
                pos2.add(code)
    t3 = {}
    kop, rijen = wb.tabel("Tabel5")
    for r in rijen:
        code = schoon(r[1])
        if code:
            t3[code] = schoon(r[2])
    return {"tabel1": t1, "tabel1_pos2": sorted(pos2), "tabel3": t3}


def lees_subcategorieen_naamgenerator(wb: "_Werkboek") -> dict[str, set[str]]:
    uit: dict[str, set[str]] = defaultdict(set)
    if "Tabel1012" not in wb.tabellen:
        return uit
    kop, rijen = wb.tabel("Tabel1012")
    ic = next((i for i, k in enumerate(kop) if "categor" in k.lower() and "naam" in k.lower()), 3)
    isub = next((i for i, k in enumerate(kop) if "sub" in k.lower()), 4)
    for r in rijen:
        if r[ic] and r[isub]:
            uit[schoon(r[ic])].add(schoon(r[isub]))
    return uit
