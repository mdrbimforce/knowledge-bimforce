"""De publieke NLRS-repositories ophalen naar een lokale cache, en zeggen welke stand er ligt.

De NLRS wordt beheerd door de Revit Standards Foundation op github.com/RevitStandards. Deze module
haalt drie repositories op als zip (alleen de standaardbibliotheek), of gebruikt een map die de
gebruiker opgeeft met --bron (bijvoorbeeld eigen clones).

    python ophalen.py                    # downloaden naar de cache
    python ophalen.py --bron D:\\NLRS     # map met de drie repositories als submap gebruiken
    python ophalen.py --toon             # alleen tonen wat er in de cache ligt

De cache staat in %LOCALAPPDATA%\\RevitAgent\\nlrs-bron (of ~/.revit-agent/nlrs-bron), tenzij
NLRS_BRON_CACHE iets anders zegt. Daar komt ook bron.json met per repository de herkomst, de commit
en de datum. Licenties: NLRS_Shared_Parameters en NLRS_IFC_settings zijn MIT. NLRS_Revit_Settings
heeft (stand november 2026) geen licentiebestand: die bestanden worden daarom nooit meegeleverd,
alleen bij de bron opgehaald.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import shutil
import sys
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

EIGENAAR = "RevitStandards"
REPOS = ("NLRS_Revit_Settings", "NLRS_Shared_Parameters", "NLRS_IFC_settings")
AGENT = "revit-agent-nlrs/0.1"


def cache_map() -> Path:
    if os.environ.get("NLRS_BRON_CACHE"):
        return Path(os.environ["NLRS_BRON_CACHE"])
    basis = os.environ.get("LOCALAPPDATA")
    if basis:
        return Path(basis) / "RevitAgent" / "nlrs-bron"
    return Path.home() / ".revit-agent" / "nlrs-bron"


def _get(url: str, timeout: float = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": AGENT, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _repo_info(repo: str) -> dict:
    """Standaardtak, laatste commit en datum via de publieke GitHub-API. Leeg bij een fout."""
    try:
        meta = json.loads(_get(f"https://api.github.com/repos/{EIGENAAR}/{repo}"))
        tak = meta.get("default_branch") or "main"
        c = json.loads(_get(f"https://api.github.com/repos/{EIGENAAR}/{repo}/commits/{tak}"))
        return {"tak": tak, "commit": c.get("sha"),
                "datum": ((c.get("commit") or {}).get("committer") or {}).get("date"),
                "licentie": ((meta.get("license") or {}).get("spdx_id"))}
    except (urllib.error.URLError, ValueError, OSError):
        return {}


def _veilig_uitpakken(zf: zipfile.ZipFile, doel: Path) -> None:
    """Pak een zip uit zonder dat een pad buiten de doelmap kan komen."""
    doel = doel.resolve()
    for lid in zf.infolist():
        naam = lid.filename
        delen = naam.split("/", 1)          # GitHub-zips hebben één bovenmap <repo>-<tak>/
        if len(delen) < 2 or not delen[1]:
            continue
        rel = Path(delen[1])
        if rel.is_absolute() or ".." in rel.parts:
            continue
        pad = (doel / rel).resolve()
        if doel not in pad.parents and pad != doel:
            continue
        if lid.is_dir():
            pad.mkdir(parents=True, exist_ok=True)
            continue
        pad.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(lid) as bron, open(pad, "wb") as uit:
            shutil.copyfileobj(bron, uit)


def download(repo: str, cache: Path) -> dict:
    info = _repo_info(repo)
    takken = [info["tak"]] if info.get("tak") else ["main", "master"]
    laatste_fout = ""
    for tak in takken:
        url = f"https://codeload.github.com/{EIGENAAR}/{repo}/zip/refs/heads/{tak}"
        try:
            data = _get(url, timeout=120)
        except (urllib.error.URLError, OSError) as e:
            laatste_fout = f"{url}: {e}"
            continue
        doel = cache / repo
        if doel.exists():
            shutil.rmtree(doel)
        doel.mkdir(parents=True)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            _veilig_uitpakken(zf, doel)
        return {"repo": repo, "herkomst": f"https://github.com/{EIGENAAR}/{repo}", "tak": tak,
                "commit": info.get("commit"), "datum": info.get("datum"), "licentie": info.get("licentie"),
                "pad": str(doel), "opgehaald_op": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "bytes": len(data)}
    raise RuntimeError(f"{repo} niet op te halen ({laatste_fout}). Is er internet?")


def _git_stand(map_: Path) -> dict:
    """Commit en datum van een lokale clone, zonder git aan te roepen (leest .git zelf)."""
    git = map_ / ".git"
    if not git.is_dir():
        return {}
    try:
        head = (git / "HEAD").read_text(encoding="utf-8").strip()
        sha = None
        if head.startswith("ref:"):
            ref = head.split(" ", 1)[1].strip()
            los = git / ref
            if los.is_file():
                sha = los.read_text(encoding="utf-8").strip()
            elif (git / "packed-refs").is_file():
                for r in (git / "packed-refs").read_text(encoding="utf-8").splitlines():
                    if r.endswith(" " + ref):
                        sha = r.split(" ", 1)[0]
        else:
            sha = head
        datum = None
        log = git / "logs" / "HEAD"
        if log.is_file():
            regels = log.read_text(encoding="utf-8", errors="replace").strip().splitlines()
            if regels:
                # <oud> <nieuw> <naam> <email> <tijd> <zone>\t<bericht>
                kop = regels[-1].split("\t", 1)[0].split(" ")
                if len(kop) >= 2 and kop[-2].isdigit():
                    datum = datetime.fromtimestamp(int(kop[-2]), timezone.utc).isoformat(timespec="seconds")
        return {"commit": sha, "datum_lokaal": datum}
    except OSError:
        return {}


def gebruik_map(bron: Path) -> list[dict]:
    uit = []
    for repo in REPOS:
        kand = [bron / repo, bron]
        pad = next((k for k in kand if k.is_dir() and (k.name == repo)), None)
        if pad is None:
            uit.append({"repo": repo, "pad": None, "fout": f"submap {repo} niet gevonden in {bron}"})
            continue
        st = _git_stand(pad)
        uit.append({"repo": repo, "herkomst": f"lokale map {pad}", "pad": str(pad),
                    "commit": st.get("commit"), "datum": st.get("datum_lokaal"),
                    "licentie": "MIT" if (pad / "LICENSE").is_file() else None,
                    "opgehaald_op": datetime.now(timezone.utc).isoformat(timespec="seconds")})
    return uit


def schrijf_bronlijst(cache: Path, lijst: list[dict]) -> Path:
    cache.mkdir(parents=True, exist_ok=True)
    pad = cache / "bron.json"
    pad.write_text(json.dumps({"repos": lijst}, ensure_ascii=False, indent=1), encoding="utf-8")
    return pad


def lees_bronlijst(cache: Path | None = None) -> dict:
    pad = (cache or cache_map()) / "bron.json"
    if not pad.is_file():
        return {"repos": []}
    return json.loads(pad.read_text(encoding="utf-8"))


def bronpaden(cache: Path | None = None) -> dict[str, Path]:
    """{repo: map} uit bron.json. Gooit een duidelijke fout als de bronnen nog niet zijn opgehaald."""
    lijst = lees_bronlijst(cache).get("repos", [])
    uit = {r["repo"]: Path(r["pad"]) for r in lijst if r.get("pad")}
    if "NLRS_Revit_Settings" not in uit or "NLRS_Shared_Parameters" not in uit:
        raise FileNotFoundError(
            "De NLRS-bronnen zijn nog niet opgehaald. Draai eerst: python ophalen.py "
            "(of python ophalen.py --bron <map met de repositories>).")
    return uit


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="NLRS-bronbestanden ophalen")
    ap.add_argument("--bron", help="map met de repositories als submap (eigen clones); dan geen download")
    ap.add_argument("--cache", help="cachemap (standaard %%LOCALAPPDATA%%\\RevitAgent\\nlrs-bron)")
    ap.add_argument("--toon", action="store_true", help="alleen tonen wat er nu ligt")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    cache = Path(a.cache) if a.cache else cache_map()
    if a.toon:
        lijst = lees_bronlijst(cache).get("repos", [])
    elif a.bron:
        lijst = gebruik_map(Path(a.bron))
        schrijf_bronlijst(cache, lijst)
    else:
        lijst = []
        for repo in REPOS:
            try:
                lijst.append(download(repo, cache))
            except RuntimeError as e:
                lijst.append({"repo": repo, "pad": None, "fout": str(e)})
        schrijf_bronlijst(cache, lijst)
    print(f"Cache: {cache}")
    for r in lijst:
        if r.get("fout"):
            print(f"- {r['repo']}: NIET BESCHIKBAAR. {r['fout']}")
        else:
            c = (r.get("commit") or "onbekend")[:10]
            print(f"- {r['repo']}: commit {c}, datum {r.get('datum') or 'onbekend'}, "
                  f"licentie {r.get('licentie') or 'geen licentiebestand'}, bron {r.get('herkomst')}")
    return 0 if all(not r.get("fout") for r in lijst) and lijst else 1


if __name__ == "__main__":
    raise SystemExit(main())
