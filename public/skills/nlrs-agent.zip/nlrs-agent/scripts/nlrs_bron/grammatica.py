"""NLRS-naamregels, afgeleid uit de Naamgenerator, en de toets van één naam.

    from nlrs_bron.grammatica import laad_kennis, Nlrs
    nlrs = Nlrs(laad_kennis())
    uitkomst = nlrs.toets_naam("NLRS_21_WA_beton 200mm_gen_rsf", "3.1 System Families",
                               context={"categorie": "Walls", "assembly_code": "21.12"})

laad_kennis() leest de bronbestanden één keer (openpyxl nodig) en bewaart het resultaat als
nlrs_afgeleid.json in de cache. Daarna is openpyxl niet meer nodig, tot een bronbestand verandert.

Statussen per positie en per naam: "conform", "let op" (telt als conform, met een opmerking) en
"afwijking". Een voorstel voor een betere naam heeft een zekerheid: "zeker", "waarschijnlijk" of
"vraagt een keuze" (dan staat er een <plaatshouder> in die de gebruiker moet invullen).
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ZEKER, WAARSCHIJNLIJK, KEUZE = "zeker", "waarschijnlijk", "vraagt een keuze"
_RANG = {ZEKER: 0, WAARSCHIJNLIJK: 1, KEUZE: 2}
CONFORM, LETOP, AFWIJKING = "conform", "let op", "afwijking"
_ERNST = {CONFORM: 0, LETOP: 1, AFWIJKING: 2}
KENNIS_VERSIE = 3


def _ergste(*s: str) -> str:
    return max(s, key=lambda x: _ERNST[x]) if s else CONFORM


def _minst_zeker(*z: str) -> str:
    return max(z, key=lambda x: _RANG[x]) if z else ZEKER


def _rol(p: dict) -> str:
    n = p["naam"].lower()
    lijst = p.get("keuzelijst") or {}
    if "landcode" in n:
        return "landcode"
    if "classificatiecode materiaal" in n:
        return "nlsfb3"
    if "classificatiecode" in n:
        return "nlsfb1"
    if "family category code" in n and "vaste waarde" not in p["herkomst"]:
        return "categorie"
    if "host category" in n:
        return "hostcategorie"
    if "host type" in n and "vaste waarde" not in p["herkomst"]:
        return "host"
    if "leverancier product" in n or "bronhouder" in n:
        return "leverancier"
    if "leverancier content" in n:
        return "content"
    if "vaste waarde" in p["herkomst"]:
        return "vast"
    if n.startswith("category model component"):
        return "lijncategorie"
    if n.startswith("subcategory"):
        return "subcategorie"
    if lijst:
        return "lijst"
    if "omschrijving" in n or "omschrjving" in n:
        return "omschrijving"
    return "vrij"


# ── kennis laden ──────────────────────────────────────────────────────────────

def _stempel(paden: list[Path]) -> list:
    return [[p.name, p.stat().st_size, int(p.stat().st_mtime)] for p in paden if p.is_file()]


def laad_kennis(cache: Path | None = None, ververs: bool = False) -> dict:
    """Alles wat de check uit de NLRS-bronnen nodig heeft, als één dict (en JSON-cache)."""
    from . import ophalen
    cache = cache or ophalen.cache_map()
    paden = ophalen.bronpaden(cache)
    rs, sp = paden["NLRS_Revit_Settings"], paden["NLRS_Shared_Parameters"]
    bestanden = {
        "naamgenerator": rs / "Naamgenerator_NLRS-3.1.1.xlsx",
        "categorieen": rs / "Revit categories_NLRS-3.1.1.xlsx",
        "assembly2021": rs / "RSF_NLRS_3.1.1_Assembly Code_NL-SfB2021.txt",
        "sp_totaal": sp / "NLRS_Shared Parameters - Totaal.txt",
        "sp_bronbestand": sp / "NLRS_Shared Parameters - Bronbestand.xlsx",
    }
    ontbreekt = [str(p) for p in bestanden.values() if not p.is_file()]
    if ontbreekt:
        raise FileNotFoundError("Bronbestand(en) ontbreken: " + "; ".join(ontbreekt))
    andere_txt = sorted(list(sp.glob("*.txt")) + list(rs.glob("*.txt")))
    stempel = _stempel(list(bestanden.values()) + andere_txt)
    doel = cache / "nlrs_afgeleid.json"
    if doel.is_file() and not ververs:
        try:
            oud = json.loads(doel.read_text(encoding="utf-8"))
            if oud.get("stempel") == stempel and oud.get("versie") == KENNIS_VERSIE:
                return oud
        except ValueError:
            pass
    from . import lezen
    ng = lezen.lees_naamgenerator(bestanden["naamgenerator"])
    wb = ng.pop("_werkboek")
    for s in ng["secties"]:
        for p in s.get("posities", []):
            p["rol"] = _rol(p)
    nlsfb = lezen.lees_nlsfb(wb)
    cats = lezen.lees_categorieen(bestanden["categorieen"])
    subcats: dict[str, list[str]] = {}
    for r in cats.pop("subcategorieen"):
        subcats.setdefault(r["categorie"], []).append(r["sub"])
    ac = lezen.lees_assembly_codes(bestanden["assembly2021"])
    tot = lezen.lees_shared_parameters(bestanden["sp_totaal"])
    bron = lezen.lees_bronbestand(bestanden["sp_bronbestand"])
    txt_controle = []
    for p in andere_txt:
        try:
            if "Shared Parameters" in p.name or "unittypes" in p.name:
                r = lezen.lees_shared_parameters(p)
                txt_controle.append({"bestand": p.name, "repo": p.parent.name, "dubbel_gecodeerd": r["dubbel_gecodeerd"],
                                     "parameters": len(r["parameters"]), "dubbele_guids": r["dubbele_guids"],
                                     "guids": [x["guid"] for x in r["parameters"]]})
            else:
                _, dub = lezen.lees_tekst_utf16(p)
                txt_controle.append({"bestand": p.name, "repo": p.parent.name, "dubbel_gecodeerd": dub})
        except (OSError, UnicodeError) as e:
            txt_controle.append({"bestand": p.name, "repo": p.parent.name, "fout": str(e)})
    kennis = {
        "versie": KENNIS_VERSIE, "stempel": stempel, "bron": ophalen.lees_bronlijst(cache).get("repos", []),
        "naamgenerator": {"bestand": ng["bestand"], "tabblad": ng["tabblad"]},
        "secties": ng["secties"], "nlsfb": nlsfb,
        "assembly_codes_2021": sorted(ac["codes"]), "categorieen": cats["categorieen"],
        "categorieen_ref_fouten": cats["revitname_ref_fouten"], "subcategorieen": subcats,
        "shared_parameters": {"totaal": tot["parameters"], "totaal_dubbel_gecodeerd": tot["dubbel_gecodeerd"],
                              "bronbestand": bron["parameters"], "txt_controle": txt_controle},
    }
    cache.mkdir(parents=True, exist_ok=True)
    doel.write_text(json.dumps(kennis, ensure_ascii=False), encoding="utf-8")
    return kennis


# ── de toets ──────────────────────────────────────────────────────────────────

class Nlrs:
    def __init__(self, kennis: dict, eigen_afkortingen: dict | None = None):
        self.k = kennis
        self.secties = {s["sleutel"]: s for s in kennis["secties"]}
        self.eigen = {k: {str(v) for v in vs} for k, vs in (eigen_afkortingen or {}).items()}
        # categorie -> pos3-code: Revit categories-lijst eerst, anders de pos3-tabel van de Naamgenerator
        self.cat_ui, self.cat_ost, self.cat_soort = {}, {}, {}
        for c in kennis["categorieen"]:
            if c["pos3"]:
                self.cat_ui.setdefault(c["ui"].lower(), c["pos3"])
                if c["ost"]:
                    self.cat_ost.setdefault(c["ost"], c["pos3"])
            self.cat_soort[c["ui"].lower()] = c["soort"]
            if c["ost"]:
                self.cat_soort[c["ost"]] = c["soort"]
        lijst3 = self._lijst("3.1 Loadable families", "categorie")
        self.pos3_tabel = {k.lower(): v for k, v in (lijst3 or {}).get("omschrijving_naar_code", {}).items()}
        self.subcats = {k.lower(): {s.lower() for s in v} for k, v in kennis.get("subcategorieen", {}).items()}

    def _lijst(self, sleutel: str, rol: str) -> dict | None:
        s = self.secties.get(sleutel)
        for p in (s or {}).get("posities", []):
            if p["rol"] == rol:
                return p["keuzelijst"]
        return None

    def categorie_code(self, categorie: str | None = None, ost: str | None = None) -> str | None:
        if ost and ost in self.cat_ost:
            return self.cat_ost[ost]
        if ost and not categorie:
            # RevitName is in de categorielijst vaak #REF!; probeer OST_LightingFixtures -> Lighting Fixtures
            kaal = ost.removeprefix("OST_").lower()
            for ui, code in self.cat_ui.items():
                u = ui.replace(" ", "")
                if u == kaal or u == kaal + "s":
                    return code
        if categorie:
            return self.cat_ui.get(categorie.lower()) or self.pos3_tabel.get(categorie.lower())
        return None

    def is_annotatie(self, categorie: str | None = None, ost: str | None = None) -> bool:
        s = self.cat_soort.get(ost or "") or self.cat_soort.get((categorie or "").lower())
        return s == "Annotation"

    # -- ontleden --
    def ontleed(self, naam: str, sleutel: str) -> tuple[list[tuple[dict, str | None]], list[str]]:
        """[(positie, token)] en meldingen over het aantal posities."""
        s = self.secties[sleutel]
        pos = s["posities"]
        tok = naam.split("_")
        meld: list[str] = []
        n = len(pos)
        if len(tok) == n:
            return list(zip(pos, tok)), meld
        if len(tok) < n:
            houd = list(pos)
            for p in reversed(pos):
                if len(houd) == len(tok):
                    break
                if not p["verplicht"]:
                    houd.remove(p)
            if len(houd) == len(tok):
                return list(zip(houd, tok)), meld
            meld.append(f"te weinig posities: {len(tok)} in plaats van {sum(p['verplicht'] for p in pos)}")
            return [(p, tok[i] if i < len(tok) else None) for i, p in enumerate(pos)], meld
        extra = len(tok) - n
        if pos[-1]["rol"] in ("omschrijving", "vrij") and not pos[-1].get("keuzelijst"):
            return list(zip(pos[:-1], tok[:n - 1])) + [(pos[-1], "_".join(tok[n - 1:]))], meld
        oms = [i for i, p in enumerate(pos) if p["rol"] == "omschrijving"]
        if len(oms) == 1:
            i = oms[0]
            midden = "_".join(tok[i:i + extra + 1])
            meld.append(f"de omschrijving bevat een _ ('{midden}'); het scheidingsteken hoort alleen tussen posities")
            return list(zip(pos[:i], tok[:i])) + [(pos[i], midden)] + list(zip(pos[i + 1:], tok[i + extra + 1:])), meld
        meld.append(f"te veel posities: {len(tok)} in plaats van {n}")
        return list(zip(pos, tok)), meld

    def _codes(self, p: dict) -> tuple[dict, bool]:
        kl = p.get("keuzelijst") or {}
        codes = dict(kl.get("codes", {}))
        for c in self.eigen.get(p["rol"], set()):
            codes.setdefault(c, "eigen afkorting (nlrs-uitzonderingen.json)")
        return codes, bool(kl.get("uitbreidbaar"))

    def toets_positie(self, p: dict, token: str | None, context: dict) -> tuple[str, str]:
        if token is None or token.strip() == "":
            if not p["verplicht"]:
                return CONFORM, ""
            return AFWIJKING, f"positie {p['nr']} ({p['naam']}) ontbreekt of is leeg"
        status, melding = CONFORM, ""
        if token != token.strip() or "\xa0" in token:
            status, melding = LETOP, f"spatie of harde spatie aan de rand van '{token}'"
        t = token.replace("\xa0", " ").strip()
        codes, uitbreidbaar = self._codes(p)
        if codes:
            if t in codes:
                pass
            elif t.lower() in {c.lower() for c in codes}:
                goed = next(c for c in codes if c.lower() == t.lower())
                return AFWIJKING, f"'{t}' moet '{goed}' zijn (hoofdletters)"
            elif uitbreidbaar:
                status = _ergste(status, LETOP)
                melding = (f"'{t}' staat niet in de lijst van de Naamgenerator ({', '.join(list(codes)[:6])}); "
                           "eigen afkortingen mogen, zet ze dan in nlrs-uitzonderingen.json")
            else:
                voorbeeld = ", ".join(list(codes)[:8]) + (" ..." if len(codes) > 8 else "")
                return AFWIJKING, f"'{t}' staat niet in de keuzelijst ({p['herkomst']}): {voorbeeld}"
        rol = p["rol"]
        if rol == "categorie" and (context.get("categorie") or context.get("ost")):
            verwacht = self.categorie_code(context.get("categorie"), context.get("ost"))
            if verwacht and t != verwacht:
                return AFWIJKING, (f"het element is van de categorie {context.get('categorie') or context.get('ost')}; "
                                   f"de code hoort {verwacht} te zijn, niet {t}")
        if rol == "nlsfb1" and context.get("assembly_code"):
            ac = str(context["assembly_code"]).split(".")[0].strip()
            if ac and ac != t and t[:1] != ac[:1] + "-" and not (t.endswith("-") and ac.startswith(t[0])):
                status = _ergste(status, LETOP)
                melding = f"de naam zegt NL-SfB {t}, de Assembly Code zegt {context['assembly_code']}"
        if rol == "lijncategorie":
            if t.lower() not in self.cat_ui and t.lower() not in self.pos3_tabel:
                status = _ergste(status, LETOP)
                melding = f"'{t}' is geen Revit-categorie uit de categorielijst van de NLRS"
        if rol == "subcategorie" and context.get("_lijncategorie"):
            subs = self.subcats.get(context["_lijncategorie"].lower(), set())
            if subs and t.lower() not in subs and t.replace("-", "/").lower() not in subs:
                status = _ergste(status, LETOP)
                melding = (f"'{t}' is geen subcategorie van {context['_lijncategorie']} in de categorielijst "
                           "(een / in de naam schrijf je als -)")
        return status, melding

    def toets_naam(self, naam: str, sleutel: str, context: dict | None = None) -> dict:
        context = dict(context or {})
        delen, meld = self.ontleed(naam, sleutel)
        status = AFWIJKING if meld else CONFORM
        posities = []
        for p, t in delen:
            if p["rol"] == "lijncategorie" and t:
                context["_lijncategorie"] = t.strip()
            st, m = self.toets_positie(p, t, context)
            if "bevat een _" in " ".join(meld) and p["rol"] == "omschrijving" and t and "_" in t:
                st, m = AFWIJKING, meld[0]
            status = _ergste(status, st)
            posities.append({"nr": p["nr"], "naam": p["naam"], "token": t, "status": st, "melding": m})
        if meld and not meld[0].startswith("de omschrijving"):
            opbouw = "_".join(f"<{p['naam']}>" for p in self.secties[sleutel]["posities"])
            meldingen = [f"{meld[0]}; de opbouw is {opbouw}"]
        else:
            meldingen = meld + [f"positie {x['nr']} ({x['naam']}): {x['melding']}" for x in posities
                                if x["melding"] and x["status"] != CONFORM and x["melding"] not in meld]
        return {"naam": naam, "sectie": sleutel, "status": status, "posities": posities, "meldingen": meldingen}

    # -- voorstel --
    def voorstel(self, naam: str, sleutel: str, context: dict | None = None,
                 standaard_content: str | None = None) -> tuple[str, str, list[str]] | None:
        """(nieuwe naam, zekerheid, uitleg) of None als er niets beters te zeggen is."""
        context = context or {}
        s = self.secties[sleutel]
        pos = s["posities"]
        tok = [t.replace("\xa0", " ").strip() for t in naam.split("_")]
        tok = [t for t in tok if t != ""]
        uit: dict[int, str] = {}
        zeker: list[str] = []
        uitleg: list[str] = []

        def codes(p):
            return self._codes(p)[0]

        def match(p, t):
            c = codes(p)
            if t in c:
                return t
            low = {k.lower(): k for k in c}
            return low.get(t.lower())

        # 1. landcode vooraan
        landpos = [p for p in pos if p["rol"] == "landcode"]
        if landpos:
            p = landpos[0]
            m = match(p, tok[0]) if tok else None
            if m:
                tok.pop(0)
                uit[p["nr"]] = m
            else:
                uit[p["nr"]] = "NLRS"
                zeker.append(WAARSCHIJNLIJK)
                uitleg.append("landcode NLRS toegevoegd")
        rest = [p for p in pos if p["nr"] not in uit]
        oms = next((i for i, p in enumerate(rest) if p["rol"] == "omschrijving"), len(rest))
        voor, omsp, na = rest[:oms], (rest[oms] if oms < len(rest) else None), rest[oms + 1:]

        # 2. posities na de omschrijving, van achteren
        for p in reversed(na):
            t = tok[-1] if tok else None
            m = match(p, t) if (t is not None and codes(p)) else None
            if m and len(tok) > 1:
                uit[p["nr"]] = m
                tok.pop()
            elif not codes(p) and not p["verplicht"]:
                uit[p["nr"]] = ""
            elif p["rol"] == "leverancier":
                uit[p["nr"]] = "gen"
                zeker.append(WAARSCHIJNLIJK)
                uitleg.append(f"positie {p['nr']} op 'gen' (generiek) gezet")
            elif p["rol"] == "content":
                if standaard_content:
                    uit[p["nr"]] = standaard_content
                    zeker.append(WAARSCHIJNLIJK)
                    uitleg.append(f"positie {p['nr']} op de eigen content-afkorting '{standaard_content}' gezet")
                else:
                    uit[p["nr"]] = "<content>"
                    zeker.append(KEUZE)
                    uitleg.append(f"positie {p['nr']}: kies wie de content maakt (rsf, rgg of eigen afkorting)")
            elif not codes(p) and len(tok) > 1:
                uit[p["nr"]] = tok.pop()
            else:
                uit[p["nr"]] = f"<{p['naam'].split(' ')[0].lower()}>"
                zeker.append(KEUZE)
                uitleg.append(f"positie {p['nr']} ({p['naam']}): kies een waarde")

        # 3. posities voor de omschrijving, van voren
        for p in voor:
            t = tok[0] if tok else None
            rol = p["rol"]
            if rol == "categorie":
                verwacht = self.categorie_code(context.get("categorie"), context.get("ost"))
                if t is not None and (match(p, t) or re.fullmatch(r"[A-Z]{1,6}", t)) and (t != verwacht or True):
                    if match(p, t) or (t.isupper() and len(tok) > 1):
                        tok.pop(0)
                if verwacht:
                    uit[p["nr"]] = verwacht
                    if t != verwacht:
                        uitleg.append(f"categoriecode {verwacht} uit de Revit-categorie")
                else:
                    m = match(p, t) if t else None
                    uit[p["nr"]] = m or "<categorie>"
                    if not m:
                        zeker.append(KEUZE)
                continue
            m = match(p, t) if (t is not None and codes(p)) else None
            if m:
                uit[p["nr"]] = m
                tok.pop(0)
                continue
            if rol == "vast" and len(codes(p)) == 1:
                uit[p["nr"]] = next(iter(codes(p)))
                uitleg.append(f"positie {p['nr']} is altijd {uit[p['nr']]}")
                if t is not None and (t.isupper() and len(t) <= 4):
                    tok.pop(0)
                continue
            if rol == "nlsfb1" and context.get("assembly_code"):
                ac = str(context["assembly_code"]).split(".")[0].strip()
                if ac in codes(p):
                    uit[p["nr"]] = ac
                    zeker.append(WAARSCHIJNLIJK)
                    uitleg.append(f"NL-SfB {ac} uit de Assembly Code {context['assembly_code']}")
                    if t is not None and re.fullmatch(r"\d{2}|\d-", t):
                        tok.pop(0)
                    continue
            if not codes(p) and t is not None and len(tok) > 1:
                uit[p["nr"]] = tok.pop(0)
                continue
            uit[p["nr"]] = f"<{p['naam'].split(' ')[0].lower()}>"
            zeker.append(KEUZE)
            uitleg.append(f"positie {p['nr']} ({p['naam']}): kies een waarde uit {p['herkomst']}")
            onbruikbaar = r"\d{2}|[A-Z]{2,4}" + (r"|[a-z]{1,2}\d?" if rol == "nlsfb3" else "")
            if t is not None and re.fullmatch(onbruikbaar, t) and len(tok) > 1:
                tok.pop(0)          # een onbruikbare code, geen omschrijving

        # 4. de omschrijving is wat overblijft
        if omsp is not None:
            if tok:
                uit[omsp["nr"]] = " ".join(tok)
                if len(tok) > 1:
                    uitleg.append("delen van de omschrijving samengevoegd met een spatie")
            else:
                uit[omsp["nr"]] = "<omschrijving>"
                zeker.append(KEUZE)
        nieuw = "_".join(uit[p["nr"]] for p in pos if not (uit.get(p["nr"]) == "" and not p["verplicht"]))
        if nieuw == naam:
            return None
        return nieuw, _minst_zeker(*zeker) if zeker else ZEKER, uitleg

    # -- voorbeelden van de Naamgenerator --
    def herbereken_voorbeeld(self, sleutel: str) -> str:
        """Bouw het voorbeeld opnieuw uit de invoer in de Naamgenerator en de afgeleide keuzelijsten."""
        s = self.secties[sleutel]
        delen = []
        for p in s["posities"]:
            inv = p["voorbeeld_invoer"]
            kl = p.get("keuzelijst") or {}
            if "als" in kl:
                delen.append(kl["als"]["dan"] if inv == kl["als"]["waarde"] else kl["als"]["anders"])
            elif kl and "vaste waarde" not in p["herkomst"] and kl.get("omschrijving_naar_code"):
                delen.append(kl["omschrijving_naar_code"].get(inv, inv if inv in kl["codes"] else f"#N/B({inv})"))
            else:
                delen.append(inv)
        return "_".join(delen)
