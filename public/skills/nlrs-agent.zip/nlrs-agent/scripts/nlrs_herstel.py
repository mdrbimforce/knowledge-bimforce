"""Voert een goedgekeurd NLRS-herstelplan uit via de bridge. Standaard als proef (dry_run).

Alleen acties met 'uitvoeren' = true (JSON) of 'ja' (Excel, tabblad Herstelplan) en zonder
<plaatshouder> gaan mee. Het model wordt nooit bewaard: dat doet de gebruiker zelf in Revit.

    python nlrs_herstel.py --plan nlrs-rapport/nlrs-herstelplan.json            # proef
    python nlrs_herstel.py --plan nlrs-rapport/nlrs-rapport.xlsx                # proef, plan uit Excel
    python nlrs_herstel.py --plan ... --uitvoeren                               # echt, na akkoord
    python nlrs_herstel.py --plan ... --toon                                    # alleen laten zien, geen bridge

Schrijft in --uit (standaard de map van het plan):
  nlrs-herstel-logboek-<tijd>.json   elk verzoek en elk antwoord
  nlrs-terugdraai-<tijd>.json        alleen bij --uitvoeren: een herstelplan dat de wijzigingen terugdraait
"""
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):   # in de zip: scripts/; in de repo: shared/
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import argparse  # noqa: E402
import json  # noqa: E402
from datetime import datetime  # noqa: E402

JA = {"ja", "j", "yes", "y", "true", "1", "x", "waar"}


def lees_plan(pad: Path) -> dict:
    if pad.suffix.lower() in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(pad, data_only=True, read_only=True)
        rijen = list(wb["Herstelplan"].iter_rows(values_only=True))
        wb.close()
        kop = [str(k) for k in rijen[0]]
        acties = []
        for r in rijen[1:]:
            if not r or r[1] is None:
                continue
            a = dict(zip(kop, r))
            a["uitvoeren"] = str(a.get("uitvoeren") or "").strip().lower() in JA
            acties.append(a)
        doc = None
        jsonpad = pad.with_name("nlrs-herstelplan.json")
        if jsonpad.is_file():
            doc = json.loads(jsonpad.read_text(encoding="utf-8")).get("document")
        return {"document": doc, "acties": acties}
    plan = json.loads(pad.read_text(encoding="utf-8-sig"))
    if plan.get("formaat") != "nlrs-herstelplan/1":
        raise ValueError(f"{pad} is geen NLRS-herstelplan")
    return plan


def kies(acties: list[dict]) -> tuple[list[dict], list[str]]:
    gekozen, weg = [], []
    for a in acties:
        if not a.get("uitvoeren"):
            continue
        doel = str(a.get("nieuwe_naam") or a.get("nieuwe_waarde") or "")
        if not doel or "<" in doel:
            weg.append(f"{a['id']}: nog een <plaatshouder> of leeg; overgeslagen")
            continue
        if a.get("element_id") in (None, ""):
            weg.append(f"{a['id']}: geen element-id; overgeslagen")
            continue
        if a["soort"] not in ("hernoem", "waarde", "materiaalklasse"):
            weg.append(f"{a['id']}: soort {a['soort']} wordt niet automatisch uitgevoerd")
            continue
        gekozen.append(a)
    return gekozen, weg


def verzoeken(gekozen: list[dict], doc: str, proef: bool) -> list[tuple[str, dict, list[dict]]]:
    uit = []
    hern = [a for a in gekozen if a["soort"] == "hernoem"]
    if hern:
        uit.append(("rename_element", {"target_document": doc, "dry_run": proef, "save_first": False,
                                       "renames": [{"element_id": int(a["element_id"]), "new_name": a["nieuwe_naam"],
                                                    "expected_name": a["huidige_naam"]} for a in hern]}, hern))
    wd = [a for a in gekozen if a["soort"] == "waarde"]
    if wd:
        uit.append(("set_parameter_values_bulk", {"target_document": doc, "dry_run": proef, "edits": [
            {"element_id": int(a["element_id"]), "param": a["parameter"], "value": str(a["nieuwe_waarde"]),
             "target": "instance"} for a in wd]}, wd))
    mk = [a for a in gekozen if a["soort"] == "materiaalklasse"]
    if mk:
        uit.append(("set_material_class", {"target_document": doc, "dry_run": proef, "edits": [
            {"element_id": int(a["element_id"]), "material_class": str(a["nieuwe_waarde"])} for a in mk]}, mk))
    return uit


def terugdraai(opdracht: str, acties: list[dict], data) -> list[dict]:
    """Acties die een uitgevoerde wijziging terugdraaien, op basis van het antwoord van Revit."""
    uit = []
    per_id = {int(a["element_id"]): a for a in acties}
    if opdracht == "rename_element":
        for r in (data or {}).get("results", []):
            if r.get("status") == "renamed":
                uit.append({"soort": "hernoem", "element_id": r["element_id"], "huidige_naam": r.get("new_name"),
                            "nieuwe_naam": r.get("old_name"), "zekerheid": "zeker", "uitvoeren": True})
    elif opdracht == "set_parameter_values_bulk":
        if (data or {}).get("geschreven"):
            for a in acties:
                uit.append({"soort": "waarde", "element_id": a["element_id"], "parameter": a["parameter"],
                            "huidige_waarde": a["nieuwe_waarde"], "nieuwe_waarde": a.get("huidige_waarde") or "",
                            "zekerheid": "zeker", "uitvoeren": bool(a.get("huidige_waarde")),
                            "opmerking": "" if a.get("huidige_waarde") else "was leeg; leegmaken kan niet via deze opdracht"})
    elif opdracht == "set_material_class":
        for r in (data or {}).get("results", []):
            if r.get("status") == "set" and int(r.get("element_id") or 0) in per_id:
                uit.append({"soort": "materiaalklasse", "element_id": r["element_id"], "huidige_waarde": r.get("material_class"),
                            "nieuwe_waarde": r.get("current_class") or "", "zekerheid": "zeker",
                            "uitvoeren": bool(r.get("current_class"))})
    return uit


def samenvatting(opdracht: str, data) -> list[str]:
    if not isinstance(data, dict):
        return [f"{opdracht}: onverwacht antwoord"]
    if opdracht == "rename_element":
        from collections import Counter
        c = Counter(r.get("status") for r in data.get("results", []))
        regels = [f"hernoemen: " + ", ".join(f"{k} {v}" for k, v in c.items())]
        regels += [f"  {r.get('element_id')}: '{r.get('old_name')}' -> '{r.get('new_name')}' {r.get('status')}"
                   + (f" ({r.get('error')})" if r.get("error") else "") for r in data.get("results", [])]
        return regels
    if opdracht == "set_parameter_values_bulk":
        return [f"waarden: gevraagd {data.get('gevraagd')}, zou schrijven {data.get('zou_schrijven')}, "
                f"geschreven {data.get('geschreven')}, fouten {data.get('fouten_totaal')}"]
    return [f"materiaalklasse: " + ", ".join(f"{r.get('element_id')} {r.get('status')}" for r in data.get("results", []))]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="NLRS-herstelplan uitvoeren (standaard als proef)")
    ap.add_argument("--plan", required=True)
    ap.add_argument("--document", help="titel van het open model (standaard die uit het plan)")
    ap.add_argument("--uitvoeren", action="store_true", help="echt uitvoeren; zonder deze vlag is het een proef")
    ap.add_argument("--toon", action="store_true", help="alleen tonen welke acties meegaan")
    ap.add_argument("--uit", help="map voor logboek en terugdraailijst")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    pad = Path(a.plan)
    plan = lees_plan(pad)
    gekozen, weg = kies(plan["acties"])
    doc = a.document or (plan.get("document") or {}).get("titel")
    print(f"Plan: {pad.name}. Aangevinkt en uitvoerbaar: {len(gekozen)} van {len(plan['acties'])} acties.")
    for w in weg:
        print(f"  {w}")
    for x in gekozen:
        doel = x.get("nieuwe_naam") or f"{x.get('parameter') or 'klasse'} = {x.get('nieuwe_waarde')}"
        print(f"  {x['id']} {x['soort']}: {x.get('huidige_naam')} -> {doel}")
    if a.toon or not gekozen:
        return 0
    if not doc:
        print("FOUT: geen model bekend; geef --document.")
        return 3

    from revit_agent.bridge import BridgeError, call
    proef = not a.uitvoeren
    tijd = datetime.now().strftime("%Y%m%d-%H%M%S")
    uitmap = Path(a.uit) if a.uit else pad.parent
    uitmap.mkdir(parents=True, exist_ok=True)
    logboek = {"plan": str(pad), "document": doc, "proef": proef, "tijd": tijd, "stappen": []}
    terug: list[dict] = []
    code = 0
    try:
        open_docs = [d.get("title") for d in (call("get_open_documents", {}, timeout=30) or [])]
        if doc not in open_docs:
            print(f"FOUT: model '{doc}' is niet open in Revit (open: {', '.join(map(str, open_docs))}).")
            return 3
        print(("PROEF: er verandert niets in het model." if proef else "UITVOEREN: het model wordt gewijzigd, niet bewaard."))
        for opdracht, params, acties in verzoeken(gekozen, doc, proef):
            stap = {"opdracht": opdracht, "params": params}
            try:
                data = call(opdracht, params, timeout=300)
                stap["antwoord"] = data
                for regel in samenvatting(opdracht, data):
                    print(regel)
                if not proef:
                    terug += terugdraai(opdracht, acties, data)
            except BridgeError as e:
                stap["fout"] = str(e)
                print(f"FOUT bij {opdracht}: {e}")
                code = 2
                if e.soort in ("time-out", "geen-verbinding"):
                    print("Gestopt. Kijk in Revit of er een dialoogvenster openstaat; stuur niets opnieuw voordat je weet wat er gebeurd is.")
                    logboek["stappen"].append(stap)
                    break
            logboek["stappen"].append(stap)
    finally:
        lp = uitmap / f"nlrs-herstel-logboek-{tijd}.json"
        lp.write_text(json.dumps(logboek, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"Logboek: {lp}")
        if terug:
            for i, t in enumerate(terug, 1):
                t["id"] = f"T{i:04d}"
                t.setdefault("opmerking", "")
            tp = uitmap / f"nlrs-terugdraai-{tijd}.json"
            tp.write_text(json.dumps({"formaat": "nlrs-herstelplan/1", "document": {"titel": doc},
                                      "uitleg": "Terugdraailijst: voer uit met nlrs_herstel.py --plan <dit bestand>.",
                                      "acties": terug}, ensure_ascii=False, indent=1), encoding="utf-8")
            print(f"Terugdraailijst: {tp}")
    if not proef:
        print("Het model is gewijzigd maar niet bewaard. Bewaren doet de gebruiker zelf in Revit.")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
