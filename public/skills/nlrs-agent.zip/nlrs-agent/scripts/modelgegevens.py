"""Modelgegevens voor de NLRS-check: ophalen via de bridge (alleen leesopdrachten) of lezen uit een bestand.

Het bestandsformaat ('nlrs-modelgegevens/1') is ook wat --bewaar-gegevens schrijft, zodat een model
één keer uit Revit gelezen kan worden en daarna zonder Revit te controleren is:

{
  "formaat": "nlrs-modelgegevens/1",
  "document": {"titel": "...", "pad": "..."},
  "families":   [{"id", "naam", "categorie", "ost"}],
  "types":      [{"id", "naam", "soort": "loadable"|"system", "type_id", "familie", "familie_id",
                  "categorie", "ost", "assembly_code"}],
  "materialen": [{"id", "naam", "klasse"}],
  "stijlen":    {"fill_patterns": [{"id", "naam"}], "line_patterns": [...], "line_styles": [...],
                 "text_note_types": [...], "dimension_types": [...], "view_family_types": [...],
                 "view_templates": [...], "view_filters": [...]},
  "parameters": [{"naam", "guid", "bron": "shared_element"|"binding", "binding": "type"|"instance"|null,
                  "categorieen": [...]}],
  "overgeslagen": [{"onderdeel", "reden"}]
}

Gebruikte bridge-opdrachten (alle lezend, uit de kernlijst): get_open_documents, get_families_loaded,
query_elements, read_parameter_values, list_parameter_bindings, get_element_detail.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

FORMAAT = "nlrs-modelgegevens/1"

SYSTEEMTYPES = [
    "wall_type", "floor_type", "ceiling_type", "roof_type", "stairs_type", "railing_type",
    "curtain_system_type", "mullion_type", "slab_edge_type", "fascia_type", "gutter_type",
    "structural_connection_type", "beam_system_type", "structural_foundation_type",
    "stairs_run_type", "stairs_landing_type", "stairs_support_type", "handrail_type", "toprail_type",
    "roof_soffit_type", "ramp_type", "toposolid_type", "building_pad_type",
    "duct_type", "pipe_type", "conduit_type", "cable_tray_type", "duct_insulation_type",
    "pipe_insulation_type", "duct_lining_type", "flex_duct_type", "flex_pipe_type", "wire_type",
    "duct_system_type", "piping_system_type",
]
STIJLEN = ["fill_patterns", "line_patterns", "line_styles", "text_note_types", "dimension_types",
           "view_family_types", "view_templates", "view_filters"]
TIME_OUT = 120


def leeg() -> dict:
    return {"formaat": FORMAAT, "document": {}, "families": [], "types": [], "materialen": [],
            "stijlen": {k: [] for k in STIJLEN}, "parameters": [], "overgeslagen": []}


def lees_bestand(pad: Path) -> dict:
    d = json.loads(Path(pad).read_text(encoding="utf-8-sig"))
    if d.get("formaat") != FORMAAT:
        raise ValueError(f"{pad} is geen bestand met NLRS-modelgegevens (formaat {FORMAAT}).")
    basis = leeg()
    basis.update(d)
    for k in STIJLEN:
        basis["stijlen"].setdefault(k, [])
    basis["bron"] = f"bestand {Path(pad).name}"
    return basis


def bewaar(gegevens: dict, pad: Path) -> None:
    Path(pad).write_text(json.dumps(gegevens, ensure_ascii=False, indent=1), encoding="utf-8")


# ── via de bridge ─────────────────────────────────────────────────────────────

def kies_document(call, gevraagd: str | None) -> dict:
    docs = call("get_open_documents", {}, timeout=30) or []
    projecten = [d for d in docs if not d.get("is_family")]
    if gevraagd:
        for d in docs:
            if d.get("title") == gevraagd:
                return d
        raise ValueError(f"Model '{gevraagd}' is niet open. Open zijn: {', '.join(d.get('title', '?') for d in docs)}")
    if len(projecten) == 1:
        return projecten[0]
    if not projecten:
        raise ValueError("Er is geen projectmodel open in Revit.")
    raise ValueError("Er zijn meer modellen open; kies er één met --document: "
                     + ", ".join(d.get("title", "?") for d in projecten))


def _elementen(call, type_id: str, doc: str, extra: dict | None = None) -> list[dict]:
    params = {"type_id": type_id, "target_document": doc}
    params.update(extra or {})
    data = call("query_elements", params, timeout=TIME_OUT) or {}
    return [e for e in data.get("elements", []) if e.get("name") is not None
            and (e.get("document_title") in (None, doc))]


def _parameterwaarden(call, doc: str, ids: list[int], namen: list[str]) -> dict[int, dict]:
    uit: dict[int, dict] = {}
    for i in range(0, len(ids), 1000):
        blok = ids[i:i + 1000]
        offset = 0
        while True:
            data = call("read_parameter_values", {"target_document": doc, "element_ids": blok, "params": namen,
                                                  "offset": offset, "limit": 5000}, timeout=TIME_OUT) or {}
            for r in data.get("rows", []):
                uit[int(r["element_id"])] = {n: ((r.get("values") or {}).get(n) or {}).get("value")
                                             for n in namen} | {"_ontbreekt": [n for n in namen if (r.get("values") or {}).get(n) is None]}
            if not data.get("volgende_offset"):
                break
            offset = data["volgende_offset"]
    return uit


class BridgeGestopt(BaseException):
    """Revit antwoordt niet (meer). Bewust geen Exception: niets mag dit wegvangen en doorgaan."""


def _bewaakt(call):
    def wrap(command, params=None, timeout=TIME_OUT):
        try:
            return call(command, params, timeout=timeout)
        except Exception as e:  # noqa: BLE001
            if getattr(e, "soort", "") in ("time-out", "geen-verbinding"):
                raise BridgeGestopt(str(e)) from e
            raise
    return wrap


def haal_op(call, document: str | None = None, melding=print) -> dict:
    """Lees het model via de bridge. `call(command, params, timeout=...)` is revit_agent.bridge.call.

    Een time-out of verbroken verbinding stopt het ophalen meteen (BridgeGestopt): niet blind herhalen,
    de gebruiker laten kijken in Revit."""
    call = _bewaakt(call)
    g = leeg()
    g["bron"] = "bridge"
    g["opgehaald_op"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    d = kies_document(call, document)
    doc = d["title"]
    g["document"] = {"titel": doc, "pad": d.get("path") or ""}
    melding(f"Model: {doc}")

    # families
    cat_per_naam = {}
    try:
        for f in call("get_families_loaded", {"target_document": doc}, timeout=TIME_OUT) or []:
            cat_per_naam[f.get("name")] = f.get("category")
    except Exception as e:  # noqa: BLE001
        g["overgeslagen"].append({"onderdeel": "categorienamen van families", "reden": str(e)})
    fams = _elementen(call, "loadable_family", doc)
    for e in fams:
        g["families"].append({"id": e["element_id"], "naam": e["name"], "ost": e.get("builtin_category"),
                              "categorie": e.get("category_name") or cat_per_naam.get(e["name"])})
    melding(f"  families: {len(g['families'])}")
    fam_per_id = {f["id"]: f for f in g["families"]}

    # types binnen loadable families
    try:
        syms = _elementen(call, "family_symbol", doc)
        for e in syms:
            fam = fam_per_id.get(e.get("parent_id")) or {}
            g["types"].append({"id": e["element_id"], "naam": e["name"], "soort": "loadable", "type_id": "family_symbol",
                               "familie": fam.get("naam"), "familie_id": e.get("parent_id"),
                               "categorie": fam.get("categorie") or e.get("category_name"),
                               "ost": e.get("builtin_category") or fam.get("ost"), "assembly_code": e.get("assembly_code")})
        ids = [t["id"] for t in g["types"] if not t.get("assembly_code")]
        if ids:
            w = _parameterwaarden(call, doc, ids, ["Assembly Code"])
            for t in g["types"]:
                if t["id"] in w and not t.get("assembly_code"):
                    t["assembly_code"] = w[t["id"]].get("Assembly Code")
    except Exception as e:  # noqa: BLE001
        g["overgeslagen"].append({"onderdeel": "types binnen loadable families", "reden": str(e)})

    # systeemtypes
    n = 0
    for tid in SYSTEEMTYPES:
        try:
            for e in _elementen(call, tid, doc):
                g["types"].append({"id": e["element_id"], "naam": e["name"], "soort": "system", "type_id": tid,
                                   "familie": e.get("family_name"), "familie_id": None,
                                   "categorie": e.get("category_name"), "ost": e.get("builtin_category"),
                                   "assembly_code": e.get("assembly_code")})
                n += 1
        except Exception as e:  # noqa: BLE001
            g["overgeslagen"].append({"onderdeel": f"systeemtypes {tid}", "reden": str(e)})
    melding(f"  types: {len(g['types'])} (waarvan systeemtypes {n})")

    # materialen + klasse
    try:
        mats = _elementen(call, "materials", doc)
        g["materialen"] = [{"id": e["element_id"], "naam": e["name"], "klasse": e.get("material_class")} for e in mats]
        ids = [m["id"] for m in g["materialen"]]
        if ids:
            w = _parameterwaarden(call, doc, ids, ["Class"])
            gevonden = 0
            for m in g["materialen"]:
                if m["id"] in w and "Class" not in w[m["id"]]["_ontbreekt"]:
                    m["klasse"] = w[m["id"]].get("Class") or ""
                    gevonden += 1
            if not gevonden:
                if len(ids) > 400:
                    g["overgeslagen"].append({"onderdeel": "materiaalklasse",
                                              "reden": "parameter 'Class' niet leesbaar en meer dan 400 materialen"})
                else:
                    for m in g["materialen"]:
                        det = call("get_element_detail", {"type_id": "materials", "element_id": m["id"],
                                                          "target_document": doc}, timeout=30) or {}
                        m["klasse"] = (det.get("properties") or {}).get("material_class") or ""
        melding(f"  materialen: {len(g['materialen'])}")
    except Exception as e:  # noqa: BLE001
        g["overgeslagen"].append({"onderdeel": "materialen", "reden": str(e)})

    # stijlen en views
    for tid in STIJLEN:
        try:
            g["stijlen"][tid] = [{"id": e["element_id"], "naam": e["name"]} for e in _elementen(call, tid, doc)]
        except Exception as e:  # noqa: BLE001
            g["overgeslagen"].append({"onderdeel": tid, "reden": str(e)})
    melding("  stijlen: " + ", ".join(f"{k} {len(v)}" for k, v in g["stijlen"].items()))

    # parameters
    try:
        for e in _elementen(call, "shared_parameter", doc):
            g["parameters"].append({"naam": e["name"], "guid": (e.get("guid") or "").lower() or None,
                                    "bron": "shared_element", "binding": None, "categorieen": []})
    except Exception as e:  # noqa: BLE001
        g["overgeslagen"].append({"onderdeel": "shared parameters in het model", "reden": str(e)})
    try:
        b = call("list_parameter_bindings", {"target_document": doc}, timeout=TIME_OUT) or {}
        for r in b.get("bindings", []):
            g["parameters"].append({"naam": r.get("name"), "guid": (r.get("guid") or "").lower() or None,
                                    "bron": "binding", "binding": r.get("instance_or_type"),
                                    "categorieen": r.get("categories") or []})
    except Exception as e:  # noqa: BLE001
        g["overgeslagen"].append({"onderdeel": "parameterbindingen", "reden": str(e)})
    melding(f"  parameters: {len(g['parameters'])} regels")
    return g
