"""De NLRS-check zelf: modelgegevens + NLRS-kennis + uitzonderingen -> bevindingen, scores en herstelplan.

Onderdelen: naamgeving, materialen, shared parameters, classificatie.
Elke bevinding noemt het element (id, naam, categorie), de regel met het sectienummer uit de
Naamgenerator, wat er mis is in gewone taal en waar het kan een voorstel met een zekerheid.
"""
from __future__ import annotations

import fnmatch
import json
from collections import Counter, defaultdict
from pathlib import Path

from nlrs_bron.grammatica import AFWIJKING, CONFORM, KEUZE, LETOP, WAARSCHIJNLIJK, ZEKER, Nlrs

BEWUST = "bewust afwijkend"
OVERGESLAGEN = "overgeslagen"

STIJL_SECTIE = {
    "fill_patterns": "3.2.5 Filled Patterns", "line_patterns": "3.2.6 Line Patterns",
    "line_styles": "3.2.6 Line Style", "text_note_types": "3.2.7 Tekst Styles",
    "dimension_types": "3.2.8 Dimension Styles", "view_family_types": "3.5 View Types",
    "view_templates": "3.6 View Templates", "view_filters": "3.7 View Filters",
}
STIJL_SOORT = {
    "fill_patterns": "fill patterns", "line_patterns": "line patterns", "line_styles": "line styles",
    "text_note_types": "tekststijlen", "dimension_types": "maatstijlen", "view_family_types": "view types",
    "view_templates": "view templates", "view_filters": "view filters",
}
NIET_GETOETST = [
    ("3.2.5 Sketch Line", "de bridge levert geen aparte lijst met sketch lines van filled regions"),
    ("3.2.5 Filled Region als Component", "filled-region-families zijn niet apart te herkennen in de kernlijst van opdrachten"),
    ("4.2 Naamgeving Material Assets", "geen opdracht in de kernlijst die material assets opsomt"),
    ("3.3 Phases", "geen opdracht in de kernlijst die fasen opsomt"),
    ("3.3.1 Phases Filters / 3.4 Worksets", "de NLRS zegt alleen 'conform template'; er is geen template om tegen te toetsen"),
    ("5, 6, 7, 7.3", "geen naamregel (classificatie, subcategorieën, nulpunt, hosting)"),
]
# Revit-families waarvan de naam vastligt (systeemfamilies die toch in de familielijst staan)
VASTE_FAMILIES = {"System Panel", "Empty System Panel", "Rectangular Mullion", "Circular Mullion",
                  "L Corner Mullion", "V Corner Mullion", "Trapezoid Corner Mullion", "Quad Corner Mullion"}
NIET_IN_TE_VULLEN_KLASSE = {"", "unassigned", "<none>"}


# ── uitzonderingen ────────────────────────────────────────────────────────────

def lees_uitzonderingen(pad: Path | None) -> dict:
    leeg = {"uitzonderingen": [], "eigen_afkortingen": {}, "standaard_content": None, "waarschuwingen": [], "pad": None}
    if not pad or not Path(pad).is_file():
        return leeg
    d = json.loads(Path(pad).read_text(encoding="utf-8-sig"))
    w = []
    regels = []
    for i, r in enumerate(d.get("uitzonderingen", []), 1):
        if not str(r.get("reden") or "").strip():
            w.append(f"uitzondering {i} heeft geen reden en telt niet mee")
            continue
        regels.append(r)
    return {"uitzonderingen": regels, "eigen_afkortingen": d.get("eigen_afkortingen") or {},
            "standaard_content": d.get("standaard_content"), "waarschuwingen": w, "pad": str(pad)}


def _uitzondering(uz: dict, onderdeel: str, sectie: str | None, naam: str, posities: list[dict],
                  regel: str = "naam") -> dict | None:
    for r in uz["uitzonderingen"]:
        if (r.get("regel") or "naam") != regel:
            continue
        if r.get("onderdeel") and r["onderdeel"] != onderdeel:
            continue
        if r.get("sectie") and not (sectie or "").startswith(str(r["sectie"])):
            continue
        if r.get("patroon") and not fnmatch.fnmatchcase(naam, r["patroon"]):
            continue
        if r.get("positie") is not None:
            p = next((x for x in posities if x["nr"] == int(r["positie"])), None)
            if p is None or p["status"] == CONFORM:
                continue
            if r.get("waarde") is not None and (p.get("token") or "").strip() != str(r["waarde"]):
                continue
            # alle andere afwijkende posities moeten ook gedekt zijn
            rest = [x for x in posities if x["status"] == AFWIJKING and x["nr"] != p["nr"]]
            if rest:
                continue
        return r
    return None


# ── de check ──────────────────────────────────────────────────────────────────

class Check:
    def __init__(self, kennis: dict, uitzonderingen: dict, vereiste_parameters: list[str] | None = None):
        self.k = kennis
        self.uz = uitzonderingen
        self.nlrs = Nlrs(kennis, eigen_afkortingen=uitzonderingen.get("eigen_afkortingen"))
        self.vereist = vereiste_parameters or []
        self.bevindingen: list[dict] = []
        self.tellingen: dict[str, Counter] = defaultdict(Counter)
        self.per_soort: dict[str, Counter] = defaultdict(Counter)
        self.acties: list[dict] = []
        self.overgeslagen: list[dict] = []
        sec = self.nlrs.secties
        self.symbool_cats = {k.lower() for k in (sec.get("3.2.3 Symbols", {}).get("posities", [{}] * 4)[3]
                                                 .get("keuzelijst") or {}).get("omschrijving_naar_code", {})}
        self.label_cats = {k.lower() for k in (sec.get("3.2.3 Labels", {}).get("posities", [{}] * 4)[3]
                                               .get("keuzelijst") or {}).get("omschrijving_naar_code", {})}

    # -- vastleggen --
    def _tel(self, onderdeel: str, soort: str, status: str) -> None:
        self.tellingen[onderdeel][status] += 1
        self.per_soort[f"{onderdeel} / {soort}"][status] += 1

    def _bevinding(self, onderdeel, soort, element, sectie, regel, status, wat, voorstel=None, bewust=None):
        b = {"id": f"B{len(self.bevindingen) + 1:04d}", "onderdeel": onderdeel, "objectsoort": soort,
             "element": element, "sectie": sectie, "regel": regel, "status": status, "wat": wat,
             "voorstel": voorstel, "bewust_afwijkend_reden": bewust}
        self.bevindingen.append(b)
        return b

    def _actie(self, b: dict, soort: str, **velden) -> None:
        a = {"id": f"A{len(self.acties) + 1:04d}", "bevinding": b["id"], "soort": soort,
             "element_id": b["element"].get("id"), "huidige_naam": b["element"].get("naam"),
             "objectsoort": b["objectsoort"], "groep": velden.pop("groep", b["objectsoort"])}
        a.update(velden)
        z = a.get("zekerheid")
        waarde = str(a.get("nieuwe_naam") or a.get("nieuwe_waarde") or "")
        a["uitvoeren"] = bool(z == ZEKER and "<" not in waarde and a.get("element_id") is not None)
        a["opmerking"] = a.get("opmerking") or ("" if a["uitvoeren"] else
                                                "vink aan na controle" if "<" not in waarde else "vul eerst de <plaatshouder> in")
        self.acties.append(a)

    # -- naamgeving --
    def _toets_naam(self, onderdeel, soort, element, sectie, context=None, standaard_letop: str | None = None):
        naam = element["naam"]
        uit = self.nlrs.toets_naam(naam, sectie, context or {})
        status = uit["status"]
        regel = f"Naamgenerator sectie {sectie}"
        afw = [p for p in uit["posities"] if p["status"] != CONFORM]
        if afw:
            regel += ", " + ", ".join(f"positie {p['nr']} ({p['naam']})" for p in afw[:3])
        if status == AFWIJKING and standaard_letop and not any(
                (naam.split("_")[0] == c) for c in ("NLRS", "BERSnl", "BERSfr", "Rsen")):
            status = LETOP
            uit["meldingen"] = [standaard_letop]
        bewust = None
        if status != CONFORM:
            r = _uitzondering(self.uz, onderdeel, sectie, naam, uit["posities"])
            if r:
                status, bewust = BEWUST, r["reden"]
        self._tel(onderdeel, soort, status)
        if status == CONFORM:
            return uit
        wat = "; ".join(uit["meldingen"]) or "naam volgt de opbouw niet"
        voorstel = None
        if status == AFWIJKING:
            v = self.nlrs.voorstel(naam, sectie, context or {}, standaard_content=self.uz.get("standaard_content"))
            if v:
                voorstel = {"naam": v[0], "zekerheid": v[1], "uitleg": v[2]}
        b = self._bevinding(onderdeel, soort, element, sectie, regel, status, wat, voorstel, bewust)
        if voorstel and soort not in ("view types",):
            groep = soort
            if soort == "family types":
                groep = f"types van {element.get('familie')}"
            elif soort == "systeemtypes":
                groep = f"systeemtypes {element.get('categorie')}"
            self._actie(b, "hernoem", nieuwe_naam=voorstel["naam"], zekerheid=voorstel["zekerheid"], groep=groep)
        return uit

    def _sectie_familie(self, f: dict) -> str | None:
        naam, ost, cat = f["naam"], (f.get("ost") or ""), (f.get("categorie") or "").lower()
        delen = naam.split("_")
        p3 = delen[2] if len(delen) > 2 else ""
        if p3 == "GA" or ost == "OST_GenericAnnotation" or cat == "generic annotations":
            return "3.2.3 Generic Annotations"
        if p3 == "SYM" or cat in self.symbool_cats:
            return "3.2.3 Symbols"
        if p3 == "LAB" or cat in self.label_cats:
            return "3.2.3 Labels"
        if p3 == "TAG" or cat.endswith("tags") or ost.endswith("Tags"):
            return "3.2.4 Tags"
        if ost == "OST_ProfileFamilies" or cat == "profiles":
            return "3.2.2 Profile families"
        return "3.1 Loadable families"

    def naamgeving(self, g: dict) -> None:
        ac_per_familie = {}
        for t in g["types"]:
            if t.get("familie_id") is not None and t.get("assembly_code"):
                ac_per_familie.setdefault(t["familie_id"], t["assembly_code"])
        for f in g["families"]:
            el = {"id": f["id"], "naam": f["naam"], "categorie": f.get("categorie") or f.get("ost")}
            if f["naam"] in VASTE_FAMILIES:
                self._tel("naamgeving", "families", OVERGESLAGEN)
                continue
            sectie = self._sectie_familie(f)
            ctx = {"categorie": f.get("categorie"), "ost": f.get("ost"), "assembly_code": ac_per_familie.get(f["id"])}
            if sectie in ("3.2.3 Generic Annotations", "3.2.3 Symbols", "3.2.3 Labels", "3.2.4 Tags"):
                ctx = {}        # de categoriecode ligt vast of is de host-categorie
            self._toets_naam("naamgeving", "families", el, sectie, ctx)
        for t in g["types"]:
            el = {"id": t["id"], "naam": t["naam"], "categorie": t.get("categorie") or t.get("ost"),
                  "familie": t.get("familie")}
            if t["soort"] == "system":
                self._toets_naam("naamgeving", "systeemtypes", el, "3.1 System Families",
                                 {"categorie": t.get("categorie"), "ost": t.get("ost"),
                                  "assembly_code": t.get("assembly_code")})
            elif t.get("familie") in VASTE_FAMILIES:
                self._tel("naamgeving", "family types", OVERGESLAGEN)
            else:
                self._toets_naam("naamgeving", "family types", el, "3.2.1 Types binnen loadable families")
        for tid, lijst in g["stijlen"].items():
            sectie = STIJL_SECTIE.get(tid)
            if not sectie:
                continue
            for s in lijst:
                el = {"id": s["id"], "naam": s["naam"], "categorie": STIJL_SOORT[tid]}
                if s["naam"].startswith("<") or s["naam"] in ("Solid fill",):
                    self._tel("naamgeving", STIJL_SOORT[tid], OVERGESLAGEN)
                    continue
                letop = None
                if tid in ("line_patterns", "line_styles"):
                    letop = ("geen NLRS-naam; sectie 3.2.6 zegt 'gebruik de standaard waar mogelijk', "
                             "dus een standaardpatroon of -stijl van Revit mag blijven")
                self._toets_naam("naamgeving", STIJL_SOORT[tid], el, sectie, {}, standaard_letop=letop)

    # -- materialen --
    def materialen(self, g: dict) -> None:
        for m in g["materialen"]:
            el = {"id": m["id"], "naam": m["naam"], "categorie": "materiaal"}
            self._toets_naam("materialen", "materiaalnaam", el, "4.1 Naamgeving Materialen")
            klasse = (m.get("klasse") or "").strip()
            if m.get("klasse") is None:
                self._tel("materialen", "materiaalklasse", OVERGESLAGEN)
                continue
            if klasse.lower() in NIET_IN_TE_VULLEN_KLASSE:
                st, bewust = AFWIJKING, None
                r = _uitzondering(self.uz, "materialen", "4.1", m["naam"], [], regel="klasse")
                if r:
                    st, bewust = BEWUST, r["reden"]
                self._tel("materialen", "materiaalklasse", st)
                b = self._bevinding("materialen", "materiaalklasse", el, "4.1 Naamgeving Materialen",
                                    "Naamgenerator sectie 4.1: materiaal met klasse (de opdracht van deze check)",
                                    st, f"de materiaalklasse is leeg{' (Unassigned)' if klasse else ''}",
                                    {"waarde": "<klasse>", "zekerheid": KEUZE,
                                     "uitleg": ["kies een klasse, bijvoorbeeld Concrete, Masonry, Metal, Wood, Glass"]},
                                    bewust)
                if st == AFWIJKING:
                    self._actie(b, "materiaalklasse", nieuwe_waarde="<klasse>", zekerheid=KEUZE)
            else:
                self._tel("materialen", "materiaalklasse", CONFORM)

    # -- classificatie --
    def classificatie(self, g: dict) -> None:
        tabel1 = set(self.k["nlsfb"]["tabel1"]) | set(self.k.get("assembly_codes_2021", []))
        pos2 = set(self.k["nlsfb"]["tabel1_pos2"])
        for t in g["types"]:
            if self.nlrs.is_annotatie(t.get("categorie"), t.get("ost")) or t.get("familie") in VASTE_FAMILIES:
                continue
            el = {"id": t["id"], "naam": t["naam"], "categorie": t.get("categorie") or t.get("ost"),
                  "familie": t.get("familie")}
            soort = "systeemtypes" if t["soort"] == "system" else "family types"
            ac = (t.get("assembly_code") or "").strip()
            regel = "NL-SfB tabel 1 (versie 2021) in de Naamgenerator, Assembly Code-bestand NL-SfB2021"
            if ac and ac in tabel1:
                self._tel("classificatie", soort, CONFORM)
                continue
            naamcode = None
            delen = (t.get("naam") if t["soort"] == "system" else (t.get("familie") or "")).split("_")
            if len(delen) > 1 and delen[1] in pos2:
                naamcode = delen[1]
            st = AFWIJKING
            r = _uitzondering(self.uz, "classificatie", None, t["naam"], [], regel="assembly code")
            bewust = r["reden"] if r else None
            if bewust:
                st = BEWUST
            self._tel("classificatie", soort, st)
            wat = (f"Assembly Code '{ac}' bestaat niet in NL-SfB tabel 1" if ac else "Assembly Code is leeg")
            voorstel = ({"waarde": naamcode, "zekerheid": WAARSCHIJNLIJK,
                         "uitleg": [f"NL-SfB {naamcode} uit de naam"]} if naamcode else
                        {"waarde": "<NL-SfB>", "zekerheid": KEUZE, "uitleg": ["kies een code uit NL-SfB tabel 1"]})
            b = self._bevinding("classificatie", soort, el, "5 Classificatiesystemen", regel, st, wat, voorstel, bewust)
            if st == AFWIJKING:
                self._actie(b, "waarde", parameter="Assembly Code", huidige_waarde=ac,
                            nieuwe_waarde=voorstel["waarde"], zekerheid=voorstel["zekerheid"])

    # -- shared parameters --
    def parameters(self, g: dict) -> None:
        sp = self.k["shared_parameters"]
        per_guid = {p["guid"]: p for p in sp["totaal"]}
        bron = sp["bronbestand"]
        naam_guid: dict[str, str] = {}
        for gd, p in per_guid.items():
            naam_guid[p["naam"]] = gd
        oude_naam: dict[str, str] = {}
        for gd, r in bron.items():
            if r["naam"].startswith("NLRS_") and r["naam"] not in naam_guid:
                naam_guid[r["naam"]] = gd
            if r.get("naam_nlrs_2_5_2"):
                oude_naam.setdefault(r["naam_nlrs_2_5_2"], gd)
        dubbel_in_bron = {}
        for t in sp["txt_controle"]:
            for gd, namen in (t.get("dubbele_guids") or {}).items():
                dubbel_in_bron[gd] = (t["bestand"], namen)

        # samenvoegen: één regel per (naam, guid)
        model: dict[tuple, dict] = {}
        for p in g["parameters"]:
            sleutel = (p["naam"], p.get("guid"))
            m = model.setdefault(sleutel, {"naam": p["naam"], "guid": p.get("guid"), "binding": None, "categorieen": []})
            if p.get("binding"):
                m["binding"] = p["binding"]
                m["categorieen"] = p.get("categorieen") or []
        per_naam = defaultdict(set)
        for (n, gd) in model:
            if gd:
                per_naam[n].add(gd)

        for (naam, guid), m in sorted(model.items(), key=lambda x: (x[0][0] or "", x[0][1] or "")):
            el = {"id": None, "naam": naam, "categorie": "shared parameter", "guid": guid}
            regel = "NLRS_Shared Parameters - Totaal.txt en Bronbestand.xlsx (status)"
            st, wat, voorstel = CONFORM, "", None
            info = bron.get(guid or "")
            if not guid:
                if naam in naam_guid or naam.startswith("NLRS_"):
                    st, wat = AFWIJKING, ("projectparameter zonder GUID met een NLRS-naam; NLRS-parameters zijn "
                                          "shared parameters met een vaste GUID")
                else:
                    continue
            elif len(per_naam[naam]) > 1:
                st, wat = AFWIJKING, (f"de naam komt twee keer voor met verschillende GUID's "
                                      f"({', '.join(sorted(per_naam[naam]))}); dat blokkeert binden en filters")
            elif info and info["status"].upper() == "DEPRECATED":
                st = AFWIJKING
                wat = "deze parameter is DEPRECATED in de NLRS"
                if info.get("opvolger"):
                    wat += f"; opvolger is {info['opvolger']}"
                    voorstel = {"naam": info["opvolger"], "zekerheid": WAARSCHIJNLIJK,
                                "uitleg": ["waarden overzetten naar de opvolger, daarna de oude parameter weghalen"]}
            elif guid in per_guid or (info and info["naam"].startswith("NLRS_")):
                juist = per_guid[guid]["naam"] if guid in per_guid else info["naam"]
                if naam != juist:
                    st, wat = AFWIJKING, f"GUID is van NLRS-parameter '{juist}', maar de naam in het model is '{naam}'"
                    voorstel = {"naam": juist, "zekerheid": ZEKER, "uitleg": ["naam gelijkzetten aan de NLRS"]}
                elif guid not in per_guid:
                    st, wat = LETOP, (f"staat in het Bronbestand (status {info['status']}) maar niet in Totaal.txt")
                if guid in dubbel_in_bron:
                    st = LETOP if st == CONFORM else st
                    wat = (wat + "; " if wat else "") + (f"deze GUID staat in {dubbel_in_bron[guid][0]} bij twee "
                                                         f"parameters: {', '.join(dubbel_in_bron[guid][1])}")
            elif naam in naam_guid:
                st = AFWIJKING
                wat = (f"heet als de NLRS-parameter, maar heeft een andere GUID ({guid}, NLRS: {naam_guid[naam]}); "
                       "een oude NLRS-versie of zelf aangemaakt")
                voorstel = {"naam": naam, "zekerheid": WAARSCHIJNLIJK,
                            "uitleg": ["vervang door de NLRS-parameter met GUID " + naam_guid[naam]]}
            elif naam in oude_naam:
                st = AFWIJKING
                nieuw = bron[oude_naam[naam]]["naam"]
                wat = f"naam uit NLRS 2.5.2; in de huidige NLRS heet deze parameter '{nieuw}'"
            elif naam.startswith("NLRS_"):
                st, wat = AFWIJKING, "begint met NLRS_ maar is geen parameter uit de NLRS-lijst"
            else:
                self._tel("shared parameters (eigen, niet geteld)", "eigen parameters", CONFORM)
                continue
            bewust = None
            if st != CONFORM:
                r = _uitzondering(self.uz, "shared parameters", None, naam, [], regel="parameter")
                if r:
                    st, bewust = BEWUST, r["reden"]
            self._tel("shared parameters", "NLRS-parameters", st)
            if st != CONFORM:
                self._bevinding("shared parameters", "NLRS-parameters", el, "8.1 Naamgeving Shared Parameters",
                                regel, st, wat, voorstel, bewust)

        aanwezig = {n for (n, _) in model}
        for n in self.vereist:
            if n in aanwezig:
                continue
            gd = naam_guid.get(n)
            st = AFWIJKING
            wat = "deze NLRS-parameter is gevraagd maar ontbreekt in het model"
            if not gd:
                wat = "gevraagde parameter staat niet in de NLRS-lijst en ontbreekt in het model"
            self._tel("shared parameters", "gevraagde parameters", st)
            self._bevinding("shared parameters", "gevraagde parameters", {"id": None, "naam": n, "categorie": "shared parameter",
                                                                       "guid": gd}, "8.1 Naamgeving Shared Parameters",
                            "lijst met gevraagde parameters", st, wat,
                            {"naam": n, "zekerheid": ZEKER if gd else KEUZE,
                             "uitleg": [f"toevoegen uit NLRS_Shared Parameters - Totaal.txt (GUID {gd})" if gd else "controleer de naam"]})

    # -- afronden --
    def botsingen(self, g: dict) -> None:
        bestaand = defaultdict(set)
        for f in g["families"]:
            bestaand["families"].add(f["naam"])
        for t in g["types"]:
            bestaand[f"types van {t.get('familie')}" if t["soort"] == "loadable" else f"systeemtypes {t.get('categorie')}"].add(t["naam"])
        for m in g["materialen"]:
            bestaand["materiaalnaam"].add(m["naam"])
        for tid, lijst in g["stijlen"].items():
            for s in lijst:
                bestaand[STIJL_SOORT.get(tid, tid)].add(s["naam"])
        nieuw = Counter((a["groep"], a.get("nieuwe_naam")) for a in self.acties if a["soort"] == "hernoem")
        for a in self.acties:
            if a["soort"] != "hernoem":
                continue
            if nieuw[(a["groep"], a["nieuwe_naam"])] > 1:
                a["uitvoeren"] = False
                a["opmerking"] = "botsing: meer elementen krijgen deze naam; kies per element een andere omschrijving"
            elif a["nieuwe_naam"] in bestaand.get(a["groep"], set()) and a["nieuwe_naam"] != a["huidige_naam"]:
                a["uitvoeren"] = False
                a["opmerking"] = "botsing: deze naam bestaat al in het model (samenvoegen gaat niet met hernoemen)"

    def draai(self, g: dict) -> dict:
        self.naamgeving(g)
        self.materialen(g)
        self.classificatie(g)
        self.parameters(g)
        self.botsingen(g)
        return self.resultaat(g)

    def resultaat(self, g: dict) -> dict:
        def score(c: Counter) -> dict:
            getoetst = c[CONFORM] + c[LETOP] + c[AFWIJKING] + c[BEWUST]
            ok = c[CONFORM] + c[LETOP]
            return {"getoetst": getoetst, "conform": c[CONFORM], "let_op": c[LETOP], "afwijking": c[AFWIJKING],
                    "bewust_afwijkend": c[BEWUST], "overgeslagen": c[OVERGESLAGEN],
                    "procent_conform": round(100 * ok / getoetst, 1) if getoetst else None,
                    "procent_conform_incl_bewust": round(100 * (ok + c[BEWUST]) / getoetst, 1) if getoetst else None}
        return {
            "formaat": "nlrs-rapport/1",
            "document": g.get("document"), "bron_model": g.get("bron"),
            "nlrs_bron": [{k: r.get(k) for k in ("repo", "commit", "datum", "herkomst")} for r in self.k.get("bron", [])],
            "uitzonderingen": {"bestand": self.uz.get("pad"), "aantal": len(self.uz["uitzonderingen"]),
                               "waarschuwingen": self.uz["waarschuwingen"]},
            "scores": {k: score(v) for k, v in sorted(self.tellingen.items())},
            "scores_per_soort": {k: score(v) for k, v in sorted(self.per_soort.items())},
            "bevindingen": self.bevindingen,
            "niet_getoetst": [{"wat": a, "reden": b} for a, b in NIET_GETOETST] + g.get("overgeslagen", []),
        }

    def herstelplan(self, g: dict) -> dict:
        return {"formaat": "nlrs-herstelplan/1", "document": g.get("document"),
                "uitleg": ("Zet 'uitvoeren' op true (of 'ja' in Excel) bij elke actie die je wilt laten uitvoeren. "
                           "Alleen acties zonder <plaatshouder> kunnen worden uitgevoerd. nlrs_herstel.py doet "
                           "standaard een proef."),
                "acties": self.acties}
