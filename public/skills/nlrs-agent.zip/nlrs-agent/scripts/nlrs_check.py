"""NLRS-check van een Revit-model: naamgeving, shared parameters, materialen en classificatie.

Leest het model via de bridge (alleen leesopdrachten) of uit een bestand met eerder opgehaalde
gegevens, toetst tegen de NLRS-bronbestanden en schrijft een rapport (JSON, Markdown, Excel) en een
herstelplan. Er wordt niets in het model gewijzigd.

    python nlrs_check.py                                  # het enige open projectmodel
    python nlrs_check.py --document "Mijn model"          # een bepaald open model
    python nlrs_check.py --uit-bestand gegevens.json      # zonder Revit
    python nlrs_check.py --bewaar-gegevens gegevens.json  # modelgegevens ook bewaren
    python nlrs_check.py --uitzonderingen nlrs-uitzonderingen.json --vereist NLRS_C_brandwerendheid,...
    python nlrs_check.py --uit <map>                       # waar het rapport komt (standaard ./nlrs-rapport)

Eerst de bronnen ophalen: python ophalen.py (staat naast dit script in nlrs_bron/, of in shared/).
"""
import sys
from pathlib import Path

_hier = Path(__file__).resolve().parent
for _p in (_hier, _hier.parents[2] / "shared"):   # in de zip: scripts/; in de repo: shared/
    if _p.is_dir() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import argparse  # noqa: E402
import json  # noqa: E402

import controle  # noqa: E402
import modelgegevens  # noqa: E402
import rapport  # noqa: E402
from nlrs_bron.grammatica import laad_kennis  # noqa: E402


def _vereist(waarde: str | None) -> list[str]:
    if not waarde:
        return []
    p = Path(waarde)
    if p.is_file():
        return [r.strip() for r in p.read_text(encoding="utf-8-sig").splitlines() if r.strip() and not r.startswith("#")]
    return [w.strip() for w in waarde.split(",") if w.strip()]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="NLRS-check van een Revit-model (alleen lezen)")
    ap.add_argument("--document", help="titel van het open model (bij meer open modellen)")
    ap.add_argument("--uit-bestand", help="modelgegevens uit een bestand in plaats van uit Revit")
    ap.add_argument("--bewaar-gegevens", help="schrijf de opgehaalde modelgegevens naar dit bestand")
    ap.add_argument("--uitzonderingen", help="nlrs-uitzonderingen.json (standaard: naast het model, als dat er is)")
    ap.add_argument("--vereist", help="gevraagde NLRS-parameters: komma-lijst of tekstbestand met één naam per regel")
    ap.add_argument("--uit", default="nlrs-rapport", help="map voor rapport en herstelplan")
    ap.add_argument("--ververs-bron", action="store_true", help="NLRS-bestanden opnieuw inlezen (cache negeren)")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]

    try:
        kennis = laad_kennis(ververs=a.ververs_bron)
    except (FileNotFoundError, ImportError) as e:
        print(f"FOUT: {e}")
        return 3

    if a.uit_bestand:
        g = modelgegevens.lees_bestand(Path(a.uit_bestand))
    else:
        from revit_agent.bridge import call
        try:
            g = modelgegevens.haal_op(call, a.document)
        except modelgegevens.BridgeGestopt as e:
            print(f"GESTOPT: {e}")
            return 2
        except ValueError as e:
            print(f"FOUT: {e}")
            return 3
    if a.bewaar_gegevens:
        modelgegevens.bewaar(g, Path(a.bewaar_gegevens))
        print(f"Modelgegevens bewaard: {a.bewaar_gegevens}")

    uz_pad = Path(a.uitzonderingen) if a.uitzonderingen else None
    if uz_pad is None and (g.get("document") or {}).get("pad"):
        kand = Path(g["document"]["pad"]).with_name("nlrs-uitzonderingen.json")
        if kand.is_file():
            uz_pad = kand
    uz = controle.lees_uitzonderingen(uz_pad)

    c = controle.Check(kennis, uz, _vereist(a.vereist))
    r = c.draai(g)
    plan = c.herstelplan(g)

    uit = Path(a.uit)
    uit.mkdir(parents=True, exist_ok=True)
    (uit / "nlrs-rapport.json").write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    (uit / "nlrs-herstelplan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    (uit / "nlrs-rapport.md").write_text(rapport.markdown(r, plan), encoding="utf-8")
    xl = rapport.excel(r, plan, uit / "nlrs-rapport.xlsx")

    print("\nScore per onderdeel (conform of let op / getoetst):")
    for k in rapport.VOLGORDE:
        s = r["scores"].get(k)
        if s:
            print(f"  {k:18} {rapport._pct(s):>6}  ({s['conform'] + s['let_op']}/{s['getoetst']}, "
                  f"afwijking {s['afwijking']}, bewust afwijkend {s['bewust_afwijkend']})")
    print(f"\nBevindingen: {len(r['bevindingen'])}. Herstelacties: {len(plan['acties'])} "
          f"(vooraf aangevinkt: {sum(x['uitvoeren'] for x in plan['acties'])}).")
    print(f"Rapport: {uit / 'nlrs-rapport.md'}" + (f", {uit / 'nlrs-rapport.xlsx'}" if xl else " (geen Excel: openpyxl ontbreekt)"))
    print(f"Herstelplan: {uit / 'nlrs-herstelplan.json'}")
    for w in uz["waarschuwingen"]:
        print(f"Let op: {w}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
