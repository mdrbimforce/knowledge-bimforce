"""Rapport van de NLRS-check als Markdown en (als openpyxl er is) als Excel met het herstelplan."""
from __future__ import annotations

from pathlib import Path

VOLGORDE = ["naamgeving", "materialen", "shared parameters", "classificatie"]


def _pct(s: dict) -> str:
    return "n.v.t." if s["procent_conform"] is None else f"{s['procent_conform']:.0f}%"


def markdown(r: dict, plan: dict, max_per_soort: int = 40) -> str:
    d = r.get("document") or {}
    L = [f"# NLRS-check: {d.get('titel', 'model')}", ""]
    bronnen = ", ".join(f"{b['repo']} ({(b.get('commit') or '?')[:7]}, {str(b.get('datum') or '?')[:10]})"
                        for b in r.get("nlrs_bron", []))
    L += [f"Gecontroleerd tegen de NLRS 3.1.1-bestanden van de Revit Standards Foundation: {bronnen}.",
          f"Modelgegevens: {r.get('bron_model')}.", ""]
    L += ["## Score per onderdeel", "", "| Onderdeel | Getoetst | Conform | Let op | Afwijking | Bewust afwijkend | Score |",
          "|---|---:|---:|---:|---:|---:|---:|"]
    for k in VOLGORDE:
        s = r["scores"].get(k)
        if s:
            L.append(f"| {k} | {s['getoetst']} | {s['conform']} | {s['let_op']} | {s['afwijking']} | "
                     f"{s['bewust_afwijkend']} | **{_pct(s)}** |")
    L += ["", "Score = (conform + let op) / getoetst. 'Let op' telt als conform maar verdient een blik. "
          "Bewust afwijkend telt apart (uitzonderingen van het bureau).", ""]
    L += ["### Per objectsoort", "", "| Onderdeel / soort | Getoetst | Afwijking | Score |", "|---|---:|---:|---:|"]
    for k, s in r["scores_per_soort"].items():
        if s["getoetst"]:
            L.append(f"| {k} | {s['getoetst']} | {s['afwijking']} | {_pct(s)} |")
    L.append("")
    uz = r.get("uitzonderingen") or {}
    if uz.get("bestand"):
        L += [f"Uitzonderingen gelezen uit `{Path(uz['bestand']).name}`: {uz['aantal']} regel(s)."]
        L += [f"- {w}" for w in uz.get("waarschuwingen", [])]
        L.append("")
    L += ["## Bevindingen", ""]
    groepen: dict[str, list] = {}
    for b in r["bevindingen"]:
        groepen.setdefault(f"{b['onderdeel']} / {b['objectsoort']}", []).append(b)
    for g, lijst in groepen.items():
        afw = [b for b in lijst if b["status"] == "afwijking"]
        L += [f"### {g} ({len(afw)} afwijkingen, {len(lijst) - len(afw)} overige)", "",
              "| Id | Element | Status | Wat | Voorstel | Zekerheid |", "|---|---|---|---|---|---|"]
        for b in sorted(lijst, key=lambda x: x["status"] != "afwijking")[:max_per_soort]:
            e = b["element"]
            v = b.get("voorstel") or {}
            vs = v.get("naam") or v.get("waarde") or ""
            el = f"`{e.get('naam')}`" + (f" ({e.get('categorie')})" if e.get("categorie") else "")
            wat = b["wat"].replace("|", "/")
            if b.get("bewust_afwijkend_reden"):
                wat += f" (bewust: {b['bewust_afwijkend_reden']})"
            L.append(f"| {b['id']} | {el} | {b['status']} | {wat} | {('`' + vs + '`') if vs else ''} | {v.get('zekerheid', '')} |")
        if len(lijst) > max_per_soort:
            L.append(f"| | ... nog {len(lijst) - max_per_soort} | | zie JSON of Excel | | |")
        L.append("")
    acties = plan["acties"]
    L += ["## Herstelplan", "",
          f"{len(acties)} acties, waarvan {sum(a['uitvoeren'] for a in acties)} vooraf aangevinkt (alleen 'zeker').",
          "Niets is uitgevoerd. Vink aan wat mag, laat een proef draaien, en voer pas daarna uit.", ""]
    L += ["## Niet getoetst", ""]
    for n in r.get("niet_getoetst", []):
        L.append(f"- {n.get('wat') or n.get('onderdeel')}: {n.get('reden')}")
    L.append("")
    return "\n".join(L)


def excel(r: dict, plan: dict, pad: Path) -> bool:
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        return False
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Score"
    ws.append(["Onderdeel", "Getoetst", "Conform", "Let op", "Afwijking", "Bewust afwijkend", "Score %"])
    for k in VOLGORDE:
        s = r["scores"].get(k)
        if s:
            ws.append([k, s["getoetst"], s["conform"], s["let_op"], s["afwijking"], s["bewust_afwijkend"], s["procent_conform"]])
    ws.append([])
    for k, s in r["scores_per_soort"].items():
        ws.append([k, s["getoetst"], s["conform"], s["let_op"], s["afwijking"], s["bewust_afwijkend"], s["procent_conform"]])
    wb2 = wb.create_sheet("Bevindingen")
    wb2.append(["id", "onderdeel", "objectsoort", "element_id", "naam", "categorie", "sectie", "regel", "status", "wat",
                "voorstel", "zekerheid", "bewust afwijkend (reden)"])
    for b in r["bevindingen"]:
        e, v = b["element"], b.get("voorstel") or {}
        wb2.append([b["id"], b["onderdeel"], b["objectsoort"], e.get("id"), e.get("naam"), e.get("categorie"),
                    b["sectie"], b["regel"], b["status"], b["wat"], v.get("naam") or v.get("waarde"),
                    v.get("zekerheid"), b.get("bewust_afwijkend_reden")])
    hp = wb.create_sheet("Herstelplan")
    kop = ["uitvoeren", "id", "soort", "element_id", "huidige_naam", "nieuwe_naam", "parameter", "huidige_waarde",
           "nieuwe_waarde", "zekerheid", "opmerking", "objectsoort", "groep", "bevinding"]
    hp.append(kop)
    for a in plan["acties"]:
        hp.append(["ja" if a["uitvoeren"] else "nee"] + [a.get(k) for k in kop[1:]])
    geel = PatternFill("solid", fgColor="FFF2CC")
    for blad in (ws, wb2, hp):
        for c in blad[1]:
            c.font = Font(bold=True)
        blad.freeze_panes = "A2"
        for kol in blad.columns:
            breedte = max(len(str(c.value or "")) for c in list(kol)[:200])
            blad.column_dimensions[kol[0].column_letter].width = min(max(10, breedte + 2), 70)
    for rij in hp.iter_rows(min_row=2, max_col=1):
        rij[0].fill = geel
    wb.save(pad)
    return True
