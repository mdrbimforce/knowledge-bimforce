# Naamopbouw per objectsoort

Alle namen bestaan uit posities met een liggend streepje `_` ertussen. Binnen een positie staan spaties of koppeltekens, nooit een `_`. De sectienummers zijn die van de Naamgenerator NLRS 3.1.1 (tabblad VOL_Naamgeving Objecten). Waar "keuzelijst" staat, komt de toegestane waarde uit een tabblad van de Naamgenerator; met `nlrs_naam.py lijst "<sectie>" <positie>` zie je de hele lijst.

Veel posities komen steeds terug:

| Positie | Wat erin hoort | Waar de waarde vandaan komt |
|---|---|---|
| Landcode | `NLRS` (of BERSnl, BERSfr, Rsen) | tabblad `<pos1>` |
| Classificatiecode | NL-SfB tabel 1, twee tekens: `21`, `31`, of een hoofdgroep als `2-` | tabblad `<pos2>` (62 codes) |
| Classificatiecode materiaal | NL-SfB tabel 3: `f4`, `i2`, `o8` | tabblad `<pos2>`, kolom tabel 3 |
| Family category code | de afkorting van de Revit-categorie: `DO` deuren, `WA` wanden, `GM` generic models | tabblad `<pos3>`; de check toetst ook of de code past bij de echte categorie |
| Host Type | hoe de family geplaatst wordt: `UN`, `FB`, `WB`, `CB`, `FLB`, `RB`, `AC`, `TLB`, `LB`, `LIB`, `PB` | tabblad `<pos4>` |
| Leverancier product | `gen` voor generiek, of de afkorting van de fabrikant | tabblad `<pos6>`, uit te breiden |
| Leverancier content | wie de content maakte: `rsf`, `rgg`, of een eigen afkorting | tabblad `<pos7>`, uit te breiden |

## Families en types

| Sectie | Opbouw | Voorbeeld uit de Naamgenerator |
|---|---|---|
| 3.1 Loadable families | Landcode_Classificatie_Categoriecode_HostType_Omschrijving_Leverancier_Content | `NLRS_28_SF_LIB_stalen ligger HEA_gen_rsf` |
| 3.1 System Families (wanden, vloeren, daken, kanalen, leidingen) | Landcode_Classificatie_Categoriecode_Omschrijving_Leverancier_Content (positie 4 vervalt) | `NLRS_11_AIR_metselwerk 100mm_gen_rsf` |
| 3.2.1 Types binnen loadable families | Omschrijving, daarna optioneel Leverancier, Model, Afmetingen, Beperkingen | `Binnendeur_gen_rechtsdraaiend_bxh 1034x2300_zelfsluitend` |
| 3.2.2 Profile families | als 3.1 Loadable families | `NLRS_31_DO_WB_enkele deur_gen_rsf` |
| 3.2.3 Generic Annotations | als 3.1, positie 3 is altijd `GA`, positie 4 altijd `UN` | `NLRS_31_GA_UN_KOMO keur Omschrijving_gen_rsf` |
| 3.2.3 Symbols | als 3.1, positie 3 is `SYM`, positie 4 de symboolcategorie (`COOR`, `SDS`, ...) | `NLRS_31_SYM_COOR_KOMO keur Omschrijving_gen_rsf` |
| 3.2.3 Labels | als 3.1, positie 3 is `LAB` (of `SYM`), positie 4 de labelcategorie (`GH`, `LH`, `CAH`, `VT`) | `NLRS_31_LAB_GH_bol stramienlijn_gen_rsf` |
| 3.2.4 Tags | als 3.1, positie 3 is `TAG`, positie 4 de categoriecode van wat getagd wordt (`MC` voor multi-category) | `NLRS_1-_TAG_MC_Description-Model_gen_rsf` |

In de omschrijving van een family staan eerst de woorden die het ding beschrijven, daarna attribuutcodes uit tabblad `<pos5>` met een koppelteken (`-SH` shared, `-WPB` work plane based, `-AV` always vertical).

## Patronen, lijnen en tekst

| Sectie | Opbouw | Voorbeeld |
|---|---|---|
| 3.2.5 Filled Patterns | Landcode_NL-SfB tabel 3_DP of MP_Omschrijving_Afmetingen (optioneel)_Content | `NLRS_f3_MP_kalkzandsteen diagonaal 2mm__rsf` |
| 3.2.5 Filled Region als Component | Landcode_NL-SfB tabel 3_FR_DP of MP_Omschrijving_t of o_Content | `NLRS_a_FR_MP_noodverlichtingsarmatuur-groen_o_rsf` |
| 3.2.6 Line Patterns | Landcode_Omschrijving_Content | `NLRS_hidden 1-50_rsf` |
| 3.2.6 Line Style | Landcode_Categorie_Subcategorie (een `/` wordt `-`)_Content | `NLRS_Doors_Frame-Mullion_rsf` |
| 3.2.7 Tekststijlen | Landcode_Tekstgrootte_Omschrijving_Content | `NLRS_2.5mm_Arial-30gr pijl-0_rsf` |
| 3.2.8 Maatstijlen | Landcode_Tekstgrootte_Eenheid (`mm`, `cm`, `m`, `deg`)_Omschrijving_Content | `NLRS_2.5mm_mm_Arial-t-c_rsf` |

Bij line patterns en line styles zegt de NLRS: gebruik de standaard van Revit waar het kan. Een standaardnaam van Revit krijgt daarom "let op" en telt als conform.

## Views

| Sectie | Opbouw | Voorbeeld |
|---|---|---|
| 3.5 View Types | Landcode_Kennisgebied (`bwk`, `con`, `ins`, ...)_Omschrijving | `NLRS_bwk_plattegrond` |
| 3.6 View Templates | Landcode_Kennisgebied_Viewtype (`fp`, `rcp`, `sec`, ...)_Eigenschappen_Schaal (`1-100`)_Content | `NLRS_bwk_fp_verkooptekening zonder maatvoering_1-500_rsf` |
| 3.7 View Filters | Landcode_Classificatie_Categoriecode_Filterregel (`01` t/m `05`)_Omschrijving_Content | `NLRS_31_MC_01_buitenwanden metselwerk_rsf` |

## Materialen en parameters

| Sectie | Opbouw | Voorbeeld |
|---|---|---|
| 4.1 Materialen | Landcode_NL-SfB tabel 3_Omschrijving (eigenschappen met `-`)_Bronhouder (`gen` of fabrikant)_Content | `NLRS_o8_glas-gehard-opaal_gen_rsf` |
| 4.2 Material Assets | Landcode_A, P of T_Omschrijving_Content | `NLRS_A_staal-RAL 5023-verblauw_rsf` |
| 8.1 Shared Parameters | Landcode_Discipline (zie parameters.md)_omschrijving in kleine letters | `NLRS_C_omschrijving parameter` |

Een omschrijving van een shared parameter mag zelf een `_` bevatten (`NLRS_C_deur hoogte_min`); de check leest alles na positie 2 als omschrijving.
