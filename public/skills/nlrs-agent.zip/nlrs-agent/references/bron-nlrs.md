# De NLRS-bestanden: herkomst, licentie, bekende gebreken

## Herkomst en licentie

| Repository (github.com/RevitStandards) | Wat de skill eruit gebruikt | Licentie |
|---|---|---|
| NLRS_Revit_Settings | Naamgenerator_NLRS-3.1.1.xlsx, Revit categories_NLRS-3.1.1.xlsx, Assembly Code NL-SfB2021 | geen licentiebestand (stand februari 2026) |
| NLRS_Shared_Parameters | NLRS_Shared Parameters - Totaal.txt en Bronbestand.xlsx | MIT |
| NLRS_IFC_settings | nog niet gebruikt door deze skill | MIT |

Omdat NLRS_Revit_Settings geen licentie heeft, zit er niets uit die repository in deze skill. `ophalen.py` haalt de bestanden bij de bron op en noemt de commit en de datum.

## Hoe de regels uit de Naamgenerator komen

Voor elke sectie bouwt de Naamgenerator een voorbeeld met een formule (`RESULTAAT:`). De skill leest die formule: een opzoeking in een tabel wordt de keuzelijst van die positie, een keuze in de formule (zoals DP of MP) een vaste keuze, een kale cel vrije tekst. Uit de sectietitel komt "positie 3 is altijd TAG" en dergelijke. Als controle bouwt `voorbeeldtoets.py` elk voorbeeld opnieuw op uit de invoer in de Naamgenerator en vergelijkt het met wat de Naamgenerator zelf toont (21 van 21 gelijk), en legt het voorbeeld langs de eigen toets (21 van 21 geslaagd, 5 met een opmerking).

## Bekende gebreken in de bron (stand februari 2026)

1. Vijf tekstbestanden zijn sinds de commit van 25-02-2026 dubbel gecodeerd (UTF-16 bytes die nog eens als UTF-16 zijn opgeslagen): `NLRS_Shared Parameters - Algemeen.txt`, `- Connectors.txt`, `- RVB Bimnorm 1.1.txt`, `NLRS_SP unittypes.txt` en `RSF_NLRS_3.1.1_Assembly Code_NL-SfB2019.txt`. Revit leest ze zo niet goed. De skill herkent en herstelt dit bij het lezen. `Totaal.txt` is in orde.
2. `Algemeen.txt` heeft drie GUID's die elk bij twee parameters staan (relatieve luchtvochtigheid en schoorstand), `Connectors.txt` één (c08 en c09 belastingswaarde). In `Totaal.txt` is dat opgelost.
3. `Algemeen.txt` heeft 68 GUID's die niet in `Totaal.txt` staan, waaronder 39 parameters met status "ingebracht NLRS3.1.1" (kozijn- en deurmaten). Totaal is dus niet het totaal.
4. In de categorielijst is bij 299 van de 453 categorieën de kolom RevitName (`OST_...`) een `#REF!`. De skill zoekt daarom op de naam van de categorie.
5. Keuzelijsten in de Naamgenerator bevatten harde spaties of spaties aan het eind (`bwk`, `C`, `fp`, `mm`). Daardoor hebben vijf voorbeelden een spatie in de naam (3.2.8, 3.5, 3.6, 8.1).
6. Het voorbeeld van 3.2.6 Line Style bevat de instructie zelf: `NLRS_Doors_Frame-Mullion (vervang / door -)_rsf`.
7. Het voorbeeld van 3.2.5 Filled Patterns heeft een dubbel `__` omdat de optionele afmeting leeg is.
8. Het voorbeeld van 3.1 System Families combineert een luchtrooster (`AIR`) met "metselwerk 100mm" en bodemvoorzieningen (11); het voorbeeld van 3.2.2 Profile families is een deur. Op het tabblad met afkortingen staan andere voorbeelden dan op het tabblad VOL.
9. De keuzelijst `<pos2>` kent geen `00` en geen `51`, en schrijft hoofdgroepen als `5-`. De publieke Onderwijsmodellen gebruiken `00`, `50`, `60` en `51`, en `WPB` als host type.
10. Het tabblad met de RESULTAAT-regels heet `VOL_Naamgeving Objecten (3.1.1)`; het tabblad `Naamgeving Objecten (3.1.1)` heeft alleen de afkortingen, zonder RESULTAAT.
