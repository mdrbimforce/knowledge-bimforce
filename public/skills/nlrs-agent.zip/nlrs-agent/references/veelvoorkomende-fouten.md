# Veelvoorkomende afwijkingen

Gezien bij een proefronde op elf modellen (november 2026). Per afwijking: wat je ziet, waarom het afwijkt, wat je doet.

| Wat je ziet | Waarom het afwijkt | Wat je doet |
|---|---|---|
| Standaardnamen van Revit: `Generic - 200mm`, `Floor 1`, `Default`, `Diagonal crosshatch` | Geen NLRS-opbouw | Hernoemen; de check stelt een naam voor met `<plaatshouders>` voor wat hij niet kan weten. Bij line patterns en line styles mag de standaard van Revit blijven. |
| `00`, `50`, `60` of `XX` op positie 2 | De keuzelijst van de NLRS kent alleen codes uit NL-SfB tabel 1 en hoofdgroepen als `5-`, `6-`. `00` en `X0` staan er niet in. | Een echte code kiezen, of de afspraak vastleggen als bewuste afwijking. |
| `51` op positie 2 | Staat in NL-SfB tabel 1 maar niet in de keuzelijst `<pos2>` van de Naamgenerator | Kies een code uit de lijst, of leg de afwijking vast. |
| `WPB` op positie 4 (host type) | `WPB` is een attribuutcode (work plane based) uit `<pos5>`; de host types staan in `<pos4>` | Host type kiezen uit `<pos4>` (vaak `UN` of `FB`), en `-WPB` achter de omschrijving zetten. |
| Een `_` in de omschrijving: `kast_hoog`, `waalformaat_210x100x50` | `_` scheidt posities | Vervangen door een spatie; het voorstel doet dat. |
| De verkeerde categoriecode, bijvoorbeeld `DR` voor een deur | De code moet bij de Revit-categorie horen | Het voorstel neemt de code over uit de categorie (zekerheid "zeker"). |
| `nlrs_` in kleine letters | De landcode is `NLRS` | Het voorstel past het aan. |
| Een eigen content- of leveranciersafkorting | De lijsten `<pos6>` en `<pos7>` zijn uit te breiden | Zet de afkorting in `nlrs-uitzonderingen.json` onder `eigen_afkortingen`. |
| Assembly Code leeg of `99.99` | De code moet bestaan in NL-SfB tabel 1 | Vullen; als de naam een NL-SfB-code heeft, stelt de check die voor. |
| Materiaalklasse leeg of `Unassigned` | De klasse stuurt schedules en IFC | Een klasse kiezen. |
| Shared parameter met de NLRS-naam en een andere GUID | Zie parameters.md | Vervangen door de NLRS-parameter. |

## Wat niet te hernoemen is

Sommige namen liggen vast in Revit: `<Solid fill>`, line styles tussen `<>`, en systeemfamilies als `System Panel` of `Rectangular Mullion`. De check slaat ze over.
