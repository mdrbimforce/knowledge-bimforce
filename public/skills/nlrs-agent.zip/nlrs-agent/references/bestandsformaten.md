# Bestandsformaten

## Modelgegevens (`--bewaar-gegevens`, `--uit-bestand`)

Wat de check uit Revit leest, als JSON. Zo kun je controleren zonder Revit, of een model laten controleren door iemand anders.

```json
{
  "formaat": "nlrs-modelgegevens/1",
  "document": {"titel": "Mijn model", "pad": "D:\\Projecten\\Mijn model.rvt"},
  "families":   [{"id": 1001, "naam": "NLRS_32_DO_WB_binnendeur_gen_rsf", "categorie": "Doors", "ost": "OST_Doors"}],
  "types":      [{"id": 2001, "naam": "930x2315", "soort": "loadable", "type_id": "family_symbol",
                  "familie": "NLRS_32_DO_WB_binnendeur_gen_rsf", "familie_id": 1001, "categorie": "Doors",
                  "ost": "OST_Doors", "assembly_code": "32.31"},
                 {"id": 3001, "naam": "NLRS_21_WA_beton 200mm_gen_rsf", "soort": "system", "type_id": "wall_type",
                  "familie": "Basic Wall", "categorie": "Walls", "assembly_code": "21.12"}],
  "materialen": [{"id": 4001, "naam": "NLRS_f4_kalkzandsteen_gen_rsf", "klasse": "Masonry"}],
  "stijlen":    {"fill_patterns": [{"id": 5001, "naam": "..."}], "line_patterns": [], "line_styles": [],
                 "text_note_types": [], "dimension_types": [], "view_family_types": [],
                 "view_templates": [], "view_filters": []},
  "parameters": [{"naam": "NLRS_C_brandwerendheid", "guid": "8fe8f5ce-...", "bron": "binding",
                  "binding": "type", "categorieen": ["Doors"]}],
  "overgeslagen": [{"onderdeel": "...", "reden": "..."}]
}
```

`klasse: null` betekent "niet gelezen" (wordt overgeslagen); `""` betekent leeg.

## Herstelplan (`nlrs-herstelplan.json`, tabblad Herstelplan)

Per actie: `id`, `soort` (`hernoem`, `waarde`, `materiaalklasse`), `element_id`, `huidige_naam`, `nieuwe_naam` of `parameter` + `nieuwe_waarde`, `zekerheid`, `uitvoeren` (true/false, in Excel ja/nee), `opmerking`. Alleen acties met `uitvoeren` en zonder `<plaatshouder>` worden uitgevoerd. De terugdraailijst die `nlrs_herstel.py --uitvoeren` schrijft, heeft hetzelfde formaat.

## Uitzonderingen (`nlrs-uitzonderingen.json`)

Zie SKILL.md, stap 7. De check zoekt het bestand naast het model als Revit het pad van het model doorgeeft, en anders op het pad van `--uitzonderingen`.
