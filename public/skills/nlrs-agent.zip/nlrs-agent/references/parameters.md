# Shared parameters van de NLRS

## Naam

`NLRS_<letter>_<omschrijving>`. De letter zegt voor welke discipline de parameter is (Naamgenerator 8.1, tabblad `<pos2>`):

| Letter | Discipline | Aantal in Totaal.txt |
|---|---|---:|
| C | Common, algemeen | 830 |
| P | Piping, leidingen | 348 |
| E | Electrical | 140 |
| M | HVAC, luchtbehandeling | 117 |
| S | Structural, constructie | 21 |
| B | Energy | 10 |

Acht parameters in Totaal.txt beginnen met `_DEPRECATED_`: die zijn vervallen.

## De GUID is de sleutel

Revit herkent een shared parameter aan zijn GUID. De naam telt voor Revit niet mee. Twee parameters met dezelfde naam en een andere GUID zijn voor Revit twee verschillende parameters. Gevolgen:

- Een parameter die heet als een NLRS-parameter maar een andere GUID heeft (een oude versie of zelf aangemaakt), vult geen NLRS-schedules, tags of IFC-mappings.
- Staat dezelfde naam twee keer in het model met twee GUID's, dan weigert Revit vaak het binden, en filters en schedules kiezen er willekeurig één.
- Een NLRS-GUID met een andere naam is wel de goede parameter; alleen de naam wijkt af.

## Status

`NLRS_Shared Parameters - Bronbestand.xlsx` geeft per parameter een status (definitief, voorstel, ingebracht, DEPRECATED) en bij een vervallen parameter soms een opvolger (kolom GEKOPPELD). De check gebruikt Totaal.txt als lijst van geldige parameters en het Bronbestand voor status, opvolger en de namen uit NLRS 2.5.2.

## Herstellen

Een verkeerde GUID herstel je niet met hernoemen. De gangbare weg in Revit: de NLRS-parameter toevoegen (uit `NLRS_Shared Parameters - Totaal.txt`), de waarden overzetten, de oude parameter verwijderen, en schedules, tags en filters naar de nieuwe parameter laten wijzen. Doe dat eerst in een kopie van het model.
