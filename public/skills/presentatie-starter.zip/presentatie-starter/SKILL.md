---
name: presentatie-starter
description: Maakt een presentatie als één zelfstandig HTML-bestand dat meteen in het gesprek te bekijken en te downloaden is, zonder dat er iets geïnstalleerd hoeft te worden. Claude vraagt eerst naar onderwerp, publiek, duur en de ene boodschap, laat een opzet in kopjes zien en bouwt dan de slides in een rustige zakelijke stijl, met schema's, stappen die één voor één verschijnen, sprekersnotities, een overzicht en afdrukken naar PDF. Gebruik deze skill zodra de gebruiker een presentatie, slides, dia's, een deck, sheets voor een praatje of een diavoorstelling wil maken of aanpassen, of een presentatie wil omzetten naar PDF of PowerPoint, en er geen andere presentatietool is afgesproken.
---

# Presentatie-starter

Met deze skill bouw je samen met de gebruiker een presentatie als **één HTML-bestand**: `presentatie.html`. Alles zit in dat ene bestand (tekst, opmaak, schema's, bediening). Het opent in elke browser, ook zonder internet, en de gebruiker hoeft niets te installeren.

## Voor wie je werkt

De gebruiker is vakman in zijn eigen sector, geen programmeur, en nieuw met Claude. Werk daarom zo:

- **Gewone taal.** Zeg "het bestand van de presentatie", niet "het HTML-document". Leg een vakterm in één zin uit als hij nodig is.
- **Eén stap tegelijk.** Zeg kort wat je gaat doen, doe het, en zeg dan wat er te zien is.
- **Zelf uitvoeren.** Jij schrijft en bewerkt het bestand. Vraag de gebruiker nooit code te plakken of te bewerken.
- **Na elke stap: wat is er te zien.** Bijvoorbeeld: "De presentatie staat hiernaast. Je ziet de titelslide. Klik op de rechterhelft voor de volgende."

---

## Stap 1. Eerst de inhoud: boodschap, publiek, opzet

Begin niet met slides. Vraag eerst, in één bericht, kort:

1. **Waar gaat het over?** Het onderwerp in een paar woorden.
2. **Wie zit er in de zaal?** Vakgenoten, opdrachtgevers, directie, studenten? Wat weten ze al?
3. **Hoe lang duurt het?** Reken grofweg één à twee minuten per slide.
4. **Wat moet de zaal na afloop onthouden of doen?** Eén zin. Dat is de boodschap.

Vraag ook of er al materiaal is (aantekeningen, een oude presentatie, foto's) en of er een huisstijl is (kleuren, logo).

Maak dan een **opzet in kopjes**: per slide één regel met de kernzin. Bijvoorbeeld:

```
1. Titel: ...
2. Het probleem: ...
3. Wat we zagen: ...
4. ...
7. Afsluiting: de boodschap nog één keer
```

Leg de opzet voor en **wacht op akkoord** voordat je slides bouwt. Pas hem aan zo vaak als de gebruiker wil.

### Regels voor goede slides

- **Eén idee per slide.** Past het niet in één kernzin, dan zijn het twee slides.
- **Weinig tekst.** Hooguit drie à vier punten van een korte regel. De spreker vertelt de rest.
- **Een beeld waar het kan.** Een schema, een drieluik of een groot getal blijft beter hangen dan een lijst. Beeldideeën: `references/verhaalpatronen.md`.
- **Schema's als inline SVG**, met per onderdeel een stap. Sjabloon en vuistregels: `references/svg-schemas.md`.
- **Kopjes zeggen wat er is**, niet wat er niet is.
- **Namen van klanten, collega's of projecten** alleen met akkoord van de gebruiker.
- **Beweer niets wat de gebruiker niet kan onderbouwen.** Twijfel je over een getal of claim, vraag het.
- **Sprekersnotities bij elke slide**: een paar zinnen die de spreker helpen vertellen.

---

## Stap 2. Het bestand bouwen

1. **Kopieer** `assets/deck-sjabloon.html` (in de map van deze skill) naar een nieuw bestand `presentatie.html`. Kopieer het bestand echt; typ het niet over uit je hoofd.
2. **Zet de titel** in `<title>` bovenaan.
3. **Vul de slides** tussen de commentaarregels `SLIDES BEGIN` en `SLIDES EINDE`. Het sjabloon heeft voorbeelden voor elk soort slide. Kopieer het voorbeeld dat past, vervang de tekst, en haal voorbeelden weg die je niet gebruikt.
4. **Raak de motor niet aan**: alles tussen `MOTOR BEGIN` en `MOTOR EINDE` blijft zoals het is.
5. **Controleer** als je opdrachten kunt draaien: `python scripts/controleer-deck.py presentatie.html` (Python 3, geen extra pakketten). Los elke FOUT op, beoordeel elke LET OP. Kun je geen opdrachten draaien, loop dan zelf de lijst onder *Controle zonder script* na.

### Bouwstenen

| Soort slide | Hoe |
|---|---|
| Titelslide | `<section class="slide titel">` met `h1`, `p.ondertitel`, `p.spreker` |
| Gewone slide | `<section class="slide">` met een `h2` als kop |
| Genummerde punten | `<ol class="punten">` met per punt `<li><b>Kort</b><span>uitleg</span></li>` |
| Kolommen, drieluik | `<div class="kolommen">` (drie) of `class="kolommen twee"`, met `<div class="paneel">` |
| Schema | `<svg class="schema" viewBox="...">` na de `h2`; vult de rest van de slide |
| Citaat | `<section class="slide citaat">` met `blockquote` en `p.bron` |
| Groot getal | `<section class="slide getal">` met `p.groot-getal` en `p.toelichting` |
| Afsluiting | `<section class="slide slot">` met `h2` en een paar `p` |
| Eén voor één tonen | `class="stap"` op een `li`, `div` of SVG-`g` |
| Sprekersnotities | `<aside class="notities"><p>...</p></aside>` als laatste in de slide |
| Kleine tekst, accent | `class="zacht"`, `class="klein"`, `class="nadruk"` |

**Alles moet in het bestand zelf zitten.** Geen links naar lettertypen, scripts, stylesheets of afbeeldingen op internet: in het gesprek worden die vaak tegengehouden, en zonder internet vallen ze weg. Een foto of logo gaat er als data-URI in (zie `references/verhaalpatronen.md`, patroon 4).

**Lettergrootte** komt uit de variabelen bovenaan. Zet geen vaste pixelmaten op tekst in de slides; dan schaalt de tekst niet meer mee met het venster.

### Sprekersnotities zijn van de spreker

- Schrijf bij een **nieuwe** slide gerust een eerste voorzet.
- Heeft de gebruiker een notitie **zelf geschreven of aangepast**: nooit overschrijven. Wil je iets voorstellen, zet het in een eigen `<p>` erboven, beginnend met `VOORSTEL:`. De gebruiker beslist.

### Controle zonder script

- Elke slide begint met `<section class="slide` en eindigt met `</section>`.
- Geen `http://` of `https://` in `src`, `href` of `url(...)`.
- Elke `id` komt maar één keer voor in het hele bestand (let op `<marker id>` in schema's).
- Hooguit vier punten en ongeveer veertig woorden per slide, notities niet meegeteld.
- Het stuk tussen `MOTOR BEGIN` en `MOTOR EINDE` is gelijk aan het sjabloon.

---

## Stap 3. Het bestand opleveren

Doel: de gebruiker **ziet** de presentatie in het gesprek en kan het bestand **downloaden**.

- Bewaar `presentatie.html` op de plek waar jouw omgeving bestanden aan de gebruiker geeft (de uitvoermap van het gesprek, of de map waarin de gebruiker werkt).
- Kan jouw omgeving een HTML-bestand in het gesprek tonen (als voorbeeld, artifact of in een zijpaneel), laat het dan zo zien. Toon altijd het **hele** bestand, nooit een deel.
- Geef het bestand ook als download, of zeg waar het staat.
- Kan het niet getoond worden, zeg dat dan eerlijk en leg uit: "Download het bestand en dubbelklik erop. Het opent in je browser."

Zeg daarna wat er te zien is en hoe je doorklikt:

> De presentatie heeft 7 slides. Klik op de rechterhelft of druk op → voor de volgende, links of ← voor de vorige. Met O zie je alle slides tegelijk.

Volledig scherm (F) werkt in het gesprek soms niet; in het gedownloade bestand wel.

---

## Stap 4. Bijsturen

De gebruiker vraagt wijzigingen: andere tekst, een slide erbij, een andere volgorde, eigen kleuren.

- **Werk steeds hetzelfde bestand bij**, `presentatie.html`. Maak geen nieuwe bestanden per versie, tenzij de gebruiker dat vraagt.
- Lees bij het verplaatsen of tussenvoegen van slides eerst het hele bestand, en tel de slides vóór en na de wijziging.
- **Huisstijl**: pas alleen de variabelen onder `HUISSTIJL` bovenaan aan. Vraag de kleurcode, of laat de gebruiker een website of logo aanwijzen en stel een kleur voor. Houd het bij één accentkleur en één letter.
- **Logo**: als inline SVG of als data-URI in een `<img>`, op de titelslide.
- Lever na elke wijziging opnieuw op zoals in stap 3, en zeg in één zin wat er veranderd is.
- Iets werkt niet zoals verwacht: `references/bekende-problemen.md`.

---

## Stap 5. Presenteren en bewaren

Leg de gebruiker uit, in gewone woorden:

1. **Downloaden** en het bestand bewaren waar hij het terugvindt.
2. **Openen**: dubbelklik op `presentatie.html`. Het opent in de browser (Edge, Chrome of een andere). Internet is niet nodig.
3. **Bediening:**

| Toets of handeling | Wat |
|---|---|
| → , spatiebalk, Page Down, klik rechterhelft | volgende stap of slide |
| ← , Page Up, klik linkerhelft | vorige stap of slide |
| Home / End | eerste / laatste slide |
| F | volledig scherm aan of uit |
| O | overzicht van alle slides; klik op een slide om erheen te gaan (Esc sluit) |
| N | sprekersnotities aan of uit |
| vegen (tablet, telefoon) | naar links: verder, naar rechts: terug |

4. **Let op bij een beamer:** de notities verschijnen op hetzelfde scherm als de slides. Zet ze uit met N voordat de zaal meekijkt, of print ze vooraf.
5. **PDF maken:** in de browser Ctrl+P (Afdrukken), kies **Opslaan als PDF**. De pagina's staan al liggend, één slide per pagina, met alle stappen zichtbaar en zonder notities. Zie je geen achtergrondkleuren, zet dan onder *Meer instellingen* **Achtergrondafbeeldingen** aan. Maak de PDF zelf niet voor de gebruiker tenzij je daar het gereedschap voor hebt; deze route werkt altijd.

---

## Stap 6. PowerPoint

Vraagt de gebruiker om een PowerPoint-bestand (.pptx):

- Heb je een eigen functie om PowerPoint-bestanden te maken, bouw de slides dan **opnieuw op** als .pptx, met dezelfde tekst, volgorde en sprekersnotities, en de kleuren uit de huisstijl.
- Zeg eerlijk: "Dit is een nieuwe opbouw in PowerPoint. Hij kan afwijken van het HTML-bestand, vooral bij schema's en stappen. Kijk hem even na." Schema's worden in PowerPoint vormen of een afbeelding; stappen die één voor één verschijnen gaan meestal niet mee.
- Heb je die functie niet, zeg dat dan, en bied aan: de PDF uit stap 5 (die kan in PowerPoint als afbeelding per slide), of de tekst en notities per slide om zelf in PowerPoint te plakken.
- Het HTML-bestand blijft de bron. Wijzigingen eerst daar, daarna zo nodig opnieuw naar PowerPoint.

---

## Naslag

- `assets/deck-sjabloon.html`: het sjabloon, met voorbeelden van elk soort slide.
- `references/verhaalpatronen.md`: vijf beeldpatronen voor slides (drieluik, zoek de verschillen, netwerkschema, uitgelicht in een afbeelding, poppetjesscène).
- `references/svg-schemas.md`: schema's als inline SVG, met sjabloon en kleuren.
- `references/bekende-problemen.md`: wat de gebruiker ziet, waarom, en de oplossing.
- `scripts/controleer-deck.py`: controleert `presentatie.html` op losse bronnen, dubbele id's, te veel tekst, ontbrekende notities en een gewijzigde motor.

---

Gemaakt door bimforce (bimforce.com). Deze skill is gedestilleerd uit de lessen die Leja, het kennisgeheugen van bimforce, vastlegde tijdens het bouwen van presentaties.
