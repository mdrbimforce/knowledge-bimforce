#!/usr/bin/env python3
"""Controleer een presentatie die met deck-sjabloon.html is gebouwd.

Gebruik:  python controleer-deck.py presentatie.html

Meldt FOUT voor wat de presentatie breekt en LET OP voor wat de zaal
merkt (te veel tekst, geen notities). Alleen standaardbibliotheek.
Uitgang: 0 zonder FOUT, 1 met FOUT, 2 als het bestand niet te lezen is.
"""
import os
import re
import sys
from html.parser import HTMLParser

MAX_WOORDEN = 45
MAX_PUNTEN = 4
MOTOR = re.compile(r"MOTOR BEGIN.*?MOTOR EINDE", re.S)


class Lezer(HTMLParser):
    """Verzamelt per slide de zichtbare woorden, punten, stappen en notities."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.slides = []
        self.ids = {}
        self.extern = []
        self.diepte_slide = 0
        self.in_notities = 0
        self.in_svg = 0
        self.in_onzichtbaar = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        klassen = (a.get("class") or "").split()
        regel = self.getpos()[0]
        if "id" in a and a["id"]:
            self.ids.setdefault(a["id"], []).append(regel)
        for naam in ("src", "href", "xlink:href", "poster"):
            waarde = (a.get(naam) or "").strip()
            if re.match(r"(?i)(https?:)?//", waarde) and not (tag == "a" and naam == "href"):
                self.extern.append((regel, f"<{tag} {naam}=\"{waarde[:60]}\">"))
        if tag == "link" and "stylesheet" in (a.get("rel") or ""):
            self.extern.append((regel, "<link rel=stylesheet>"))
        if tag == "section" and "slide" in klassen:
            self.slides.append({"regel": regel, "woorden": 0, "punten": 0, "stappen": 0,
                                "notities": False, "kop": False,
                                "soort": set(klassen)})
            self.diepte_slide = 1
            return
        if not self.diepte_slide:
            return
        if tag not in ("br", "img", "hr", "meta", "input", "path", "rect", "line",
                       "circle", "ellipse", "polyline", "polygon", "stop", "use"):
            self.diepte_slide += 1
        s = self.slides[-1]
        if "stap" in klassen:
            s["stappen"] += 1
        if tag == "aside" and "notities" in klassen:
            s["notities"] = True
            self.in_notities = self.diepte_slide
        if tag in ("h1", "h2"):
            s["kop"] = True
        if tag == "li" and not self.in_notities:
            s["punten"] += 1
        if tag == "svg" and not self.in_svg:
            self.in_svg = self.diepte_slide
        if tag in ("style", "script"):
            self.in_onzichtbaar = self.diepte_slide

    def handle_startendtag(self, tag, attrs):
        # <tag ... /> : openen en meteen sluiten
        voor = self.diepte_slide
        self.handle_starttag(tag, attrs)
        if voor and self.diepte_slide > voor:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if not self.diepte_slide:
            return
        if tag in ("br", "img", "hr", "meta", "input", "path", "rect", "line",
                   "circle", "ellipse", "polyline", "polygon", "stop", "use"):
            return
        if self.in_notities == self.diepte_slide:
            self.in_notities = 0
        if self.in_svg == self.diepte_slide:
            self.in_svg = 0
        if self.in_onzichtbaar == self.diepte_slide:
            self.in_onzichtbaar = 0
        self.diepte_slide -= 1

    def handle_data(self, data):
        if self.diepte_slide and not self.in_notities and not self.in_onzichtbaar and not self.in_svg:
            self.slides[-1]["woorden"] += len(data.split())


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    pad = sys.argv[1]
    try:
        with open(pad, encoding="utf-8") as f:
            tekst = f.read()
    except (OSError, UnicodeDecodeError) as e:
        print(f"FOUT: kan {pad} niet lezen: {e}")
        return 2

    fouten, letop = [], []

    if not tekst.lstrip().lower().startswith("<!doctype html"):
        fouten.append("Het bestand begint niet met <!doctype html>.")
    if not re.search(r'<meta\s+charset="?utf-8', tekst, re.I):
        fouten.append('<meta charset="utf-8"> ontbreekt: letters als é en ë worden dan onleesbaar.')

    for patroon, uitleg in (
        (r"@import", "@import in de opmaak (laadt iets van buiten)"),
        (r"url\(\s*['\"]?(https?:)?//", "url(...) naar internet in de opmaak"),
        (r"<script[^>]+src=", "<script src=...> (los script)"),
        (r"\blocalStorage\b|\bsessionStorage\b", "localStorage of sessionStorage (werkt niet in een afgeschermd venster)"),
        (r"\b(alert|confirm|prompt)\s*\(", "alert, confirm of prompt (geblokkeerd in een afgeschermd venster)"),
        (r"window\.print\s*\(", "window.print() (afdrukken gaat via Ctrl+P)"),
    ):
        for m in re.finditer(patroon, tekst):
            fouten.append(f"Regel {tekst.count(chr(10), 0, m.start()) + 1}: {uitleg}.")

    lezer = Lezer()
    lezer.feed(tekst)

    for regel, wat in lezer.extern:
        fouten.append(f"Regel {regel}: {wat} verwijst naar internet. Zet het in het bestand zelf.")
    for naam, regels in sorted(lezer.ids.items()):
        if len(regels) > 1:
            fouten.append(f"id \"{naam}\" komt {len(regels)} keer voor (regels {', '.join(map(str, regels))}). "
                          "Geef elke id een eigen naam, bv. pijl-s3.")

    if not lezer.slides:
        fouten.append('Geen enkele <section class="slide"> gevonden.')

    for nr, s in enumerate(lezer.slides, start=1):
        waar = f"Slide {nr} (regel {s['regel']})"
        if s["woorden"] > MAX_WOORDEN:
            letop.append(f"{waar}: {s['woorden']} woorden. Hooguit ongeveer {MAX_WOORDEN}; de rest hoort in de notities.")
        if s["punten"] > MAX_PUNTEN:
            letop.append(f"{waar}: {s['punten']} punten. Hooguit {MAX_PUNTEN}, of verdeel over twee slides.")
        if not s["notities"]:
            letop.append(f"{waar}: geen sprekersnotities (<aside class=\"notities\">).")
        if not s["kop"] and not s["soort"] & {"citaat", "getal"}:
            letop.append(f"{waar}: geen kop (h1 of h2).")

    motor = MOTOR.search(tekst)
    if not motor:
        fouten.append("Het stuk tussen MOTOR BEGIN en MOTOR EINDE ontbreekt. Kopieer het uit het sjabloon.")
    else:
        sjabloon = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "deck-sjabloon.html")
        try:
            with open(sjabloon, encoding="utf-8") as f:
                origineel = MOTOR.search(f.read())
            if origineel and " ".join(origineel.group(0).split()) != " ".join(motor.group(0).split()):
                fouten.append("De motor (tussen MOTOR BEGIN en MOTOR EINDE) wijkt af van het sjabloon. Zet hem terug.")
        except OSError:
            letop.append("Sjabloon niet gevonden; de motor is niet vergeleken.")

    stappen = sum(s["stappen"] for s in lezer.slides)
    print(f"{pad}: {len(lezer.slides)} slides, {stappen} stappen, {len(tekst) // 1024} kB")
    for f in fouten:
        print("FOUT:   " + f)
    for l in letop:
        print("LET OP: " + l)
    if not fouten and not letop:
        print("Alles in orde.")
    if len(tekst) > 5 * 1024 * 1024:
        print("LET OP: het bestand is groter dan 5 MB; verklein de afbeeldingen.")
    return 1 if fouten else 0


if __name__ == "__main__":
    sys.exit(main())
