# Verhaalpatronen voor slides

Vijf beeldpatronen die in de praktijk goed werken. Elk patroon heeft een eigen volgorde van stappen. Kies per slide **één** patroon: twee mechanieken op één slide is te veel voor de zaal.

Alles wat een voor een moet verschijnen krijgt `class="stap"`. De stappen verschijnen in de volgorde waarin ze in het bestand staan.

---

## 1. Drieluik (strip in drie panelen)

**Waarvoor:** een verloop in drie stappen. Probleem, twijfel, oplossing. Vroeger, nu, straks. Handmatig, half, automatisch.

**Opbouw:** drie panelen naast elkaar, elk met een klein beeld en één zin eronder.

**Stappen:** paneel 1, paneel 2, paneel 3, en eventueel een conclusie eronder.

```html
<section class="slide">
  <h2>Van losse lijsten naar één bron</h2>
  <div class="kolommen">
    <div class="paneel stap">
      <svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="10" width="36" height="50" rx="4" fill="#fff" stroke="#334155" stroke-width="3"/><rect x="64" y="20" width="36" height="50" rx="4" fill="#fff" stroke="#334155" stroke-width="3"/></svg>
      <p>Alles staat in losse lijsten.</p>
    </div>
    <div class="paneel stap">
      <svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><circle cx="55" cy="38" r="22" fill="none" stroke="#92400e" stroke-width="5"/><line x1="71" y1="54" x2="95" y2="74" stroke="#92400e" stroke-width="6" stroke-linecap="round"/></svg>
      <p>Niemand weet welke lijst klopt.</p>
    </div>
    <div class="paneel stap">
      <svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><polyline points="30,42 52,62 92,18" fill="none" stroke="#15803d" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <p>Eén lijst, door iedereen bijgehouden.</p>
    </div>
  </div>
  <aside class="notities"><p>Vertel per paneel een voorbeeld uit de praktijk.</p></aside>
</section>
```

Een emoji in plaats van een tekeningetje kan ook, maar ziet er op elke computer anders uit. Een eenvoudige SVG oogt rustiger.

---

## 2. Zoek de verschillen

**Waarvoor:** een voor-en-na-vergelijking waarbij de zaal zelf moet zoeken, in plaats van alleen te kijken. Twee tekeningen of documenten die op het oog gelijk lijken.

**Opbouw:** `<div class="kolommen twee">` met twee beelden. Per verschil een cirkel op de plek (in een SVG over het beeld, zie patroon 4), en een korte uitleg eronder.

**Stappen:** de beelden staan er meteen (zonder `stap`). Daarna per verschil een `<g class="stap">` met de cirkel én een `<p class="stap">` met de uitleg. Eerdere stappen blijven zichtbaar als de volgende verschijnt, dus de zaal ziet aan het eind alle verschillen tegelijk.

Let op de volgorde: de stappen verschijnen in de volgorde van het bestand. Staat de cirkel in de SVG boven en de uitleg in een lijst eronder, dan komen eerst alle cirkels en dan alle uitleg. Wil je cirkel en uitleg samen, zet de uitleg dan als `<text>` in dezelfde `<g class="stap">` als de cirkel.

---

## 3. Netwerkschema

**Waarvoor:** iets wat uit onderdelen en verbanden bestaat: een organisatie, een keten van partijen, een installatie met componenten. Een opsomming laat de verbanden niet zien, een schema wel.

**Opbouw:** inline SVG met vakken of ellipsen en pijlen. Sjabloon in `svg-schemas.md`.

**Stappen:** eerst de onderdelen in de volgorde van het verhaal, dan de verbanden. Bij een groot schema: per stap een groepje van drie of vier onderdelen.

---

## 4. Uitgelicht in een afbeelding

**Waarvoor:** een foto, tekening of schermafbeelding met veel details, waarvan je per stap één gebied wilt toelichten.

**Opbouw:** de afbeelding op de slide, met een SVG eroverheen in dezelfde verhouding. Per stap een half doorzichtige rechthoek op het gebied.

**De afbeelding moet in het bestand zelf zitten**, als data-URI: de afbeelding omgezet naar tekst. Kun je opdrachten draaien, doe het zo (Python, standaardbibliotheek):

```python
import base64
data = base64.b64encode(open("foto.jpg", "rb").read()).decode()
print("data:image/jpeg;base64," + data[:40] + "...")   # gebruik de hele tekst in src
```

Houd de foto klein: liefst onder 300 kB en hooguit zo'n 1600 pixels breed. Elke foto maakt het bestand een derde groter dan de foto zelf, en een heel groot bestand opent traag of wordt in het gesprek niet getoond. Is de foto groter, vraag de gebruiker een kleinere versie, of verklein hem als je daar het gereedschap voor hebt.

```html
<section class="slide">
  <h2>Hier zit het probleem</h2>
  <div style="position: relative; flex: 1 1 0; min-height: 0;">
    <img src="data:image/jpeg;base64,..." alt="Foto van de installatie" style="width: 100%; height: 100%;">
    <svg viewBox="0 0 1600 900" style="position: absolute; inset: 0; width: 100%; height: 100%;" xmlns="http://www.w3.org/2000/svg">
      <g class="stap">
        <rect x="200" y="150" width="400" height="250" rx="10" fill="#fef3c7" fill-opacity="0.4" stroke="#92400e" stroke-width="6"/>
      </g>
      <g class="stap">
        <rect x="900" y="500" width="450" height="300" rx="10" fill="#fef3c7" fill-opacity="0.4" stroke="#92400e" stroke-width="6"/>
      </g>
    </svg>
  </div>
  <aside class="notities"><p>Eerst het overzicht, dan per stap het detail.</p></aside>
</section>
```

Zet de `viewBox` gelijk aan de pixelmaat van de afbeelding (hier 1600 bij 900), dan kloppen de coördinaten met wat je in een tekenprogramma meet. Heeft de afbeelding een andere verhouding dan het vlak, dan schuiven beeld en rechthoeken op dezelfde manier mee (beide worden gecentreerd ingepast).

Staan er namen, adressen of andere gegevens van derden in een schermafbeelding: maak ze onleesbaar voordat de afbeelding in het bestand gaat.

---

## 5. Poppetjesscène

**Waarvoor:** de menselijke kant van een technisch verhaal. Een opdrachtgever die iets vraagt, een monteur die zoekt in een stapel tekeningen, iemand die iets uitlegt aan een collega. Zo'n scène is levendiger dan een foto en neutraler dan een cartoon.

**Opbouw:** een eenvoudige SVG met een grondlijn en poppetjes (hoofd als cirkel, lijf en ledematen als lijnen), eventueel met een tekstballon.

**Stappen:** eerst de omgeving, dan de poppetjes in de volgorde van het verhaal, als laatste de tekstballon of het onderschrift.

```html
<svg class="schema" viewBox="0 0 640 220" xmlns="http://www.w3.org/2000/svg">
  <line x1="10" y1="200" x2="630" y2="200" stroke="#334155" stroke-width="2" opacity="0.4"/>
  <g class="stap" stroke="#1e293b" stroke-width="3" stroke-linecap="round" fill="none">
    <circle cx="150" cy="80" r="18"/>
    <line x1="150" y1="98" x2="150" y2="150"/>
    <line x1="150" y1="115" x2="190" y2="95"/>
    <line x1="150" y1="115" x2="120" y2="135"/>
    <line x1="150" y1="150" x2="130" y2="200"/>
    <line x1="150" y1="150" x2="170" y2="200"/>
  </g>
  <g class="stap">
    <rect x="200" y="20" width="180" height="50" rx="10" fill="#ffffff" stroke="#334155" stroke-width="2"/>
    <text x="290" y="52" text-anchor="middle" font-size="20" fill="#1e293b">Waar staat dat?</text>
  </g>
</svg>
```

Houd poppetjes bewust simpel: hoofd met straal 18 tot 20, lijf zo'n 50 tot 60 lang, armen en benen 40 tot 50. Meer detail oogt kinderachtig, minder oogt als een schema.

---

## Combineren

- **Drieluik met poppetjes** (1 + 5): werkt goed, elk paneel een kleine scène.
- **Netwerkschema op een afbeelding** (3 + 4): als het schema op een plattegrond of tekening hoort.
- **Zoek de verschillen op schermafbeeldingen** (2 + 4).
- **Niet:** drieluik én zoek-de-verschillen op één slide. Kies één mechaniek.

## Schrijven voor de slide

- Kopjes zeggen wat er wél is: "Waar dit ophoudt" in plaats van "Wat dit níet is".
- Noem geen klanten of collega's bij naam zonder hun akkoord. "Een woningcorporatie" of "een installateur in het oosten" werkt ook.
- Beweer niets wat je niet kunt onderbouwen als iemand in de zaal ernaar vraagt.
