# Schema's als inline SVG

Een schema schrijf je als SVG direct in de slide: de tekening staat als code in `presentatie.html`. Geen plaatje van internet, geen los bestand, geen tekenbibliotheek.

## Waarom SVG

- **Stap voor stap.** Zet elk onderdeel in een eigen `<g class="stap">`. Dan verschijnt het schema in de volgorde van het verhaal.
- **Scherp op elk scherm.** SVG is een tekening, geen foto: hij blijft scherp op een beamer, in een smal venster en in de PDF.
- **Alles in één bestand.** Niets om te verliezen of mee te sturen.

## Sjabloon: drie vakken met pijlen, één vak per stap

Dit staat ook in het sjabloon (`assets/deck-sjabloon.html`, derde voorbeeldslide).

```html
<section class="slide">
  <h2>Van idee naar presentatie</h2>
  <svg class="schema" viewBox="0 0 1200 420" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Drie stappen: opzet, slides, presenteren">
    <defs>
      <marker id="pijl-s3" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
        <path d="M 0 0 L 10 5 L 0 10 z" fill="#475569"/>
      </marker>
    </defs>
    <g class="stap">
      <rect x="20" y="110" width="300" height="140" rx="14" fill="#e0f2fe" stroke="#0369a1" stroke-width="3"/>
      <text x="170" y="192" text-anchor="middle" font-size="34" font-weight="600" fill="#0c4a6e">Opzet</text>
    </g>
    <g class="stap">
      <line x1="328" y1="180" x2="442" y2="180" stroke="#475569" stroke-width="4" marker-end="url(#pijl-s3)"/>
      <rect x="450" y="110" width="300" height="140" rx="14" fill="#f1f5f9" stroke="#334155" stroke-width="3"/>
      <text x="600" y="192" text-anchor="middle" font-size="34" font-weight="600" fill="#1e293b">Slides</text>
    </g>
    <g class="stap">
      <line x1="758" y1="180" x2="872" y2="180" stroke="#475569" stroke-width="4" marker-end="url(#pijl-s3)"/>
      <rect x="880" y="110" width="300" height="140" rx="14" fill="#dcfce7" stroke="#15803d" stroke-width="3"/>
      <text x="1030" y="192" text-anchor="middle" font-size="34" font-weight="600" fill="#14532d">Presenteren</text>
    </g>
  </svg>
  <aside class="notities"><p>Eerst de opzet, dan pas slides.</p></aside>
</section>
```

## Vuistregels

| Onderdeel | Regel | Waarom |
|---|---|---|
| `class="schema"` | Op de `<svg>` die na de `h2` komt | Het schema vult dan de rest van de slide, ook in een smal venster. |
| `viewBox` | Breedte en hoogte van je tekening, bv. `0 0 1200 420` | Het schema schaalt mee. Een brede, lage viewBox past het best onder een kop. |
| Lettergrootte | `font-size="34"` als attribuut op `<text>`, in de maat van de viewBox | Schaalt mee met de tekening. Bij een viewBox van 1200 breed: vakken 30-36, labels 22-26. Kleiner dan 22 is achter in de zaal onleesbaar. |
| Tekst in een vak | Hooguit twee of drie woorden | Een vak met een zin erin wordt een lap tekst in een kader. Uitleg hoort in de notities. |
| Lijndikte | 3 tot 4 bij een viewBox van 1200 breed | Zichtbaar op een groot scherm zonder zwaar te ogen. |
| Pijlpunt | Eén `<marker>` in `<defs>`, verwijzen met `marker-end="url(#...)"` | Eén keer tekenen, overal in dat schema gebruiken. |
| **Id per slide** | **Elke `id` maar één keer in het hele bestand**: `pijl-s3`, `pijl-s5`, ... | Alle slides staan in één bestand. Twee schema's met `id="pijl"` delen dan één pijlpunt, en die verdwijnt zodra de slide waar hij gedefinieerd is niet zichtbaar is. Het controlescript meldt dubbele id's. |
| Stappen | `<g class="stap">` om elk onderdeel, in de volgorde van het verhaal | De zaal ziet wat de spreker op dat moment vertelt, niet de tekening van links naar rechts. |
| Pijl bij een vak | In dezelfde `g` als het vak waar hij naartoe wijst | Dan verschijnt de pijl samen met zijn doel. |
| Uitsnede | Schuif de `viewBox`, niet alle coördinaten | Eén getal aanpassen in plaats van tientallen. |
| Lettertype | Niets opgeven | Het schema neemt de letter van de presentatie over. |

## Rustige kleuren

| Soort vak | Vulling | Rand | Tekst |
|---|---|---|---|
| Begin of bron | `#e0f2fe` | `#0369a1` | `#0c4a6e` |
| Tussenstap | `#f1f5f9` | `#334155` | `#1e293b` |
| Resultaat | `#dcfce7` | `#15803d` | `#14532d` |
| Let op | `#fef3c7` | `#92400e` | `#78350f` |
| Pijlen en labels | n.v.t. | `#475569` | `#475569` |

Past de gebruiker de huisstijl aan, neem de accentkleur dan over in de rand van het vak "Begin of bron", en houd de rest neutraal.

## Een schema bedenken

1. Vraag of schets de volgorde van het verhaal: wat vertelt de spreker eerst, wat daarna.
2. Verdeel de ruimte: vakken op vaste afstanden, bijvoorbeeld kolommen op x = 20, 450, 880 bij een breedte van 300.
3. Schrijf per onderdeel een `<g class="stap">` met `rect` en `text`, per pijl een `line` in de groep van het vak waar hij naartoe wijst.
4. Geef de marker een id met het slidenummer erin.
5. Bekijk de slide en klik hem door. Staat er tekst buiten een vak, maak de tekst korter of het vak breder.
6. Pas de sprekersnotities aan, zodat die de stappen volgen.
