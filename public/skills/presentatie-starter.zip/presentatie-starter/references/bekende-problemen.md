# Bekende problemen en oplossingen

| Wat de gebruiker ziet | Oorzaak | Oplossing |
|---|---|---|
| De toetsen doen niets. | De presentatie heeft de focus niet; de toetsen gaan naar het gesprek of een ander venster. | Eén keer in de presentatie klikken, dan werken de toetsen. |
| F (volledig scherm) doet niets in het gesprek. | Het voorbeeld in het gesprek staat in een afgeschermd venster dat volledig scherm niet toestaat. | Download het bestand, dubbelklik erop, en druk dan op F. |
| Dubbelklik opent het bestand in Kladblok, Word of een andere app. | Windows koppelt `.html` niet aan de browser. | Rechtsklik, *Openen met*, kies Edge of Chrome. |
| Een pijlpunt in een schema ontbreekt. | Twee schema's gebruiken dezelfde `id` voor hun pijlpunt. | Elke `id` een eigen naam geven, bv. `pijl-s3`. Zie `svg-schemas.md`. |
| Tekst valt onder of naast de slide weg. | Te veel tekst op één slide. De slide schaalt mee met het venster, maar de hoeveelheid tekst niet. | Tekst inkorten of over twee slides verdelen. Lettergrootte niet verkleinen. |
| Tekst is in een klein venster piepklein, of juist niet. | Vaste pixelmaten op tekst in een slide. | Geen `px` op tekst in de slides; de maten komen uit de variabelen bovenaan (in `cqw`). |
| De PDF heeft witte slides zonder achtergrondkleur. | De browser drukt achtergronden niet af. | In het afdrukvenster onder *Meer instellingen* **Achtergrondafbeeldingen** aanzetten. |
| De PDF heeft staande pagina's of een slide over twee pagina's. | De browser negeert het paginaformaat van het bestand, of er is een ander papierformaat gekozen. | Afdrukken via Edge of Chrome, *Opslaan als PDF*, marges *Geen* of *Standaard*. Lukt het niet, kies *Liggend*. |
| In de PDF ontbreken stappen of staan de notities erbij. | Een oude versie van het bestand, of de motor onderaan is aangepast. | De motor vergelijken met het sjabloon (`scripts/controleer-deck.py` meldt het). |
| Het bestand is heel groot of opent traag. | Grote foto's als data-URI in het bestand. | Foto's verkleinen tot onder 300 kB. Zie `verhaalpatronen.md`, patroon 4. |
| Een afbeelding of lettertype ontbreekt in het gesprek of zonder internet. | Het bestand verwijst naar iets op internet. | Alles in het bestand zelf zetten: afbeeldingen als data-URI of SVG, systeemletter. |
| De notities zijn op de beamer te zien. | Er is één venster; de notities staan over de slide heen. | N drukken voordat de zaal meekijkt, of de notities vooraf printen. |
| Een mail met het bestand komt niet aan, of de bijlage is geblokkeerd. | Sommige mailprogramma's houden `.html`-bijlagen tegen. | Het bestand eerst inpakken (rechtsklik, *Comprimeren naar zip*), of de PDF sturen. |
| Na een correctie is nog de oude versie te zien. | De browser of het gesprek toont een eerder bestand. | Opnieuw openen, of in de browser Ctrl+F5. Controleer of het juiste bestand is gedownload (geen `presentatie (1).html`). |

## Gedrag van Claude bij grote bestanden

- Slides verplaatsen of tussenvoegen: lees eerst het hele bestand, tel de `<section class="slide` vóór en na de wijziging, en controleer met het script.
- Een presentatie met veel slides blijft één bestand. Werk dan per stuk: lees en wijzig alleen de slides die het betreft, en laat de rest staan.
- Vervang nooit het hele bestand door een nieuwe versie uit je hoofd. Dan raak je wijzigingen kwijt die de gebruiker eerder liet maken.
