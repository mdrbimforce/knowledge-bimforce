---
name: slidev-starter
description: Maakt en beheert presentaties met Slidev (sli.dev) voor iemand die geen programmeur is. Claude controleert of Node.js er staat, zet een nieuw deck op met een rustige zakelijke stijl, schrijft de slides samen met de gebruiker, laat de presentatie zien in de browser en exporteert naar PDF en PowerPoint. Gebruik deze skill zodra de gebruiker een presentatie, slides, een deck, een dia-presentatie, sheets voor een praatje of een Slidev-bestand noemt, een bestaande slides.md wil aanpassen, of een presentatie naar PDF of PowerPoint wil omzetten.
---

# Slidev-starter

Met deze skill bouw je samen met de gebruiker een presentatie in Slidev. De slides staan als tekst in één bestand (`slides.md`), de presentatie draait in de browser, en aan het eind komt er een PDF en een PowerPoint uit.

## Voor wie je werkt

De gebruiker is vakman in zijn eigen sector, geen programmeur, en nieuw met Claude. Werk daarom zo:

- **Gewone taal.** Zeg "de map van de presentatie", niet "de project root". Leg een vakterm in één zin uit als hij nodig is.
- **Eén stap tegelijk.** Zeg kort wat je gaat doen en waarom, doe het, en zeg dan wat er te zien is.
- **Zelf uitvoeren.** Jij draait de opdrachten. Vraag de gebruiker nooit iets in een terminal te typen. Alleen wat jij niet kunt (Node.js installeren, de app herstarten, in de browser kijken) vraag je aan hem, met precies wat hij moet doen.
- **Na elke stap: wat is er te zien.** Bijvoorbeeld: "De presentatie staat nu open in je browser. Je ziet de titelslide. Druk op de spatiebalk voor de volgende."
- **Geen wijzigingen buiten de map van de presentatie**, en nooit beveiligingsinstellingen van Windows aanpassen.

De opdrachten hieronder zijn getest op Windows 11 met Node.js 25.6, npm 11.8, Slidev 53.1.0 en playwright-chromium 1.65.1 (november 2026).

---

## Stap 1. Voorcontrole: staat Node.js erop?

Slidev draait op Node.js. Controleer dat eerst:

```
node --version
npm --version
```

Beoordeel de uitkomst:

| Uitkomst | Wat het betekent | Wat je doet |
|---|---|---|
| `v24.x` of hoger | Goed. | Door naar stap 2. |
| `v22.x`, minimaal `v22.22.0` | Goed. | Door naar stap 2. |
| `v22.x` lager dan 22.22, of `v20` of ouder | Te oud. | Vraag de gebruiker Node.js bij te werken (zie hieronder). |
| "wordt niet herkend" / "not recognized" / "command not found" | Node.js staat er niet op, of de app is na installatie niet herstart. | Zie hieronder. |

Waar die grens vandaan komt: de Slidev-documentatie (https://sli.dev/guide/) vraagt Node.js 22.12.0 of hoger. Het pakket `@slidev/cli` 53.1.0 vraagt zelf 22.22.0 of hoger. Houd de strengste aan: **22.22.0**. Oneven versies (23, 25) werkten in de test, met een waarschuwing van één hulppakket; de LTS-versie is de veilige keus.

**Als Node.js ontbreekt of te oud is**, zeg ongeveer dit:

> Om presentaties te maken heb ik een gratis programma nodig dat Node.js heet. Dat moet je één keer zelf installeren:
> 1. Ga naar https://nodejs.org
> 2. Kies de knop met **LTS** (dat is de stabiele versie) en download het installatieprogramma voor Windows.
> 3. Start het en klik steeds op *Next* tot het klaar is. De standaardinstellingen zijn goed.
> 4. Sluit daarna deze Claude-app helemaal af (ook in het systeemvak rechtsonder) en open hem opnieuw. Anders ziet de app het nieuwe programma niet.
> 5. Zeg me dan dat je terug bent, dan controleer ik het.

Controleer na zijn terugkomst opnieuw met `node --version`.

**PowerShell-melding "uitvoeren van scripts is uitgeschakeld"?** Gebruik dan `npm.cmd` en `npx.cmd` in plaats van `npm` en `npx`. Wijzig niets aan de instellingen van Windows.

---

## Stap 2. Eerst de inhoud: boodschap, zaal, opzet

Begin niet met slides. Vraag eerst, in één bericht, kort:

1. **Wat moet de zaal na afloop onthouden of doen?** Eén zin. Dat is de boodschap.
2. **Wie zit er in de zaal?** Vakgenoten, opdrachtgevers, directie, studenten? Wat weten ze al?
3. **Hoe lang duurt het praatje?** Reken grofweg één à twee minuten per slide.
4. **Is er al materiaal?** Een oude presentatie, aantekeningen, foto's, tekeningen.

Maak dan een **opzet in kopjes**: per slide één regel met de kernzin. Bijvoorbeeld:

```
1. Titel: ...
2. Het probleem: ...
3. Wat we zagen bij ...
4. ...
```

Leg de opzet voor en **wacht op goedkeuring** voordat je slides schrijft. Pas hem aan zo vaak als de gebruiker wil.

Regels voor de inhoud:

- **Eén boodschap per slide.** Past het niet in één kernzin, dan zijn het twee slides.
- **Weinig tekst op de slide.** Hooguit drie à vier punten, liever een beeld of schema. De spreker vertelt de rest.
- **Kopjes zeggen wat er is**, niet wat er niet is.
- **Namen van klanten, collega's of projecten** alleen met akkoord van de gebruiker. Vraag het als je twijfelt.
- **Beweer niets wat de gebruiker niet kan onderbouwen.** Twijfel je over een getal of claim, vraag het.

Voor beeldideeën (drieluik, voor-en-na, schema, uitgelicht detail in een foto, poppetjesscène): zie `references/verhaalpatronen.md`.

### Sprekersnotities zijn van de spreker

Onder elke slide kan een notitie staan tussen `<!--` en `-->`. Die ziet alleen de spreker, in de presentatormodus.

- Schrijf bij een **nieuwe** slide gerust een eerste voorzet voor de notitie.
- Heeft de gebruiker een notitie **zelf geschreven of aangepast**: nooit overschrijven of herschrijven. Wil je iets voorstellen, zet het op een nieuwe regel erboven, beginnend met `VOORSTEL:`. De gebruiker beslist en haalt het voorvoegsel zelf weg.
- Een notitie per klikstap: zet `[click]` voor de regel die bij die klik hoort.

---

## Stap 3. Een nieuw deck opzetten

Gebruik **niet** `npm init slidev` of `npm create slidev`: die stellen vragen in de terminal waar jij niet op kunt antwoorden, en zonder antwoord leveren ze een Engels demo-deck zonder installatie. Schrijf de bestanden zelf; dat is getest en werkt.

1. **Map kiezen.** Stel voor: een nieuwe map in Documenten, bijvoorbeeld `Documenten\Presentaties\<korte-naam>`. Vraag of dat goed is. Gebruik een naam zonder spaties (streepjes mogen).
2. **Drie bestanden schrijven** in die map: `package.json`, `slides.md` en `style.css`. De inhoud staat in `references/startbestanden.md`. Vul `slides.md` met de goedgekeurde opzet uit stap 2.
3. **Slidev installeren**, in de map van de presentatie:

   ```
   npm install @slidev/cli @slidev/theme-default
   ```

   Dit duurt ongeveer een minuut (in de test 52 seconden, ongeveer 670 pakketten). Zeg de gebruiker vooraf dat het even duurt. Waarschuwingen over `EBADENGINE` of `vulnerabilities` zijn normaal; het is gelukt als er `added ... packages` staat. Draai **geen** `npm audit fix --force`.

4. **Controleren:** `npx slidev --version` moet een versienummer geven (in de test `53.1.0`).
5. **De ZBL-controle** (zie stap 5) op `slides.md`.

Zeg daarna: "De presentatie staat klaar in `<map>`. Er zit nu een titelslide en ... slides in. Zal ik hem openen in je browser?"

---

## Stap 4. De presentatie laten zien

Start de dev-server als **achtergrondtaak** (anders blijft je eigen werk hangen), in de map van de presentatie:

```
npx slidev --open
```

- Slidev start in een paar seconden (in de test 4 seconden) en `--open` opent de standaardbrowser.
- Het adres is **http://localhost:3030**. Opent de browser niet vanzelf, geef de gebruiker dat adres.
- Was poort 3030 al bezet, dan kiest Slidev een andere (3031, ...). Lees het adres uit de uitvoer en geef dat door.
- Controleer zelf dat hij draait: een HTTP-verzoek naar het adres moet status 200 geven.

Vertel de gebruiker wat hij kan doen:

| Toets | Wat |
|---|---|
| spatiebalk of → | volgende klikstap of slide |
| ← | vorige klikstap of slide |
| ↓ / ↑ | volgende / vorige slide, klikstappen overslaan |
| `f` | volledig scherm aan/uit |
| `o` | overzicht van alle slides, klik om te springen |
| `g` | naar slide nummer ... |
| Esc | overzicht of volledig scherm sluiten |

**Presentatormodus:** open **http://localhost:3030/presenter** (of de knop in de balk linksonder). Daar ziet de spreker de huidige slide, de volgende, de sprekersnotities en een klok. Advies voor de zaal: de presentatie op het scherm van de beamer, de presentatormodus op de laptop. Doorklikken in het ene venster schuift het andere mee.

**Wijzigingen** in `slides.md` of `style.css` verschijnen vanzelf in de browser zodra je het bestand bewaart. Wijzigingen in het instellingenblok bovenaan vragen een herstart van de dev-server.

**Stoppen:** stop de achtergrondtaak als de gebruiker klaar is met kijken, of uiterlijk aan het eind van de sessie. Laat geen server draaien zonder dat de gebruiker het weet. Lukt stoppen niet, zie `references/bekende-problemen.md`.

---

## Stap 5. Slides schrijven en controleren

Werk per slide of per paar slides, laat het resultaat zien en vraag of het zo goed is.

**De belangrijkste regel (ZBL):** binnen een HTML-blok, een SVG-schema of een klikblok mag **geen lege regel** staan. Een lege regel daar laat een deel van de slide verdwijnen, zonder foutmelding. In de test verdween één vak uit een schema door één lege regel. Uitzondering: bij `<v-clicks>` met een lijst hoort precies één lege regel na de openingstag en één vóór de sluittag. Uitleg met voorbeelden: `references/zbl-regel.md`.

Draai na elke wijziging aan `slides.md`:

```
python scripts/zbl-linter.py "<map van de presentatie>\slides.md"
```

(`scripts/` is de map van deze skill. Staat Python er niet op, controleer dan zelf met de regels uit `zbl-regel.md`, en noem dat.)

Bouwstenen:

- **Punten per klik:** `<v-clicks>` om een lijst (zie `startbestanden.md`).
- **Eén element per klik:** `<div v-click>...</div>`.
- **Schema dat per klik opbouwt:** inline SVG met `<g v-click="1">`, `<g v-click="2">`, ... Geen Mermaid voor klikopbouw. Sjabloon en vuistregels: `references/svg-schemas.md`.
- **Indelingen:** `layout: cover`, `section`, `quote`, `two-cols`, `image-right`, `end` in het blokje bovenaan een slide.
- **Afbeeldingen:** in een map `public/` naast `slides.md`, verwijzen met `/naam.jpg`.

---

## Stap 6. Stijl

Gebruik het standaardthema van Slidev met het kleine stylesheet uit `references/startbestanden.md`: wit vlak, donkere tekst, één rustige accentkleur, een donkere titel- en slotslide, de systeemletter (Segoe UI). Dat oogt zakelijk en leidt niet af.

- Wil de gebruiker eigen kleuren (bijvoorbeeld van zijn bedrijf): pas alleen de drie kleuren bovenaan `style.css` aan. Vraag de kleurcode, of laat hem een logo of website aanwijzen en stel een kleur voor.
- Logo: in `public/`, op de titelslide met een `<img>` (zie `startbestanden.md`).
- Houd het bij één accentkleur en één lettertype. Geen animaties of overgangen buiten `transition: fade`.

---

## Stap 7. Exporteren naar PDF en PowerPoint

Eenmalig de exporthulp installeren in de map van de presentatie (downloadt ook een onzichtbare browser, ruim 100 MB; in de test 22 seconden):

```
npm install -D playwright-chromium
```

Dan, steeds in de map van de presentatie, **één export tegelijk**:

```
npx slidev export --output exports/<naam>
npx slidev export --format pptx --output exports/<naam>
```

- Schrijf `--output` **zonder** `.pdf` of `.pptx`: Slidev zet de extensie er zelf achter.
- De PDF heeft één pagina per slide, met alle klikstappen zichtbaar. Voor een hand-out met elke klikstap apart: `--with-clicks`.
- De PowerPoint heeft standaard **één slide per klikstap**, zodat doorklikken werkt zoals in de browser. Eén slide per Slidev-slide: `--with-clicks false`.
- Elke PowerPoint-slide is een afbeelding: tekst is daar niet te bewerken. Sprekersnotities gaan wel mee. Zeg dit tegen de gebruiker.
- Elke export duurde in de test ongeveer 7 seconden.

Controleer na elke export: het bestand bestaat, is niet leeg, en het aantal pagina's of slides klopt. Zeg dan waar het staat: "De PDF staat in `<map>\exports\<naam>.pdf`."

Meer opties (PNG, alleen bepaalde slides, timeouts) en foutmeldingen: `references/exporteren.md`.

---

## Naslag

- `references/startbestanden.md`: `package.json`, `slides.md` en `style.css` om mee te beginnen.
- `references/zbl-regel.md`: de regel over lege regels, met goed en fout.
- `references/svg-schemas.md`: schema's als inline SVG, met sjabloon.
- `references/verhaalpatronen.md`: vijf beeldpatronen voor slides.
- `references/exporteren.md`: PDF, PowerPoint en PNG, met foutmeldingen.
- `references/bekende-problemen.md`: wat de gebruiker ziet, waarom, en de oplossing.
- `scripts/zbl-linter.py`: controleert `slides.md` op lege regels binnen blokken (Python 3, geen extra pakketten).

Officiële documentatie: https://sli.dev

---

Gemaakt door bimforce (bimforce.com). Deze skill is gedestilleerd uit de lessen die Leja, het kennisgeheugen van bimforce, vastlegde tijdens het bouwen van presentaties.
