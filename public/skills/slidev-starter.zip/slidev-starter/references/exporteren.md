# Exporteren naar PDF, PowerPoint en PNG

Getest op Windows 11 met Slidev 53.1.0 en playwright-chromium 1.65.1 (november 2026). Elke export van een deck van 5 slides duurde ongeveer 7 seconden.

## Eenmalig: de exporthulp installeren

Slidev maakt een export door de slides in een onzichtbare browser te openen en te fotograferen. Die browser zit in het pakket `playwright-chromium`. Installeer het in de map van de presentatie:

```
npm install -D playwright-chromium
```

Dit downloadt ook de browser zelf (ruim 100 MB, duurt een halve minuut tot een paar minuten). Vertel de gebruiker vooraf dat dit eenmalig is.

## De opdrachten

Draai ze in de map van de presentatie. Zet de uitvoer in een eigen map `exports/`.

| Wat | Opdracht | Resultaat |
|---|---|---|
| PDF, één pagina per slide | `npx slidev export --output exports/presentatie` | `exports/presentatie.pdf` |
| PDF, één pagina per klikstap (hand-out) | `npx slidev export --with-clicks --output exports/presentatie-per-klik` | `exports/presentatie-per-klik.pdf` |
| PowerPoint, één slide per klikstap | `npx slidev export --format pptx --output exports/presentatie` | `exports/presentatie.pptx` |
| PowerPoint, één slide per Slidev-slide | `npx slidev export --format pptx --with-clicks false --output exports/presentatie` | `exports/presentatie.pptx` |
| Losse plaatjes (PNG) | `npx slidev export --format png --output exports/png` | `exports/png/1.png`, `2.png`, ... |
| Alleen bepaalde slides | voeg toe: `--range 1,3-5` | alleen die slides |

Gemeten bij het testdeck (5 slides, waarvan twee met drie klikstappen): PDF 5 pagina's, PDF per klik 11 pagina's, PowerPoint standaard 11 slides, PowerPoint met `--with-clicks false` 5 slides.

## Wat je moet weten over de uitvoer

- **PDF zonder `--with-clicks`** toont elke slide in de eindstand: alle klikstappen zijn zichtbaar. Dat is meestal wat je wilt voor een hand-out.
- **PowerPoint: elke slide is een afbeelding.** De tekst is in PowerPoint niet te bewerken of te selecteren. Wie de presentatie in PowerPoint wil aanpassen, past `slides.md` aan en exporteert opnieuw.
- **PowerPoint: klikstappen standaard aan.** Bij `--format pptx` krijgt elke klikstap een eigen slide. Zo werkt het doorklikken in PowerPoint net als in de browser. Wil je één slide per Slidev-slide, gebruik `--with-clicks false`.
- **Sprekersnotities gaan mee** in de PowerPoint, bij elke klikstap opnieuw dezelfde notitie.
- **Schrijf `--output` zonder extensie.** Slidev zet de juiste extensie er zelf achter. In Slidev 53.1.0 ging `--output naam.pptx` ook goed, maar oudere versies maakten daar een map van met de naam `naam.pptx`. Zonder extensie werkt het in beide gevallen.

## Na elke export controleren

1. Kijk of het bestand er staat en niet leeg is (grootte groter dan een paar kB).
2. Tel de pagina's of slides. Klopt het aantal met wat je verwacht?
3. Bekijk de PNG van een slide met een schema of klikopbouw. Ontbreekt er iets, dan is het meestal een lege regel binnen een blok (zie `zbl-regel.md`).

Draai **nooit twee exports tegelijk**. Ze gebruiken dezelfde onzichtbare browser en kunnen elkaars slides fotograferen. Wacht tot de ene klaar is.

## Als de export niet lukt

| Melding | Oplossing |
|---|---|
| `Executable doesn't exist at ...chromium_headless_shell-...` | De browser is niet (volledig) gedownload. Draai in de map van de presentatie `npx playwright install chromium-headless-shell` en probeer opnieuw. |
| `Error: The exporting for Slidev is powered by Playwright, please install it via npm i -D playwright-chromium` | Het pakket ontbreekt nog: `npm install -D playwright-chromium` (getest: daarna werkt de export). |
| Timeout bij een groot deck | Voeg `--timeout 120000` toe. Laadt een slide traag (grote afbeeldingen), voeg ook `--wait 2000` toe. |
| Er ontbreken delen op een slide | Draai de ZBL-linter; bekijk de slide daarna in de browser. |

Alternatief zonder Playwright (niet getest in deze skill): start de dev-server en open in de browser `http://localhost:3030/export`. Slidev 53 heeft daar een export-pagina die via de eigen browser van de gebruiker naar PDF exporteert.
