# Bekende problemen en oplossingen

| Wat de gebruiker ziet | Oorzaak | Oplossing |
|---|---|---|
| Een deel van een slide is weg, of een klikstap doet niets. Geen foutmelding. | Een lege regel binnen een HTML-, SVG- of klikblok. | `python scripts/zbl-linter.py slides.md`, de gemelde lege regel weghalen. Zie `zbl-regel.md`. |
| Alle punten van een lijst staan meteen op de slide in plaats van per klik. | Twee lege regels na `<v-clicks>`, of de lijst staat er niet direct onder. | Precies één lege regel na `<v-clicks>` en één vóór `</v-clicks>`. |
| `Port 3030 is in use` of de presentatie opent op poort 3031. | Er draait nog een dev-server, bijvoorbeeld van een eerdere keer. | De oude stoppen (zie hieronder) of bewust een andere poort kiezen: `npx slidev --port 3031`. |
| Een wijziging in de instellingen bovenaan (`---`-blok) doet niets. | De dev-server leest die instellingen bij het starten. | Dev-server stoppen en opnieuw starten. |
| Na een correctie is de oude versie nog te zien. | De browser bewaart de oude versie. | Pagina helemaal herladen met Ctrl+F5. |
| `npm` of `node` wordt niet herkend. | Node.js is niet geïnstalleerd, of de app is na de installatie niet herstart. | Node.js LTS installeren van https://nodejs.org en de Claude-app helemaal afsluiten en opnieuw openen. |
| In PowerShell: "... kan niet worden geladen omdat het uitvoeren van scripts is uitgeschakeld". | Windows staat PowerShell-scripts niet toe; `npm` en `npx` zijn in PowerShell een script. | `npm.cmd` en `npx.cmd` gebruiken in plaats van `npm` en `npx`. Geen beveiligingsinstellingen van Windows wijzigen. |
| Bij `npm install` waarschuwingen `EBADENGINE` of `vulnerabilities`. | Een onderliggend pakket noemt andere Node-versies, of npm meldt bekende zwakke plekken in hulppakketten. | Zolang de opdracht eindigt met `added ... packages` werkt het. Niet `npm audit fix --force` draaien: dat kan Slidev zelf breken. |
| Export: `Executable doesn't exist at ...chromium...` | De exportbrowser ontbreekt. | `npx playwright install chromium-headless-shell` in de map van de presentatie. Zie `exporteren.md`. |
| Een deck doet het in de ene map wel en in de andere niet, terwijl er niets geïnstalleerd lijkt. | Node zoekt pakketten ook in bovenliggende mappen. Een deck in een submap van een ander deck gebruikt diens `node_modules`. | Zet elk deck in een eigen map naast de andere, niet erin. Installeer in elke deckmap apart. |
| PowerPoint-tekst is niet te bewerken. | Slidev exporteert elke slide als afbeelding. | Zo werkt het. Aanpassen in `slides.md` en opnieuw exporteren. |
| Mermaid-schema verschijnt in één keer, niet per klik. | Mermaid tekent het schema als één geheel. | Omzetten naar inline SVG met `<g v-click>`-groepen. Zie `svg-schemas.md`. |
| Tekst in een SVG is veel te groot of te klein. | `font-size` zonder eenheid. | Altijd `style="font-size:24px"`, met `px`. |
| De slides zien er anders uit zonder internet. | Lettertypen worden van internet geladen. | In de instellingen bovenaan: `fonts:` met `provider: none` en een letter die op de computer staat (zie `startbestanden.md`). |
| `npm init slidev` of `npm create slidev` wacht op een antwoord, of stopt zonder iets te installeren. | Deze opdracht stelt vragen in de terminal ("Install and start it now?"), en Claude kan daar niet op antwoorden. Getest: zonder antwoord zet hij een demo-deck neer (Engelse voorbeeldslides, ander thema, extra mappen) en installeert hij niets. | Niet gebruiken. De drie bestanden zelf schrijven, zoals in `startbestanden.md`, en dan `npm install @slidev/cli @slidev/theme-default`. |

## De dev-server stoppen

Claude start de dev-server als achtergrondtaak. Stoppen kan op twee manieren:

1. De achtergrondtaak stoppen via de app (de taak die Claude startte).
2. Lukt dat niet, het programma op poort 3030 stoppen. In PowerShell:

```
Get-NetTCPConnection -LocalPort 3030 -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

Controleer daarna of de poort vrij is: dezelfde opdracht zonder het stuk na `|` geeft dan niets terug.

## Gedrag van Claude bij grote bestanden

- Een `slides.md` met heel veel slides kan beter in delen: Slidev kan een andere file invoegen met een slide die alleen `src: ./pages/deel2.md` in de instellingen heeft.
- Slides verplaatsen of tussenvoegen: lees eerst het hele bestand, controleer het aantal slides vóór en na de wijziging (in de browser met de toets `o`, het overzicht), en houd een kopie (`slides.md.bak`) tot de gebruiker het resultaat goed vindt.
