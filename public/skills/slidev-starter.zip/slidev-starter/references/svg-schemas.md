# Schema's: inline SVG in plaats van Mermaid

Slidev kan schema's tekenen met Mermaid (een tekstnotatie voor stroomschema's). Dat is handig om snel iets te schetsen. Voor een schema dat **stap voor stap per klik** moet opbouwen, schrijf je het als inline SVG: de tekening staat dan als code direct in `slides.md`.

## Waarom SVG

- **Klik per onderdeel.** Mermaid wordt als één geheel getekend. Per vak of pijl laten verschijnen kan niet. In SVG zet je elk onderdeel in een eigen `<g v-click="N">`-groep.
- **Lettergrootte in de hand.** Mermaid schaalt de letters anders dan de rest van de slide. In SVG bepaal je het zelf.
- **Geen stille tekenfouten.** Een kleine fout in Mermaid-tekst kan het hele schema laten verdwijnen.

Mermaid is prima voor een eerste schets of een eenvoudig schema zonder klikopbouw.

## Sjabloon: drie vakken met pijlen, één stap per klik

Dit sjabloon is getest met Slidev 53.1.0.

```html
<svg viewBox="0 0 900 260" class="schema" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <marker id="pijl" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#475569"/>
    </marker>
  </defs>
  <g v-click="1">
    <rect x="20" y="80" width="220" height="100" rx="12" fill="#e0f2fe" stroke="#0369a1" stroke-width="2"/>
    <text x="130" y="138" text-anchor="middle" style="font-size:24px" fill="#0c4a6e">Stap 1</text>
  </g>
  <g v-click="2">
    <line x1="245" y1="130" x2="335" y2="130" stroke="#475569" stroke-width="3" marker-end="url(#pijl)"/>
    <rect x="340" y="80" width="220" height="100" rx="12" fill="#f1f5f9" stroke="#334155" stroke-width="2"/>
    <text x="450" y="138" text-anchor="middle" style="font-size:24px" fill="#1e293b">Stap 2</text>
  </g>
  <g v-click="3">
    <line x1="565" y1="130" x2="655" y2="130" stroke="#475569" stroke-width="3" marker-end="url(#pijl)"/>
    <rect x="660" y="80" width="220" height="100" rx="12" fill="#dcfce7" stroke="#15803d" stroke-width="2"/>
    <text x="770" y="138" text-anchor="middle" style="font-size:24px" fill="#14532d">Stap 3</text>
  </g>
</svg>
```

## Vuistregels

| Onderdeel | Regel | Waarom |
|---|---|---|
| Lege regels | Geen enkele binnen `<svg>` | Zie `zbl-regel.md`: anders verdwijnt een deel zonder melding. |
| `viewBox` | Breedte en hoogte van je tekening, bv. `0 0 900 260` | Het schema schaalt dan mee met de slide. |
| Lettergrootte | Altijd `style="font-size:24px"`, met `px` | Zonder eenheid schaalt de tekst onvoorspelbaar. |
| Tekstgrootte | Vakken 20-24px, pijllabels 16-18px | Leesbaar achter in de zaal. |
| Lijndikte | 2 tot 3 | Zichtbaar op een groot scherm zonder zwaar te ogen. |
| Pijlpunt | Eén `<marker>` in `<defs>`, verwijzen met `marker-end="url(#pijl)"` | Eén keer tekenen, overal gebruiken. Gebruik per slide een eigen id als er meer schema's in het deck staan. |
| Klikvolgorde | Volg het verhaal van de spreker, niet de tekening van links naar rechts | De zaal ziet wat de spreker op dat moment vertelt. |
| Uitsnede | Schuif de `viewBox`, niet alle coördinaten | Eén getal aanpassen in plaats van tientallen. |

## Rustige kleuren

| Soort vak | Vulling | Rand |
|---|---|---|
| Begin of bron | `#e0f2fe` | `#0369a1` |
| Tussenstap | `#f1f5f9` | `#334155` |
| Resultaat | `#dcfce7` | `#15803d` |
| Let op | `#fef3c7` | `#92400e` |
| Pijlen | n.v.t. | `#475569` |

## Een Mermaid-schets omzetten

1. Laat de Mermaid-schets zien (of teken het schema op papier) en spreek de volgorde af.
2. Verdeel de ruimte: vakken op vaste afstanden, bijvoorbeeld kolommen op x = 20, 340, 660.
3. Schrijf per vak een `<g v-click="N">` met `rect` en `text`, per pijl een `line` (in dezelfde groep als het vak waar hij naartoe wijst, of een eigen groep).
4. Draai de linter.
5. Bekijk de slide in de browser en klik hem door.
6. Pas de klikmarkeringen in de sprekersnotities aan (`[click]`), zodat die gelijk lopen met de schemastappen.
