# Verhaalpatronen voor slides

Vijf beeldpatronen die in de praktijk goed werken. Elk patroon heeft een eigen klikmechaniek. Kies per slide **één** patroon: twee mechanieken op één slide is te veel voor de zaal.

Alle voorbeelden volgen de ZBL-regel (geen lege regels binnen blokken, zie `zbl-regel.md`).

---

## 1. Drieluik (strip in drie panelen)

**Waarvoor:** een verloop in drie stappen. Probleem, twijfel, oplossing. Vroeger, nu, straks. Handmatig, half, automatisch.

**Opbouw:** drie panelen naast elkaar, elk met één beeld of icoon en één zin eronder.

**Klikken:** paneel 1, paneel 2, paneel 3, en eventueel een conclusie eronder.

```html
<div class="grid grid-cols-3 gap-6 mt-8">
<div v-click class="paneel">
  <div class="text-5xl">📋</div>
  <p>Alles staat in losse lijsten.</p>
</div>
<div v-click class="paneel">
  <div class="text-5xl">🔍</div>
  <p>Niemand weet welke lijst klopt.</p>
</div>
<div v-click class="paneel">
  <div class="text-5xl">✅</div>
  <p>Eén lijst, door iedereen bijgehouden.</p>
</div>
</div>
```

Met in `style.css`:

```css
.paneel { border: 2px solid #cbd5e1; border-radius: 12px; padding: 1.5rem; text-align: center; }
```

In plaats van een emoji kan elk paneel ook een kleine SVG-tekening bevatten (zie patroon 5).

---

## 2. Zoek de verschillen

**Waarvoor:** een voor-en-na-vergelijking waarbij de zaal zelf moet zoeken, in plaats van alleen te kijken. Twee tekeningen of documenten die op het oog gelijk lijken.

**Opbouw:** twee beelden naast elkaar. Per verschil verschijnt een cirkel op de plek, met een korte uitleg eronder.

**Klikken:** eerst beide beelden, dan per klik één cirkel met uitleg, aan het eind een samenvatting.

**Let op:** de uitleg moet blijven staan als de volgende cirkel verschijnt. Gebruik daarvoor `v-click` met een vast nummer per regel (`v-click="2"`, `v-click="3"`), zodat eerdere regels zichtbaar blijven en de volgorde vastligt.

---

## 3. Netwerkschema

**Waarvoor:** iets wat uit onderdelen en verbanden bestaat: een organisatie, een keten van partijen, een installatie met componenten. Een opsomming laat de verbanden niet zien, een schema wel.

**Opbouw:** inline SVG met vakken of ellipsen en pijlen (sjabloon in `svg-schemas.md`).

**Klikken:** eerst de onderdelen in de volgorde van het verhaal, dan de verbanden. Bij een groot schema: per klik een groepje van drie of vier onderdelen.

---

## 4. Uitgelicht in een afbeelding

**Waarvoor:** een foto, tekening of schermafbeelding met veel details, waarvan je per klik één gebied wilt toelichten.

**Opbouw:** de afbeelding op de slide, met een SVG eroverheen in dezelfde verhouding. Per klik een half doorzichtige rechthoek op het gebied.

```html
<div class="relative">
<img src="/foto.jpg" class="w-full"/>
<svg viewBox="0 0 1600 900" class="absolute inset-0 w-full h-full">
  <g v-click="1">
    <rect x="200" y="150" width="400" height="250" rx="10" fill="#fef3c7" fill-opacity="0.4" stroke="#92400e" stroke-width="4"/>
  </g>
  <g v-click="2">
    <rect x="900" y="500" width="450" height="300" rx="10" fill="#fef3c7" fill-opacity="0.4" stroke="#92400e" stroke-width="4"/>
  </g>
</svg>
</div>
```

Zet de `viewBox` gelijk aan de pixelmaat van de afbeelding (hier 1600 bij 900), dan kloppen de coördinaten met wat je in een tekenprogramma meet. Afbeeldingen horen in de map `public/` naast `slides.md`; je verwijst ernaar met `/naam.jpg`.

Staan er namen, adressen of andere gegevens van derden in een schermafbeelding: maak ze onleesbaar voordat de afbeelding in het deck gaat.

---

## 5. Poppetjesscène

**Waarvoor:** de menselijke kant van een technisch verhaal. Een opdrachtgever die iets vraagt, een monteur die zoekt in een stapel tekeningen, iemand die iets uitlegt aan een collega. Zo'n scène is levendiger dan een foto en neutraler dan een cartoon.

**Opbouw:** een eenvoudige SVG met een grondlijn en poppetjes (hoofd als cirkel, lijf en ledematen als lijnen), eventueel met een tekstballon.

**Klikken:** eerst de omgeving, dan de poppetjes in de volgorde van het verhaal, als laatste de tekstballon of het onderschrift.

```html
<svg viewBox="0 0 640 220" class="w-full" xmlns="http://www.w3.org/2000/svg">
  <line x1="10" y1="200" x2="630" y2="200" stroke="#334155" stroke-width="2" opacity="0.4"/>
  <g v-click="1" stroke="#1e293b" stroke-width="3" stroke-linecap="round" fill="none">
    <circle cx="150" cy="80" r="18"/>
    <line x1="150" y1="98" x2="150" y2="150"/>
    <line x1="150" y1="115" x2="190" y2="95"/>
    <line x1="150" y1="115" x2="120" y2="135"/>
    <line x1="150" y1="150" x2="130" y2="200"/>
    <line x1="150" y1="150" x2="170" y2="200"/>
  </g>
  <g v-click="2">
    <rect x="200" y="20" width="180" height="50" rx="10" fill="#ffffff" stroke="#334155" stroke-width="2"/>
    <text x="290" y="52" text-anchor="middle" style="font-size:20px" fill="#1e293b">Waar staat dat?</text>
  </g>
</svg>
```

Houd poppetjes bewust simpel: hoofd met straal 18 tot 20, lijf zo'n 50 tot 60 lang, armen en benen 40 tot 50. Meer detail oogt kinderachtig, minder oogt als een schema.

---

## Combineren

- **Drieluik met poppetjes** (1 + 5): werkt goed, elk paneel een kleine scène.
- **Netwerkschema op een afbeelding** (3 + 4): als het schema op een plattegrond of tekening hoort.
- **Zoek de verschillen op schermafbeeldingen** (2 + 4).
- **Niet:** drieluik én zoek-de-verschillen op één slide. Kies één mechaniek.

## Schrijven voor de slide

- Kopjes zeggen wat er wél is: "Waar dit ophoudt" in plaats van "Wat dit níet is".
- Noem geen klanten of collega's bij naam zonder hun akkoord. "Een woningcorporatie" of "een installateur in het oosten" werkt ook.
- Beweer niets wat je niet kunt onderbouwen als iemand in de zaal ernaar vraagt.
