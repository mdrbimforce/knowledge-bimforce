# De ZBL-regel: geen lege regels binnen blokken

ZBL staat voor *Zero Blank Lines*. Het is de belangrijkste regel bij het schrijven van Slidev-slides, omdat een overtreding **zonder foutmelding** misgaat: de slide laadt gewoon, maar een deel ervan is weg of een klikstap doet niets.

## De regel

Binnen een HTML-blok, een SVG-blok of een klikblok staat **geen enkele lege regel** tussen de openingstag en de sluittag. Tussen blokken op het hoogste niveau van de slide zijn lege regels juist wel nodig (zo scheidt Markdown alinea's).

Waarom: Slidev leest een slide als Markdown. Een lege regel betekent voor Markdown "hier eindigt het HTML-blok". Wat erna komt, wordt als gewone tekst gelezen, en de rest van het blok valt weg.

Getest met Slidev 53.1.0: één lege regel binnen een `<g v-click>`-groep in een SVG liet die hele groep (een vak met pijl) uit de export verdwijnen. Er kwam geen foutmelding.

## Goed en fout

**Goed: klikbare lijst.** Bij `<v-clicks>` met een Markdown-lijst hoort precies één lege regel na de openingstag en één vóór de sluittag. Dat is de uitzondering: zo herkent Slidev de lijst.

```md
<v-clicks>

- Eerste punt
- Tweede punt
- Derde punt

</v-clicks>
```

**Fout: lege regels in een div.**

```html
<div v-click>

  <h3>Titel</h3>

  <p>Tekst</p>

</div>
```

**Goed:**

```html
<div v-click>
  <h3>Titel</h3>
  <p>Tekst</p>
</div>
```

Inspringen met spaties mag gewoon. Alleen echt lege regels niet.

## Waar het misgaat

| Waar | Wat je ziet |
|---|---|
| `<div v-click>` met een lege regel erin | De inhoud verschijnt niet bij het doorklikken. |
| `<v-clicks>` met twee lege regels na de opening | De punten staan meteen allemaal op de slide, of als losse tekst. |
| `<svg>` of `<g v-click>` met een lege regel erin | Delen van het schema ontbreken, of de klikvolgorde springt. |
| `<table>`, `<ul>` of `<div class="...">` met een lege regel | Rijen of punten ontbreken. |

## Controleren

Na elke wijziging aan de slides draait Claude de linter:

```
python scripts/zbl-linter.py slides.md
```

- `OK: ...` betekent: niets gevonden.
- `LET OP: ...` geeft per overtreding het regelnummer. Haal die lege regel weg en draai de linter opnieuw.

De linter vindt de bekende gevallen, niet elk denkbaar geval. Bekijk een gewijzigde slide daarom ook in de browser en klik hem helemaal door.

## Na een correctie

De browser laat na een wijziging soms nog de oude versie zien. Herlaad de pagina helemaal (Ctrl+F5). Helpt dat niet, herstart dan de dev-server.
