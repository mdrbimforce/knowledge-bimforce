# Startbestanden voor een nieuw deck

Drie bestanden, samen een werkende presentatie met een rustige zakelijke stijl. Getest met Slidev 53.1.0 op Windows 11. Claude schrijft ze in een nieuwe, lege map (bijvoorbeeld `Documenten\Presentaties\<naam>`).

## package.json

Vervang `naam-van-de-presentatie` door een korte naam in kleine letters, zonder spaties (streepjes mogen).

```json
{
  "name": "naam-van-de-presentatie",
  "type": "module",
  "private": true,
  "scripts": {
    "dev": "slidev --open",
    "build": "slidev build",
    "export": "slidev export"
  }
}
```

De pakketten zelf staan er nog niet in: die zet `npm install` er straks bij.

## slides.md

Het eerste blok tussen `---` is de instelling van het hele deck. Daarna volgen de slides, gescheiden door een regel met alleen `---`. Een slide kan bovenaan een eigen instelling hebben (zoals `layout: quote`).

```md
---
theme: default
title: Titel van de presentatie
colorSchema: light
transition: fade
fonts:
  sans: Segoe UI, Arial, Helvetica
  provider: none
layout: cover
class: titel
---

# Titel van de presentatie

Ondertitel in één zin

<div class="ondertitel">Naam spreker · datum</div>

<!--
Sprekersnotitie: wat zeg je bij deze slide?
-->

---

# Drie dingen om te onthouden

<v-clicks>

- **Eerste punt.** Korte toelichting.
- **Tweede punt.** Korte toelichting.
- **Derde punt.** Korte toelichting.

</v-clicks>

<!--
[click] Toelichting bij het eerste punt.
[click] Toelichting bij het tweede punt.
[click] Toelichting bij het derde punt.
-->

---
layout: quote
---

# "Een citaat dat blijft hangen."

Bron van het citaat

---
layout: end
class: titel
---

# Bedankt

Vragen?
```

Toelichting bij de instellingen:

- `theme: default`: het standaardthema van Slidev, rustig en zonder opsmuk.
- `colorSchema: light`: altijd licht, ook als de computer op donkere modus staat.
- `fonts ... provider: none`: gebruik de letters die op de computer staan (Segoe UI op Windows). Zo laadt Slidev geen lettertypen van internet en ziet de presentatie er ook zonder internet hetzelfde uit.
- `layout: cover`, `quote`, `end`: kant-en-klare slide-indelingen. Andere nuttige: `section` (tussentitel), `two-cols` (twee kolommen, scheiden met `::right::`), `image-right` (met `image: /foto.jpg`).

## style.css

Slidev laadt een bestand met de naam `style.css` naast `slides.md` automatisch. Hierin staat de eigen stijl. De kleuren staan bovenaan, zodat ze in één keer aan te passen zijn (bijvoorbeeld naar de kleur van het eigen bedrijf).

```css
:root {
  --kleur-tekst: #1e293b;   /* bijna zwart */
  --kleur-accent: #0369a1;  /* rustig blauw: streep onder kopjes, vetgedrukte woorden */
  --kleur-vlak: #0f172a;    /* donker vlak van titel- en slotslide */
}

.slidev-layout {
  color: var(--kleur-tekst);
  padding: 3rem 4rem;
}

.slidev-layout h1 {
  color: var(--kleur-tekst);
  font-weight: 600;
  font-size: 2.4rem;
  border-bottom: 4px solid var(--kleur-accent);
  padding-bottom: 0.4rem;
  display: inline-block;
}

.slidev-layout li {
  margin: 0.6rem 0;
  font-size: 1.35rem;
}

.slidev-layout strong {
  color: var(--kleur-accent);
}

/* Titel- en slotslide: donker vlak met witte tekst */
.slidev-layout.titel {
  background: var(--kleur-vlak);
  color: #fff;
}
.slidev-layout.titel h1 {
  color: #fff;
  border-bottom-color: #38bdf8;
}
.slidev-layout.titel .ondertitel {
  color: #cbd5e1;
  margin-top: 2rem;
  font-size: 1.1rem;
}

/* Citaatslide */
.slidev-layout.quote h1 {
  border: none;
  font-style: italic;
  font-weight: 400;
}

/* Schema's over de volle breedte */
svg.schema {
  width: 100%;
  margin-top: 2rem;
}
```

Een logo toevoegen: zet het bestand in een map `public/` naast `slides.md` en zet op de titelslide `<img src="/logo.png" class="absolute bottom-10 right-12 h-16"/>`.

## Map na installatie

```
naam-van-de-presentatie\
  package.json
  package-lock.json      (maakt npm zelf)
  slides.md
  style.css
  node_modules\          (maakt npm zelf, niet aankomen)
  public\                (optioneel: afbeeldingen, logo)
  exports\               (maakt de export: PDF, PowerPoint, PNG)
```
