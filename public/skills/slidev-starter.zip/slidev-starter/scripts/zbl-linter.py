#!/usr/bin/env python3
"""ZBL-linter (Zero Blank Lines) voor Slidev-bestanden.

Zoekt lege regels binnen HTML-, SVG- en klikblokken in een Slidev-deck.
Zo'n lege regel breekt de weergave zonder foutmelding: een deel van de
slide verdwijnt of een klikstap werkt niet.

Gebruik:
    python zbl-linter.py slides.md
    python zbl-linter.py slides.md pages/deel2.md

Afsluitcodes:
    0 = niets gevonden
    1 = overtredingen gevonden (met regelnummer)
    2 = bestand niet gevonden of geen bestand opgegeven

Uitleg en oplossingen: references/zbl-regel.md
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path

# Een "lege regel" = een regel met alleen spaties of tabs.
BLANK = r"\n[ \t]*\n"

# Elk patroon: (regex, uitleg). Het eerste deel van de regex blijft binnen
# het blok, zodat een lege regel ná de sluittag niet meetelt.
ZBL_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (
        re.compile(r"<div[^>]*\bv-click[^>]*>[ \t]*" + BLANK),
        "lege regel direct na <div v-click>",
    ),
    (
        re.compile(r"<v-clicks?[^>]*>[ \t]*\n[ \t]*\n[ \t]*\n"),
        "twee of meer lege regels na <v-clicks> (één is goed, twee breekt de lijst)",
    ),
    (
        re.compile(r"<g[^>]*\bv-click[^>]*>(?:(?!</g>)[\s\S])*?" + BLANK),
        "lege regel binnen een <g v-click>-groep in een SVG",
    ),
    (
        re.compile(r"<svg\b(?:(?!</svg>)[\s\S])*?" + BLANK + r"(?:(?!</svg>)[\s\S])*?</svg>"),
        "lege regel binnen een <svg>-blok",
    ),
    (
        re.compile(r"<table[^>]*>(?:(?!</table>)[\s\S])*?" + BLANK + r"(?:(?!</table>)[\s\S])*?</table>"),
        "lege regel binnen een <table>",
    ),
    (
        re.compile(r"<ul[^>]*>(?:(?!</ul>)[\s\S])*?" + BLANK + r"(?:(?!</ul>)[\s\S])*?</ul>"),
        "lege regel binnen een <ul>",
    ),
]


@dataclass
class Violation:
    file: Path
    line: int
    kind: str
    snippet: str


def line_of(content: str, offset: int) -> int:
    return content[:offset].count("\n") + 1


def check_file(path: Path) -> list[Violation]:
    content = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    found: list[Violation] = []
    for pattern, kind in ZBL_PATTERNS:
        for match in pattern.finditer(content):
            # Wijs de eerste lege regel binnen het blok aan, niet de opening.
            blank = re.search(BLANK, match.group(0))
            offset = match.start() + (blank.start() + 1 if blank else 0)
            snippet = match.group(0)[:100].replace("\n", "\\n")
            line = line_of(content, offset)
            # Eén melding per regel, ook als twee patronen hem raken.
            if not any(f.line == line for f in found):
                found.append(Violation(path, line, kind, snippet))
    return found


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(__doc__)
        return 2

    violations: list[Violation] = []
    checked = 0
    for arg in argv[1:]:
        path = Path(arg)
        if not path.exists():
            print(f"FOUT: bestand niet gevonden: {path}", file=sys.stderr)
            return 2
        if not path.is_file():
            continue
        checked += 1
        violations.extend(check_file(path))

    if not violations:
        print(f"OK: {checked} bestand(en) gecontroleerd, geen lege regels binnen blokken.")
        return 0

    print(f"LET OP: {len(violations)} lege regel(s) binnen blokken in {checked} bestand(en):\n")
    for v in sorted(violations, key=lambda x: (str(x.file), x.line)):
        print(f"  {v.file}, regel {v.line}")
        print(f"    wat: {v.kind}")
        print(f"    stuk: {v.snippet}")
        print()
    print("Haal de lege regel weg. Uitleg: references/zbl-regel.md")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
